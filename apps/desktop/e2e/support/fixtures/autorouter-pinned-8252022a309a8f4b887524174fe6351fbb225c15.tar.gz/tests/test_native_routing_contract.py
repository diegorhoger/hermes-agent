"""Contract tests for the native pre-inference routing consumer (issue #104).

Bounded contract fixture: the host does NOT exist in v0.23.1, so these tests
drive the consumer exactly the way a host middleware would — calling
``resolve_consumer_route`` with the same non-secret metadata shape. They prove
the consumer's obligations: capability detection, opt-in gate, session
binding, fail-closed refusal (before any network), per-session profile
pinning, and sanitized receipts.

They do NOT prove end-to-end ordinary-session routing — no host call site
exists to invoke this yet. Acceptance requires the host extension plus a real
Desktop opt-in; see docs/internal/hermes-native-routing-contract.md.
"""
from __future__ import annotations

import json
import os
import sys
import threading
from pathlib import Path

import pytest

os.environ.setdefault("HERMES_DISABLE_LAZY_INSTALLS", "1")

from autorouter.autorouter_core.integration import native_routing  # noqa: E402
from autorouter.autorouter_core.integration import _route_resolution  # noqa: E402
from autorouter.autorouter_core.storage import state as state_mod  # noqa: E402
from autorouter.autorouter_core.routing import router as rt_mod  # noqa: E402

_HERMES_IMPORTABLE = False
try:
    import hermes_cli.middleware  # noqa: F401
    import hermes_cli.plugins  # noqa: F401

    _HERMES_IMPORTABLE = True
except Exception:
    _HERMES_IMPORTABLE = False

requires_hermes = pytest.mark.skipif(not _HERMES_IMPORTABLE, reason="Hermes v0.23.1 not importable")


def _seed_catalog(store, rows):
    """rows: [(provider, model, context_length, capabilities, cost_tier)]"""
    now = 1.0
    expiry = 9999999999.0
    for p, m, ctx, caps, tier in rows:
        store.upsert_catalog(p, m, context_length=ctx, capabilities=caps, cost_tier=tier)
        store.upsert_capability(
            p, m,
            json.dumps({
                "provider": p, "model": m,
                "field_evidence": {
                    "context_window": {"metadata_source": "provider",
                                       "retrieved_at": now, "expires_at": expiry},
                    "tools": {"metadata_source": "provider",
                              "retrieved_at": now, "expires_at": expiry},
                    "cost_tier": {"metadata_source": "provider",
                                  "retrieved_at": now, "expires_at": expiry},
                },
                "context_window": ctx, "tools": caps["tools"],
                "cost_tier": tier, "source": "provider",
            }),
            metadata_source="provider", retrieved_at=now, expires_at=expiry,
        )


@pytest.fixture
def store_dir(tmp_path):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "nvidia-free", 131072, {"tools": "supported"}, "free"),
        ("nvidia", "paid-x", 131072, {"tools": "supported"}, "paid"),
        ("nvidia", "unknown-cost", 131072, {"tools": "supported"}, "unknown"),
        ("openrouter", "qwen/qwen3-coder:free", 262144, {"tools": "supported"}, "free"),
        ("openrouter", "no-tools", 131072, {"tools": "unsupported"}, "free"),
    ])
    return tmp_path / "store"


def _settings(**overrides):
    base = {
        "enabled": True,
        "enable_chat_router": False,
        "enable_native_routing": True,
        "policy": "auto",
        "min_context": 8192,
        "cooldown_seconds": 60,
        "requires_tools": True,
        "free_only": True,
        "providers": ["nvidia", "openrouter"],
        "model_include": [],
        "model_exclude": [],
    }
    base.update(overrides)
    return base


def _patch_hermes_config(monkeypatch, **settings):
    import hermes_cli.config as _hcfg

    merged = _settings(**settings)
    monkeypatch.setattr(_hcfg, "load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": merged}}}})
    return merged


# ---------------------------------------------------------------------------
# Capability detection
# ---------------------------------------------------------------------------

@requires_hermes
def test_detect_reports_unsupported_on_v0_23_1():
    detection = native_routing.detect_host_native_routing()
    assert detection["supported"] is False
    assert detection["signals"] == []
    assert detection["contract_version"] == native_routing.CONTRACT_VERSION
    assert "NOT auto-routed" in detection["reason"]


def test_detect_reports_supported_when_host_exposes_the_contract(monkeypatch):
    import types

    fake_mw = types.ModuleType("hermes_cli.middleware")
    fake_mw.VALID_MIDDLEWARE = {"llm_request", "pre_inference_route"}
    fake_mw.PRE_INFERENCE_ROUTE_MIDDLEWARE = "pre_inference_route"
    fake_mw.apply_pre_inference_route_middleware = lambda metadata, **ctx: None
    fake_hp = types.ModuleType("hermes_cli.plugins")
    fake_hp.VALID_HOOKS = set()
    monkeypatch.setitem(sys.modules, "hermes_cli.middleware", fake_mw)
    monkeypatch.setitem(sys.modules, "hermes_cli.plugins", fake_hp)
    detection = native_routing.detect_host_native_routing()
    assert detection["supported"] is True
    assert detection["signals"]


def test_detect_observer_hook_name_alone_cannot_enable_native_routing(monkeypatch):
    """A declared observer hook cannot replace a pre-construction route seam."""
    import types

    fake_mw = types.ModuleType("hermes_cli.middleware")
    fake_mw.VALID_MIDDLEWARE = {"llm_request"}
    fake_hp = types.ModuleType("hermes_cli.plugins")
    fake_hp.VALID_HOOKS = {"pre_inference_route"}
    monkeypatch.setitem(sys.modules, "hermes_cli.middleware", fake_mw)
    monkeypatch.setitem(sys.modules, "hermes_cli.plugins", fake_hp)

    detection = native_routing.detect_host_native_routing()
    assert detection["supported"] is False
    assert "NOT auto-routed" in detection["reason"]
    assert any("observer name alone" in signal for signal in detection["signals"])


def test_detect_marker_without_callable_and_hook_name_is_not_supported(monkeypatch):
    """A marker and similarly named hook still cannot bypass the callable gate."""
    import types

    fake_mw = types.ModuleType("hermes_cli.middleware")
    fake_mw.VALID_MIDDLEWARE = {"pre_inference_route"}
    fake_mw.PRE_INFERENCE_ROUTE_MIDDLEWARE = "pre_inference_route"
    fake_hp = types.ModuleType("hermes_cli.plugins")
    fake_hp.VALID_HOOKS = {"pre_inference_route"}
    monkeypatch.setitem(sys.modules, "hermes_cli.middleware", fake_mw)
    monkeypatch.setitem(sys.modules, "hermes_cli.plugins", fake_hp)

    detection = native_routing.detect_host_native_routing()
    assert detection["supported"] is False
    assert any("without callable" in signal for signal in detection["signals"])


def test_detect_marker_without_callable_is_not_supported(monkeypatch):
    import types

    fake_mw = types.ModuleType("hermes_cli.middleware")
    fake_mw.VALID_MIDDLEWARE = {"llm_request", "pre_inference_route"}
    fake_mw.PRE_INFERENCE_ROUTE_MIDDLEWARE = "pre_inference_route"
    fake_hp = types.ModuleType("hermes_cli.plugins")
    fake_hp.VALID_HOOKS = set()
    monkeypatch.setitem(sys.modules, "hermes_cli.middleware", fake_mw)
    monkeypatch.setitem(sys.modules, "hermes_cli.plugins", fake_hp)
    detection = native_routing.detect_host_native_routing()
    assert detection["supported"] is False
    assert any("callable" in signal for signal in detection["signals"])


# ---------------------------------------------------------------------------
# Opt-in gate
# ---------------------------------------------------------------------------

def test_flag_off_is_passthrough_not_a_route(store_dir):
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-flag-off"},
        store_dir=store_dir,
        providers=["nvidia", "openrouter"],
        settings=_settings(enable_native_routing=False),
    )
    assert out["status"] == "passthrough"
    assert out["provider"] is None and out["model"] is None
    assert out["receipt"]["decision"] == "passthrough"
    assert out["reason"] == "native_routing_disabled"


def test_flag_requires_strict_boolean_true(store_dir):
    for value in ("true", "yes", 1, None, "True"):
        out = native_routing.resolve_consumer_route(
            metadata={"session_id": f"session-{value!s}"},
            store_dir=store_dir,
            providers=["nvidia"],
            settings=_settings(enable_native_routing=value),
        )
        assert out["status"] == "passthrough", value


# ---------------------------------------------------------------------------
# Metadata contract
# ---------------------------------------------------------------------------

def test_missing_session_binding_refuses_before_any_store_access(store_dir):
    out = native_routing.resolve_consumer_route(
        metadata={"platform": "desktop"},
        store_dir=None,  # would explode if touched
        settings=_settings(enable_native_routing=True),
    )
    assert out["status"] == "refuse"
    assert out["reason"] == "missing_session_binding"


def test_metadata_not_an_object_refuses():
    out = native_routing.resolve_consumer_route(
        metadata="session-xyz",
        settings=_settings(enable_native_routing=True),
    )
    assert out["status"] == "refuse"
    assert out["reason"] == "metadata_not_an_object"


# ---------------------------------------------------------------------------
# Selection, binding, isolation
# ---------------------------------------------------------------------------

def test_route_selects_verified_free_model_and_records_receipt(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-route", "platform": "desktop",
                  "requested_model": "autorouter/auto", "explicit_model": False},
        store_dir=store_dir,
        providers=["nvidia", "openrouter"],
    )
    assert out["status"] == "route"
    assert out["provider"] == "nvidia"
    assert out["model"] == "nvidia-free"
    receipt = out["receipt"]
    assert receipt["decision"] == "route"
    assert receipt["route"] == {"provider": "nvidia", "model": "nvidia-free"}
    assert receipt["session"] and receipt["session"] != "session-route"
    assert "session-route" not in json.dumps(out)


def test_paid_and_unknown_cost_models_are_never_routed(monkeypatch, tmp_path):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "paid-x", 131072, {"tools": "supported"}, "paid"),
        ("nvidia", "unknown-cost", 131072, {"tools": "supported"}, "unknown"),
        ("nvidia", "no-evidence", 131072, {"tools": "supported"}, "free"),
    ])
    # Drop the cost_tier evidence for 'no-evidence' so it is never verified-free.
    now = 1.0
    store.upsert_capability(
        "nvidia", "no-evidence",
        json.dumps({"provider": "nvidia", "model": "no-evidence",
                    "field_evidence": {},
                    "context_window": 131072, "tools": "supported",
                    "cost_tier": "unknown", "source": "provider"}),
        metadata_source="provider", retrieved_at=now, expires_at=9999999999.0,
    )
    _patch_hermes_config(monkeypatch, requires_tools=True)
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-paid-gate"},
        store_dir=tmp_path / "store",
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"
    assert out["provider"] is None
    assert "no eligible free model" in out["reason"]


def test_session_bound_to_user_profile_survives_default_change(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    first = rps.create({"name": "Bound Nvidia Only", "ranking_policy": "auto",
                        "providers": ["nvidia"], "min_context": 8192,
                        "requires_tools": True})
    rps.set_active(first["id"])

    first_route = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-bound"},
        store_dir=store_dir,
        providers=["nvidia", "openrouter"],
    )
    assert first_route["status"] == "route"
    assert first_route["route_profile"]["id"] == first["id"]

    second = rps.create({"name": "Bound OpenRouter Only", "ranking_policy": "auto",
                         "providers": ["openrouter"], "min_context": 8192,
                         "requires_tools": True})
    rps.set_active(second["id"])   # operator changes the global AutoRouter default

    again = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-bound"},
        store_dir=store_dir,
        providers=["nvidia", "openrouter"],
    )
    assert again["status"] == "route"
    assert again["route_profile"]["id"] == first["id"]
    assert again["provider"] == "nvidia"

    fresh = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-fresh"},
        store_dir=store_dir,
        providers=["nvidia", "openrouter"],
    )
    assert fresh["status"] == "route"
    assert fresh["route_profile"]["id"] == second["id"]
    assert fresh["provider"] == "openrouter"


def test_bound_session_refuses_when_bound_profile_is_deleted(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    bound = rps.create({"name": "Doomed Profile", "ranking_policy": "auto",
                        "providers": ["nvidia"], "min_context": 8192,
                        "requires_tools": True})
    rps.set_active(bound["id"])
    first_route = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-doomed"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert first_route["status"] == "route"
    rps.delete(bound["id"])
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-doomed"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"
    assert "bound routing profile" in out["reason"]
    assert out["provider"] is None


def test_binding_is_first_route_wins_under_concurrency(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    profile = rps.create({"name": "Concurrent Bound", "ranking_policy": "auto",
                          "providers": ["nvidia"], "min_context": 8192,
                          "requires_tools": True})
    rps.set_active(profile["id"])
    results = []

    def _worker():
        results.append(native_routing.resolve_consumer_route(
            metadata={"session_id": "session-concurrent"},
            store_dir=store_dir,
            providers=["nvidia"]))

    threads = [threading.Thread(target=_worker) for _ in range(6)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert all(r["status"] == "route" for r in results)
    store = state_mod.StateStore(store_dir)
    with store._connect() as conn:
        rows = conn.execute(
            "SELECT COUNT(*) FROM meta WHERE key LIKE 'native_route_binding:%'").fetchone()[0]
    assert rows == 1


# ---------------------------------------------------------------------------
# Zero-outbound refusal
# ---------------------------------------------------------------------------

def test_refusal_path_makes_no_network_call(monkeypatch, tmp_path):
    empty = tmp_path / "empty-store"
    state_mod.StateStore(empty)  # schema exists, catalog empty
    import socket

    def _boom(*args, **kwargs):
        raise AssertionError("network access is forbidden on the refusal path")

    monkeypatch.setattr(socket, "socket", _boom)
    monkeypatch.setattr(socket, "create_connection", _boom)
    _patch_hermes_config(monkeypatch, requires_tools=True)
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-zero-outbound"},
        store_dir=empty,
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"


# ---------------------------------------------------------------------------
# Receipt hygiene
# ---------------------------------------------------------------------------

def test_receipt_redacts_credential_like_material():
    out = native_routing._sanitize({
        "model": "qwen/qwen3-coder:free",
        "nested": [{"trace": "Authorization: Bearer sk-abcdefghijklmnopqrstuvwxyz123456"},
                   "ghp_1234567890abcdefghijklmnopqrstuv"],
    })
    dumped = json.dumps(out)
    assert "sk-abcdefghijklmnopqrstuvwxyz123456" not in dumped
    assert "ghp_1234567890abcdefghijklmnopqrstuv" not in dumped
    assert out["model"] == "qwen/qwen3-coder:free"


def test_binding_meta_never_stores_raw_session_id(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    profile = rps.create({"name": "Hashed Binding", "ranking_policy": "auto",
                          "providers": ["nvidia"], "min_context": 8192,
                          "requires_tools": True})
    rps.set_active(profile["id"])
    native_routing.resolve_consumer_route(
        metadata={"session_id": "raw-session-id-should-not-appear"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    binding = native_routing.read_binding(store_dir, "raw-session-id-should-not-appear")
    assert binding is not None
    assert binding["profile_id"] == profile["id"]
    with state_mod.StateStore(store_dir)._connect() as conn:
        blob = " ".join(row["value"] for row in conn.execute(
            "SELECT value FROM meta WHERE key LIKE 'native_route_binding:%'").fetchall())
    assert "raw-session-id-should-not-appear" not in blob


# ---------------------------------------------------------------------------
# Binding tri-state, atomic first-route-wins, consistency (dispatch 108)
# ---------------------------------------------------------------------------

import itertools  # noqa: E402
import time  # noqa: E402


def _competing_profiles(rps):
    a = rps.create({"name": "Conflict A Nvidia", "ranking_policy": "auto",
                    "providers": ["nvidia"], "min_context": 8192,
                    "requires_tools": True})
    b = rps.create({"name": "Conflict B OpenRouter", "ranking_policy": "auto",
                    "providers": ["openrouter"], "min_context": 8192,
                    "requires_tools": True})
    return a, b


def test_missing_binding_is_absent_and_routes(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    prof = rps.create({"name": "Absent OK", "ranking_policy": "auto",
                       "providers": ["nvidia"], "min_context": 8192,
                       "requires_tools": True})
    rps.set_active(prof["id"])
    state, binding = native_routing.read_binding_state(store_dir, "session-absent")
    assert (state, binding) == ("absent", None)
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-absent"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert out["status"] == "route"
    state, binding = native_routing.read_binding_state(store_dir, "session-absent")
    assert state == "valid"
    assert binding["profile_id"] == prof["id"]


def test_corrupt_binding_json_refuses_and_is_not_overwritten(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    prof = rps.create({"name": "Corrupt Guard", "ranking_policy": "auto",
                       "providers": ["nvidia"], "min_context": 8192,
                       "requires_tools": True})
    rps.set_active(prof["id"])
    key = native_routing._session_key("session-corrupt")
    with state_mod.StateStore(store_dir)._connect() as conn:
        conn.execute("INSERT INTO meta(key, value) VALUES (?, ?)", (key, "{not json"))
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-corrupt"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"
    assert "binding" in out["reason"]
    assert out["provider"] is None
    # The corrupt row MUST NOT be silently replaced by a fresh binding.
    with state_mod.StateStore(store_dir)._connect() as conn:
        row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    assert _row_raw(row) == "{not json"


def _row_raw(row):
    try:
        return row["value"]
    except Exception:
        return row[0]


def test_binding_json_valid_but_shape_invalid_refuses(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    key = native_routing._session_key("session-shape")
    with state_mod.StateStore(store_dir)._connect() as conn:
        conn.execute("INSERT INTO meta(key, value) VALUES (?, ?)",
                     (key, json.dumps({"profile_id": "not-an-rp-prefix"})))
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-shape"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"


def test_binding_provider_shape_invalid_refuses(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    prof = rps.create({"name": "Shape Guard", "ranking_policy": "auto",
                       "providers": ["nvidia"], "min_context": 8192,
                       "requires_tools": True})
    rps.set_active(prof["id"])
    key = native_routing._session_key("session-badprovider")
    payload = json.dumps({"v": 1, "profile_id": prof["id"], "provider": "NVIDIA FREE!",
                          "model": "nvidia-free", "bound_at": 1.0})
    with state_mod.StateStore(store_dir)._connect() as conn:
        conn.execute("INSERT INTO meta(key, value) VALUES (?, ?)", (key, payload))
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-badprovider"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"


def test_database_read_error_refuses(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)

    real_connect = state_mod.StateStore._connect

    class _Flaky:
        def __init__(self, real):
            self._real = real

        def execute(self, sql, *args, **kwargs):
            if "SELECT" in sql.upper():
                raise RuntimeError("database is locked")
            return self._real.execute(sql, *args, **kwargs)

        def close(self):
            self._real.close()

        def __getattr__(self, name):
            return getattr(self._real, name)

    monkeypatch.setattr(state_mod.StateStore, "_connect",
                        lambda self: _Flaky(real_connect(self)))
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-db-read"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"
    assert out["provider"] is None


def test_database_write_insert_error_refuses(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    prof = rps.create({"name": "Write Guard", "ranking_policy": "auto",
                       "providers": ["nvidia"], "min_context": 8192,
                       "requires_tools": True})
    rps.set_active(prof["id"])

    real_connect = state_mod.StateStore._connect

    class _NoBindingInsert:
        def __init__(self, real):
            self._real = real

        def execute(self, sql, *args, **kwargs):
            def _has_binding_key(items):
                for a in items:
                    if isinstance(a, str):
                        if "native_route_binding" in a:
                            return True
                    elif isinstance(a, (tuple, list)):
                        if _has_binding_key(a):
                            return True
                return False
            if "INSERT" in sql.upper() and _has_binding_key(args):
                raise RuntimeError("database is locked")
            return self._real.execute(sql, *args, **kwargs)

        def close(self):
            self._real.close()

        def __getattr__(self, name):
            return getattr(self._real, name)

    monkeypatch.setattr(state_mod.StateStore, "_connect",
                        lambda self: _NoBindingInsert(real_connect(self)))
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-db-write"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"
    assert "persist" in out["reason"]


def test_binding_write_reports_error_and_refuses(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    prof = rps.create({"name": "Write Claim Guard", "ranking_policy": "auto",
                       "providers": ["nvidia"], "min_context": 8192,
                       "requires_tools": True})
    rps.set_active(prof["id"])
    monkeypatch.setattr(native_routing, "write_binding", lambda *a, **k: "error")
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-write-fail"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"
    assert "persist" in out["reason"]
    state, binding = native_routing.read_binding_state(store_dir, "session-write-fail")
    assert state == "absent"


def test_conflicting_winning_binding_is_not_replaced(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    prof_a, prof_b = _competing_profiles(rps)
    # A racing first route already persisted its binding (profile B).
    claim = native_routing.write_binding(store_dir, "session-race", {
        "profile_id": prof_b["id"], "profile_name": prof_b["name"],
        "provider": "openrouter", "model": "qwen/qwen3-coder:free"})
    assert claim == "won"
    # This caller's own selection (stale) would pick A.
    real_detailed = _route_resolution.resolve_route_detailed
    fake_a = {"provider": "nvidia", "model": "nvidia-free", "error": None,
              "profile_id": prof_a["id"], "profile_name": prof_a["name"],
              "policy": "auto", "at": time.time()}
    monkeypatch.setattr(_route_resolution, "resolve_route_detailed",
                        lambda **kw: fake_a if kw.get("bound_profile_id") is None
                        else real_detailed(**kw))
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-race"},
        store_dir=store_dir,
        providers=["nvidia", "openrouter"],
    )
    assert out["status"] == "route"
    assert out["route_profile"]["id"] == prof_b["id"]
    assert out["provider"] == "openrouter"
    state, binding = native_routing.read_binding_state(store_dir, "session-race")
    assert state == "valid" and binding["profile_id"] == prof_b["id"]


def test_conflicting_winner_profile_deleted_before_adoption_refuses(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    prof_a, prof_b = _competing_profiles(rps)
    native_routing.write_binding(store_dir, "session-race-doomed", {
        "profile_id": prof_b["id"], "profile_name": prof_b["name"],
        "provider": "openrouter", "model": "qwen/qwen3-coder:free"})
    real_detailed = _route_resolution.resolve_route_detailed
    fake_a = {"provider": "nvidia", "model": "nvidia-free", "error": None,
              "profile_id": prof_a["id"], "profile_name": prof_a["name"],
              "policy": "auto", "at": time.time()}
    monkeypatch.setattr(_route_resolution, "resolve_route_detailed",
                        lambda **kw: fake_a if kw.get("bound_profile_id") is None
                        else real_detailed(**kw))
    rps.delete(prof_b["id"])  # winner disappears before we follow it
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-race-doomed"},
        store_dir=store_dir,
        providers=["nvidia", "openrouter"],
    )
    assert out["status"] == "refuse"
    state, binding = native_routing.read_binding_state(store_dir, "session-race-doomed")
    assert state == "valid" and binding["profile_id"] == prof_b["id"]


def test_six_conflicting_first_routes_converge_on_winner(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    prof_a, prof_b = _competing_profiles(rps)

    real_detailed = _route_resolution.resolve_route_detailed
    counter = itertools.count()

    def _competing(**kw):
        if kw.get("bound_profile_id") is not None:
            return real_detailed(**kw)
        n = next(counter)
        prof = prof_a if n % 2 == 0 else prof_b
        provider, model = (("nvidia", "nvidia-free") if prof is prof_a
                           else ("openrouter", "qwen/qwen3-coder:free"))
        return {"provider": provider, "model": model, "error": None,
                "profile_id": prof["id"], "profile_name": prof["name"],
                "policy": "auto", "at": time.time()}

    monkeypatch.setattr(_route_resolution, "resolve_route_detailed", _competing)

    results = []

    def _worker():
        results.append(native_routing.resolve_consumer_route(
            metadata={"session_id": "session-sixway"},
            store_dir=store_dir,
            providers=["nvidia", "openrouter"]))

    threads = [threading.Thread(target=_worker) for _ in range(6)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert len(results) == 6
    assert all(r["status"] == "route" for r in results), results
    routed = {r["route_profile"]["id"] for r in results}
    state, binding = native_routing.read_binding_state(store_dir, "session-sixway")
    assert state == "valid"
    # Every racing caller routes under the single persisted winner.
    assert routed == {binding["profile_id"]}
    with state_mod.StateStore(store_dir)._connect() as conn:
        rows = conn.execute(
            "SELECT COUNT(*) FROM meta WHERE key = ?",
            (native_routing._session_key("session-sixway"),)).fetchone()[0]
    assert rows == 1


def test_binding_survives_module_reload(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    prof = rps.create({"name": "Restart Bound", "ranking_policy": "auto",
                       "providers": ["nvidia"], "min_context": 8192,
                       "requires_tools": True})
    rps.set_active(prof["id"])
    before = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-restart"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert before["status"] == "route"
    import importlib
    importlib.reload(native_routing)
    after = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-restart"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert after["status"] == "route"
    assert after["route_profile"]["id"] == before["route_profile"]["id"]


def test_session_a_b_binding_isolation_under_default_changes(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, requires_tools=True)
    rps = state_mod.RoutingProfileStore(store_dir)
    a = rps.create({"name": "Isolation A", "ranking_policy": "auto",
                    "providers": ["nvidia"], "min_context": 8192,
                    "requires_tools": True})
    b = rps.create({"name": "Isolation B", "ranking_policy": "auto",
                    "providers": ["openrouter"], "min_context": 8192,
                    "requires_tools": True})
    rps.set_active(a["id"])
    out_a = native_routing.resolve_consumer_route(
        metadata={"session_id": "isolation-a"}, store_dir=store_dir,
        providers=["nvidia", "openrouter"])
    rps.set_active(b["id"])
    out_b = native_routing.resolve_consumer_route(
        metadata={"session_id": "isolation-b"}, store_dir=store_dir,
        providers=["nvidia", "openrouter"])
    rps.set_active(a["id"])
    resume_a = native_routing.resolve_consumer_route(
        metadata={"session_id": "isolation-a"}, store_dir=store_dir,
        providers=["nvidia", "openrouter"])
    rps.set_active(b["id"])
    resume_b = native_routing.resolve_consumer_route(
        metadata={"session_id": "isolation-b"}, store_dir=store_dir,
        providers=["nvidia", "openrouter"])
    assert out_a["route_profile"]["id"] == a["id"]
    assert out_b["route_profile"]["id"] == b["id"]
    assert resume_a["route_profile"]["id"] == a["id"]
    assert resume_b["route_profile"]["id"] == b["id"]
    with state_mod.StateStore(store_dir)._connect() as conn:
        blob = " ".join(_row_raw(r) for r in conn.execute(
            "SELECT value FROM meta WHERE key LIKE 'native_route_binding:%'").fetchall())
    assert "isolation-a" not in blob and "isolation-b" not in blob


@pytest.mark.parametrize("mode", ["empty-catalog", "corrupt-binding", "shape-invalid-binding",
                                  "write-failure", "read-error"])
def test_refusal_modes_make_no_network_call(monkeypatch, tmp_path, mode):
    import socket

    def _boom(*args, **kwargs):
        raise AssertionError("network access is forbidden on the refusal path")

    monkeypatch.setattr(socket, "socket", _boom)
    monkeypatch.setattr(socket, "create_connection", _boom)
    store_dir = tmp_path / "store"
    state_mod.StateStore(store_dir)

    if mode == "empty-catalog":
        pass  # empty catalog: no eligible model
    else:
        rps = state_mod.RoutingProfileStore(store_dir)
        prof = rps.create({"name": "Refusal Guard", "ranking_policy": "auto",
                           "providers": ["nvidia"], "min_context": 8192,
                           "requires_tools": True})
        rps.set_active(prof["id"])
        key = native_routing._session_key("session-zero-outbound")
        if mode == "corrupt-binding":
            with state_mod.StateStore(store_dir)._connect() as conn:
                conn.execute("INSERT INTO meta(key, value) VALUES (?, ?)", (key, "{oops"))
        elif mode == "shape-invalid-binding":
            with state_mod.StateStore(store_dir)._connect() as conn:
                conn.execute("INSERT INTO meta(key, value) VALUES (?, ?)",
                             (key, json.dumps({"profile_id": "nope"})))
        elif mode == "write-failure":
            monkeypatch.setattr(native_routing, "write_binding", lambda *a, **k: "error")
        elif mode == "read-error":
            real_connect = state_mod.StateStore._connect

            class _NoSelect:
                def __init__(self, real):
                    self._real = real

                def execute(self, sql, *args, **kwargs):
                    if "SELECT" in sql.upper():
                        raise RuntimeError("database is locked")
                    return self._real.execute(sql, *args, **kwargs)

                def close(self):
                    self._real.close()

            monkeypatch.setattr(state_mod.StateStore, "_connect",
                                lambda self: _NoSelect(real_connect(self)))

    _patch_hermes_config(monkeypatch, requires_tools=True)
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-zero-outbound"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"


# ---------------------------------------------------------------------------
# MODE A (manual) — explicit picker selection goes through the same resolver
# ---------------------------------------------------------------------------

def test_manual_mode_routes_with_chat_router_flag_only(store_dir):
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-manual-a", "selection_mode": "manual"},
        store_dir=store_dir,
        providers=["nvidia"],
        settings=_settings(enable_chat_router=True, enable_native_routing=False),
    )
    assert out["status"] == "route"
    assert out["provider"] == "nvidia"
    assert out["model"] == "nvidia-free"


def test_manual_mode_requires_strict_boolean_chat_router(store_dir):
    for value in ("true", "yes", 1, None, "True"):
        out = native_routing.resolve_consumer_route(
            metadata={"session_id": f"session-manual-strict-{value!s}", "selection_mode": "manual"},
            store_dir=store_dir,
            providers=["nvidia"],
            settings=_settings(enable_chat_router=value, enable_native_routing=False),
        )
        assert out["status"] == "passthrough", value
        assert out["reason"] == "chat_router_disabled"


def test_automatic_mode_ignores_chat_router_flag(store_dir):
    # MODE B (ordinary sessions) must not be enabled by the picker's own opt-in.
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-auto-a"},
        store_dir=store_dir,
        providers=["nvidia"],
        settings=_settings(enable_chat_router=True, enable_native_routing=False),
    )
    assert out["status"] == "passthrough"
    assert out["reason"] == "native_routing_disabled"


def test_manual_mode_refuses_without_session_binding(store_dir):
    out = native_routing.resolve_consumer_route(
        metadata={"selection_mode": "manual"},
        settings=_settings(enable_chat_router=True, enable_native_routing=False),
    )
    assert out["status"] == "refuse"
    assert out["reason"] == "missing_session_binding"


def test_manual_mode_zero_eligible_free_routes_refuses(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, enable_chat_router=True, enable_native_routing=False,
                         model_preference={"mode": "none"})
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-manual-noeligible", "selection_mode": "manual"},
        store_dir=store_dir,
        providers=["nvidia"],
    )
    assert out["status"] == "refuse"


def test_manual_mode_binding_is_first_route_wins(store_dir):
    first = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-manual-binding", "selection_mode": "manual"},
        store_dir=store_dir,
        providers=["nvidia"],
        settings=_settings(enable_chat_router=True, enable_native_routing=False),
    )
    second = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-manual-binding", "selection_mode": "manual"},
        store_dir=store_dir,
        providers=["nvidia"],
        settings=_settings(enable_chat_router=True, enable_native_routing=False),
    )
    assert first["status"] == "route" and second["status"] == "route"
    assert first["provider"] == second["provider"] == "nvidia"
    assert first["model"] == second["model"] == "nvidia-free"


def test_manual_mode_mode_b_session_unaffected(store_dir):
    # A MODE A session leaves no binding the ordinary-session path would read.
    manual = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-manual-isolation", "selection_mode": "manual"},
        store_dir=store_dir,
        providers=["nvidia"],
        settings=_settings(enable_chat_router=True, enable_native_routing=False),
    )
    assert manual["status"] == "route"
    automatic = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-auto-isolation"},
        store_dir=store_dir,
        providers=["nvidia"],
        settings=_settings(enable_native_routing=False, enable_chat_router=True),
    )
    assert automatic["status"] == "passthrough"


def test_manual_mode_corrupt_binding_refuses(store_dir):
    import json as _json
    from pathlib import Path as _Path
    store_path = _Path(store_dir)
    rps = state_mod.RoutingProfileStore(store_dir)
    profile = rps.create({"name": "Manual Corrupt Probe", "ranking_policy": "auto",
                          "providers": ["nvidia"], "min_context": 8192,
                          "requires_tools": True})
    rps.set_active(profile["id"])
    first = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-manual-corrupt", "selection_mode": "manual"},
        store_dir=store_dir,
        providers=["nvidia"],
        settings=_settings(enable_chat_router=True, enable_native_routing=False),
    )
    assert first["status"] == "route"
    assert first["route_profile"]["id"] == profile["id"]
    state_db = store_path / "autorouter.db"
    import sqlite3
    with sqlite3.connect(state_db) as conn:
        rows = list(conn.execute("SELECT key FROM meta"))
    victim = next(key for (key,) in rows if key.startswith("native_route_binding:"))
    with sqlite3.connect(state_db) as conn:
        conn.execute("UPDATE meta SET value=? WHERE key=?", ("{corrupt", victim))
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "session-manual-corrupt", "selection_mode": "manual"},
        store_dir=store_dir,
        providers=["nvidia"],
        settings=_settings(enable_chat_router=True, enable_native_routing=False),
    )
    assert out["status"] == "refuse"


# ---------------------------------------------------------------------------
# Consumer registration gate — either MODE registers the consumer
# ---------------------------------------------------------------------------

def test_hook_only_host_cannot_register_native_consumer(monkeypatch):
    """Mode A and Mode B must stay inactive if only an observer hook exists."""
    import types

    fake_mw = types.ModuleType("hermes_cli.middleware")
    fake_mw.VALID_MIDDLEWARE = {"llm_request"}
    fake_hp = types.ModuleType("hermes_cli.plugins")
    fake_hp.VALID_HOOKS = {"pre_inference_route"}
    monkeypatch.setitem(sys.modules, "hermes_cli.middleware", fake_mw)
    monkeypatch.setitem(sys.modules, "hermes_cli.plugins", fake_hp)

    class Ctx:
        def __init__(self):
            self.middleware = {}

        def register_middleware(self, kind, callback):
            self.middleware[kind] = callback

    ctx = Ctx()
    out = native_routing.register_if_supported(
        ctx, settings=_settings(enable_chat_router=True, enable_native_routing=True)
    )
    assert out["supported"] is False
    assert out["registered"] is False
    assert out["enabled"] is True
    assert not ctx.middleware


def test_register_if_supported_registers_chat_router_only(tmp_path, monkeypatch):
    class _Ctx:
        def __init__(self):
            self.middleware = {}

        def register_middleware(self, kind, callback):
            self.middleware[kind] = callback

    detector = {"supported": True, "signals": [], "host_version": "0.24.0", "reason": None}
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: detector)
    ctx = _Ctx()
    out = native_routing.register_if_supported(ctx, settings=_settings(enable_chat_router=True,
                                                                      enable_native_routing=False))
    assert out["registered"] is True
    assert "pre_inference_route" in ctx.middleware


def test_register_if_supported_unsupported_host_stays_unregistered(tmp_path, monkeypatch):
    class _Ctx:
        def __init__(self):
            self.middleware = {}

        def register_middleware(self, kind, callback):
            self.middleware[kind] = callback

    detector = {"supported": False, "signals": [], "host_version": "0.23.1",
                "reason": "host exposes no sanctioned pre-inference route extension"}
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: detector)
    ctx = _Ctx()
    out = native_routing.register_if_supported(ctx, settings=_settings(enable_chat_router=True,
                                                                      enable_native_routing=False))
    assert out["registered"] is False
    assert ctx.middleware == {}


def test_register_if_supported_neither_flag_stays_unregistered(monkeypatch):
    class _Ctx:
        def __init__(self):
            self.middleware = {}

        def register_middleware(self, kind, callback):
            self.middleware[kind] = callback

    out = native_routing.register_if_supported(
        _Ctx(), settings=_settings(enable_native_routing=False, enable_chat_router=False))
    assert out["registered"] is False


# ---------------------------------------------------------------------------
# Issue #126 — consumer authorization must match plugin registration
# ---------------------------------------------------------------------------

@requires_hermes
def test_authorized_providers_denies_malformed_list(monkeypatch):
    _patch_hermes_config(monkeypatch, providers=["nvidia", "no-such-provider"])
    assert _route_resolution.authorized_providers() == []


@requires_hermes
def test_authorized_providers_denies_duplicate_entries(monkeypatch):
    _patch_hermes_config(monkeypatch, providers=["nvidia", "nvidia"])
    assert _route_resolution.authorized_providers() == []


@requires_hermes
def test_authorized_providers_denies_non_list_values(monkeypatch):
    _patch_hermes_config(monkeypatch, providers="nvidia")
    assert _route_resolution.authorized_providers() == []


@requires_hermes
def test_authorized_providers_passes_valid_list(monkeypatch):
    _patch_hermes_config(monkeypatch, providers=["nvidia", "openrouter"])
    assert _route_resolution.authorized_providers() == ["nvidia", "openrouter"]


@requires_hermes
def test_malformed_authorization_list_grants_no_route(monkeypatch, store_dir):
    """Regression (#126): a malformed providers list must grant nothing.

    Before the fix, ``authorized_providers()`` returned the raw list, so a
    config of ``["nvidia", "no-such-provider"]`` authorized nvidia for
    selection while plugin registration correctly refused the whole list.
    """
    _patch_hermes_config(monkeypatch, providers=["nvidia", "no-such-provider"],
                         requires_tools=True)
    out = native_routing.resolve_consumer_route(
        metadata={"session_id": "malformed-list", "platform": "desktop",
                  "requested_model": "", "explicit_model": False},
        store_dir=store_dir,
    )
    assert out["status"] == "refuse"
