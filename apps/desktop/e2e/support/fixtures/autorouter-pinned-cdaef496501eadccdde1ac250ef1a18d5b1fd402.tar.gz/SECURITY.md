# Security

AutoRouter is a plugin with deliberately narrow authority: it reads catalog evidence, ranks eligible models, and reports state. It does not execute inference, move credentials, or grant permissions.

## Reporting a vulnerability

Open an issue at https://github.com/diegorhoger/autorouter/issues describing:

- what you observed,
- the affected component,
- minimal reproduction steps with a **redacted configuration** (never include real keys, tokens, provider account details, or database dumps).

If the report is sensitive and could enable credential theft or quota theft, **omit the exact secret**; maintainers will follow up privately on the issue thread. Do not email or attach raw credentials anywhere.

## What a bug report must never contain

- raw or partially redacted credentials, keys or tokens
- database dumps from live profiles (`autorouter.db`, `state.db`)
- full request/response payloads containing content or keys
- account IDs, email addresses, billing identifiers

## Security boundaries this plugin relies on

- **Hermes protects your keys; AutoRouter handles presence only.** Keys are read from the environment or through Hermes' auth APIs only to authorize a single fixed-origin read-only catalog GET (and never appear anywhere else). Presence labels never reveal the value; no raw credential is persisted, logged, displayed or exported by this plugin. Analytics markers (`k_<12 hex>`) are short unsalted truncated SHA-256 hashes of the *opaque scope label*, not of any key, and do not prove account identity.
- **Profile isolation.** All state stays inside the profile that installed the plugin.
- **Dashboard reads are read-only;** the only write path is the restricted settings API for `plugins.entries.autorouter.settings`.
- **In-flight eligibility checks fail closed.** No free evidence → no selection.
- **No substitution.** Nothing silently replaces an unavailable route.

## What this plugin cannot protect

Direct Hermes requests, provider-side account breaches, quota granted or abused upstream, and any request made outside AutoRouter's selection path. Treat provider risk as separate from plugin risk.
