"""Versioned V1 ranking preferences; verified-free eligibility is never optional."""
from __future__ import annotations

from copy import deepcopy

SCHEMA_VERSION = 1
# Task requirement profiles are a separate contract; these map launch vocabulary
# onto existing operational weights, not semantic model-quality benchmarks.
_PROFILES = {
    "auto": {"label": "General", "task": "general"},
    "coding": {"label": "Coding", "task": "coding"},
    "fastest": {"label": "Fast response", "task": "general"},
    "reliable": {"label": "Reliability-first", "task": "general"},
    "smartest": {"label": "Legacy smartest (quality unknown)", "task": "general", "legacy": True},
    "priority": {"label": "Legacy priority", "task": "general", "legacy": True},
}
ALIASES = {"general": "auto", "fast-response": "fastest", "reliability-first": "reliable",
           "free-first": "auto"}
POLICY_OPTIONS = tuple(_PROFILES)


def resolve(value="auto"):
    """Reject unrecognized preferences; never silently fall back to another policy."""
    if not isinstance(value, str):
        raise ValueError("unknown policy")
    key = ALIASES.get(value, value)
    if key not in _PROFILES:
        raise ValueError("unknown policy")
    from ..routing.scoring import WEIGHTS
    profile = deepcopy(_PROFILES[key])
    profile.update(schema_version=SCHEMA_VERSION, id=key, ranking_policy=key,
        verified_free_only=True, paid_fallback=False, semantic_quality="unknown",
        weights=dict(zip(("reliability", "speed", "semantic_quality", "cooldown", "tools"), WEIGHTS[key])))
    return profile


def contract():
    from .selection_policy import metadata
    return {"schema_version": SCHEMA_VERSION, "cost_mode": "verified-free-only",
        "paid_authorized": False, "paid_fallback": False, "selection_policy": metadata(),
        "policies": [resolve(key) for key in _PROFILES], "aliases": dict(ALIASES),
        "tie_break": ["score_descending", "provider_ascending", "model_ascending"],
        "no_match": "no eligible model; do not execute or fall back",
        "unknown_policy": "reject", "semantic_quality": "unknown"}
