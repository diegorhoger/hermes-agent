"""AutoRouter configuration package."""
