"""Version-1 executor-independent requirements; no credential or execution authority."""

from copy import deepcopy
from dataclasses import dataclass
import math
import re

MISSING = object()
VERSION = 1
QUOTA_MODES = (
    "prefer_available_allowance",
    "require_fresh_account_allowance",
    "avoid_verified_exhaustion",
    "require_no_charge_guarantee",
)


class PolicyError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def _fields(value, required, optional=()):
    if (
        not isinstance(value, dict)
        or not set(required) <= value.keys()
        or not value.keys() <= set(required) | set(optional)
    ):
        raise ValueError("invalid selection policy")
    return value


def _integer(value):
    if type(value) is not int or not 1 <= value <= 1000000000:
        raise ValueError("invalid selection policy")
    return value


def _identifier(value, provider=False):
    pattern = (
        r"[a-z][a-z0-9-]{0,63}" if provider else r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}"
    )
    if (
        not isinstance(value, str)
        or re.fullmatch(pattern, value) is None
        or re.search(r"(?i)(sk-|sk_|bearer|api[_-]?key|token[=:])", value)
    ):
        raise ValueError("invalid selection policy")
    return value


def _scope(value):
    if value is not None and (
        not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{32}", value) is None
    ):
        raise ValueError("invalid selection policy")
    return value


def _models(value):
    if not isinstance(value, list) or len(value) > 128:
        raise ValueError("invalid selection policy")
    return [
        dict(
            provider=_identifier(_fields(row, ("provider", "model"))["provider"], True),
            model=_identifier(row["model"]),
        )
        for row in value
    ]


def _capabilities(value):
    _fields(value, (), ("tools",))
    if any(v not in ("required", "forbidden") for v in value.values()):
        raise ValueError("invalid selection policy")
    return dict(value)


def validate(value):
    """Strict public constraints only: caller JSON cannot supply authority/evidence."""
    _fields(
        value,
        (
            "schema_version",
            "hard_eligibility",
            "preferences",
            "task_requirements",
            "connection_restrictions",
            "quota_policy",
        ),
    )
    if type(value["schema_version"]) is not int or value["schema_version"] != VERSION:
        raise PolicyError("selection_policy_version_unsupported")
    hard = _fields(
        value["hard_eligibility"],
        (
            "verified_free_only",
            "required_capabilities",
            "min_context",
            "authorized_providers",
            "exclude",
            "max_in_flight",
            "health",
        ),
    )
    if hard["verified_free_only"] is not True:
        raise ValueError("verified free only required")
    providers = hard["authorized_providers"]
    if not isinstance(providers, list) or len(providers) > 128:
        raise ValueError("invalid selection policy")
    for provider in providers:
        _identifier(provider, True)
    _capabilities(hard["required_capabilities"])
    _integer(hard["min_context"])
    _models(hard["exclude"])
    if hard["max_in_flight"] is not None:
        _integer(hard["max_in_flight"])
    health = _fields(
        hard["health"],
        ("respect_failures", "respect_cooldowns", "require_observed"),
        ("max_age_seconds",),
    )
    if (
        health["respect_failures"] is not True
        or health["respect_cooldowns"] is not True
        or type(health["require_observed"]) is not bool
    ):
        raise ValueError("invalid selection policy")
    if "max_age_seconds" in health:
        _integer(health["max_age_seconds"])
    if health["require_observed"] and "max_age_seconds" not in health:
        raise ValueError("health freshness bound required")
    preference = _fields(value["preferences"], ("policy",))
    from .policies import resolve

    try:
        resolve(preference["policy"])
    except ValueError:
        raise PolicyError("ranking_policy_unsupported") from None
    task = _fields(
        value["task_requirements"],
        ("schema_version", "label", "required_capabilities", "min_context"),
        ("profile",),
    )
    if type(task["schema_version"]) is not int or task["schema_version"] != 1:
        raise PolicyError("task_requirements_version_unsupported")
    if task["label"] not in ("general", "coding", "fast-response", "explicit"):
        raise PolicyError("task_requirements_unsupported")
    caps = _capabilities(task["required_capabilities"])
    if any(
        key in hard["required_capabilities"] and hard["required_capabilities"][key] != v
        for key, v in caps.items()
    ):
        raise ValueError("conflicting task requirements")
    _integer(task["min_context"])
    connection = _fields(
        value["connection_restrictions"],
        (
            "provider_id",
            "connection_id",
            "require_authority",
            "models",
            "shared_quota_scope",
        ),
    )
    if connection["provider_id"] is not None:
        _identifier(connection["provider_id"], True)
    if type(connection["require_authority"]) is not bool:
        raise ValueError("invalid selection policy")
    _scope(connection["connection_id"])
    _scope(connection["shared_quota_scope"])
    _models(connection["models"])
    if connection["provider_id"] is None and (
        connection["connection_id"] is not None
        or connection["shared_quota_scope"] is not None
    ):
        raise ValueError("connection provider required")
    if (
        connection["provider_id"] is not None
        and connection["provider_id"] not in providers
        or any(row["provider"] not in providers for row in connection["models"])
    ):
        raise ValueError("conflicting provider restrictions")
    if (
        not isinstance(value["quota_policy"], str)
        or value["quota_policy"] not in QUOTA_MODES
    ):
        raise PolicyError("quota_policy_unsupported")
    from ..routing.task_profiles import compose
    return compose(value)


def requirements(value, requires_tools, min_context):
    caps = dict(value["hard_eligibility"]["required_capabilities"])
    caps.update(value["task_requirements"]["required_capabilities"])
    if requires_tools and caps.get("tools") == "forbidden":
        raise ValueError("conflicting tool requirement")
    return (
        requires_tools or caps.get("tools") == "required",
        max(
            min_context,
            value["hard_eligibility"]["min_context"],
            value["task_requirements"]["min_context"],
        ),
        caps.get("tools") == "forbidden",
    )


@dataclass(frozen=True)
class SelectionContext:
    """Adapter-owned current context; never accepted from public policy JSON."""

    profile_id: str
    session_id: str
    request_id: str
    schema_version: int = 1


@dataclass(frozen=True)
class ConnectionContext:
    """Authorized observation binding, NOT permission to apply/execute or expose a key."""

    context: SelectionContext
    provider_id: str
    connection_id: str
    shared_quota_scope: str | None
    models: tuple[str, ...]
    granted: bool
    observed_at: float
    expires_at: float
    schema_version: int = 1


def authority(connection, active, provider, now):
    if (
        type(connection) is not ConnectionContext
        or type(active) is not SelectionContext
    ):
        return False
    times = (connection.observed_at, connection.expires_at, now)
    return (
        type(active.schema_version) is int
        and active.schema_version == 1
        and type(connection.schema_version) is int
        and connection.schema_version == 1
        and connection.context == active
        and all(
            isinstance(v, str) and re.fullmatch(r"[0-9a-f]{32}", v)
            for v in (active.profile_id, active.session_id, active.request_id)
        )
        and connection.granted is True
        and connection.provider_id == provider
        and isinstance(connection.connection_id, str)
        and re.fullmatch(r"[0-9a-f]{32}", connection.connection_id) is not None
        and (
            connection.shared_quota_scope is None
            or isinstance(connection.shared_quota_scope, str)
            and re.fullmatch(r"[0-9a-f]{32}", connection.shared_quota_scope) is not None
        )
        and type(connection.models) is tuple
        and len(connection.models) <= 128
        and all(
            isinstance(v, str)
            and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}", v)
            for v in connection.models
        )
        and all(type(v) in (int, float) and math.isfinite(v) for v in times)
        and connection.observed_at
        <= now
        < connection.expires_at
        <= connection.observed_at + 120
    )


def restriction_reasons(value, candidate, connection, active, now):
    """Only extra gates; existing free/capability/health gates always remain in force."""
    hard = value["hard_eligibility"]
    wanted = value["connection_restrictions"]
    provider, model = candidate["provider"], candidate["model"]
    reasons = []
    if provider not in hard["authorized_providers"]:
        reasons.append("provider_disabled")
    if dict(provider=provider, model=model) in hard["exclude"]:
        reasons.append("excluded")
    if hard["health"]["require_observed"]:
        observed = (candidate.get("health") or {}).get("last_success_at")
        if (
            candidate.get("health_reason", "health_unknown") != "available"
            or type(observed) not in (int, float)
            or not math.isfinite(observed)
            or not 0 < observed <= now
            or now - observed > hard["health"]["max_age_seconds"]
        ):
            reasons.append("health_observation_required")
    maximum = hard["max_in_flight"]
    count = candidate.get("in_flight")
    if maximum is not None and (
        type(count) is not int or count < 0 or count >= maximum
    ):
        reasons.append("concurrency_limit")
    known = authority(connection, active, provider, now)
    needs = (
        wanted["require_authority"]
        or wanted["connection_id"] is not None
        or wanted["shared_quota_scope"] is not None
        or bool(wanted["models"])
        or value["quota_policy"] == "require_fresh_account_allowance"
    )
    if wanted["provider_id"] is not None and wanted["provider_id"] != provider:
        reasons.append("connection_restriction_mismatch")
    if needs and not known:
        reasons.append("connection_authority_unavailable")
    if known:
        if wanted["models"] and not connection.models:
            reasons.append("connection_model_scope_unavailable")
        if (
            wanted["connection_id"] is not None
            and wanted["connection_id"] != connection.connection_id
            or wanted["shared_quota_scope"] is not None
            and wanted["shared_quota_scope"] != connection.shared_quota_scope
            or connection.models
            and model not in connection.models
            or wanted["models"]
            and dict(provider=provider, model=model) not in wanted["models"]
        ):
            reasons.append("connection_restriction_mismatch")
    return reasons, known


def quota_decision(evaluator, snapshot, provider, model, connection, known, now, mode):
    """Consume #58's interface; do not implement its window/account evaluator here."""
    unknown = dict(
        schema_version=1,
        allowed=mode
        not in ("require_fresh_account_allowance", "require_no_charge_guarantee"),
        state="unknown",
        reason="quota_evaluator_unavailable",
        preference_available=False,
        quota_policy=mode,
        evidence=[],
        evaluator_available=False,
    )
    if mode == "require_no_charge_guarantee":
        return dict(unknown, allowed=False, reason="no_charge_guarantee_unverified")
    if not known or not callable(evaluator):
        return unknown
    try:
        from ..evidence.free_access import canonical_scope, _safe_observation

        scope = provider + ":" + connection.connection_id
        result = evaluator(snapshot, provider, model, scope, now, quota_policy=mode)
        allowance = result.get("allowance") if isinstance(result, dict) else None
        if (
            not isinstance(allowance, dict)
            or type(allowance.get("schema_version")) is not int
            or allowance.get("schema_version") != 1
            or allowance.get("provider") != provider
            or allowance.get("account_scope") != canonical_scope(scope)
            or type(result.get("quota_policy_version")) is not int
            or result.get("quota_policy_version") != 1
            or result.get("quota_policy") != mode
            or type(result.get("allowed")) is not bool
            or type(result.get("preference_available")) is not bool
            or result.get("state")
            not in (
                "unknown",
                "unavailable",
                "healthy",
                "approaching_limit",
                "exhausted",
            )
        ):
            return dict(unknown, reason="quota_result_invalid")
        windows = allowance.get("quota_windows")
        if not isinstance(windows, list) or len(windows) > 32:
            return dict(unknown, reason="quota_result_invalid")
        evidence = []
        statuses = []
        for window in windows:
            shared = (
                provider + ":" + connection.shared_quota_scope
                if connection.shared_quota_scope
                else scope
            )
            compatible = (
                isinstance(window, dict)
                and window.get("model") in (None, model)
                and window.get("shared_scope") == canonical_scope(shared)
            )
            safe = (
                _safe_observation(window, provider, canonical_scope(scope))
                if compatible
                else None
            )
            if safe is None:
                # Unsupported dimensions remain explicit without copying raw diagnostics.
                from ..evidence.quota import DIMENSIONS, WINDOWS

                evidence.append(
                    dict(
                        dimension=window.get("dimension")
                        if isinstance(window, dict)
                        and isinstance(window.get("dimension"), str)
                        and window["dimension"] in DIMENSIONS
                        else "unknown",
                        window=window.get("window")
                        if isinstance(window, dict)
                        and isinstance(window.get("window"), str)
                        and window["window"] in WINDOWS
                        else "unknown",
                        state="unknown",
                    )
                )
            else:
                from ..evidence.quota import quota_status

                statuses.append(quota_status(safe, now))
                evidence.append(
                    {
                        k: v
                        for k, v in safe.items()
                        if k not in ("account_scope", "shared_scope")
                    }
                )
        # Matching verified exhaustion overrides every producer assertion and preference.
        if "exhausted" in statuses:
            consistent = (
                result["state"] == "exhausted"
                and result["allowed"] is False
                and result["preference_available"] is False
            )
            return dict(
                unknown,
                allowed=False,
                state="exhausted",
                evidence=evidence,
                evaluator_available=True,
                reason="quota_policy_evaluated"
                if consistent
                else "quota_result_invalid",
            )
        fresh = (
            bool(windows)
            and len(statuses) == len(windows)
            and all(v == "available" for v in statuses)
            and allowance.get("complete") is True
        )
        if (
            result["state"] == "exhausted"
            or fresh
            and (
                result["state"] not in ("healthy", "approaching_limit")
                or result["allowed"] is not True
            )
        ):
            return dict(unknown, allowed=False, reason="quota_result_invalid")
        if (
            mode == "require_fresh_account_allowance"
            and result["allowed"]
            and not fresh
            or result["state"] == "exhausted"
            and "exhausted" not in statuses
            or result["state"] in ("healthy", "approaching_limit")
            and not fresh
        ):
            return dict(unknown, reason="quota_result_invalid")
        return dict(
            unknown,
            allowed=result["allowed"],
            state=result["state"],
            reason="quota_policy_evaluated",
            preference_available=mode == "prefer_available_allowance"
            and result["preference_available"] is True
            and result["state"] == "healthy"
            and fresh,
            evidence=evidence,
            evaluator_available=True,
        )
    except Exception:
        return dict(unknown, reason="quota_evaluator_failed")


def public(value):
    """Safe explanation: opaque restrictions and authority identifiers are not exported."""
    result = deepcopy(value)
    for key in ("connection_id", "shared_quota_scope"):
        result["connection_restrictions"][key] = (
            "required" if result["connection_restrictions"][key] is not None else None
        )
    result["task_requirements"]["semantic_quality"] = "unknown"
    return result


def metadata():
    return dict(
        schema_version=VERSION,
        sections=[
            "hard_eligibility",
            "preferences",
            "task_requirements",
            "connection_restrictions",
        ],
        quota_policies=list(QUOTA_MODES),
        task_requirements_version=1,
        quota_evaluator_version=1,
        execution_authority=False,
        semantic_quality="unknown",
        unknown_fields="reject",
    )


def request_schema():
    """Portable JSON description used by tools; validate() remains authoritative."""

    def obj(properties, required=None):
        return dict(
            type="object",
            additionalProperties=False,
            properties=properties,
            required=list(properties) if required is None else required,
        )

    integer = dict(type="integer", minimum=1, maximum=1000000000)
    provider = dict(type="string", pattern="^[a-z][a-z0-9-]{0,63}$")
    model = dict(type="string", maxLength=200)
    pairs = dict(
        type="array", maxItems=128, items=obj(dict(provider=provider, model=model))
    )
    caps = obj(dict(tools=dict(type="string", enum=["required", "forbidden"])), [])
    health = obj(
        dict(
            respect_failures=dict(const=True),
            respect_cooldowns=dict(const=True),
            require_observed=dict(type="boolean"),
            max_age_seconds=integer,
        ),
        ["respect_failures", "respect_cooldowns", "require_observed"],
    )
    health.update(
        {
            "if": {"properties": {"require_observed": {"const": True}}},
            "then": {"required": ["max_age_seconds"]},
        }
    )
    from .policies import POLICY_OPTIONS, ALIASES

    return obj(
        dict(
            schema_version=dict(type="integer", const=1),
            hard_eligibility=obj(
                dict(
                    verified_free_only=dict(const=True),
                    required_capabilities=caps,
                    min_context=integer,
                    authorized_providers=dict(
                        type="array", maxItems=128, items=provider
                    ),
                    exclude=pairs,
                    max_in_flight=dict(anyOf=[integer, dict(type="null")]),
                    health=health,
                )
            ),
            preferences=obj(
                dict(
                    policy=dict(
                        type="string", enum=list(POLICY_OPTIONS) + list(ALIASES)
                    )
                )
            ),
            task_requirements=obj(
                dict(
                    schema_version=dict(type="integer", const=1),
                    label=dict(
                        type="string",
                        enum=["general", "coding", "fast-response", "explicit"],
                    ),
                    required_capabilities=caps,
                    min_context=integer,
                    profile=obj(dict(schema_version=dict(type="integer", const=1),
                        id=dict(type="string", enum=["general", "coding", "fast-response"]))),
                ),
                ["schema_version", "label", "required_capabilities", "min_context"],
            ),
            connection_restrictions=obj(
                dict(
                    provider_id=dict(anyOf=[provider, dict(type="null")]),
                    connection_id=dict(
                        type=["string", "null"], pattern="^[0-9a-f]{32}$"
                    ),
                    require_authority=dict(type="boolean"),
                    models=pairs,
                    shared_quota_scope=dict(
                        type=["string", "null"], pattern="^[0-9a-f]{32}$"
                    ),
                )
            ),
            quota_policy=dict(type="string", enum=list(QUOTA_MODES)),
        )
    )
