"""Dynamic capability resolution for AutoRouter v0.2.

Typed capability structures with provenance and freshness. Source precedence:
  1. explicit operator override (subject to safety/cost gates)
  2. authoritative provider metadata
  3. verified recent cached metadata
  4. trusted static metadata
  5. unknown (fail-closed for safety-critical decisions)
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional


class VerificationState(str, Enum):
    SUPPORTED = "supported"
    UNSUPPORTED = "unsupported"
    UNKNOWN = "unknown"
    TEMPORARILY_UNAVAILABLE = "temporarily_unavailable"


@dataclass
class CapabilityValue:
    value: Any
    source: str
    verified_at: float = 0.0
    expires_at: float = 0.0
    confidence: float = 0.0

    def is_expired(self, now: Optional[float] = None) -> bool:
        now = now if now is not None else time.time()
        return self.expires_at > 0 and now > self.expires_at


@dataclass
class ModelCapabilities:
    provider: str
    model: str
    context_window: Optional[int] = None
    max_output_tokens: Optional[int] = None
    tools: VerificationState = VerificationState.UNKNOWN
    structured_output: VerificationState = VerificationState.UNKNOWN
    input_modalities: list[str] = field(default_factory=list)
    cost_tier: str = "unknown"  # free|paid|premium|unknown
    metadata_source: str = "unknown"
    retrieved_at: float = 0.0
    expires_at: float = 0.0
    provenance: dict[str, str] = field(default_factory=dict)
    access_evidence: Optional[list[dict]] = None
    quota_evidence: Optional[list[dict]] = None

    def to_dict(self) -> dict:
        d = asdict(self)
        d["tools"] = self.tools.value
        d["structured_output"] = self.structured_output.value
        if self.access_evidence is None:
            d.pop("access_evidence")
        if self.quota_evidence is None:
            d.pop("quota_evidence")
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "ModelCapabilities":
        tools = d.get("tools", "unknown")
        so = d.get("structured_output", "unknown")
        try:
            tools = VerificationState(tools)
        except ValueError:
            tools = VerificationState.UNKNOWN
        try:
            so = VerificationState(so)
        except ValueError:
            so = VerificationState.UNKNOWN
        return cls(
            provider=d.get("provider", ""),
            model=d.get("model", ""),
            context_window=d.get("context_window"),
            max_output_tokens=d.get("max_output_tokens"),
            tools=tools,
            structured_output=so,
            input_modalities=list(d.get("input_modalities") or []),
            cost_tier=d.get("cost_tier", "unknown"),
            metadata_source=d.get("metadata_source", "unknown"),
            retrieved_at=float(d.get("retrieved_at") or 0.0),
            expires_at=float(d.get("expires_at") or 0.0),
            provenance=dict(d.get("provenance") or {}),
            quota_evidence=d.get("quota_evidence"),
            access_evidence=(d.get("access_evidence") if d.get("access_evidence") is not None else [])
            if "access_evidence" in d else None,
        )

    def is_expired(self, now: Optional[float] = None) -> bool:
        now = now if now is not None else time.time()
        return self.expires_at > 0 and now > self.expires_at


def resolve_capabilities(provider_meta: Optional[dict], cached: Optional[dict],
                        static: Optional[dict], override: Optional[dict] = None,
                        now: Optional[float] = None) -> ModelCapabilities:
    """Combine sources by precedence. Fail-closed on conflicts for safety-critical fields."""
    now = now if now is not None else time.time()
    # Expired sources cannot renew their own verification through resolution.
    sources = [provider_meta, cached, static]
    original = [src for src in sources if src]
    provider_meta, cached, static = [
        src if src and not (src.get("expires_at") and src["expires_at"] <= now) else None
        for src in sources
    ]
    prov = (provider_meta or {}).get("provider") or (cached or {}).get("provider") or (static or {}).get("provider") or ""
    model = (provider_meta or {}).get("model") or (cached or {}).get("model") or (static or {}).get("model") or ""

    caps = ModelCapabilities(provider=prov, model=model, retrieved_at=now)

    # context window: provider -> cached -> static
    for src in (provider_meta, cached, static):
        if src and src.get("context_window") is not None:
            caps.context_window = int(src["context_window"])
            caps.metadata_source = src.get("source", caps.metadata_source)
            break
    if override and override.get("context_window") is not None:
        caps.context_window = int(override["context_window"])
        caps.metadata_source = "override"

    # max output tokens
    for src in (provider_meta, cached, static):
        if src and src.get("max_output_tokens") is not None:
            caps.max_output_tokens = int(src["max_output_tokens"])
            break
    if override and override.get("max_output_tokens") is not None:
        caps.max_output_tokens = int(override["max_output_tokens"])

    # tools capability: conflicting evidence fails closed -> UNKNOWN
    tool_states = []
    for src in (provider_meta, cached, static):
        if src and src.get("tools") is not None:
            v = src["tools"]
            if isinstance(v, bool):
                tool_states.append(VerificationState.SUPPORTED if v else VerificationState.UNSUPPORTED)
            else:
                try:
                    tool_states.append(VerificationState(v))
                except ValueError:
                    tool_states.append(VerificationState.UNKNOWN)
    # override can set
    if override and override.get("tools") is not None:
        v = override["tools"]
        if isinstance(v, bool):
            tool_states = [VerificationState.SUPPORTED if v else VerificationState.UNSUPPORTED]
        else:
            try:
                tool_states = [VerificationState(v)]
            except ValueError:
                tool_states = [VerificationState.UNKNOWN]

    if not tool_states:
        caps.tools = VerificationState.UNKNOWN
    else:
        # if any UNSUPPORTED present alongside SUPPORTED -> fail closed UNKNOWN
        has_sup = VerificationState.SUPPORTED in tool_states
        has_uns = VerificationState.UNSUPPORTED in tool_states
        if has_sup and has_uns:
            caps.tools = VerificationState.UNKNOWN
        else:
            caps.tools = tool_states[0]

    # structured output
    for src in (provider_meta, cached, static, override):
        if src and src.get("structured_output") is not None:
            v = src["structured_output"]
            if isinstance(v, bool):
                caps.structured_output = VerificationState.SUPPORTED if v else VerificationState.UNSUPPORTED
            else:
                try:
                    caps.structured_output = VerificationState(v)
                except ValueError:
                    caps.structured_output = VerificationState.UNKNOWN
            break

    # input modalities
    for src in (provider_meta, cached, static):
        if src and src.get("input_modalities"):
            caps.input_modalities = list(src["input_modalities"])
            break
    if override and override.get("input_modalities"):
        caps.input_modalities = list(override["input_modalities"])

    # cost tier: provider authoritative; override cannot make paid free
    for src in (provider_meta, cached, static):
        if src and src.get("cost_tier") and src["cost_tier"] != "unknown":
            caps.cost_tier = src["cost_tier"]
            break
    if override and override.get("cost_tier"):
        # safety: never downgrade paid to free via override
        if caps.cost_tier in ("paid", "premium") and override["cost_tier"] == "free":
            pass
        else:
            caps.cost_tier = override["cost_tier"]

    # Preserve scoped access proof through the typed resolver and deny conflicting claims.
    records = [src["access_evidence"] for src in original if "access_evidence" in src]
    if records:
        from ..evidence.evidence import access_allowed
        caps.access_evidence = [record for group in records if isinstance(group, list) for record in group]
        if any(not isinstance(group, list) for group in records) or not access_allowed(
                caps.access_evidence, prov, model, now):
            caps.cost_tier = "unknown"

    quota_records = [src["quota_evidence"] for src in original if "quota_evidence" in src]
    if quota_records:
        from ..evidence.quota import normalize_quota
        caps.quota_evidence = [normalize_quota(record) for group in quota_records
                               if isinstance(group, list) for record in group]

    # availability / retired handling: provider saying unavailable overrides positive cache
    if provider_meta and provider_meta.get("available") is False:
        caps.tools = VerificationState.TEMPORARILY_UNAVAILABLE
        caps.metadata_source = provider_meta.get("source", caps.metadata_source)

    # provenance
    caps.provenance = {
        "provider_meta": (provider_meta or {}).get("source", "none"),
        "cached": (cached or {}).get("source", "none"),
        "static": (static or {}).get("source", "none"),
        "override": "operator" if override else "none",
    }

    # freshness
    ttl = 86400.0
    if provider_meta:
        ttl = float(provider_meta.get("ttl", ttl))
    timestamps = [src.get("retrieved_at") for src in (provider_meta, cached, static) if src and src.get("retrieved_at")]
    expirations = [src.get("expires_at") for src in (provider_meta, cached, static) if src and src.get("expires_at")]
    caps.retrieved_at = min(timestamps) if timestamps else (0 if original else now)
    caps.expires_at = min(expirations) if expirations else (now if original else now + ttl)

    return caps
