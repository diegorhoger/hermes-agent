"""Native pre-inference routing consumer contract (issue #104).

Hermes v0.23.1 has NO sanctioned extension point that lets a plugin choose the
provider/model for an ordinary session before the client is built:

* plugin ``llm_request`` / ``llm_execution`` middleware rewrite request payloads
  or wrap execution — neither can rebuild the provider client, swap credentials,
  or rebind the profile, so they cannot legitimately re-route a session;
* ``on_session_open`` / ``pre_api_request`` and friends are observers and
  cannot affect execution;
* nothing in the host calls ``invoke_middleware("pre_inference_route", ...)``.

This module implements the AutoRouter half of the documented contract in
``docs/internal/hermes-native-routing-contract.md``. When a future host exposes
``pre_inference_route`` (or an equivalent sanctioned pre-inference selection
seam), an operator flips one opt-in flag and ordinary sessions route through
the canonical AutoRouter selector — same hard gates, fail-closed semantics,
per-session profile binding and honest receipts as the virtual-model path.

Registering the consumer is a no-op until such a host exists:
``detect_host_native_routing()`` reports the missing capability and
``register_if_supported()`` logs loudly instead of pretending ordinary sessions
are routed. Nothing here monkey-patches the host.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import logging
import time
from typing import Any, Optional

from . import _route_resolution

logger = logging.getLogger(__name__)

CONTRACT_VERSION = 1
EXTENSION_KIND = "pre_inference_route"
SETTING_FLAG = "enable_native_routing"
_BINDING_KEY = "native_route_binding:"

_KEY_LIKE = ("sk-", "sk_", "bearer ", "api_key=", "api-key=", "ghp_", "gho_", "github_pat_",
             "nvapi-", "hf_")

# ---------------------------------------------------------------------------
# Capability detection (read-only; imports the host lazily and never raises)
# ---------------------------------------------------------------------------

def detect_host_native_routing() -> dict[str, Any]:
    """Probe the host for a sanctioned pre-inference route extension.

    Returns a structured, sanitizable report. ``supported`` is true only when
    the host exposes the contract's extension kind; anything else is UNKNOWN,
    never assumed supported.
    """
    signals: list[str] = []
    host_version: Optional[str] = None
    try:
        hermes_cli = importlib.import_module("hermes_cli")

        host_version = getattr(hermes_cli, "__version__", None)
    except Exception:
        host_version = None

    supported = False
    try:
        mw = importlib.import_module("hermes_cli.middleware")

        valid = getattr(mw, "VALID_MIDDLEWARE", set()) or set()
        marker = getattr(mw, "PRE_INFERENCE_ROUTE_MIDDLEWARE", None)
        marker_present = marker == EXTENSION_KIND or EXTENSION_KIND in valid
        # The middleware kind is only usable when the host also ships a
        # callable entry point; a bare string in VALID_MIDDLEWARE is not a
        # contract. Detection requires both where possible.
        entry = getattr(mw, "apply_pre_inference_route_middleware", None)
        if marker_present and callable(entry):
            supported = True
            signals.append(f"hermes_cli.middleware:{marker or EXTENSION_KIND}+apply_pre_inference_route_middleware")
        elif marker_present:
            signals.append(
                "hermes_cli.middleware:marker present without callable "
                "apply_pre_inference_route_middleware (not treated as supported)"
            )
    except Exception:
        pass
    try:
        hp = importlib.import_module("hermes_cli.plugins")

        hooks = getattr(hp, "VALID_HOOKS", set()) or set()
        if EXTENSION_KIND in hooks:
            supported = True
            signals.append(f"hermes_cli.plugins.VALID_HOOKS:{EXTENSION_KIND}")
    except Exception:
        pass
    return {
        "supported": bool(supported),
        "extension_kind": EXTENSION_KIND,
        "contract_version": CONTRACT_VERSION,
        "signals": signals,
        "host_version": host_version,
        "reason": None if supported else (
            "host exposes no sanctioned pre-inference route extension; ordinary sessions are NOT auto-routed"
        ),
    }


def _read_settings_from_config() -> dict[str, Any]:
    """Best-effort enablement read for the plugin LOAD path. Returns ``{}`` on
    any failure — an unreadable source means 'not opted in', which keeps the
    load-time gate closed (nothing registered) rather than refusing. The
    per-attempt resolver path revalidates strictly and refuses instead."""
    settings, error = _route_resolution.read_autorouter_settings()
    if error is not None:
        logger.warning("autorouter: plugin settings unreadable for enablement (%s); routing gate stays closed",
                       error)
        return {}
    return dict(settings or {})


def _overlay_settings(settings):
    """Tri-state overlay for the per-attempt path.

    ``(settings-dict, None)`` when the source is structurally readable,
    ``(None, error)`` otherwise. Callers refuse on error — an unreadable
    source must never reach selection."""
    if settings is not None:
        if isinstance(settings, dict):
            return settings, None
        return None, "invalid settings shape"
    return _route_resolution.read_autorouter_settings()


def _merged_settings(settings: Optional[dict[str, Any]]) -> Optional[dict[str, Any]]:
    """Operator/test settings layered over the fail-closed engine defaults.

    ``settings`` is the already-validated snapshot for this attempt; the
    derived engine defaults are recomputed from the **same** dict so no two
    reads may diverge inside one attempt."""
    if settings is None:
        # Fallback for direct unit callers that inject no snapshot. Still
        # one strict read; never a re-read across the boundary.
        snap, error = _route_resolution.read_autorouter_settings()
        if error is not None:
            return None
        settings = snap or {}
    # Canonical restriction fields (model_mode, model_include_pairs,
    # model_exclude_pairs, min_context, cooldown_seconds, requires_tools,
    # policy) come from the validated/normalized derivation ONLY. Raw config
    # keys that collide with or attempt to override them are dropped.
    return _route_resolution._derive_routing_settings(settings)


def is_enabled(settings: Optional[dict[str, Any]] = None) -> bool:
    """Strict boolean opt-in for automatic ordinary-session routing (MODE B).

    Anything unreadable is disabled.
    """
    overlay = settings if settings is not None else _read_settings_from_config()
    return isinstance(overlay, dict) and overlay.get(PRIMARY_FLAG) is True and overlay.get(SETTING_FLAG) is True


PRIMARY_FLAG = "enabled"


CHAT_ROUTER_SETTING = "enable_chat_router"


def is_chat_router_enabled(settings: Optional[dict[str, Any]] = None) -> bool:
    """Strict boolean opt-in for an explicit model-picker selection (MODE A).

    Independent from MODE B on purpose: enabling MODE B never authorizes an
    ordinary session to route for this flag, and MODE A only authorizes the
    explicit ``autorouter/auto-free`` pick path.
    """
    overlay = settings if settings is not None else _read_settings_from_config()
    return isinstance(overlay, dict) and overlay.get(PRIMARY_FLAG) is True and overlay.get(CHAT_ROUTER_SETTING) is True


# ---------------------------------------------------------------------------
# Session binding (non-reversible meta keys; never raw session ids)
# ---------------------------------------------------------------------------

def _session_key(session_id: str) -> str:
    return _BINDING_KEY + hashlib.sha256(session_id.strip().encode("utf-8")).hexdigest()[:24]


def _session_hash(session_id: str) -> str:
    return hashlib.sha256(session_id.strip().encode("utf-8")).hexdigest()[:12]


def _store(store_dir):
    router_mod, state_mod = _route_resolution.load_engine()
    if state_mod is None:
        return None, "auto-router engine unavailable"
    try:
        return state_mod.StateStore(store_dir), None
    except Exception as exc:
        return None, f"invalid AutoRouter catalog: {exc}"


BINDING_ABSENT = "absent"
BINDING_VALID = "valid"
BINDING_ERROR = "error"

_BINDING_STATES = (BINDING_ABSENT, BINDING_VALID, BINDING_ERROR)


def _row_value(row):
    try:
        return row["value"]
    except Exception:
        try:
            return row[0]
        except Exception:
            return None


def _valid_route_provider(provider: Any) -> bool:
    import re
    return isinstance(provider, str) and bool(re.match(r"^[a-z0-9][a-z0-9-]{0,63}$", provider))


def _validate_binding(data: Any) -> Optional[dict[str, Any]]:
    """Return a sanitized binding dict, or None if it is unusable.

    A persisted binding that fails any of these checks MUST be treated as
    corrupt — never as 'no binding'.
    """
    if not isinstance(data, dict):
        return None
    profile_id = data.get("profile_id")
    if not isinstance(profile_id, str) or not profile_id.startswith("rp_"):
        return None
    profile_name = data.get("profile_name")
    if profile_name is not None and not isinstance(profile_name, str):
        return None
    provider = data.get("provider")
    if not _valid_route_provider(provider):
        return None
    model = data.get("model")
    if not isinstance(model, str):
        return None
    model = model.strip()
    if not model or len(model) > 199:
        return None
    lowered = model.lower()
    if any(fragment in lowered for fragment in _KEY_LIKE):
        return None
    bound_at = data.get("bound_at")
    if not isinstance(bound_at, (int, float)) or isinstance(bound_at, bool):
        return None
    return {
        "profile_id": profile_id,
        "profile_name": profile_name,
        "provider": provider.strip().lower(),
        "model": model,
        "bound_at": float(bound_at),
        **({"v": data["v"]} if isinstance(data.get("v"), int) else {}),
    }


def read_binding_state(store_dir, session_id: str) -> tuple[str, Optional[dict[str, Any]]]:
    """Tri-state binding read.

    Returns ``(BINDING_ABSENT, None)`` when no binding is persisted,
    ``(BINDING_VALID, binding)`` when a persisted binding passes validation,
    and ``(BINDING_ERROR, None)`` otherwise. Never raises; unreadable and
    corrupt bindings are indistinguishable from each other ON PURPOSE — both
    mean 'cannot establish consistency', which the caller MUST treat as
    refuse-before-network.
    """
    store, _err = _store(store_dir)
    if store is None:
        return BINDING_ERROR, None
    try:
        conn = store._connect()
        try:
            row = conn.execute("SELECT value FROM meta WHERE key = ?", (_session_key(session_id),)).fetchone()
        finally:
            conn.close()
    except Exception:
        return BINDING_ERROR, None
    if not row:
        return BINDING_ABSENT, None
    try:
        data = json.loads(_row_value(row))
    except Exception:
        return BINDING_ERROR, None
    binding = _validate_binding(data)
    if binding is None:
        return BINDING_ERROR, None
    return BINDING_VALID, binding


def read_binding(store_dir, session_id: str) -> Optional[dict[str, Any]]:
    """Compatibility wrapper: the persisted binding, or None.

    Prefer read_binding_state() — this wrapper deliberately conflates absent
    and error so legacy callers can never mistake an unreadable binding for a
    missing one. New code MUST use the tri-state form.
    """
    state, binding = read_binding_state(store_dir, session_id)
    return binding if state == BINDING_VALID else None


def _binding_matches(binding: Optional[dict[str, Any]], result: Optional[dict[str, Any]]) -> bool:
    if not isinstance(binding, dict) or not isinstance(result, dict):
        return False
    return (binding.get("profile_id") == result.get("profile_id")
            and binding.get("provider") == result.get("provider")
            and binding.get("model") == result.get("model"))


def write_binding(store_dir, session_id: str, binding: dict[str, Any]) -> str:
    """First-route-wins atomic claim.

    Returns ``"won"`` when this call persisted the binding, ``"lost"`` when a
    conflicting first route already persisted its own binding (ours was NOT
    written and MUST NOT be written), and ``"error"`` when persistence could
    not be established. Callers MUST read back and validate the authoritative
    persisted binding after this call and MUST refuse on ``"error"``.
    """
    store, _err = _store(store_dir)
    if store is None:
        return "error"
    try:
        payload = json.dumps({
            "v": 1,
            "profile_id": binding.get("profile_id"),
            "profile_name": binding.get("profile_name"),
            "provider": binding.get("provider"),
            "model": binding.get("model"),
            "bound_at": time.time(),
        }, sort_keys=True)
        conn = store._connect()
        try:
            cur = conn.execute("INSERT OR IGNORE INTO meta(key, value) VALUES (?, ?)",
                               (_session_key(session_id), payload))
            rowcount = getattr(cur, "rowcount", -1)
            conn.commit()
        finally:
            conn.close()
        if rowcount == 1:
            return "won"
        if rowcount == 0:
            return "lost"
        return "error"
    except Exception:
        return "error"


# ---------------------------------------------------------------------------
# Contract output helpers
# ---------------------------------------------------------------------------

def _sanitize(value: Any) -> Any:
    """Defense in depth: the contract may never carry credential-like material.

    Any string carrying a known key shape collapses to ``"[redacted]"``."""
    if isinstance(value, str):
        lowered = value.lower()
        if any(fragment in lowered for fragment in _KEY_LIKE):
            return "[redacted]"
        return value
    if isinstance(value, dict):
        return {str(k): _sanitize(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_sanitize(v) for v in value]
    return value


def _envelope(status: str, reason: str, *, provider=None, model=None, route_profile=None,
              session_hash=None, policy=None, refusal=None) -> dict[str, Any]:
    out = {
        "contract_version": CONTRACT_VERSION,
        "status": status,           # 'passthrough' | 'route' | 'refuse'
        "provider": provider,
        "model": model,
        "route_profile": route_profile,
        "evidence_ts": time.time(),
        "reason": reason,
        "receipt": {
            "schema_version": 1,
            "plugin": "autorouter",
            "decision": status,
            "route": ({"provider": provider, "model": model} if provider and model else None),
            "route_profile": route_profile,
            "policy": policy,
            "session": session_hash,
            "refusal": refusal,
        },
    }
    out["receipt"]["evidence_ts"] = out["evidence_ts"]
    return _sanitize(out)


def _route(result: dict[str, Any], session_hash, *, store_dir) -> dict[str, Any]:
    profile = {"id": result.get("profile_id"), "name": result.get("profile_name")} \
        if result.get("profile_id") else None
    provider, model = result.get("provider"), result.get("model")
    out = _envelope("route", "selected via canonical AutoRouter selection",
                    provider=provider, model=model, route_profile=profile,
                    session_hash=session_hash, policy=result.get("policy"))
    # Best-effort decision ledger entry; never changes the outcome.
    try:
        store, err = _store(store_dir) if store_dir is not None else (None, None)
        if store is not None:
            store.record_decision(policy=str(result.get("policy") or "auto"),
                                  provider=provider, model=model,
                                  reason="pre_inference_route", candidates=1)
    except Exception:
        pass
    return out


def _refuse(result: dict[str, Any], session_hash, binding) -> dict[str, Any]:
    reason = str(result.get("error") or "unknown")
    profile = ({"id": binding.get("profile_id"), "name": binding.get("profile_name")}
               if isinstance(binding, dict) else None)
    return _envelope("refuse", reason, route_profile=profile,
                     session_hash=session_hash, policy=result.get("policy"),
                     refusal=reason)


# ---------------------------------------------------------------------------
# Consumer entry point (invoked by the host's pre_inference_route middleware)
# ---------------------------------------------------------------------------

def resolve_consumer_route(*, metadata: Any, store_dir=None, providers=None, settings=None,
                           engine_loader=None, profiles_loader=None) -> dict[str, Any]:
    """Resolve a pre-inference route for one ordinary session.

    Never raises and never opens a socket. ``metadata`` is the host's NON-SECRET
    context. Every failure is a ``refuse`` the host must honor by stopping
    before any provider request is built. A ``passthrough`` (opt-in flag off)
    tells the host to proceed exactly as if this consumer were absent — it is
    not a routing decision.
    """
    overlay, overlay_error = _overlay_settings(settings)
    if overlay_error is not None:
        # Unreadable source is not a valid omission: the consumer MUST refuse
        # (never route, never silently passthrough into a possibly-permissive
        # stock route while a restrictive policy may have been active).
        session_hash = None
        sid_hint = metadata.get("session_id") if isinstance(metadata, dict) else None
        if isinstance(sid_hint, str) and sid_hint.strip():
            session_hash = _session_hash(sid_hint)
        return _envelope("refuse", "the routing configuration is unreadable; refusing to route",
                         session_hash=session_hash, policy=None)
    if not isinstance(metadata, dict):
        return _envelope("refuse", "metadata_not_an_object")

    # MODE A (manual) carries an explicit pick through the same resolver; MODE B
    # (automatic) keeps its independent, ordinary-session gate.
    # ``resolve_consumer_route`` only runs when a consumer is registered on
    # this host (plugin enabled at load). Therefore any configuration that
    # disables the plugin at attempt time is *revocation* — fail closed.
    manual_mode = isinstance(metadata, dict) and metadata.get("selection_mode") == "manual"
    if overlay.get(PRIMARY_FLAG) is not True:
        # The consumer only runs on a host where it was registered under
        # enabled: True. Anything other than literal True afterwards —
        # revoked (False), missing, null, numeric, string, or a different
        # falsy/truthy value — is revocation territory: refuse before any
        # client construction. Unchanged: never-registered hosts never call
        # this path at all (documented disabled-by-default semantics).
        logger.warning("autorouter: primary enabled flag is not literal True; refusing to route")
        return _envelope("refuse", "the AutoRouter plugin is not enabled on this host; refusing to route")
    if manual_mode:
        if not is_chat_router_enabled(overlay):
            return _envelope("passthrough", "chat_router_disabled")
    elif not is_enabled(overlay):
        # The automatic consumer is not opted in: host proceeds stock.
        # (Documented opt-out — the flag was true for MODE A gate purposes
        # but never engaged for ordinary sessions; nothing routes.)
        return _envelope("passthrough", "native_routing_disabled")

    session_id = metadata.get("session_id")
    session_id = session_id.strip() if isinstance(session_id, str) else ""
    if not session_id:
        # Without a stable session binding the isolation contract cannot be
        # honored — refuse rather than route anonymously.
        return _envelope("refuse", "missing_session_binding")

    merged = _merged_settings(overlay)
    store_dir = store_dir or _route_resolution.profile_store_dir()
    # The authorization set is derived from the same validated snapshot —
    # one read per attempt, no interleaving of a different configuration.
    if providers is None:
        providers = _route_resolution.authorized_providers_from(overlay)
    session_hash = _session_hash(session_id)
    if merged is None:
        # The routing configuration could not be established. Refuse before
        # any store access — a failure is never a permissive default.
        return _refuse({"error": "the routing configuration is unreadable; refusing to route",
                        "policy": None}, session_hash, None)
    if not providers:
        return _refuse({"error": "no authorized provider under the current authorization; refusing to route",
                        "policy": merged.get("policy")}, session_hash, None)

    def _refuse_reason(reason: str, binding=None):
        return _refuse({"error": reason, "policy": merged.get("policy")}, session_hash, binding)

    state, existing = read_binding_state(store_dir, session_id) if store_dir is not None else (BINDING_ERROR, None)
    if state == BINDING_ERROR:
        # Unreadable or corrupt persisted binding: consistency cannot be
        # established, so the route MUST NOT widen to any default.
        return _refuse_reason(
            "the session routing binding is unreadable or corrupt; refusing to route "
            "rather than widen to any default")

    if state == BINDING_VALID:
        binding = existing
        result = _route_resolution.resolve_route_detailed(
            store_dir=store_dir, providers=providers, settings=merged,
            engine_loader=engine_loader, profiles_loader=profiles_loader,
            bound_profile_id=binding.get("profile_id"))
        if result.get("error"):
            return _refuse(result, session_hash, binding)
        return _route(result, session_hash, store_dir=store_dir)

    # Absent binding: select under the current global policy, then make the
    # first-route-wins claim atomic and prove it against the persisted state.
    result = _route_resolution.resolve_route_detailed(
        store_dir=store_dir, providers=providers, settings=merged,
        engine_loader=engine_loader, profiles_loader=profiles_loader)
    if result.get("error"):
        return _refuse(result, session_hash, None)

    if not result.get("profile_id"):
        # Global-policy route (no user-created default profile): unpinned by
        # design; resumed sessions follow the current default. Documented in
        # the contract; no binding is persisted.
        return _route(result, session_hash, store_dir=store_dir)

    claim = write_binding(store_dir, session_id, {
        "profile_id": result.get("profile_id"),
        "profile_name": result.get("profile_name"),
        "provider": result.get("provider"),
        "model": result.get("model"),
    })
    if claim == "error":
        # A failed binding write MUST refuse — never return a route whose
        # session consistency cannot be persisted.
        return _refuse_reason(
            "failed to persist the session routing binding; refusing to route "
            "without consistency")

    state, persisted = read_binding_state(store_dir, session_id)
    if state != BINDING_VALID:
        # The binding we were responsible for is missing or corrupt after our
        # claim; the persisted state cannot prove session consistency.
        return _refuse_reason(
            "the session routing binding is missing or unreadable after persistence; "
            "refusing to route")
    if claim == "won":
        if not _binding_matches(persisted, result):
            # Our insert was authoritative yet the persisted row does not match
            # what we selected — treat as corruption, never as routeable.
            return _refuse_reason(
                "the persisted session binding does not match the selected route; "
                "refusing to route", persisted)
        return _route(result, session_hash, store_dir=store_dir)

    # claim == "lost": a racing first route persisted a conflicting binding.
    # It MUST NOT be replaced — follow the authoritative persisted binding.
    winner = _route_resolution.resolve_route_detailed(
        store_dir=store_dir, providers=providers, settings=merged,
        engine_loader=engine_loader, profiles_loader=profiles_loader,
        bound_profile_id=persisted["profile_id"])
    if winner.get("error"):
        return _refuse(winner, session_hash, persisted)
    return _route(winner, session_hash, store_dir=store_dir)


def register_if_supported(ctx, *, settings=None) -> dict[str, Any]:
    """Register the consumer middleware when — and only when — both the host
    exposes the contract AND the operator opted in. Returns the detection
    report for the caller's log line."""
    overlay = settings if settings is not None else _read_settings_from_config()
    detection = detect_host_native_routing()
    native_on = is_enabled(overlay)
    chat_router_on = is_chat_router_enabled(overlay)
    if not (native_on or chat_router_on):
        return {**detection, "registered": False, "enabled": False}
    if not detection["supported"]:
        logger.warning(
            "autorouter: a sanctioned pre_inference_route extension is required but this "
            "Hermes (%s) does not expose one; routing stays OFF",
            detection.get("host_version") or "unknown host",
        )
        return {**detection, "registered": False, "enabled": True,
                "native_routing": native_on, "chat_router": chat_router_on}
    try:
        ctx.register_middleware(EXTENSION_KIND,
                                lambda **kwargs: resolve_consumer_route(metadata=kwargs))
    except Exception:
        logger.warning("autorouter: host exposes the contract but consumer registration failed",
                       exc_info=True)
        return {**detection, "registered": False, "enabled": True,
                "native_routing": native_on, "chat_router": chat_router_on}
    return {**detection, "registered": True, "enabled": True,
            "native_routing": native_on, "chat_router": chat_router_on}
