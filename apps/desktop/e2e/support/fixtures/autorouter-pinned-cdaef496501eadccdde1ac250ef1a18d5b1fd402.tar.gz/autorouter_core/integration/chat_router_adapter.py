"""DEPRECATED — legacy compatibility adapter for AutoRouter as a native chat-router.

Not activated automatically anywhere in this repository. Kept for the
documented v0.1 patch-candidate workflow (tools/routing_proof.py) and for
regression coverage. The supported MODE A path on any sanctioned-capable host
is the native ``pre_inference_route`` consumer (issue #116 / ADR-0015); on a
host without that seam, MODE A is simply unavailable — this adapter is never
installed from the plugin entrypoint.

Local-host compatibility adapter for AutoRouter as a native chat-router.

The AutoRouter plugin remains *headless*: it registers tools, hooks and the
five-tab dashboard. It does NOT modify Hermes' core. Hermes v0.23.1 has no
sanctioned plugin extension point for (a) injecting a picker provider row or
(b) intercepting/redirecting a model switch in-flight. Both would require a
core change (Nous) or a source patch to local Hermes.

This module is the smallest isolated, REVERSIBLE compatibility adapter for a
LOCAL host. It is version-gated, opt-in, and disabled by default. It routes
the AutoRouter virtual model through Hermes' **sanctioned** provider path by
interposing on Hermes functions. Every interposition is marker-wrapped so
``disable()`` can unwind *all* of them back to the original bindings:

  1. ``hermes_cli.model_switch_providers.list_authenticated_providers`` and
     ``list_picker_providers`` (the inventory picker build) -- inject an
     "AutoRouter" provider row whose model is the virtual marker
     ``autorouter/auto-free`` ("Auto (Free)").
  2. ``hermes_cli.model_switch_providers.list_picker_providers`` (the
     interactive picker's provider-listing path; gateway ``/model`` calls it
     by a call-time ``from hermes_cli.model_switch_providers import
     list_picker_providers``) -- the definition site. Hermes v0.23.1 does NOT
     import ``list_picker_providers`` into ``hermes_cli.model_switch`` (there
     is nothing to patch there); the classic CLI and gateway text fallbacks
     import ``list_authenticated_providers`` from
     ``hermes_cli.model_switch`` directly.
  3. ``hermes_cli.model_switch.list_authenticated_providers`` -- the
     *from-import* binding of the inventory function that the picker and
     inventory call sites import at call time.
  4. ``hermes_cli.model_switch.switch_model`` (the core model-switching
     pipeline shared by CLI, TUI and gateway) -- when the chosen model is the
     virtual marker, resolve it through the AutoRouter selector and call the
     original pipeline with the *resolved* route; the sanctioned pipeline then
     commits that route.
  4. ``hermes_cli.model_switch.resolve_startup_model_route`` (the startup
     route lookup used by ``-m/--model`` at session create) -- same
     resolution before any provider request is built. On resolution failure
     the wrapper returns an empty route, which the host's own policy check
     rejects *before* any network execution.
  5. ``agent.agent_runtime_helpers.switch_model`` (the live in-place agent
     swap) -- same resolution for direct live-agent switches.
  6. ``agent.agent_init.init_agent`` -- resolves a virtual startup model
     before the client is built (defense in depth).

All interposition is gated by
``plugins.entries.autorouter.settings.enable_chat_router: true`` (default
false) and can be reverted by ``disable()``, which restores **every modified
binding** to its pre-adapter original, or by removing the flag + the loader.
It mutates nothing but a Python-level wrapper; the host SOURCE is never
written. It never reads raw secrets: provider selection draws only from the
Hermes provider inventory + the AutoRouter profile store.

This module is a *candidate* for a local-host voluntary patch. It is NOT
loaded by default and is NOT applied to production Hermes. It is expected to
be loaded through the sanctioned plugin loader (the plugin's ``register()``
does this when the opt-in flag is set) or by the user applying the one-line
loader. If loading fails for any reason the plugin logs a warning. Be aware:
the adapter is what makes the virtual marker resolvable; without it (or when a
patch target has moved in a Hermes upgrade) nothing rewrites the marker, so a
launch that pins ``autorouter/auto-free`` sends that string as the model id.
With the adapter loaded, every resolution failure refuses *before* network
execution (see ``_resolve_virtual`` / the interposed wrappers).

IMPORTANT — engine loading:
----------------
The AutoRouter engine ships as the plugin package itself. The Hermes plugin
loader imports the plugin as ``hermes_plugins.autorouter`` (profile-scoped
digest names are possible), so the adapter loads the engine **relative to
its own package** (``from . import router`` / ``from . import state``),
which resolves to the exact modules the plugin loader already loaded. No
``sys.path`` additions, no ``sys.modules`` eviction. When imported outside
that package (the test shell registers ``autorouter``), it falls back to the
absolute ``autorouter`` import.
"""
from __future__ import annotations

import functools
import logging
import sys
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("autorouter.chat_router_adapter")

VIRTUAL_MODEL = "autorouter/auto-free"
VIRTUAL_PROVIDER = "autorouter"
ADAPTER_FLAG_KEY = "enable_chat_router"

# Cache of checked flag so we only read config once per process.
_flag_checked = False
_flag_cache = False

# Hermes SwitchModelResult / StartupModelRoute types (used by the adapter
# interceptors below). Imported lazily with a hard fallback: this module must
# stay importable in environments where Hermes is not on the path, and the
# fail-closed paths must still work (they refuse / raise rather than leak the
# virtual model).
try:
    from hermes_cli.model_switch import ModelSwitchResult, StartupModelRoute
except Exception:  # pragma: no cover - host absent or moved
    ModelSwitchResult = None
    StartupModelRoute = None


def _is_enabled() -> bool:
    """Return True only when the opt-in adapter flag is set true in config."""
    global _flag_checked, _flag_cache
    if _flag_checked:
        return _flag_cache
    try:
        from hermes_cli.config import load_config_readonly

        cfg = load_config_readonly() or {}
        entry = cfg.get("plugins", {}).get("entries", {}).get("autorouter", {})
        settings = entry.get("settings", {}) if isinstance(entry, dict) else {}
        value = settings.get(ADAPTER_FLAG_KEY, False)
    except Exception:
        value = False
    _flag_checked = True
    _flag_cache = bool(value)
    return _flag_cache


# Backwards-compatible alias (the plugin loader reads this name).
_flag_enabled = _is_enabled


def _host_interceptions_installed() -> Optional[bool]:
    """True when the adapter's host interception is installed in this process.

    Verified by the marker the adapter sets on the wrapped ``switch_model``
    binding — i.e. the same binding the chat-router route and the /model
    pipeline share. Returns ``None`` when the marker cannot be observed
    (host absent, import failure), so callers can report ``unknown`` instead
    of guessing.
    """
    try:
        import hermes_cli.model_switch as _ms

        return bool(getattr(_ms.switch_model, "_ar_patched", False))
    except Exception:
        return None


def runtime_activation_status() -> dict[str, Any]:
    """Truthful activation status for the dashboard.

    This function runs inside one process (usually the plugin dashboard
    process). It can observe **that process only**: whether the adapter is
    interposed *here*, and what the persisted ``enable_chat_router`` says. It
    cannot truthfully report what a *separate* chat gateway process decided
    since this process started — the gateway applies the persisted flag when
    its own plugin registry loads, not retroactively.

    Returned states (``scope`` always present):

    - ``active``              — configured ON, adapter interposed in **this
                                process only**; the chat gateway process
                                reports its own state (it usually shares this
                                code, but that is not proven from here).
                               Restart the gateway (or reload the plugin) if
                               the flag changed after startup.
    - ``restart_required``    — configured ON but this process does not have
                                the adapter installed, or configured OFF but
                                this process still holds the adapter — a
                                restart/reload is needed for the
                                configured/actual states to converge.
    - ``inactive``            — configured OFF, adapter absent in this process.
    - ``unknown``             — the probe could not observe the state;
                                restart/reload and re-check.
    """
    configured = _is_enabled()
    marker = _host_interceptions_installed()
    if marker is True and configured is True:
        return {
            "configured": True,
            "runtime": "active",
            "scope": "process_local",
            "detail": (
                "Chat routing is enabled and the adapter is interposed in this process only. "
                "The chat gateway is a separate process; it honors this setting on its next "
                "start or plugin reload."
            ),
        }
    if marker is True and configured is False:
        return {
            "configured": False,
            "runtime": "restart_required",
            "scope": "process_local",
            "detail": (
                "Chat routing is disabled in configuration but this process still has the "
                "adapter installed; restart the gateway or reload the plugin for the "
                "configured/actual states to converge."
            ),
        }
    if marker is False and configured is True:
        return {
            "configured": True,
            "runtime": "restart_required",
            "scope": "process_local",
            "detail": (
                "Chat routing is enabled in configuration but is not active in this process; "
                "restart the gateway or reload the plugin for the setting to take effect."
            ),
        }
    if marker is False and configured is False:
        return {
            "configured": False,
            "runtime": "inactive",
            "scope": "process_local",
            "detail": "Chat routing is disabled in configuration.",
        }
    return {
        "configured": bool(configured),
        "runtime": "unknown",
        "scope": "unknown",
        "detail": (
            "Runtime activation cannot be determined from this process; "
            "reload the plugin or restart the gateway and re-check."
        ),
    }


def _mark(wrapper, original):
    """Mark a wrapper so ``disable()`` can recognize and unwind it."""
    wrapper._ar_patched = True
    wrapper._ar_original = original
    return wrapper


def _unpatch_ours(mod, attr: str) -> bool:
    """Restore the pre-adapter binding for ``attr`` on ``mod``.

    Unwinds every layer this adapter installed (marked with ``_ar_patched``),
    stopping at the first foreign binding so a later, unrelated patch is never
    clobbered. Returns True when a binding was restored.
    """
    restored = False
    try:
        cur = getattr(mod, attr, None)
        while getattr(cur, "_ar_patched", False):
            original = getattr(cur, "_ar_original", None)
            if original is None:
                break
            setattr(mod, attr, original)
            restored = True
            cur = getattr(mod, attr, None)
    except Exception:
        logger.debug("autorouter adapter: could not restore %s.%s", getattr(mod, "__name__", "?"), attr,
                     exc_info=True)
    return restored


def _module(name: str):
    try:
        import importlib

        return importlib.import_module(name)
    except Exception:
        return None


# Bindings the adapter patches, as (module name, attribute) pairs. ``disable()``
# restores every one of them; tests iterate this same table to prove the
# restore covers all modified bindings.
_PATCH_TARGETS = (
    ("hermes_cli.model_switch_providers", "list_authenticated_providers"),
    ("hermes_cli.model_switch_providers", "list_picker_providers"),
    ("hermes_cli.model_switch", "list_authenticated_providers"),
    ("hermes_cli.model_switch", "switch_model"),
    ("hermes_cli.model_switch", "resolve_startup_model_route"),
    ("agent.agent_runtime_helpers", "switch_model"),
    ("agent.agent_init", "init_agent"),
)

# ---------------------------------------------------------------------------
# Interposition implementations
# ---------------------------------------------------------------------------

def _inject_autorouter_row(providers: list) -> list:
    """Insert the AutoRouter provider row into the picker provider list."""
    if any(str(p.get("slug", "")) == VIRTUAL_PROVIDER for p in providers):
        return providers
    return providers + [
        {
            "slug": VIRTUAL_PROVIDER,
            "name": "AutoRouter",
            "description": (
                "AutoRouter model selector: choose 'Auto (Free)' to route this chat "
                "through the best eligible free model."
            ),
            "is_current": False,
            "is_user_defined": True,
            "source": "autorouter-compat",
            "models": [VIRTUAL_MODEL],
            "total_models": 1,
            "virtual": True,
            "virtual_model": VIRTUAL_MODEL,
        }
    ]


def _load_engine():
    """Backwards-compatible delegate to :func:`_route_resolution.load_engine`."""
    from . import _route_resolution

    return _route_resolution.load_engine()


def _load_profiles():
    from . import _route_resolution

    return _route_resolution.load_profiles()


# Bindings the adapter patches, as (module name, attribute) pairs. ``disable()``
# restores every one of them; tests iterate this same table to prove the
# restore covers all modified bindings.
_PATCH_TARGETS = (
    ("hermes_cli.model_switch_providers", "list_authenticated_providers"),
    ("hermes_cli.model_switch_providers", "list_picker_providers"),
    ("hermes_cli.model_switch", "list_authenticated_providers"),
    ("hermes_cli.model_switch", "switch_model"),
    ("hermes_cli.model_switch", "resolve_startup_model_route"),
    ("agent.agent_runtime_helpers", "switch_model"),
    ("agent.agent_init", "init_agent"),
)

# ---------------------------------------------------------------------------
# Interposition implementations
# ---------------------------------------------------------------------------

def _inject_autorouter_row(providers: list) -> list:
    """Insert the AutoRouter provider row into the picker provider list."""
    if any(str(p.get("slug", "")) == VIRTUAL_PROVIDER for p in providers):
        return providers
    return providers + [
        {
            "slug": VIRTUAL_PROVIDER,
            "name": "AutoRouter",
            "description": (
                "AutoRouter model selector: choose 'Auto (Free)' to route this chat "
                "through the best eligible free model."
            ),
            "is_current": False,
            "is_user_defined": True,
            "source": "autorouter-compat",
            "models": [VIRTUAL_MODEL],
            "total_models": 1,
            "virtual": True,
            "virtual_model": VIRTUAL_MODEL,
        }
    ]


def _default_profile_configured(store) -> bool:
    from . import _route_resolution

    return _route_resolution.default_profile_configured(store)


def _hybrid_select(config: dict[str, Any]) -> Optional[dict[str, Any]]:
    from . import _route_resolution

    return _route_resolution.hybrid_select(config)


class ChatRouterAdapter:
    """Idempotent interposition adapter.

    ``enable()`` patches the sanctioned host bindings exactly once per instance.
    ``disable()`` restores **every** binding this class can touch -- including
    ``list_authenticated_providers`` / ``list_picker_providers`` at their
    definition site and the from-import bindings the inventory/picker call
    sites use -- unwinding all adapter layers (its own and any other
    ``ChatRouterAdapter``'s) back to the pre-adapter originals. Foreign
    (non-adapter) bindings installed after this adapter are left untouched.
    """

    def __init__(self, enabled: bool = False):
        self.enabled = bool(enabled)
        self._list_auth_wrapped = False
        self._switch_model_wrapped = False
        self._picker_wrapped = False
        self._switch_agent_wrapped = False
        self._init_agent_wrapped = False
        self._startup_route_wrapped = False
        self._orig_list_auth = None
        self._orig_switch_model = None
        self._orig_startup_route = None
        self._orig_picker = None
        self._wrapper_list_auth = None
        self._wrapper_switch_model = None
        self._wrapper_startup_route = None
        self._wrapper_picker = None
        self._orig_switch_agent = None
        self._wrapper_switch_agent = None
        self._orig_init_agent = None
        self._wrapper_init_agent = None
        self.logger = logging.getLogger(__name__)

    # -- registration ---------------------------------------------------

    def register_list_authenticated_providers(self) -> None:
        """Patch the picker inventory at BOTH the definition site and the
        from-import binding the picker call site actually uses.

        Hermes' ``hermes_cli/model_switch.py`` does
        ``from hermes_cli.model_switch_providers import
        list_authenticated_providers`` at module load, so the bindings the
        inventory/picker call sites see are
        ``hermes_cli.model_switch.list_authenticated_providers`` and
        ``hermes_cli.model_switch_providers.list_picker_providers``
        (``/model``'s interactive picker imports it from the definition
        module). Both modules are patched and both are restored by
        ``disable()``.
        """
        if not self.enabled or self._list_auth_wrapped:
            return
        try:
            _msp_mod = _module("hermes_cli.model_switch_providers")
            _ms_mod = _module("hermes_cli.model_switch")
            if _msp_mod is None or _ms_mod is None:
                raise ImportError("hermes_cli.model_switch(_providers) not importable")

            _orig = _msp_mod.list_authenticated_providers
            _orig_picker = _msp_mod.list_picker_providers

            @functools.wraps(_orig)
            def _wrapper(*args, **kwargs):
                return _inject_autorouter_row(_orig(*args, **kwargs))

            @functools.wraps(_orig_picker)
            def _picker_wrapper(*args, **kwargs):
                return _inject_autorouter_row(_orig_picker(*args, **kwargs))

            self._orig_list_auth = _orig
            self._wrapper_list_auth = _mark(_wrapper, _orig)
            self._orig_picker = _orig_picker
            self._wrapper_picker = _mark(_picker_wrapper, _orig_picker)
            self._list_auth_wrapped = True
            self._picker_wrapped = True
            # Definition sites (the /model interactive picker imports
            # list_picker_providers from here at call time).
            _msp_mod.list_authenticated_providers = self._wrapper_list_auth
            _msp_mod.list_picker_providers = self._wrapper_picker
            # The from-import binding call sites in hermes_cli.model_switch.
            _ms_mod.list_authenticated_providers = self._wrapper_list_auth
        except Exception as exc:
            logger.warning(
                "autorouter adapter: could not wrap list_authenticated_providers: %s", exc
            )

    def register_switch_agent(self) -> None:
        """Wrap the agent's in-place switch_model() so a live agent that switches
        models (e.g. a direct agent.switch_model call) resolves the virtual marker
        through the canonical selector before rebuilding its client. On resolution
        failure this RAISES, so the caller's rollback path keeps the previous
        valid runtime instead of swapping in the virtual marker."""
        if not self.enabled or self._switch_agent_wrapped:
            return
        try:
            from agent.agent_runtime_helpers import switch_model as _orig_switch_agent
            from functools import wraps

            @wraps(_orig_switch_agent)
            def _wrapper_switch_agent(agent, new_model, new_provider, api_key="", base_url="",
                                      api_mode="", capabilities=None):
                if self._is_virtual_request(new_model, new_provider or ""):
                    provider, model, error = self._resolve_virtual(new_provider or "",
                                                                    new_model or "")
                    if error:
                        # Fail closed: never hand the virtual marker to the runtime.
                        raise RuntimeError(
                            f"autorouter: could not resolve {VIRTUAL_MODEL}: {error}")
                    # The profile's provider definition owns the endpoint and API
                    # mode for the resolved provider: never carry the caller's
                    # endpoint/credentials for the pre-switch route across.
                    new_provider, new_model = provider, model
                    api_key, base_url, api_mode = "", "", ""
                else:
                    new_provider, new_model = new_provider, new_model
                return _orig_switch_agent(
                    agent, new_model, new_provider, api_key=api_key, base_url=base_url,
                    api_mode=api_mode, capabilities=capabilities)

            self._orig_switch_agent = _orig_switch_agent
            self._wrapper_switch_agent = _mark(_wrapper_switch_agent, _orig_switch_agent)
            self._switch_agent_wrapped = True
            _ar_mod = _module("agent.agent_runtime_helpers")
            if _ar_mod is not None:
                _ar_mod.switch_model = self._wrapper_switch_agent
            logger.info("autorouter adapter: agent switch_model() patched")
        except Exception as exc:
            logger.warning("autorouter adapter: could not wrap agent switch_model: %s", exc)

    def register_init_agent(self) -> None:
        """Wrap init_agent() so a virtual startup model is resolved through the
        canonical selector before the client is built. On resolution failure this
        RAISES *before* any network call; the previous valid configuration is
        left untouched."""
        if not self.enabled or self._init_agent_wrapped:
            return
        try:
            from agent.agent_init import init_agent as _orig_init_agent
            from functools import wraps

            @wraps(_orig_init_agent)
            def _wrapper_init_agent(agent, *args, **kwargs):
                model = kwargs.get("model") or (args[0] if args else "")
                if isinstance(model, str) and model.strip() == VIRTUAL_MODEL:
                    chosen_provider, chosen_model, error = self._resolve_virtual(
                        kwargs.get("provider") or "", model or "")
                    if error:
                        # Fail closed: refuse to build a client for the virtual marker.
                        raise RuntimeError(
                            f"autorouter: could not resolve {VIRTUAL_MODEL}: {error}")
                    kwargs["model"] = chosen_model
                    kwargs["provider"] = chosen_provider
                    logger.info("autorouter adapter: startup model %r -> %r/%r",
                                model, chosen_provider, chosen_model)
                return _orig_init_agent(agent, *args, **kwargs)

            self._orig_init_agent = _orig_init_agent
            self._wrapper_init_agent = _mark(_wrapper_init_agent, _orig_init_agent)
            self._init_agent_wrapped = True
            _agent_init_mod = _module("agent.agent_init")
            if _agent_init_mod is not None:
                _agent_init_mod.init_agent = self._wrapper_init_agent
            logger.info("autorouter adapter: init_agent() patched for virtual-model routing")
        except Exception as exc:
            logger.warning("autorouter adapter: could not wrap init_agent: %s", exc)

    def register_switch_model(self) -> None:
        """Patch the model-switch pipeline and the startup route lookup."""
        if not self.enabled or self._switch_model_wrapped:
            return
        try:
            _ms_mod = _module("hermes_cli.model_switch")
            if _ms_mod is None:
                raise ImportError("hermes_cli.model_switch not importable")
            _orig_switch_model = _ms_mod.switch_model
            _orig_startup_route = _ms_mod.resolve_startup_model_route

            self._orig_switch_model = _orig_switch_model
            self._wrapper_switch_model = _mark(
                self._make_switch_model_wrapper(_orig_switch_model), _orig_switch_model)
            self._orig_startup_route = _orig_startup_route
            self._wrapper_startup_route = _mark(
                self._make_startup_route_wrapper(_orig_startup_route), _orig_startup_route)
            self._switch_model_wrapped = True
            self._startup_route_wrapped = True
            _ms_mod.switch_model = self._wrapper_switch_model
            _ms_mod.resolve_startup_model_route = self._wrapper_startup_route
        except Exception as exc:
            logger.warning(
                "autorouter adapter: could not wrap startup/switch model: %s", exc
            )

    def _make_switch_model_wrapper(self, orig):
        @functools.wraps(orig)
        def _wrapper(
            raw_input,
            current_provider,
            current_model,
            current_base_url="",
            current_api_key="",
            is_global=False,
            explicit_provider="",
            user_providers=None,
            custom_providers=None,
        ):
            if not self._is_virtual_request(raw_input, explicit_provider):
                return orig(
                    raw_input=raw_input,
                    current_provider=current_provider,
                    current_model=current_model,
                    current_base_url=current_base_url,
                    current_api_key=current_api_key,
                    is_global=is_global,
                    explicit_provider=explicit_provider,
                    user_providers=user_providers,
                    custom_providers=custom_providers,
                )
            provider, model, error = self._resolve_virtual(current_provider, current_model)
            if error:
                logger.warning("autorouter adapter: virtual model resolution refused: %s", error)
                return self._fail_closed(error)
            if provider is None or model is None:
                logger.warning("autorouter adapter: virtual model resolution refused: no eligible free model")
                return self._fail_closed("no eligible free model")
            # The underlying Hermes switch pipeline resolves the target endpoint
            # from the active profile's provider definitions (``providers:`` /
            # ``custom_providers:``), not the adapter's own authorization list.
            # The adapter only injects the picker row; it never rewrites the
            # endpoint inventory. Credentials never cross the adapter boundary:
            # the application's credential pool supplies them.
            try:
                from hermes_cli.config import load_config_readonly

                _cfg = load_config_readonly() or {}
                _profile_providers = _cfg.get("providers") or {}
                _profile_custom = _cfg.get("custom_providers") or []
            except Exception:
                _profile_providers = {}
                _profile_custom = []
            return orig(
                raw_input=model,
                current_provider=current_provider,
                current_model=current_model,
                current_base_url=current_base_url,
                current_api_key=current_api_key,
                is_global=is_global,
                explicit_provider=provider,
                user_providers=_profile_providers,
                custom_providers=_profile_custom,
            )

        return _wrapper

    def _make_startup_route_wrapper(self, orig):
        @functools.wraps(orig)
        def _wrapper(
            raw_model,
            *,
            explicit_provider="",
            current_provider="",
            user_providers=None,
            custom_providers=None,
            alias_config=None,
        ):
            if self._is_virtual_request(raw_model, explicit_provider):
                provider, model, error = self._resolve_virtual(current_provider, raw_model)
                if error or provider is None or model is None:
                    # Fail closed: the virtual marker did not resolve. Refuse to
                    # route: the host's policy check rejects the empty model before
                    # any provider request is built, so the virtual string can never
                    # reach an endpoint as the final inference model. The previous
                    # valid session configuration is left untouched.
                    logger.warning(
                        "autorouter adapter: startup route for %r refused: %s",
                        raw_model, error or "no eligible free model")
                    return StartupModelRoute(model="") if StartupModelRoute is not None else None
                # Route the virtual marker through the canonical selector; the
                # controller endpoint then receives the RESOLVED model.
                logger.info("autorouter adapter: resolved virtual model %r -> %s/%s",
                            raw_model, provider, model)
                return StartupModelRoute(model=model, provider=provider, base_url="", api_key="")
            return orig(
                raw_model,
                explicit_provider=explicit_provider,
                current_provider=current_provider,
                user_providers=user_providers,
                custom_providers=custom_providers,
                alias_config=alias_config,
            )

        return _wrapper

    def _is_virtual_request(self, raw_input, explicit_provider) -> bool:
        """True when the pick is the AutoRouter virtual model."""
        if isinstance(raw_input, str) and raw_input.strip() == VIRTUAL_MODEL:
            return True
        if (
            isinstance(explicit_provider, str)
            and explicit_provider.strip().lower() == VIRTUAL_PROVIDER
        ):
            return True
        return False

    def _fail_closed(self, error: str):
        """Return a fail-closed ModelSwitchResult; never delegate to the host."""
        if ModelSwitchResult is not None:
            return ModelSwitchResult(success=False, error_message=error)
        return type("Result", (), {"success": False, "error_message": error})()

    def _profile_store_dir(self) -> Optional[Path]:
        """The isolated profile's persistent AutoRouter catalog directory:
        ``$HERMES_HOME/plugin-data/autorouter``. None when no valid profile
        home can be resolved; the adapter then fails closed in
        ``_resolve_virtual``."""
        from . import _route_resolution

        return _route_resolution.profile_store_dir()

    def _routing_settings(self) -> dict[str, Any]:
        """Routing knobs from the plugin's own settings; read fresh per call.

        ``policy``, ``min_context``, ``requires_tools``, ``cooldown_seconds`` and the
        model include/exclude lists take effect for the next selection (committed
        sessions are never retroactively rewritten). Anything unreadable or invalid
        falls back to the fail-closed defaults (8192 context, 60s cooldown, auto
        policy, tool support not required, no include/exclude lists).
        """
        from . import _route_resolution

        return _route_resolution.routing_settings()

    def _authorized_providers(self):
        """Providers the AutoRouter plugin is authorized to use (read from the
        plugin's own config: plugins.entries.autorouter.settings.providers).
        The picker / provider discovery is NEVER mutated by this adapter:
        the virtual row is the only injection point, and that is the model
        picker, not the provider inventory. Controlled-provider registration
        (e.g. mock-local) lives in the isolated test profile's config only."""
        from . import _route_resolution

        return _route_resolution.authorized_providers()

    def _resolve_virtual(self, current_provider: str, current_model: str):
        """Resolve the virtual marker to (provider, model) via the canonical
        selector over the isolated profile's persistent store. Fails closed:
        returns (None, None, error) unless the route is safe."""
        from . import _route_resolution

        return _route_resolution.resolve_route(
            store_dir=self._profile_store_dir(),
            providers=self._authorized_providers(),
            settings=self._routing_settings(),
            engine_loader=_load_engine,
            profiles_loader=_load_profiles,
        )

    def enable(self) -> None:
        """Enable the adapter, patching the sanctioned host functions exactly
        once (idempotent per instance)."""
        if not self.enabled:
            return
        self.register_list_authenticated_providers()
        self.register_switch_model()
        self.register_switch_agent()
        self.register_init_agent()

    def disable(self) -> None:
        """Restore EVERY modified binding to its pre-adapter original.

        Unwinds every adapter layer (this instance's and any other
        ``ChatRouterAdapter``'s) installed on the bindings listed in
        ``_PATCH_TARGETS`` -- including ``list_authenticated_providers`` and
        ``list_picker_providers`` at their definition site and the
        from-import binding the inventory call sites use. Bindings installed
        by foreign code after the adapter are left untouched. Safe to call
        repeatedly and when the adapter was never enabled.
        """
        self.enabled = False
        for module_name, attr in _PATCH_TARGETS:
            mod = _module(module_name)
            if mod is not None:
                _unpatch_ours(mod, attr)
        self._list_auth_wrapped = False
        self._picker_wrapped = False
        self._switch_model_wrapped = False
        self._startup_route_wrapped = False
        self._switch_agent_wrapped = False
        self._init_agent_wrapped = False
        self._orig_list_auth = None
        self._orig_picker = None
        self._orig_switch_model = None
        self._orig_startup_route = None
        self._orig_switch_agent = None
        self._orig_init_agent = None
        self._wrapper_list_auth = None
        self._wrapper_picker = None
        self._wrapper_switch_model = None
        self._wrapper_startup_route = None
        self._wrapper_switch_agent = None
        self._wrapper_init_agent = None

    def is_registered(self) -> bool:
        return (
            self.enabled
            and self._list_auth_wrapped
            and self._switch_model_wrapped
            and self._switch_agent_wrapped
            and self._init_agent_wrapped
        )
