"""Runtime singleton and hook callbacks for AutoRouter."""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Optional

from ..evidence.credential_scope import observed_scope

logger = logging.getLogger(__name__)

_STATE: dict[str, Any] = {
    "ctx": None,
    "policy": "auto",
    "free_only": True,
    "providers": ["nvidia", "openrouter"],
    "cooldown_seconds": 60,
    "state_dir": None,
    "store": None,
    "router": None,
}


def configure(**kwargs) -> None:
    global _STATE
    for k, v in kwargs.items():
        _STATE[k] = v
    # init store
    try:
        from ..storage import state as st
        sd = _STATE["state_dir"]
        _STATE["store"] = st.StateStore(Path(sd))
    except Exception as exc:
        logger.warning("autorouter: state store init failed: %s", exc)
        _STATE["store"] = None
    try:
        from ..routing import router as rt
        _STATE["router"] = rt.Router(_STATE)
    except Exception as exc:
        logger.warning("autorouter: router init failed: %s", exc)
        _STATE["router"] = None


def get_state() -> dict[str, Any]:
    return _STATE


def get_store():
    return _STATE.get("store")


def get_router():
    return _STATE.get("router")


def _begin(kwargs, allow_unidentified=False):
    from ..telemetry import telemetry
    store = get_store()
    if store is None:
        return None
    identity = kwargs.get("api_request_id")
    identity = identity if isinstance(identity, str) and identity else None
    if identity is None and not allow_unidentified:
        return None  # No synthetic key: unrelated concurrent callbacks must never correlate.
    return store.begin_request(
        api_request_id=identity,
        task_id=kwargs.get("task_id"), turn_id=kwargs.get("turn_id"),
        session_hash=telemetry.agent_id_from_kwargs(kwargs), platform=kwargs.get("platform"),
        provider=kwargs.get("provider"), model=kwargs.get("model"),
        key_scope=observed_scope(kwargs.get("provider"), kwargs.get("credential_scope")),
        approx_input_tokens=kwargs.get("approx_input_tokens"), started_at=kwargs.get("started_at"))


def on_pre_api_request(**kwargs):
    try:
        store = get_store()
        if store is None:
            return
        # Bound unfinished lifecycle state; abandoned observations are canceled, never successes.
        store.expire_pending_requests()
        _begin(kwargs)
        from ..evidence.scope_quota import observe
        observe(_STATE, kwargs)
    except Exception:
        logger.debug("autorouter: pre-request telemetry unavailable")


def _request_id_for(kwargs):
    store = get_store()
    identity = kwargs.get("api_request_id")
    if store is None or not isinstance(identity, str) or not identity:
        return None
    return store.find_request_by_api_id(identity)


def _observe(kwargs, error=False):
    from ..telemetry import telemetry
    store = get_store()
    if store is None:
        return
    request_id = _request_id_for(kwargs) or _begin(kwargs, allow_unidentified=True)
    if request_id is None:
        return
    if not store.request_event_matches(request_id, kwargs):
        return  # Session/task/turn binding precedes scope or health mutation.
    scope = observed_scope(kwargs.get("provider"), kwargs.get("credential_scope"))
    store.reconcile_request_scope(request_id, scope)
    code = kwargs.get("status_code")
    etype, message = telemetry.error_parts(kwargs)
    success = not error and not kwargs.get("error") and not (isinstance(code, int) and code >= 400)
    terminal_status = telemetry.status_from_kwargs(kwargs, default="success" if success else "error")
    if error and terminal_status != "canceled":
        terminal_status = "error"
    success = terminal_status == "success"
    category = telemetry.classify_error(code, etype, message) if terminal_status == "error" else None
    ordinal = kwargs.get("retry_count")
    if not isinstance(ordinal, int):
        previous_attempts = store.get_request_attempts(request_id)
        ordinal = max((a["ordinal"] for a in previous_attempts), default=-1) + 1
    accepted_attempt = store.record_attempt(request_id, ordinal or 0, provider=kwargs.get("provider"), model=kwargs.get("model"), key_scope=scope,
                         status_code=code, retryable=kwargs.get("retryable"), reason=kwargs.get("reason"),
                         error_category=category, duration_ms=telemetry.latency_ms_from_kwargs(kwargs))
    if not accepted_attempt:
        return
    r = get_router()
    if r is not None and terminal_status != "canceled":
        r.record_outcome(provider=kwargs.get("provider"), model=kwargs.get("model"), success=success,
                         status_code=code, latency_ms=telemetry.latency_ms_from_kwargs(kwargs),
                         key_scope=scope, error_type=etype,
                         retry_after=kwargs.get("retry_after"), trusted_reason=kwargs.get("failure_reason"))
    if terminal_status == "error":
        from ..evidence.free_access import invalidate_cached
        invalidate_cached(store,kwargs.get("provider"),scope,code)
    retry = kwargs.get("retry_count")
    maximum = kwargs.get("max_retries")
    exhausted = isinstance(retry, int) and isinstance(maximum, int) and retry >= maximum
    if terminal_status == "error" and error and kwargs.get("api_request_id") and kwargs.get("retryable") is True and not exhausted:
        return  # Same-ID retries remain pending until success/exhaustion or bounded cleanup.
    usage = telemetry.extract_usage(kwargs)
    store.finish_request(request_id, status=terminal_status,
                         response_model=kwargs.get("response_model"), input_tokens=usage.input_tokens,
                         output_tokens=usage.output_tokens, latency_ms=telemetry.latency_ms_from_kwargs(kwargs),
                         ttft_ms=telemetry.ttft_ms_from_kwargs(kwargs), error_category=category,
                         error_summary=message, ended_at=kwargs.get("ended_at"))


def on_post_api_request(**kwargs):
    try:
        _observe(kwargs)
    except Exception:
        logger.debug("autorouter: post-request telemetry unavailable")


def on_api_request_error(**kwargs):
    try:
        _observe(kwargs, error=True)
    except Exception:
        logger.debug("autorouter: error telemetry unavailable")
