"""Shared route resolution for the AutoRouter virtual model and the native
pre-inference routing consumer contract (issue #104).

Extracts the single canonical resolution path that both the opt-in chat-router
adapter (``autorouter/auto-free`` virtual model) and the host-extension
consumer (``pre_inference_route``, issue #104) use. There is exactly one
selection engine and exactly one policy path: eligibility, profile merge,
include/exclude, cooldown and free-tier constraints all flow through
``hybrid_select``. Callers inject their own authorization/store-dir callables
so tests (and the adapter, which monkey-patches instance methods) keep their
override seams.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


def load_engine():
    """Return the AutoRouter engine package's (router, state) modules.

    The Hermes plugin loader imports this plugin under a namespaced package,
    so imports go relative to this package first; the absolute ``autorouter``
    import is the fallback for the test shell. Nothing is added to
    ``sys.path`` and nothing is removed from ``sys.modules``.
    """
    if __package__:
        try:
            from ..routing import router as router_mod  # noqa: F401
            from ..storage import state as state_mod  # noqa: F401
            return router_mod, state_mod
        except Exception:
            pass
    try:
        from autorouter import router as router_mod  # noqa: F401
        from autorouter import state as state_mod  # noqa: F401
        return router_mod, state_mod
    except Exception:
        return None, None


def load_profiles():
    if __package__:
        try:
            from ..routing import profiles as profiles_mod  # noqa: F401
            return profiles_mod
        except Exception:
            pass
    try:
        from autorouter import profiles as profiles_mod  # noqa: F401
        return profiles_mod
    except Exception:
        return None


def profile_store_dir() -> Optional[Path]:
    """The isolated profile's persistent AutoRouter catalog directory:
    ``$HERMES_HOME/plugin-data/autorouter``. None when no valid profile
    home can be resolved; callers then fail closed."""
    try:
        from hermes_constants import get_hermes_home

        return Path(get_hermes_home()) / "plugin-data" / "autorouter"
    except Exception:
        return None


_MODEL_REF_RE = None  # compiled lazily to avoid importing ``re`` at module load


def read_autorouter_settings() -> tuple[Optional[dict[str, Any]], Optional[str]]:
    """Strict structural read of ``plugins.entries.autorouter.settings``.

    Returns ``(settings, None)`` when the configuration source is readable and
    structurally valid — the settings object may legitimately be absent
    (``{}``), which is a *valid omission*, not an error. Returns ``(None,
    error)`` when the source cannot be read or is malformed. A read failure is
    never equivalent to a valid omission, and no value from a failed read is
    used for anything but refusing. Never raises.
    """
    try:
        from hermes_cli.config import load_config_readonly

        cfg = load_config_readonly()
    except Exception as exc:
        return None, f"unreadable config source ({type(exc).__name__})"
    try:
        from hermes_cli.config_read_errors import (
            FailedConfigRead,
            get_active_config_parse_failure,
        )
    except Exception:
        FailedConfigRead = None
        get_active_config_parse_failure = None
    if FailedConfigRead is not None and isinstance(cfg, FailedConfigRead):
        read_error = getattr(cfg, "read_error", None)
        return None, (
            f"config read failed ({type(read_error).__name__ if read_error is not None else 'unknown'})"
        )
    # A last-known-good fallback is byte-identical to a file that failed to
    # parse; the recorded parse failure disqualifies it as well.
    if get_active_config_parse_failure is not None:
        try:
            if get_active_config_parse_failure():
                return None, "active config has a recorded parse failure"
        except Exception:
            return None, "config parse-failure state could not be verified"
    if not isinstance(cfg, dict):
        return None, "top-level config is not an object"
    plugins = cfg.get("plugins")
    if plugins is None:
        return {}, None
    if not isinstance(plugins, dict):
        return None, "plugins is not an object"
    entries = plugins.get("entries")
    if entries is None:
        return {}, None
    if not isinstance(entries, dict):
        return None, "plugins.entries is not an object"
    entry = entries.get("autorouter")
    if entry is None:
        return {}, None
    if not isinstance(entry, dict):
        return None, "plugins.entries.autorouter is not an object"
    settings = entry.get("settings")
    if settings is None:
        return {}, None
    if not isinstance(settings, dict):
        return None, "plugins.entries.autorouter.settings is not an object"
    return dict(settings), None


def _model_preference_from_settings(settings: dict[str, Any]) -> dict[str, Any]:
    """Resolve the effective model preference from raw plugin settings.

    Canonical source is the single, plugin-scoped ``model_preference`` key
    (one indivisible value so Hermes' per-key writer can persist it
    atomically). Legacy two-key installations (``model_include`` /
    ``model_exclude`` with no ``model_preference``) remain readable; the
    legacy include list implies allowlist mode.

    Fail closed on anything unrecognized: an invalid ``model_preference``
    resolves to mode ``none`` (zero selectable models), never to unrestricted.
    """
    import re as _re

    global _MODEL_REF_RE
    if _MODEL_REF_RE is None:
        _MODEL_REF_RE = _re.compile(r"^([a-z0-9][a-z0-9_-]{0,63})/([A-Za-z0-9][A-Za-z0-9._:/-]{0,199})$")

    def _valid_pairs(raw):
        pairs = []
        seen = set()
        if not isinstance(raw, list):
            return pairs, False
        for item in raw:
            if not isinstance(item, str):
                return pairs, False
            match = _MODEL_REF_RE.match(item.strip())
            if not match:
                return pairs, False
            pair = (match.group(1).strip().lower(), match.group(2).strip())
            if pair not in seen:
                seen.add(pair)
                pairs.append(pair)
        return pairs, True

    pref = settings.get("model_preference")
    if pref is not None:
        if not isinstance(pref, dict):
            logger.warning("autorouter: model_preference is not an object; failing closed (no models enabled)")
            return {"model_mode": "none", "model_include_pairs": [], "model_exclude_pairs": []}
        mode = pref.get("mode")
        inc, inc_ok = _valid_pairs(pref.get("include", []))
        exc, exc_ok = _valid_pairs(pref.get("exclude", []))
        if not inc_ok or not exc_ok or mode not in ("none", "allowlist", "unrestricted"):
            logger.warning("autorouter: model_preference is invalid; failing closed (no models enabled)")
            return {"model_mode": "none", "model_include_pairs": [], "model_exclude_pairs": exc if exc_ok else []}
        if mode == "allowlist" and not inc:
            # allowlist with an empty include is corrupt input; fail closed.
            return {"model_mode": "none", "model_include_pairs": [], "model_exclude_pairs": exc}
        if mode == "none":
            return {"model_mode": "none", "model_include_pairs": [], "model_exclude_pairs": exc}
        if mode == "unrestricted":
            return {"model_mode": "unrestricted", "model_include_pairs": [], "model_exclude_pairs": exc}
        return {"model_mode": "allowlist", "model_include_pairs": inc, "model_exclude_pairs": exc}

    # Legacy fallback (no model_preference persisted yet). A restricted
    # preference whose entries do not parse is unreadable, not empty:
    # when a list key is present but unusable the route is refused.
    def _legacy_pairs(raw):
        if raw is None:
            return [], True
        if not isinstance(raw, list):
            return [], False
        pairs = []
        for item in raw:
            if not isinstance(item, str):
                return [], False
            provider, sep, model = item.strip().partition("/")
            provider = provider.lower().strip()
            model = model.strip()
            if not sep or not provider or not model:
                return [], False
            pairs.append((provider, model))
        return pairs, True

    raw_inc = settings.get("model_include", None)
    raw_exc = settings.get("model_exclude", None)
    inc, inc_ok = _legacy_pairs(raw_inc)
    exc, exc_ok = _legacy_pairs(raw_exc)
    if not (inc_ok and exc_ok):
        logger.warning("autorouter: legacy model preference is unreadable; failing closed (refusing route)")
        return {
            "model_mode": "none",
            "model_include_pairs": inc,
            "model_exclude_pairs": exc,
        }
    return {
        "model_mode": "allowlist" if inc else "unrestricted",
        "model_include_pairs": inc,
        "model_exclude_pairs": exc,
    }


def _derive_routing_settings(settings: dict[str, Any]) -> dict[str, Any]:
    """Routing knobs derived from an already-validated settings dict.

    Deliberately absent keys use documented manufacturing defaults; invalid
    values fail closed (8192 / 60s / auto). Applied identically to the
    strict per-attempt path."""
    policy = settings.get("policy", "auto")
    if not isinstance(policy, str):
        policy = "auto"
    min_context = settings.get("min_context", 8192)
    if isinstance(min_context, bool) or not isinstance(min_context, int) or min_context < 2048:
        min_context = 8192
    cooldown = settings.get("cooldown_seconds", 60)
    if isinstance(cooldown, bool) or not isinstance(cooldown, int) or not (1 <= cooldown <= 86400):
        cooldown = 60

    preference = _model_preference_from_settings(settings)

    return {
        "policy": policy,
        "min_context": min_context,
        "cooldown_seconds": cooldown,
        "requires_tools": bool(settings.get("requires_tools", False)),
        "model_mode": preference["model_mode"],
        "model_include_pairs": preference["model_include_pairs"],
        "model_exclude_pairs": preference["model_exclude_pairs"],
    }


def routing_settings() -> Optional[dict[str, Any]]:
    """Routing knobs from the plugin's own settings; read fresh per call.

    ``policy``, ``min_context``, ``requires_tools``, ``cooldown_seconds`` and the
    model preference take effect for the next selection (committed
    sessions are never retroactively rewritten). Returns ``None`` when the
    settings source cannot be read or is malformed — callers MUST refuse
    rather than route, because a read failure is not a valid omission and
    never widens to unrestricted. A structurally valid file whose settings are
    deliberately absent yields the fail-closed defaults (8192 context, 60s
    cooldown, auto policy, tool support not required, no enabled models when
    an invalid model_preference is present; otherwise unrestricted with no
    include or exclude lists).
    """
    settings, error = read_autorouter_settings()
    if error is not None:
        logger.warning("autorouter: routing settings unreadable (%s); refusing to route", error)
        return None
    assert settings is not None
    return _derive_routing_settings(settings)


def authorized_providers() -> list[str]:
    """Providers the AutoRouter plugin is authorized to use (read from the
    plugin's own config: plugins.entries.autorouter.settings.providers).
    The picker / provider discovery is NEVER mutated here: this only names
    the authorization set the selector draws from.

    The list is validated exactly the way plugin registration validates it:
    any unknown, malformed, duplicated or non-list value grants NO access at
    all — never a subset. Registration gates tools/hooks on this same
    decision, and the routing consumer must fail the same way (issue #126)."""
    settings, error = read_autorouter_settings()
    if error is not None:
        return []
    assert settings is not None
    return authorized_providers_from(settings)


def authorized_providers_from(settings: dict[str, Any]) -> list[str]:
    """Same authorization rule derived from an already-validated settings
    dict (one snapshot per attempt)."""
    providers = settings.get("providers", ["nvidia", "openrouter"])
    # Registration validates the raw value exactly (a string is not a list
    # and fails closed); the consumer does the same. No parsing, no splitting.
    try:
        from ..providers.connections import valid_provider_list

        if not valid_provider_list(providers):
            return []
    except Exception:
        # The authorization authority is unreachable: fail closed, never open.
        return []
    return [str(p) for p in providers]


def load_profile_by_id(store, profile_id: str):
    """Tri-state read of a specific stored routing profile.

    Returns ``(profile, None)`` when the id exists and validates,
    ``(None, None)`` when no such id is configured, and ``(None, error)``
    when the row exists but fails strict validation — the caller must then
    fail closed. Never raises.
    """
    if not isinstance(profile_id, str) or not profile_id.strip():
        return None, None
    try:
        conn = store._connect()
        try:
            row = conn.execute("SELECT * FROM routing_profiles WHERE id = ?", (profile_id,)).fetchone()
        finally:
            conn.close()
    except Exception:
        return None, "bound profile could not be read from the store"
    if row is None:
        return None, f"the session-bound routing profile ({profile_id!r}) no longer exists"
    try:
        from ..routing import profiles as routing_profiles
        candidate = routing_profiles.decode_row(row)
        return routing_profiles.validate_stored_profile(candidate), None
    except Exception as exc:
        code = getattr(exc, "code", None) or "stored_profile_invalid"
        return None, f"the session-bound routing profile is corrupt ({code})"


def default_profile_configured(store) -> bool:
    """True when an AutoRouter default routing profile is configured (meta row present)."""
    try:
        conn = store._connect()
        try:
            row = conn.execute("SELECT value FROM meta WHERE key = ?", (
                "active_routing_profile",)).fetchone()
            return bool(row and row["value"])
        finally:
            conn.close()
    except Exception:
        return False


def hybrid_select(config: dict[str, Any], engine_loader=None) -> Optional[dict[str, Any]]:
    """Select an eligible free model through the AutoRouter engine.

    The caller MUST supply a real ``autorouter.state.StateStore`` (the
    isolated profile's persistent catalog, seeded by the test fixture). No
    temp/dummy store is ever created here: an absent or invalid store is a
    hard failure and is reported as such by the caller.
    """
    router_mod, state_mod = (engine_loader or load_engine)()
    if router_mod is None or state_mod is None:
        return None
    store = config.get("store")
    if not isinstance(store, state_mod.StateStore):
        return None
    mode = str(config.get("model_mode") or "unrestricted")
    if mode == "none":
        # Explicit none-enabled preference: zero selectable models. Refuse
        # before any ranking or provider access — never widen to unrestricted.
        logger.info("autorouter: model_preference mode is 'none' (all models disabled); refusing route")
        return None
    try:
        r = router_mod.Router(dict(config))
        state = dict(r.state)
        state["free_only"] = True
        state["paid_authorized"] = False
        state["policy"] = str(config.get("policy", "auto") or "auto")
        state["providers"] = list(config.get("providers") or [])
        safe = router_mod.Router(state)
        include = {
            (str(p).strip().lower(), str(m).strip())
            for p, m in config.get("model_include_pairs", [])
            if isinstance(p, str) and isinstance(m, str)
        }

        def _norm(provider, model):
            return str(provider or "").strip().lower(), str(model or "").strip()

        exclude = {
            (p, m) for p, m in config.get("model_exclude_pairs", []) if isinstance(p, str) and isinstance(m, str)
        }
        if include:
            # Inclusion is a *selection* constraint: it must narrow the candidate
            # set before ranking so the highest-ranked eligible INCLUDED model
            # wins — an eligible excluded-by-include higher-ranked model must
            # never out-rank the included one. We therefore pre-exclude everything
            # in the catalog that is not in the allowlist. If the catalog cannot
            # be read, inclusion cannot be enforced and the route is refused.
            try:
                excluded_not_included = {
                    _norm(row.get("provider"), row.get("model"))
                    for row in store.get_catalog()
                } - include
                exclude = excluded_not_included | exclude
            except Exception:
                logger.warning("autorouter: cannot read catalog to enforce model_include; refusing route")
                return None
        return safe.select(
            requires_tools=bool(config.get("requires_tools", False)),
            min_context=int(config.get("min_context", 8192) or 8192),
            exclude=exclude or None,
            policy=state["policy"],
        )
    except Exception:
        return None


def resolve_route_detailed(*, store_dir, providers, settings, engine_loader=None,
                           profiles_loader=None, bound_profile_id=None) -> dict[str, Any]:
    """Canonical resolution returning a dict that also carries the routing context
    receipts need:

    ``{provider, model, error, profile_id, profile_name, policy, at}``

    ``error`` is None on success. ``profile_id``/``profile_name`` are None
    when no user-created default profile narrowed the route. The loaders are
    injectable so hosts/tests keep their override seams.

    ``bound_profile_id`` (optional) pins resolution to a specific stored
    profile instead of the operator-set default — the session-binding path.
    The bound profile can only narrow the route; it is validated fail-closed
    and never silently replaced.
    """
    engine_loader = engine_loader or load_engine
    profiles_loader = profiles_loader or load_profiles
    if not isinstance(settings, dict):
        return {"provider": None, "model": None,
                "error": "the routing configuration is unreadable; refusing to route",
                "profile_id": None, "profile_name": None,
                "policy": None, "at": time.time()}
    out: dict[str, Any] = {"provider": None, "model": None, "error": None,
                           "profile_id": None, "profile_name": None,
                           "policy": settings.get("policy"), "at": time.time()}
    provider, model, error, profile = _resolve_route_inner(store_dir=store_dir, providers=providers,
                                                           settings=settings,
                                                           engine_loader=engine_loader,
                                                           profiles_loader=profiles_loader,
                                                           bound_profile_id=bound_profile_id)
    out.update({"provider": provider, "model": model, "error": error,
                "profile_id": (profile or {}).get("id"), "profile_name": (profile or {}).get("name")})
    return out


def resolve_route(*, store_dir, providers, settings, engine_loader=None,
                  profiles_loader=None, bound_profile_id=None) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """Canonical resolution to (provider, model, error). Fails closed.

    ``store_dir``/``providers``/``settings`` are injected so callers keep
    their override seams. An absent/corrupt store, an unreadable default
    profile, or a merged constraint violation all refuse the route instead of
    silently changing what the user asked for.
    """
    out = resolve_route_detailed(store_dir=store_dir, providers=providers, settings=settings,
                                 engine_loader=engine_loader, profiles_loader=profiles_loader,
                                 bound_profile_id=bound_profile_id)
    return out["provider"], out["model"], out["error"]


def _resolve_route_inner(*, store_dir, providers, settings, engine_loader, profiles_loader,
                         bound_profile_id=None):
    if store_dir is None or not store_dir.is_dir():
        return None, None, "no AutoRouter catalog (disabled or not seeded)", None
    router_mod, state_mod = engine_loader()
    if router_mod is None or state_mod is None:
        return None, None, "auto-router engine unavailable", None
    try:
        store = state_mod.StateStore(store_dir)
    except Exception as exc:
        return None, None, f"invalid AutoRouter catalog: {exc}", None

    routing = settings
    profiles_mod = profiles_loader()
    profile, profile_error = None, None
    if bound_profile_id is not None:
        # Session-binding path: resolution is pinned to the requested stored
        # profile. It can only narrow the route; the operator's default is
        # never consulted for this session.
        profile, profile_error = load_profile_by_id(store, bound_profile_id)
        if profile_error is not None:
            return None, None, (f"the session-bound routing profile is unavailable "
                                f"({profile_error}); refusing to route instead of "
                                "falling back to any default"), None
        if profile is None:
            return None, None, ("the session-bound routing profile no longer exists; "
                                "refusing to route instead of falling back to any default"), None
        if profiles_mod is None:
            return None, None, ("the bound routing profile exists but its module could not "
                                "be loaded; refusing to route"), None
    else:
        try:
            profile, profile_error = state_mod.active_routing_profile(store)
        except Exception as exc:
            profile, profile_error = None, f"active profile unreadable: {exc}"
        if profiles_mod is None and profile is None and profile_error is None:
            # The routing engine is up but the profile module did not load.
            # If a default is configured we cannot know what it pins; fail closed.
            if default_profile_configured(store):
                return None, None, ("the AutoRouter default routing profile is set "
                                    "but its module could not be loaded; refusing to route"), None
        if profile_error is not None:
            return None, None, (f"the AutoRouter default routing profile is unavailable "
                                f"({profile_error}); refusing to route instead of falling "
                                "back to the global policy"), None
    if profile is not None:
        assert profiles_mod is not None
        authorized = list(providers)
        routing, merge_error = profiles_mod.merge_global_and_profile(
            routing, profile, authorized_providers=authorized)
        if merge_error:
            return None, None, (f"{merge_error}; refusing to route instead of "
                                "falling back to the global policy"), None
        providers = routing["providers"]

    model_mode = routing.get("model_mode") or ("allowlist" if routing.get("model_include_pairs") else "unrestricted")
    if model_mode == "none":
        return None, None, (
            "no model is enabled (every model is toggled off in the model preference); "
            "refusing to route until the user enables a model or resets the preference"
        ), None

    config = {
        "strategy": "auto",
        "policy": routing["policy"],
        "free_only": True,
        "paid_authorized": False,
        "providers": list(providers),
        "cooldown_seconds": routing.get("cooldown_seconds", 60),
        "store": store,
        "requires_tools": routing["requires_tools"],
        "min_context": routing["min_context"],
        "model_mode": model_mode,
        "model_exclude_pairs": routing["model_exclude_pairs"],
        "model_include_pairs": routing["model_include_pairs"],
    }

    chosen = hybrid_select(config, engine_loader=engine_loader)
    if chosen is None:
        suffix = f", profile={routing.get('profile_name')!r}" if routing.get("profile_name") else ""
        return None, None, (
            "no eligible free model under the current routing policy "
            f"(policy={routing['policy']}, min_context={routing['min_context']}, "
            f"requires_tools={routing['requires_tools']}{suffix})"
        ), None

    include = routing["model_include_pairs"]
    if include and (chosen["provider"], chosen["model"]) not in include:
        return None, None, (
            f"resolved model {chosen['provider']}/{chosen['model']} is not in the "
            "model_include allowlist"
        ), None

    profile_ref = {"id": profile.get("id"), "name": profile.get("name")} if isinstance(profile, dict) else None
    return chosen["provider"], chosen["model"], None, profile_ref
