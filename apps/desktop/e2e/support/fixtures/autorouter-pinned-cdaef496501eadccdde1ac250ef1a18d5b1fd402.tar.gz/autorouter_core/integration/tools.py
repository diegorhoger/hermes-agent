"""Tools registered by AutoRouter."""

from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)

from ..configuration.policies import POLICY_OPTIONS, ALIASES, contract
from ..configuration.selection_policy import MISSING, validate, requirements, request_schema
from ..integration import runtime

TOOLSET = "autorouter"


def _rt():
    return runtime


def _status_handler(args: dict, **kwargs) -> dict:
    r = _rt().get_router()
    if r is None:
        return {"ok": False, "error": "router not initialized"}
    from ..routing.task_profiles import catalog
    from ..routing.execution_adapter import capabilities
    from . import native_routing
    detection = native_routing.detect_host_native_routing()
    return dict(r.status(), policy_contract=contract(), task_profiles=catalog(),
                execution_capabilities=capabilities(), native_routing=detection)


def _refresh_handler(args: dict, **kwargs) -> dict:
    r = _rt().get_router()
    if r is None:
        return {"ok": False, "error": "router not initialized"}
    result = r.refresh()
    if args.get("include_quota") is True:
        from ..evidence.free_access import refresh
        result = dict(result, quota=refresh(r, quota_policy=args.get('quota_policy', 'avoid_verified_exhaustion')))
    return result


def _select_handler(args: dict, **kwargs) -> dict:
    r = _rt().get_router()
    if r is None:
        return {"ok": False, "error": "router not initialized"}
    from ..configuration.policies import resolve
    try:
        policy = args.get("policy", r.policy)
        resolve(policy)
        selected_contract = args.get("selection_policy", MISSING)
        if selected_contract is not MISSING:
            validate(selected_contract)
        has_profile = selected_contract is not MISSING and "profile" in selected_contract["task_requirements"]
        requires_tools = args.get("requires_tools", not has_profile)
        min_context = args.get("min_context", 8192)
        if (type(requires_tools) is not bool or type(min_context) is not int or min_context < 1
                or type(args.get("strict_no_charge", False)) is not bool):
            raise ValueError("invalid constraints")
        if selected_contract is not MISSING:
            requirements(selected_contract, requires_tools, min_context)
        if "handoff" in args and (not isinstance(args["handoff"],dict) or set(args["handoff"]) != {"confirmed"} or type(args["handoff"]["confirmed"]) is not bool):
            raise ValueError("invalid handoff")
    except (ValueError, TypeError) as error:
        denied = {"ok": False, "error": "invalid policy or constraints"}
        if "selection_policy" in args:
            denied["error_code"] = getattr(error, "code", "selection_policy_invalid")
        return denied
    decision = r.select(requires_tools=requires_tools, min_context=min_context,
        strict_no_charge=args.get("strict_no_charge") is True, policy=policy,
        return_decision=True, selection_policy=selected_contract)
    chosen = decision["chosen"]
    if chosen is None:
        return {"ok": False, "error": "no eligible model", "providers_exhausted": True,
                "decision": decision}
    result = {"ok": True, "provider": chosen["provider"], "model": chosen["model"], "decision": decision}
    if "handoff" in args:
        from ..routing.execution_adapter import ManualHermesAdapter
        from ..routing.router import Router
        adapter=ManualHermesAdapter(Router(dict(r.state,policy=policy)))
        selection=dict(schema_version=1,provider=chosen["provider"],model=chosen["model"],generated_at=decision["generated_at"])
        result["handoff_receipt"]=adapter.handoff(selection,confirmed=args["handoff"]["confirmed"],
            selection_policy=selected_contract,requires_tools=requires_tools,min_context=min_context)
    return result



_STATUS_SCHEMA = {
    "name": "autorouter_status",
    "description": "Show AutoRouter state and catalog summary.",
    "parameters": {"type": "object", "properties": {}, "required": []},
}

_REFRESH_SCHEMA = {
    "name": "autorouter_refresh",
    "description": "Refresh AutoRouter model catalogs without restarting the gateway.",
    "parameters": {"type": "object", "properties": {
        "quota_policy": {"type":"string", "default":"avoid_verified_exhaustion",
            "enum":["prefer_available_allowance", "require_fresh_account_allowance", "avoid_verified_exhaustion", "require_no_charge_guarantee"],
            "description":"Read-only cached preflight policy; never authorizes credential use or execution."},
        "include_quota": {"type":"boolean", "default":False,
            "description":"Explicitly request cached, rate-limited read-only quota metadata for configured credential scopes."}
        }, "required": []},
}

_SELECT_SCHEMA = {
    "name": "autorouter_select",
    "description": "Select an eligible model using AutoRouter policy.",
    "parameters": {
        "type": "object",
        "properties": {
            "selection_policy": request_schema(),
            "handoff": {"type":"object","additionalProperties":False,"properties":{"confirmed":{"type":"boolean"}},"required":["confirmed"],
                "description":"Only after explicit user confirmation: prepare supported manual CLI steps. Never applies or executes a model."},
            "policy": {"type": "string", "enum": list(POLICY_OPTIONS) + list(ALIASES),
                "description": "Ranking preference among verified-free eligible models; never enables paid fallback."},
            "requires_tools": {"type": "boolean", "default": True},
            "strict_no_charge": {"type":"boolean","default":False,
                "description":"Require an independently verified no-charge execution guarantee; currently unavailable and therefore denies selection."},
            "min_context": {"type": "integer", "default": 8192},
        },
        "required": [],
    },
}


def register_tools(ctx) -> None:
    ctx.register_tool(
        name="autorouter_status", toolset=TOOLSET, schema=_STATUS_SCHEMA,
        handler=_status_handler, description="AutoRouter status", emoji="🔀",
    )
    ctx.register_tool(
        name="autorouter_refresh", toolset=TOOLSET, schema=_REFRESH_SCHEMA,
        handler=_refresh_handler, description="Refresh AutoRouter catalogs", emoji="🔄",
    )
    ctx.register_tool(
        name="autorouter_select", toolset=TOOLSET, schema=_SELECT_SCHEMA,
        handler=_select_handler, description="Select model via AutoRouter", emoji="🎯",
    )
