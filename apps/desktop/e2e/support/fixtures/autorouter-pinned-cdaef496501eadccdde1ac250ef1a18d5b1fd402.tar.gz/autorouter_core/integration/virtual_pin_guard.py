"""Deactivation safety for the AutoRouter virtual model.

The chat-router adapter (``enable_chat_router: true``) is the only thing that
makes ``autorouter/auto-free`` resolvable. When chat routing is disabled —
the explicit deactivation checkbox in the dashboard, a gateway restart with
the flag off, or a failed adapter load — that marker is no longer rewritten
by anything inside the plugin. If the profile's persisted configuration pins
it (``model.default``/``model``), the **next** session would send the marker
to the configured endpoint verbatim. That is an unsafe operational condition
(potentially billable, guaranteed non-functional).

This module is the strongest guard the plugin can enforce within its own
authority, which is deliberately narrow:

* it **never** blocks or intercepts a host request; without the adapter there
  is no plugin interception point in Hermes, and none is claimed;
* it **never** guesses or substitutes a replacement provider/model, and
  **never** silently enables any provider;
* it **never rewrites the persisted profile configuration.** Historical
  ``decisions``/``requests`` rows are usage history, not authoritative
  snapshots of the previously configured route — a selected model was not
  necessarily configured, and a request does not prove success or imply the
  model is appropriate now. Neither is consulted for restoration. Earlier
  revisions of this module restored a route inferred from those rows; that
  path was removed. Restoration would require a *complete*, separately
  authorized, authoritative configuration snapshot (model, provider, endpoint
  and credential scope, with provenance and explicit user authorization) that
  does not exist in this plugin; without one, the configuration is preserved
  verbatim — including any endpoint/credential fields — rather than edited
  half-way (see docs/adapter-deactivation-boundary.md);
* it detects the pin read-only (config + advisory env marker), logs a
  critical message in logs and persists a durable marker in the plugin's own
  store that the dashboard renders as a red banner; the banner directs the
  user to select a real model via Hermes ``/model`` or re-enable AutoRouter
  and restart;
* a stale in-memory session whose model was already resolved keeps that
  route; guarding live sessions is outside the plugin's authority and is not
  attempted.

Full boundary analysis and the recommendation for a sanctioned host-side
guard live in ``docs/adapter-deactivation-boundary.md``.
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import sys
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

VIRTUAL_MARKER = "autorouter/auto-free"
VIRTUAL_PROVIDER = "autorouter"

# Durable, human-visible status persisted in the plugin's own store; the
# dashboard renders a banner when it is present. None of this data is secret:
# it is a pin presence verdict, not a credential.
_GUARD_META_KEY = "virtual_pin_guard"

_ACTION = (
    "Run /model and select a real model, or re-enable AutoRouter chat routing "
    "and restart the gateway. The configuration was NOT modified."
)


def detect_virtual_pin(cfg: Any, env: Optional[dict] = None) -> list[dict[str, str]]:
    """Return every unresolved virtual pin visible in config/env.

    ``cfg`` is the raw host config mapping (already read readonly by the
    caller); ``env`` defaults to ``os.environ``. Absence/unreadability means
    "no finding" — the caller still treats an unknown config as no-op.
    """
    pins: list[dict[str, str]] = []
    if isinstance(cfg, dict):
        model = cfg.get("model")
        if isinstance(model, str) and model.strip().lower() == VIRTUAL_MARKER:
            pins.append({"source": "config.model", "detail": model.strip()})
        elif isinstance(model, dict):
            default = model.get("default")
            if isinstance(default, str) and default.strip().lower() == VIRTUAL_MARKER:
                pins.append({"source": "config.model.default", "detail": default.strip()})
    if env is None:
        env = os.environ
    if isinstance(env, dict):
        value = env.get("HERMES_INFERENCE_MODEL")
        if isinstance(value, str) and value.strip().lower() == VIRTUAL_MARKER:
            pins.append({"source": "env.HERMES_INFERENCE_MODEL", "detail": value.strip()})
    return pins


def _write_marker(store_dir: Optional[Path], report: dict[str, Any]) -> None:
    """Persist the guard outcome for the dashboard. Best effort.

    Healthy outcomes (``clear`` / ``routing_active``) are only superseded in a
    store that already exists — the guard must never materialize plugin state
    just to report that nothing is wrong. The unresolved-pin verdict is the
    exception: it may create the minimal meta table so a pinned profile is
    still surfaced even before first use; the plugin's own schema init
    overwrites nothing it did not create.
    """
    if store_dir is None:
        return
    try:
        db_path = Path(store_dir) / "autorouter.db"
        allow_create = report.get("state") == "unresolved_pin"
        if not allow_create and not db_path.is_file():
            return
        if allow_create:
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(db_path), timeout=2.0)
        try:
            conn.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            conn.execute(
                "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
                (_GUARD_META_KEY, json.dumps(report, separators=(",", ":"), sort_keys=True)),
            )
            conn.commit()
        finally:
            conn.close()
    except Exception:
        logger.debug("autorouter virtual-pin guard: could not persist marker", exc_info=True)


def read_marker(store_dir: Optional[Path]) -> Optional[dict[str, Any]]:
    """Read the persisted guard outcome (read-only). None when absent/unreadable."""
    if store_dir is None:
        return None
    try:
        conn = sqlite3.connect(f"file:{Path(store_dir) / 'autorouter.db'}?mode=ro", uri=True)
        try:
            row = conn.execute("SELECT value FROM meta WHERE key = ?", (_GUARD_META_KEY,)).fetchone()
        finally:
            conn.close()
    except Exception:
        return None
    if not row:
        return None
    try:
        value = json.loads(row[0])
    except Exception:
        return None
    return value if isinstance(value, dict) else None


def _routing_interposed() -> bool:
    """True when the chat-router adapter is interposed in THIS process.

    Reads the host-bound marker only when hermes_cli.model_switch is already
    in sys.modules — never imports the host, which would bind a socket and
    violate the plugin isolation contract at load time.
    """
    _ms = sys.modules.get("hermes_cli.model_switch")
    if _ms is None:
        return False
    return bool(getattr(getattr(_ms, "switch_model", None), "_ar_patched", False))


def _unresolved_report(pins: list[dict[str, str]], now: float) -> dict[str, Any]:
    return {
        "schema_version": 2,
        "state": "unresolved_pin",
        "pins": pins,
        "restored": None,
        "restore_error": "not attempted — historical usage rows are not authoritative configuration snapshots",
        "detail": (
            "Profile is pinned to the unresolved virtual model 'autorouter/auto-free' while chat "
            "routing is disabled. The next chat would send the virtual marker upstream verbatim. "
            "The configuration was NOT modified; no provider was substituted. " + _ACTION
        ),
        "action": _ACTION,
        "ts": now,
    }


def guard(store_dir: Optional[Path], cfg: Any = None, env: Optional[dict] = None,
          _routing_check=_routing_interposed, assume_disabled: bool = False) -> dict[str, Any]:
    """Evaluate a dangling virtual pin. Never raises; never modifies config.

    Safe to call repeatedly. Every failure degrades to a conservative report.
    Healthy outcomes (``routing_active`` / ``clear``) also persist, so a stale
    unresolved-pin banner disappears once the user fixes the pin or re-enables
    routing. An unreadable profile config yields ``guard_error`` and persists
    nothing, so a stale unresolved-pin banner is never cleared on unknown.

    ``assume_disabled=True`` skips the in-process interposition check. Callers
    that already know routing is off for the *next* process (the dashboard
    deactivation save, where the adapter stays interposed in the current
    process until restart) must use it, so the persisted verdict reflects the
    state the next host load will actually see. This function performs no
    writes to the profile configuration — it reports loudly instead.
    """
    now = time.time()
    try:
        if not assume_disabled and _routing_check():
            report = {"schema_version": 2, "state": "routing_active", "pins": [], "ts": now}
            _write_marker(store_dir, report)
            return report
        cfg_available = cfg is not None
        if cfg is None:
            try:
                from hermes_cli.config import load_config_readonly
                cfg = load_config_readonly()
                cfg_available = True
            except Exception:
                cfg = None
        pins = detect_virtual_pin(cfg, env)
        if not pins and not cfg_available:
            # Unknown config: never claim the profile is clean; never clear a
            # previously persisted unresolved-pin banner.
            report = {
                "schema_version": 2, "state": "guard_error", "pins": [], "ts": now,
                "detail": ("Profile configuration could not be read; the virtual-pin check "
                           "could not run. Any previously persisted unresolved-pin warning "
                           "was left in place."),
            }
            logger.warning("autorouter virtual-pin guard: %s", report["detail"])
            return report
        if not pins:
            report = {"schema_version": 2, "state": "clear", "pins": [], "ts": now}
            _write_marker(store_dir, report)
            return report
        report = _unresolved_report(pins, now)
        _write_marker(store_dir, report)
        logger.critical(
            "autorouter virtual-pin guard: %s (detected at: %s)",
            report["detail"], sorted({p["source"] for p in pins}),
        )
        return report
    except Exception:
        logger.warning("autorouter virtual-pin guard failed", exc_info=True)
        return {"schema_version": 2, "state": "guard_error", "pins": [], "ts": now}
