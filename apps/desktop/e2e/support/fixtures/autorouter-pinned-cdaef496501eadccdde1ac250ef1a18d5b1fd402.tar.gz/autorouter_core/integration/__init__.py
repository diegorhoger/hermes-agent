"""AutoRouter integration package."""
