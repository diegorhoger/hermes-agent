"""Profile-scoped durable state, with non-destructive legacy SQLite migration."""
from __future__ import annotations

import os
from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
from urllib.parse import quote


def _readonly(path):
    return sqlite3.connect('file:' + quote(str(path.resolve()), safe='/') + '?mode=ro', uri=True)


def _check_database(path):
    with closing(_readonly(path)) as conn:
        if conn.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise RuntimeError('AutoRouter database integrity check failed')


def _migrate_database(source, target):
    if target.exists():
        _check_database(target)
        return
    if not source.is_file():
        return
    _check_database(source)
    # SQLite backup includes committed WAL rows; copying the .db alone loses them.
    handle, temporary = tempfile.mkstemp(prefix='.autorouter-migrate-', suffix='.db', dir=target.parent)
    os.close(handle)
    temporary = Path(temporary)
    try:
        with closing(_readonly(source)) as old, closing(sqlite3.connect(temporary)) as new:
            old.backup(new)
        _check_database(temporary)
        with temporary.open('rb') as stream:
            os.fsync(stream.fileno())
        try:
            os.link(temporary, target)  # Atomic publication, never replaces another process's DB.
        except FileExistsError:
            _check_database(target)
    finally:
        temporary.unlink(missing_ok=True)


def _owned_legacy(root, plugin_root):
    # Shared/root fallback and symlinked installs do not establish ownership.
    owned_install = root.parent.parent.resolve() / 'plugins' / 'autorouter'
    if Path(plugin_root).resolve() != owned_install:
        return None
    legacy = owned_install / 'state' / 'autorouter.db'
    sources = (legacy, Path(str(legacy) + '-wal'), Path(str(legacy) + '-shm'))
    return legacy if all(path.resolve() == path for path in sources) else None


def resolve_state_dir(config_state_dir: object, plugin_root: object) -> Path:
    """Read-only profile path lookup, including legacy diagnostics before migration."""
    raw = str(config_state_dir or '').strip()
    if raw:
        return Path(raw)
    from hermes_constants import get_hermes_home
    # plugin_data_dir creates directories: readers use the same documented layout.
    root = get_hermes_home() / 'plugin-data' / 'autorouter'
    legacy = _owned_legacy(root, plugin_root)
    if not (root / 'autorouter.db').exists() and legacy is not None and legacy.is_file():
        return legacy.parent
    return root


def initialize_state_dir(config_state_dir: object, plugin_root: object) -> Path:
    """Runtime startup only; migrate once with legacy writers stopped by the owner."""
    raw = str(config_state_dir or '').strip()
    if raw:
        return Path(raw)
    from plugins.plugin_storage import plugin_data_dir
    root = plugin_data_dir('autorouter')
    legacy = _owned_legacy(root, plugin_root)
    if legacy is not None:
        _migrate_database(legacy, root / 'autorouter.db')
    return root
