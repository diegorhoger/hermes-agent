"""Read-only state access for diagnostics; never initializes or migrates storage."""
from pathlib import Path
import sqlite3

from .state import StateStore


class ReadOnlyStateStore(StateStore):
    def __init__(self, db_path):
        self.db_path = Path(db_path)

    def _connect(self):
        conn = sqlite3.connect(self.db_path.resolve().as_uri() + '?mode=ro', uri=True, timeout=5)
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA query_only=ON')
        return conn
