"""SQLite-backed state store for AutoRouter."""

from __future__ import annotations

import json
import hashlib
import re
import sqlite3
import time
from pathlib import Path
from typing import Any, Optional

SCHEMA_VERSION = 6

TELEMETRY_TABLES = (
    "requests",
    "request_attempts",
    "request_hourly",
    "cache_events",
    "search_events",
    "credential_scopes",
    "lifetime_counters",
)


def _opaque_id(value):
    if not isinstance(value, str) or not value:
        return None
    return "id_" + hashlib.sha256(value.encode("utf-8")).hexdigest()


def _telemetry_label(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}", value):
        return None
    if re.search(r"(?i)(?:sk-|sk_|bearer|api[_-]?key|token[=:])", value):
        return None
    return value


def safe_telemetry_error(value):
    """Existing telemetry category allowlist, shared by persistence and legacy reads."""
    from ..telemetry.telemetry import ERROR_CATEGORIES
    return value if value in ERROR_CATEGORIES or value == "Unobserved completion" else None


_error_category = safe_telemetry_error


HEALTH_ERROR_CODES = ('auth', 'rate_limit', 'quota_exhausted', 'concurrency_limited',
                      'provider_error', 'transport_error', 'unknown_error', 'model_retired', 'legacy_error')


def safe_health_error(value):
    """Use the existing migration taxonomy without exposing legacy error bodies."""
    return value if value is None or value in HEALTH_ERROR_CODES else 'legacy_error'


def read_scoring_observations(conn, provider, model, key_scope=""):
    """Shared bounded SELECT contract for normal and already-open read-only stores."""
    from ..telemetry.telemetry import redact_key_scope
    from ..routing.scoring import SAMPLE_LIMIT
    try:
        rows = conn.execute("""SELECT id,api_request_id,status,latency_ms,ended_at FROM requests INDEXED BY idx_requests_scoring
            WHERE provider=? AND model=? AND key_scope=? ORDER BY created_at DESC,id DESC LIMIT ?""",
            (provider, model, redact_key_scope(key_scope), SAMPLE_LIMIT)).fetchall()
        accepted = []
        for row in rows:
            if not row["api_request_id"] or row["status"] not in ("success", "error"):
                continue
            attempts = conn.execute("""SELECT provider,model FROM request_attempts
                WHERE request_id=? ORDER BY ordinal DESC LIMIT 17""", (row["id"],)).fetchall()
            if not attempts or len(attempts) > 16 or any(a["provider"] != provider or a["model"] != model for a in attempts):
                continue
            accepted.append(dict(row))
        return {"available": True, "rows": accepted}
    except sqlite3.Error:
        return {"available": False, "rows": []}


def read_health_observation(conn, provider, model, key_scope=""):
    """Canonical health defaults and legacy scope lookup, without opening storage."""
    from ..health.health import scope_id
    original_scope = key_scope
    key_scope = scope_id(key_scope)
    row = conn.execute(
        "SELECT * FROM health WHERE provider=? AND model=? AND key_scope IN (?,?) ORDER BY key_scope=? DESC LIMIT 1",
        (provider, model, key_scope, original_scope, key_scope),
    ).fetchone()
    if row:
        return dict(row, key_scope=key_scope, last_error=safe_health_error(row["last_error"]))
    return {
        "provider": provider, "model": model, "key_scope": key_scope,
        "successes": 0, "failures": 0, "consecutive_failures": 0,
        "last_status": None, "last_error": None, "last_latency_ms": None,
        "last_success_at": None, "last_failure_at": None, "cooldown_until": 0,
        "retired": 0, "auth_failed": 0,
    }


class StateStore:
    def __init__(self, state_dir: Path):
        self.state_dir = Path(state_dir)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.state_dir / "autorouter.db"
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), timeout=10.0)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA journal_mode=WAL")
        except Exception:
            pass
        return conn

    def _init_db(self) -> None:
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            self._execute_schema(conn,
                """
                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS catalog (
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    context_length INTEGER,
                    capabilities TEXT,
                    cost_tier TEXT,
                    updated_at REAL NOT NULL,
                    PRIMARY KEY (provider, model)
                );
                CREATE TABLE IF NOT EXISTS health (
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    key_scope TEXT NOT NULL DEFAULT '',
                    successes INTEGER NOT NULL DEFAULT 0,
                    failures INTEGER NOT NULL DEFAULT 0,
                    consecutive_failures INTEGER NOT NULL DEFAULT 0,
                    last_status INTEGER,
                    last_error TEXT,
                    last_latency_ms REAL,
                    last_success_at REAL,
                    last_failure_at REAL,
                    cooldown_until REAL NOT NULL DEFAULT 0,
                    retired INTEGER NOT NULL DEFAULT 0,
                    auth_failed INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (provider, model, key_scope)
                );
                CREATE TABLE IF NOT EXISTS decisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts REAL NOT NULL,
                    policy TEXT,
                    provider TEXT,
                    model TEXT,
                    reason TEXT,
                    candidates INTEGER
                );
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts REAL NOT NULL,
                    kind TEXT,
                    provider TEXT,
                    model TEXT,
                    status_code INTEGER,
                    detail TEXT
                );
                CREATE TABLE IF NOT EXISTS lkg_catalog (
                    version INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts REAL NOT NULL,
                    payload TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS capabilities (
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    capability_json TEXT NOT NULL,
                    metadata_source TEXT,
                    retrieved_at REAL NOT NULL,
                    expires_at REAL NOT NULL DEFAULT 0,
                    version INTEGER NOT NULL DEFAULT 1,
                    PRIMARY KEY (provider, model)
                );
                """
            )
            conn.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))
            conn.execute(
                """CREATE TABLE IF NOT EXISTS capabilities (
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    capability_json TEXT NOT NULL,
                    metadata_source TEXT,
                    retrieved_at REAL NOT NULL,
                    expires_at REAL NOT NULL DEFAULT 0,
                    version INTEGER NOT NULL DEFAULT 1,
                    PRIMARY KEY (provider, model)
                )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS in_flight (
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    reserved INTEGER NOT NULL DEFAULT 0,
                    updated_at REAL,
                    PRIMARY KEY (provider, model)
                )"""
            )
            self._init_telemetry_schema(conn)
            conn.execute("""CREATE TABLE IF NOT EXISTS health_circuits (
                provider TEXT NOT NULL, layer TEXT NOT NULL, model TEXT NOT NULL, scope TEXT NOT NULL,
                failures INTEGER NOT NULL DEFAULT 0, threshold INTEGER NOT NULL DEFAULT 3,
                opened_until REAL NOT NULL DEFAULT 0, reason TEXT NOT NULL,
                updated_at REAL NOT NULL, event_observed_at REAL, PRIMARY KEY(provider, layer, model, scope, reason))""")
            circuit_columns = {row[1] for row in conn.execute("PRAGMA table_info(health_circuits)")}
            if "event_observed_at" not in circuit_columns:
                conn.execute("ALTER TABLE health_circuits ADD COLUMN event_observed_at REAL")
            conn.execute("""CREATE TABLE IF NOT EXISTS routing_profiles (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL COLLATE NOCASE,
                description TEXT NOT NULL DEFAULT '',
                schema_version INTEGER NOT NULL,
                ranking_policy TEXT NOT NULL,
                providers TEXT NOT NULL DEFAULT '[]',
                model_include TEXT NOT NULL DEFAULT '[]',
                model_exclude TEXT NOT NULL DEFAULT '[]',
                min_context INTEGER NOT NULL DEFAULT 8192,
                requires_tools INTEGER NOT NULL DEFAULT 0,
                health TEXT NOT NULL DEFAULT '{\"respect_failures\": true, \"respect_cooldowns\": true, \"require_observed\": false}',
                task_tags TEXT NOT NULL DEFAULT '[]',
                fallback_policy TEXT NOT NULL DEFAULT 'refuse',
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_routing_profiles_updated ON routing_profiles(updated_at)")
            self._migrate_health_scopes(conn)
            self._preserve_legacy_denials(conn, conn.execute("SELECT * FROM health").fetchall(), time.time())
            conn.execute("UPDATE health SET last_error='legacy_error' WHERE last_error IS NOT NULL AND last_error NOT IN ("
                         + ",".join("?" for _ in HEALTH_ERROR_CODES) + ")", HEALTH_ERROR_CODES)
            conn.execute(
                "INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version',?)",
                (str(SCHEMA_VERSION),),
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    @staticmethod
    def _migrate_health_scopes(conn):
        from ..health.health import scope_id
        for row in conn.execute("SELECT * FROM health WHERE key_scope!=''").fetchall():
            old = row["key_scope"]
            scope = scope_id(old)
            if scope == old:
                continue
            existing = conn.execute("SELECT 1 FROM health WHERE provider=? AND model=? AND key_scope=?",
                                    (row["provider"], row["model"], scope)).fetchone()
            if existing:
                conn.execute("""UPDATE health SET successes=successes+?,failures=failures+?,
                    consecutive_failures=MAX(consecutive_failures,?),cooldown_until=MAX(cooldown_until,?),
                    retired=MAX(retired,?),auth_failed=MAX(auth_failed,?),
                    last_success_at=MAX(COALESCE(last_success_at,0),COALESCE(?,0)),
                    last_failure_at=MAX(COALESCE(last_failure_at,0),COALESCE(?,0))
                    WHERE provider=? AND model=? AND key_scope=?""",
                    (row["successes"],row["failures"],row["consecutive_failures"],row["cooldown_until"],
                     row["retired"],row["auth_failed"],row["last_success_at"],row["last_failure_at"],
                     row["provider"],row["model"],scope))
                conn.execute("DELETE FROM health WHERE provider=? AND model=? AND key_scope=?",
                             (row["provider"],row["model"],old))
            else:
                conn.execute("UPDATE health SET key_scope=? WHERE provider=? AND model=? AND key_scope=?",
                             (scope,row["provider"],row["model"],old))

    @staticmethod
    def _preserve_legacy_denials(conn, rows, now):
        for row in rows:
            denies = []
            if row["retired"]:
                denies.append(("model", row["model"], "", "model_retired", 0))
            if row["auth_failed"]:
                denies.append(("credential", "", row["key_scope"], "auth", max(float(row["cooldown_until"] or 0), now + 3600)))
            if row["cooldown_until"] and not row["auth_failed"] and not row["retired"]:
                denies.append(("connection", row["model"], row["key_scope"], "rate_limit", row["cooldown_until"]))
            observed_at = row["last_failure_at"]
            import math
            observed_at = observed_at if type(observed_at) in (int,float) and math.isfinite(observed_at) and observed_at > 0 else None
            for layer, model, scope, reason, until in denies:
                conn.execute("""INSERT OR IGNORE INTO health_circuits
                    (provider,layer,model,scope,failures,threshold,opened_until,reason,updated_at,event_observed_at)
                    VALUES(?,?,?,?,1,1,?,?,?,?)""", (row["provider"],layer,model,scope,until,reason,now,observed_at))

    @staticmethod
    def _execute_schema(conn: sqlite3.Connection, script: str) -> None:
        # executescript commits an open transaction, preventing migration rollback.
        statement = ""
        for line in script.splitlines(keepends=True):
            statement += line
            if sqlite3.complete_statement(statement):
                conn.execute(statement)
                statement = ""
        if statement.strip():
            raise ValueError("Incomplete schema statement")

    def _init_telemetry_schema(self, conn: sqlite3.Connection) -> None:
        """Analytics telemetry tables (v2).

        Prompt/response content is never stored. Only counters, identifiers,
        timings and hashed scope buckets are persisted.
        """
        self._execute_schema(conn,
            """
            CREATE TABLE IF NOT EXISTS requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                api_request_id TEXT UNIQUE,
                task_id TEXT,
                turn_id TEXT,
                session_hash TEXT,
                platform TEXT,
                provider TEXT,
                model TEXT,
                response_model TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                input_tokens INTEGER,
                output_tokens INTEGER,
                latency_ms REAL,
                ttft_ms REAL,
                error_category TEXT,
                error_summary TEXT,
                key_scope TEXT NOT NULL DEFAULT '',
                approx_input_tokens INTEGER,
                started_at REAL,
                ended_at REAL,
                created_at REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_requests_created ON requests(created_at);
            CREATE INDEX IF NOT EXISTS idx_requests_provider ON requests(provider, created_at);
            CREATE INDEX IF NOT EXISTS idx_requests_model ON requests(provider, model, created_at);
            CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status, created_at);
            CREATE INDEX IF NOT EXISTS idx_requests_scoring ON requests(provider, model, key_scope, created_at DESC, id DESC);
            CREATE TABLE IF NOT EXISTS request_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_id INTEGER NOT NULL REFERENCES requests(id),
                ordinal INTEGER NOT NULL,
                provider TEXT,
                model TEXT,
                key_scope TEXT NOT NULL DEFAULT '',
                status_code INTEGER,
                retryable INTEGER,
                reason TEXT,
                error_category TEXT,
                duration_ms REAL,
                created_at REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_attempts_request ON request_attempts(request_id, ordinal);
            CREATE TABLE IF NOT EXISTS request_hourly (
                hour TEXT PRIMARY KEY,
                total_requests INTEGER NOT NULL DEFAULT 0,
                success_count INTEGER NOT NULL DEFAULT 0,
                error_count INTEGER NOT NULL DEFAULT 0,
                canceled_count INTEGER NOT NULL DEFAULT 0,
                input_tokens INTEGER NOT NULL DEFAULT 0,
                output_tokens INTEGER NOT NULL DEFAULT 0,
                latency_sum REAL NOT NULL DEFAULT 0,
                latency_count INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS cache_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                provider TEXT,
                model TEXT,
                hit INTEGER NOT NULL DEFAULT 0,
                latency_ms REAL,
                source TEXT NOT NULL DEFAULT 'bounded_ingestion'
            );
            CREATE INDEX IF NOT EXISTS idx_cache_ts ON cache_events(ts);
            CREATE TABLE IF NOT EXISTS search_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                provider TEXT,
                query_length INTEGER,
                latency_ms REAL,
                results_count INTEGER,
                source TEXT NOT NULL DEFAULT 'bounded_ingestion'
            );
            CREATE INDEX IF NOT EXISTS idx_search_ts ON search_events(ts);
            CREATE TABLE IF NOT EXISTS credential_scopes (
                provider TEXT NOT NULL,
                key_scope_hash TEXT NOT NULL,
                last_auth_ok INTEGER,
                last_reason TEXT,
                last_seen REAL NOT NULL,
                observation_count INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (provider, key_scope_hash)
            );
            CREATE TABLE IF NOT EXISTS lifetime_counters (
                key TEXT PRIMARY KEY,
                value INTEGER NOT NULL DEFAULT 0
            );
            """
        )
        attempt_columns = {row[1] for row in conn.execute("PRAGMA table_info(request_attempts)")}
        if "key_scope" not in attempt_columns:
            conn.execute("ALTER TABLE request_attempts ADD COLUMN key_scope TEXT NOT NULL DEFAULT ''")

    # ---- telemetry: requests / attempts / hourly / cache / search ----
    def begin_request(self, *, api_request_id=None, task_id=None, turn_id=None,
                      session_hash=None, platform=None, provider=None, model=None,
                      key_scope="", approx_input_tokens=None, started_at=None):
        try:
            from ..telemetry.telemetry import redact_key_scope
            scope = redact_key_scope(key_scope)
        except Exception:
            scope = ""
        api_request_id = _opaque_id(api_request_id)
        task_id, turn_id = _opaque_id(task_id), _opaque_id(turn_id)
        session_hash = _opaque_id(session_hash)
        platform, provider, model = map(_telemetry_label, (platform, provider, model))
        now = time.time()
        started = float(started_at) if started_at is not None else now
        conn = self._connect()
        try:
            with conn:  # atomic: rollback on any failure
                if api_request_id:
                    existing = conn.execute("SELECT id FROM requests WHERE api_request_id=?", (api_request_id,)).fetchone()
                    if existing is not None:
                        return existing["id"]
                    conn.execute(
                        """INSERT OR IGNORE INTO requests(
                            api_request_id, task_id, turn_id, session_hash, platform,
                            provider, model, status, key_scope, approx_input_tokens,
                            started_at, created_at)
                           VALUES(?,?,?,?,?,?,?, 'pending',?,?,?,?)""",
                        (api_request_id, task_id, turn_id, session_hash, platform,
                         provider, model, scope, approx_input_tokens, started, now),
                    )
                    row = conn.execute(
                        "SELECT id FROM requests WHERE api_request_id=?", (api_request_id,)
                    ).fetchone()
                    return row["id"] if row else None
                cur = conn.execute(
                    """INSERT INTO requests(task_id, turn_id, session_hash, platform,
                        provider, model, status, key_scope, approx_input_tokens,
                        started_at, created_at)
                       VALUES(?,?,?,?,?,?, 'pending',?,?,?,?)""",
                    (task_id, turn_id, session_hash, platform, provider, model,
                     scope, approx_input_tokens, started, now),
                )
                return cur.lastrowid
        finally:
            conn.close()

    def finish_request(self, request_id: int, *, status="success",
                       response_model=None, input_tokens=None, output_tokens=None,
                       latency_ms=None, ttft_ms=None, error_category=None,
                       error_summary=None, ended_at=None):
        try:
            from ..telemetry.telemetry import hour_key
        except Exception:
            hour_key = None
        response_model = _telemetry_label(response_model)
        error_category = _error_category(error_category)
        # Provider error bodies are untrusted and can echo arbitrary credentials.
        error_summary = error_category if error_summary else None
        now = time.time()
        ended = float(ended_at) if ended_at is not None else now
        conn = self._connect()
        try:
            with conn:  # atomic: hourly + lifetime update together or not at all
                if status not in ("success", "error", "canceled"):
                    raise ValueError("terminal status required")
                conn.execute("BEGIN IMMEDIATE")
                updated = conn.execute(
                    """UPDATE requests SET status=?, response_model=COALESCE(?, response_model),
                        input_tokens=COALESCE(?, input_tokens), output_tokens=COALESCE(?, output_tokens),
                        latency_ms=COALESCE(?, latency_ms), ttft_ms=COALESCE(?, ttft_ms),
                        error_category=COALESCE(?, error_category),
                        error_summary=COALESCE(?, error_summary), ended_at=?
                       WHERE id=? AND status='pending'""",
                    (status, response_model, input_tokens, output_tokens,
                     latency_ms, ttft_ms, error_category,
                     (str(error_summary)[:240] if error_summary else None), ended, request_id),
                )
                if updated.rowcount != 1:
                    return
                if hour_key is not None:
                    hkey = hour_key(ended)
                    conn.execute(
                        """INSERT INTO request_hourly(hour, total_requests, success_count, error_count,
                            canceled_count, input_tokens, output_tokens, latency_sum, latency_count)
                           VALUES(?,?,?,?,?,?,?,?,?)
                           ON CONFLICT(hour) DO UPDATE SET
                            total_requests=total_requests+1,
                            success_count=success_count+excluded.success_count,
                            error_count=error_count+excluded.error_count,
                            canceled_count=canceled_count+excluded.canceled_count,
                            input_tokens=input_tokens+excluded.input_tokens,
                            output_tokens=output_tokens+excluded.output_tokens,
                            latency_sum=latency_sum+excluded.latency_sum,
                            latency_count=latency_count+excluded.latency_count""",
                        (hkey, 1,
                         1 if status == "success" else 0,
                         1 if status == "error" else 0,
                         1 if status == "canceled" else 0,
                         int(input_tokens or 0), int(output_tokens or 0),
                         float(latency_ms or 0), 1 if latency_ms is not None else 0),
                    )
                    conn.execute(
                        "INSERT OR IGNORE INTO lifetime_counters(key,value) VALUES('total_requests',0)",
                    )
                    conn.execute("UPDATE lifetime_counters SET value=value+1 WHERE key='total_requests'")
                    if input_tokens is not None:
                        conn.execute(
                            "INSERT OR IGNORE INTO lifetime_counters(key,value) VALUES('total_input_tokens',0)",
                        )
                        conn.execute(
                            "UPDATE lifetime_counters SET value=value+? WHERE key='total_input_tokens'",
                            (int(input_tokens),),
                        )
                    if output_tokens is not None:
                        conn.execute(
                            "INSERT OR IGNORE INTO lifetime_counters(key,value) VALUES('total_output_tokens',0)",
                        )
                        conn.execute(
                            "UPDATE lifetime_counters SET value=value+? WHERE key='total_output_tokens'",
                            (int(output_tokens),),
                        )
        finally:
            conn.close()

    def expire_pending_requests(self, max_age=3600):
        conn = self._connect()
        try:
            rows = conn.execute("SELECT id FROM requests WHERE status='pending' AND started_at < ? LIMIT 1000",
                                (time.time() - max_age,)).fetchall()
        finally:
            conn.close()
        for row in rows:
            self.finish_request(row["id"], status="canceled", error_category="Unobserved completion")

    def record_attempt(self, request_id: int, ordinal: int, *, provider=None,
                       model=None, key_scope="", status_code=None, retryable=None,
                       reason=None, error_category=None, duration_ms=None):
        from ..telemetry.telemetry import redact_key_scope
        provider, model = map(_telemetry_label, (provider, model))
        error_category = _error_category(error_category)
        reason = error_category if reason else None
        status_code = status_code if isinstance(status_code, int) and not isinstance(status_code, bool) else None
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            terminal = conn.execute("SELECT status FROM requests WHERE id=?", (request_id,)).fetchone()
            if not terminal or terminal["status"] != "pending":
                return False
            existing = conn.execute("SELECT key_scope FROM request_attempts WHERE request_id=? AND ordinal=?",
                                    (request_id, int(ordinal))).fetchone()
            if existing is not None:
                return False  # First accepted observation owns ordinal, target, scope and time.
            attempt_scope = redact_key_scope(key_scope)
            conn.execute(
                """INSERT INTO request_attempts(request_id, ordinal, provider, model, key_scope,
                    status_code, retryable, reason, error_category, duration_ms, created_at)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (request_id, int(ordinal), provider, model, attempt_scope,
                 int(status_code) if isinstance(status_code, (int, float)) and not isinstance(status_code, bool) else status_code,
                 (1 if retryable else 0) if retryable is not None else None,
                 reason, error_category,
                 float(duration_ms) if duration_ms is not None else None, time.time()),
            )
            conn.commit()
            return existing is None
        finally:
            conn.close()

    def record_cache_event(self, *, provider=None, model=None, hit=False, latency_ms=None):
        provider, model = map(_telemetry_label, (provider, model))
        conn = self._connect()
        try:
            conn.execute(
                "INSERT INTO cache_events(ts,provider,model,hit,latency_ms) VALUES(?,?,?,?,?)",
                (time.time(), provider, model, 1 if hit else 0,
                 float(latency_ms) if latency_ms is not None else None),
            )
            conn.commit()
        finally:
            conn.close()

    def record_search_event(self, *, provider=None, query_length=None,
                            latency_ms=None, results_count=None):
        provider = _telemetry_label(provider)
        conn = self._connect()
        try:
            conn.execute(
                "INSERT INTO search_events(ts,provider,query_length,latency_ms,results_count)"
                " VALUES(?,?,?,?,?)",
                (time.time(), provider, query_length,
                 float(latency_ms) if latency_ms is not None else None, results_count),
            )
            conn.commit()
        finally:
            conn.close()

    def record_credential_scope(self, *, provider=None, key_scope="",
                                auth_ok=None, reason=None):
        provider = _telemetry_label(provider)
        reason = _error_category(reason)
        try:
            from ..telemetry.telemetry import redact_key_scope
            scope = redact_key_scope(key_scope)
        except Exception:
            scope = ""
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO credential_scopes(provider,key_scope_hash,last_auth_ok,
                    last_reason,last_seen,observation_count)
                   VALUES(?,?,?, ?,?, 1)
                   ON CONFLICT(provider,key_scope_hash) DO UPDATE SET
                    last_auth_ok=excluded.last_auth_ok, last_reason=excluded.last_reason,
                    last_seen=excluded.last_seen, observation_count=observation_count+1""",
                (provider or "", scope,
                 (1 if auth_ok else 0) if auth_ok is not None else None,
                 reason, time.time()),
            )
            conn.commit()
        finally:
            conn.close()

    def request_event_matches(self, request_id, event):
        """Check host context before mutating a lifecycle row; no raw IDs persist."""
        from ..telemetry.telemetry import agent_id_from_kwargs
        row = self.get_request(request_id)
        if row is None:
            return False
        session = _opaque_id(agent_id_from_kwargs(event))
        if row["session_hash"] and row["session_hash"] != session:
            return False
        for name in ("task_id", "turn_id"):
            incoming = _opaque_id(event.get(name))
            if row[name] and incoming and row[name] != incoming:
                return False
        return True

    def reconcile_request_scope(self, request_id, raw_scope):
        """A missing/changed observed scope permanently loses specific attribution."""
        from ..telemetry.telemetry import redact_key_scope
        scope = redact_key_scope(raw_scope)
        conn = self._connect()
        try:
            with conn:
                conn.execute("UPDATE requests SET key_scope=CASE WHEN key_scope=? THEN key_scope ELSE '' END WHERE id=? AND status='pending'",
                             (scope, request_id))
        finally:
            conn.close()

    def get_scoring_observations(self, provider, model, key_scope=""):
        """Bounded indexed final request facts, never cross-provider retry outcomes."""
        conn = None
        try:
            conn = self._connect()
            return read_scoring_observations(conn, provider, model, key_scope)
        except sqlite3.Error:
            return {"available": False, "rows": []}
        finally:
            if conn is not None:
                conn.close()

    def find_request_by_api_id(self, identity):
        conn = self._connect()
        try:
            row = conn.execute("SELECT id FROM requests WHERE api_request_id=?",
                               (_opaque_id(identity),)).fetchone()
            return row["id"] if row else None
        finally:
            conn.close()

    def get_request(self, request_id: int):
        conn = self._connect()
        try:
            row = conn.execute("SELECT * FROM requests WHERE id=?", (request_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    def get_request_attempts(self, request_id: int):
        conn = self._connect()
        try:
            rows = conn.execute(
                "SELECT * FROM request_attempts WHERE request_id=? ORDER BY ordinal ASC",
                (request_id,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def integrity_check(self) -> dict:
        conn = self._connect()
        try:
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            fk_ok = conn.execute("PRAGMA foreign_key_check").fetchall()
            return {"integrity_check": integrity, "foreign_key_violations": len(fk_ok)}
        finally:
            conn.close()

    # ---- catalog ----
    def upsert_catalog(self, provider: str, model: str, context_length=None, capabilities=None, cost_tier=None) -> None:
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO catalog(provider,model,context_length,capabilities,cost_tier,updated_at)
                   VALUES(?,?,?,?,?,?)
                   ON CONFLICT(provider,model) DO UPDATE SET
                     context_length=excluded.context_length,
                     capabilities=excluded.capabilities,
                     cost_tier=excluded.cost_tier,
                     updated_at=excluded.updated_at""",
                (provider, model, context_length, json.dumps(capabilities) if capabilities is not None else None,
                 cost_tier, time.time()),
            )
            conn.commit()
        finally:
            conn.close()

    def persist_discovered_model(self, model):
        """Commit catalog and proof together; any capability write failure rolls back both."""
        mc = model.get("metadata") or {}
        with self._connect() as conn:
            conn.execute("""INSERT OR REPLACE INTO catalog
                (provider,model,context_length,capabilities,cost_tier,updated_at)
                VALUES(?,?,?,?,?,?)""", (model["provider"], model["model"], model.get("context_length"),
                json.dumps(model.get("capabilities")), model.get("cost_tier"), time.time()))
            conn.execute("""INSERT OR REPLACE INTO capabilities
                (provider,model,capability_json,metadata_source,retrieved_at,expires_at,version)
                VALUES(?,?,?,?,?,?,1)""", (model["provider"], model["model"], json.dumps(mc),
                mc.get("metadata_source", "unknown"), mc.get("retrieved_at", 0), mc.get("expires_at", 0)))

    def get_catalog(self, provider: Optional[str] = None):
        conn = self._connect()
        try:
            if provider:
                rows = conn.execute("SELECT * FROM catalog WHERE provider=?", (provider,)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM catalog").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def save_lkg(self, payload: Any) -> None:
        conn = self._connect()
        try:
            conn.execute("INSERT INTO lkg_catalog(ts,payload) VALUES(?,?)", (time.time(), json.dumps(payload)))
            conn.commit()
        finally:
            conn.close()

    def get_lkg(self):
        conn = self._connect()
        try:
            row = conn.execute("SELECT payload FROM lkg_catalog ORDER BY version DESC LIMIT 1").fetchone()
            if row:
                return json.loads(row["payload"])
            return None
        finally:
            conn.close()

    # ---- in-flight reservations ----
    def get_in_flight(self, provider: str, model: str) -> int:
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT reserved FROM in_flight WHERE provider=? AND model=?",
                (provider, model),
            ).fetchone()
            return int(row["reserved"]) if row else 0
        finally:
            conn.close()

    def reserve(self, provider: str, model: str) -> int:
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO in_flight(provider,model,reserved,updated_at)
                   VALUES(?,?,1,?)
                   ON CONFLICT(provider,model) DO UPDATE SET
                     reserved=reserved+1, updated_at=excluded.updated_at""",
                (provider, model, time.time()),
            )
            conn.commit()
            return self.get_in_flight(provider, model)
        finally:
            conn.close()

    def release(self, provider: str, model: str) -> int:
        conn = self._connect()
        try:
            conn.execute(
                "UPDATE in_flight SET reserved=MAX(reserved-1,0), updated_at=? WHERE provider=? AND model=?",
                (time.time(), provider, model),
            )
            conn.commit()
            return self.get_in_flight(provider, model)
        finally:
            conn.close()

    # ---- health ----
    def get_health(self, provider: str, model: str, key_scope: str = "") -> dict:
        conn = self._connect()
        try:
            return read_health_observation(conn, provider, model, key_scope)
        finally:
            conn.close()

    def upsert_health(self, provider: str, model: str, key_scope: str = "", **fields) -> None:
        from ..health.health import scope_id
        key_scope = scope_id(key_scope)
        conn = self._connect()
        try:
            existing = conn.execute(
                "SELECT 1 FROM health WHERE provider=? AND model=? AND key_scope=?",
                (provider, model, key_scope),
            ).fetchone()
            if existing:
                if fields:
                    sets = ", ".join(f"{k}=?" for k in fields)
                    vals = list(fields.values()) + [provider, model, key_scope]
                    conn.execute(f"UPDATE health SET {sets} WHERE provider=? AND model=? AND key_scope=?", vals)
            else:
                cols = ["provider", "model", "key_scope"] + list(fields.keys())
                placeholders = ",".join("?" for _ in cols)
                vals = [provider, model, key_scope] + list(fields.values())
                conn.execute(f"INSERT INTO health({','.join(cols)}) VALUES({placeholders})", vals)
            conn.commit()
        finally:
            conn.close()

    def get_health_circuits(self, provider, model, scope=""):
        from ..health.health import scope_id
        scope = scope_id(scope)
        conn = self._connect()
        try:
            return [dict(row) for row in conn.execute(
                "SELECT * FROM health_circuits WHERE provider=? AND "
                "((layer='provider') OR (layer='model' AND model=?) OR "
                "(layer='credential' AND scope=?) OR (layer='connection' AND model=? AND scope=?))",
                (provider, model, scope, model, scope))]
        except sqlite3.OperationalError:
            return []  # Legacy database, no migration during read-only diagnostics.
        finally:
            conn.close()

    def record_outcome(self, provider, model, success, *, key_scope="", status_code=None,
                       latency_ms=None, error_type=None, error_message=None, retry_after=None,
                       trusted_reason=None, now=None):
        from ..health.health import scope_id, classify_failure, parse_retry_after
        now = time.time() if now is None else now
        key_scope = scope_id(key_scope)
        layer, reason, seconds, threshold = classify_failure(status_code, error_type, trusted_reason)
        retry = parse_retry_after(retry_after, now=now)
        if retry is not None and not success:
            seconds = max(seconds, retry)
        circuit_model = "" if layer in ("provider", "credential") else model
        circuit_scope = "" if layer in ("provider", "model") else key_scope
        if latency_ms is not None:
            try:
                import math
                latency_ms = float(latency_ms)
                if not math.isfinite(latency_ms) or latency_ms < 0: latency_ms = None
            except (TypeError, ValueError): latency_ms = None
        conn = self._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("INSERT OR IGNORE INTO health(provider,model,key_scope) VALUES(?,?,?)", (provider, model, key_scope))
            previous = conn.execute("SELECT * FROM health WHERE provider=? AND model=? AND key_scope=?",
                                    (provider, model, key_scope)).fetchall()
            self._preserve_legacy_denials(conn, previous, now)
            conn.execute("""UPDATE health SET successes=successes+?, failures=failures+?,
                consecutive_failures=CASE WHEN ? THEN 0 ELSE consecutive_failures+1 END,
                last_status=?, last_error=?, last_latency_ms=COALESCE(?,last_latency_ms),
                last_success_at=CASE WHEN ? THEN ? ELSE last_success_at END,
                last_failure_at=CASE WHEN ? THEN last_failure_at ELSE ? END,
                retired=?, auth_failed=?, cooldown_until=? WHERE provider=? AND model=? AND key_scope=?""",
                (int(success), int(not success), int(success), status_code, None if success else reason,
                 latency_ms, int(success), now, int(success), now,
                 int(not success and reason == "model_retired"), int(not success and reason == "auth"),
                 now + seconds if not success and threshold == 1 else 0, provider, model, key_scope))
            if success:
                conn.execute("""UPDATE health_circuits SET failures=0,opened_until=0,updated_at=?,event_observed_at=?
                    WHERE provider=? AND reason!='model_retired' AND
                    ((layer='provider') OR (layer='connection' AND model=? AND scope=?) OR (layer='credential' AND scope=?))""",
                    (now, now, provider, model, key_scope, key_scope))
            else:
                conn.execute("""INSERT INTO health_circuits(provider,layer,model,scope,failures,threshold,opened_until,reason,updated_at,event_observed_at)
                    VALUES(?,?,?,?,1,?,?,?,?,?) ON CONFLICT(provider,layer,model,scope,reason) DO UPDATE SET
                    failures=failures+1,threshold=excluded.threshold,reason=excluded.reason,updated_at=excluded.updated_at,event_observed_at=excluded.event_observed_at,
                    opened_until=CASE WHEN failures+1>=excluded.threshold THEN MAX(opened_until,?) ELSE opened_until END""",
                    (provider, layer, circuit_model, circuit_scope, threshold, now + seconds if threshold == 1 else 0,
                     reason, now, now, now + seconds))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def get_free_quota_status(self, provider: str, model: str | None = None, key_scope: str | None = None) -> dict[str, Any]:
        """Get free quota status for a provider/model/key_scope.

        Tracks observed request outcomes from the health table.
        Quota is tracked per key_scope (credential/account scope).
        Does NOT aggregate across different key_scopes,
        which would mix different credentials\' data.

        If model is specified, returns quota for that specific model.
        If key_scope is specified, returns quota for that credential scope.
        If neither is specified, returns per-model status for all models.

        Observed request count = successes + failures recorded in health table.
        This is a conservative estimate — it does not represent
        authoritative remaining tokens or account-level quotas.

        Unknown quota is labeled "unknown".
        Observed quota is labeled "observed" with the count.
        """
        import time
        from typing import Any

        if key_scope is None:
            key_scope = ""

        if model is not None:
            # Single model — read from health table under this key_scope
            health = self.get_health(provider, model, key_scope)
            total_observed = int(health.get("successes") or 0) + int(health.get("failures") or 0)
            cooldown_until = float(health.get("cooldown_until") or 0)
            return {
                "provider": provider,
                "model": model,
                "key_scope": key_scope,
                "total_observed": total_observed,
                "cooldown_until": cooldown_until,
                "cooldown_active": cooldown_until > time.time(),
                "status": "observed" if total_observed > 0 else "unknown",
            }

        # All models for a provider — per-model status
        catalog = self.get_catalog(provider)
        models_status = []
        for entry in catalog:
            mname = entry["model"]
            health = self.get_health(provider, mname, key_scope)
            total_observed = int(health.get("successes") or 0) + int(health.get("failures") or 0)
            cooldown_until = float(health.get("cooldown_until") or 0)
            models_status.append({
                "model": mname,
                "total_observed": total_observed,
                "status": "observed" if total_observed > 0 else "unknown",
                "cooldown_active": cooldown_until > time.time(),
            })

        return {
            "provider": provider,
            "key_scope": key_scope,
            "models": models_status,
        }

    def set_cooldown(self, provider, model, seconds, key_scope=""):
        from ..health.health import scope_id, parse_retry_after
        seconds = parse_retry_after(seconds)
        if seconds is None: return
        now = time.time()
        conn = self._connect()
        try:
            with conn:
                conn.execute("""INSERT INTO health_circuits(provider,layer,model,scope,failures,threshold,opened_until,reason,updated_at,event_observed_at)
                    VALUES(?,'connection',?,?,1,1,?,'rate_limit',?,?) ON CONFLICT(provider,layer,model,scope,reason)
                    DO UPDATE SET failures=MAX(failures,1),threshold=1,opened_until=MAX(opened_until,excluded.opened_until),
                    reason='rate_limit',updated_at=excluded.updated_at,event_observed_at=excluded.event_observed_at""",
                    (provider,model,scope_id(key_scope),now+seconds,now,now))
        finally: conn.close()

    def is_available(self, provider: str, model: str, key_scope: str = "") -> bool:
        from ..health.health import decision
        return decision(self, provider, model, key_scope)["available"]

    def record_decision(self, policy: str, provider: Optional[str], model: Optional[str], reason: str, candidates: int) -> None:
        conn = self._connect()
        try:
            conn.execute(
                "INSERT INTO decisions(ts,policy,provider,model,reason,candidates) VALUES(?,?,?,?,?,?)",
                (time.time(), policy, provider, model, reason, candidates),
            )
            conn.commit()
        finally:
            conn.close()

    def record_event(self, kind: str, provider=None, model=None, status_code=None, detail=None) -> None:
        conn = self._connect()
        try:
            conn.execute(
                "INSERT INTO events(ts,kind,provider,model,status_code,detail) VALUES(?,?,?,?,?,?)",
                (time.time(), kind, provider, model, status_code, detail),
            )
            conn.commit()
        finally:
            conn.close()

    def upsert_capability(self, provider: str, model: str, capability_json: str,
                          metadata_source: str = "", retrieved_at: float = 0.0,
                          expires_at: float = 0.0, version: int = 1) -> None:
        conn = self._connect()
        try:
            conn.execute(
                """INSERT INTO capabilities(provider,model,capability_json,metadata_source,retrieved_at,expires_at,version)
                   VALUES(?,?,?,?,?,?,?)
                   ON CONFLICT(provider,model) DO UPDATE SET
                     capability_json=excluded.capability_json,
                     metadata_source=excluded.metadata_source,
                     retrieved_at=excluded.retrieved_at,
                     expires_at=excluded.expires_at,
                     version=excluded.version""",
                (provider, model, capability_json, metadata_source, retrieved_at, expires_at, version),
            )
            conn.commit()
        finally:
            conn.close()

    def get_capability(self, provider: str, model: str):
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT * FROM capabilities WHERE provider=? AND model=?", (provider, model)
            ).fetchone()
            if row:
                return dict(row)
            return None
        finally:
            conn.close()

    def summary(self) -> dict:
        conn = self._connect()
        try:
            models = conn.execute("SELECT COUNT(*) c FROM catalog").fetchone()["c"]
            health_rows = conn.execute("SELECT COUNT(*) c FROM health").fetchone()["c"]
            decisions = conn.execute("SELECT COUNT(*) c FROM decisions").fetchone()["c"]
            return {"catalog_models": models, "health_rows": health_rows, "decisions": decisions, "db_path": str(self.db_path)}
        finally:
            conn.close()


# ---------------------------------------------------------------------------
# Routing profiles (issue #100)
# ---------------------------------------------------------------------------

ROUTING_PROFILE_META_KEY = "active_routing_profile"


def _import_profiles():
    from ..routing import profiles as routing_profiles
    return routing_profiles


def _row_to_profile(row):
    profiles = _import_profiles()
    return profiles.decode_row(row)


class RoutingProfileStore:
    """Transactional CRUD for user-created routing profiles.

    Separate write path from request telemetry but same database file and the
    same BEGIN IMMEDIATE serialization — concurrent API writers never see
    partial rows. IDs are server-generated and stable forever.
    """

    def __init__(self, state_dir):
        self.store = StateStore(state_dir)

    # -- reads ------------------------------------------------------------
    def get(self, profile_id: str):
        conn = self.store._connect()
        try:
            row = conn.execute(
                "SELECT * FROM routing_profiles WHERE id = ?", (str(profile_id),)
            ).fetchone()
            return _row_to_profile(row) if row else None
        finally:
            conn.close()

    def list(self):
        conn = self.store._connect()
        try:
            rows = conn.execute(
                "SELECT * FROM routing_profiles ORDER BY updated_at DESC, id ASC"
            ).fetchall()
            return [_row_to_profile(r) for r in rows]
        finally:
            conn.close()

    def _name_conflict(self, conn, name: str, exclude_id: Optional[str] = None) -> bool:
        query = "SELECT 1 FROM routing_profiles WHERE name = ? COLLATE NOCASE"
        params: list[Any] = [name]
        if exclude_id:
            query += " AND id != ?"
            params.append(exclude_id)
        return conn.execute(query, params).fetchone() is not None

    # -- writes -----------------------------------------------------------
    def create(self, data: dict[str, Any]) -> dict[str, Any]:
        profiles = _import_profiles()
        clean = profiles.validate_profile(data)
        now = time.time()
        profile_id = profiles.new_profile_id()
        row = profiles.encode_row(clean)
        conn = self.store._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            if self._name_conflict(conn, clean["name"]):
                conn.rollback()
                raise profiles.ProfileError("profile_name_conflict", "A profile with that name already exists",
                                            {"name": "name must be unique"})
            conn.execute(
                """INSERT INTO routing_profiles(
                    id, name, description, schema_version, ranking_policy, providers,
                    model_include, model_exclude, min_context, requires_tools, health,
                    task_tags, fallback_policy, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (profile_id, row["name"], row["description"], profiles.SCHEMA_VERSION,
                 row["ranking_policy"], row["providers"], row["model_include"], row["model_exclude"],
                 row["min_context"], row["requires_tools"], row["health"], row["task_tags"],
                 row["fallback_policy"], now, now),
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
        return self.get(profile_id)

    def update(self, profile_id: str, changes: dict[str, Any]) -> dict[str, Any]:
        profiles = _import_profiles()
        existing = self.get(profile_id)
        if existing is None:
            raise profiles.ProfileError("profile_not_found", "Routing profile not found")
        merged = profiles.validate_profile(changes, existing=existing)
        now = time.time()
        row = profiles.encode_row(merged)
        conn = self.store._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            if self._name_conflict(conn, merged["name"], exclude_id=profile_id):
                conn.rollback()
                raise profiles.ProfileError("profile_name_conflict", "A profile with that name already exists",
                                            {"name": "name must be unique"})
            conn.execute(
                """UPDATE routing_profiles SET
                    name=?, description=?, ranking_policy=?, providers=?, model_include=?,
                    model_exclude=?, min_context=?, requires_tools=?, health=?,
                    task_tags=?, fallback_policy=?, updated_at=?
                WHERE id=?""",
                (row["name"], row["description"], row["ranking_policy"], row["providers"],
                 row["model_include"], row["model_exclude"], row["min_context"], row["requires_tools"],
                 row["health"], row["task_tags"], row["fallback_policy"], now, profile_id),
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
        return self.get(profile_id)

    def delete(self, profile_id: str) -> dict[str, Any]:
        conn = self.store._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT id FROM routing_profiles WHERE id = ?", (profile_id,)).fetchone()
            if row is None:
                conn.rollback()
                return {"deleted": False, "deactivated": False}
            conn.execute("DELETE FROM routing_profiles WHERE id = ?", (profile_id,))
            active = conn.execute("SELECT value FROM meta WHERE key = ?", (ROUTING_PROFILE_META_KEY,)).fetchone()
            deactivated = bool(active and active["value"] == profile_id)
            if deactivated:
                conn.execute("DELETE FROM meta WHERE key = ?", (ROUTING_PROFILE_META_KEY,))
            conn.commit()
            return {"deleted": True, "deactivated": deactivated}
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def duplicate(self, profile_id: str, *, name: Optional[str] = None) -> dict[str, Any]:
        profiles = _import_profiles()
        source = self.get(profile_id)
        if source is None:
            raise profiles.ProfileError("profile_not_found", "Routing profile not found")
        base_name = (name or f"{source['name']} copy").strip()[:80]
        candidate = base_name
        payload = {k: v for k, v in source.items()
                   if k not in ("id", "schema_version", "created_at", "updated_at")}
        for attempt in range(2, 40):
            try:
                return self.create({**payload, "name": candidate})
            except profiles.ProfileError as exc:
                if exc.code != "profile_name_conflict":
                    raise
                candidate = f"{base_name} {attempt}"[:80]
        raise profiles.ProfileError("profile_name_conflict", "Could not find a free name for the duplicate",
                                    {"name": "name must be unique"})

    # -- activation ---------------------------------------------------------
    def active_id(self) -> Optional[str]:
        conn = self.store._connect()
        try:
            row = conn.execute("SELECT value FROM meta WHERE key = ?", (ROUTING_PROFILE_META_KEY,)).fetchone()
            return row["value"] if row else None
        except sqlite3.Error:
            return None
        finally:
            conn.close()

    def set_active(self, profile_id: Optional[str]) -> Optional[str]:
        if profile_id is not None and self.get(profile_id) is None:
            from ..routing import profiles as routing_profiles
            raise routing_profiles.ProfileError("profile_not_found", "Routing profile not found")
        conn = self.store._connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            if profile_id is None:
                conn.execute("DELETE FROM meta WHERE key = ?", (ROUTING_PROFILE_META_KEY,))
            else:
                conn.execute(
                    "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
                    (ROUTING_PROFILE_META_KEY, profile_id),
                )
            conn.commit()
            return profile_id
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def active_routing_profile(store: StateStore):
    """Tri-state read of the operator-set default routing profile.

    Returns ``(profile, None)`` when a default is configured and validates,
    ``(None, None)`` when no default is configured, and ``(None, error)``
    when a default IS configured but the row is missing or fails strict
    validation — the caller must then fail closed instead of silently
    resolving through any other policy. Never raises.
    """
    try:
        conn = store._connect()
        try:
            row = conn.execute("SELECT value FROM meta WHERE key = ?", (ROUTING_PROFILE_META_KEY,)).fetchone()
            profile_id = row["value"] if row else None
            if not isinstance(profile_id, str) or not profile_id:
                return None, None
            prow = conn.execute("SELECT * FROM routing_profiles WHERE id = ?", (profile_id,)).fetchone()
        finally:
            conn.close()
    except Exception:
        return None, "active profile could not be read from the store"
    if prow is None:
        return None, f"the configured default routing profile ({profile_id!r}) no longer exists"
    try:
        candidate = _row_to_profile(prow)
        from ..routing import profiles as routing_profiles
        return routing_profiles.validate_stored_profile(candidate), None
    except Exception as exc:
        code = getattr(exc, "code", None) or "stored_profile_invalid"
        return None, f"the configured default routing profile is corrupt ({code})"
