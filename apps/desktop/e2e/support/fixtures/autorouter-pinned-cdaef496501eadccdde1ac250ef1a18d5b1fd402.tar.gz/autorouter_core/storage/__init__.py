"""AutoRouter storage package."""
