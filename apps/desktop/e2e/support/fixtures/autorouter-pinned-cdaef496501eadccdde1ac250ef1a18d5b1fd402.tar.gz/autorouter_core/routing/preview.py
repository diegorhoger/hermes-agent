"""Read-only profile evaluation against the live catalog (issue #100).

Preview never discovers, never writes, never reserves a slot, never executes
an inference. It runs the same hard gates and the same ranking code the real
selector uses at session creation, so what the user sees is what the router
would do. Results are scrubbed to safe fields only.
"""

from __future__ import annotations

import time
from typing import Any, Optional

from ..evidence import free_access
from ..routing.profiles import model_include_pairs, model_exclude_pairs, selection_policy
from ..routing.router import Router, evaluate_snapshot
from ..storage.snapshot import ReadOnlyStateStore


def _scrub_chosen(c: Optional[dict]) -> Optional[dict]:
    if not isinstance(c, dict):
        return None
    return {
        "provider": c.get("provider"),
        "model": c.get("model"),
        "context_length": c.get("context_length"),
        "cost_tier": c.get("cost_tier"),
        "tools": (c.get("capabilities") or {}).get("tools") if isinstance(c.get("capabilities"), dict) else None,
        "score": (c.get("score") or {}).get("total") if isinstance(c.get("score"), dict) else None,
        "metadata_freshness": c.get("metadata_freshness"),
        "health_reason": c.get("health_reason"),
        "circuit_state": c.get("circuit_state"),
    }


def _scrub_ranked(c: dict) -> dict:
    return {
        "provider": c.get("provider"),
        "model": c.get("model"),
        "context_length": c.get("context_length"),
        "tools": (c.get("capabilities") or {}).get("tools") if isinstance(c.get("capabilities"), dict) else None,
        "cost_tier": c.get("cost_tier"),
        "score": (c.get("score") or {}).get("total") if isinstance(c.get("score"), dict) else None,
        "metadata_freshness": c.get("metadata_freshness"),
        "health_reason": c.get("health_reason"),
        "circuit_state": c.get("circuit_state"),
    }


def preview_profile(db_path, profile, *, authorized_providers, cooldown_seconds: int = 60,
                    now: Optional[float] = None, eligible_limit: int = 10,
                    excluded_limit: int = 25) -> dict[str, Any]:
    now = time.time() if now is None else now

    if not authorized_providers:
        return {
            "available": True, "profile_id": profile.get("id"), "generated_at": now,
            "eligible_count": 0, "total_considered": 0, "chosen": None,
            "eligible": [], "excluded": [], "excluded_total": 0,
            "no_match": "profile_no_authorized_providers",
            "constraints": {"requires_tools": bool(profile.get("requires_tools")),
                            "min_context": int(profile.get("min_context") or 8192),
                            "verified_free_only": True},
            "execution_authority": False, "reason": "None of the profile's providers is enabled for AutoRouter.",
        }

    contract = selection_policy(profile, authorized_providers)
    from ..configuration.selection_policy import validate
    from ..configuration.selection_policy import PolicyError

    try:
        validate(contract)
    except PolicyError as exc:
        return {
            "available": True, "profile_id": profile.get("id"), "generated_at": now,
            "eligible_count": 0, "total_considered": 0, "chosen": None,
            "eligible": [], "excluded": [], "excluded_total": 0,
            "no_match": exc.code, "execution_authority": False,
        }
    except (ValueError, TypeError):
        return {
            "available": True, "profile_id": profile.get("id"), "generated_at": now,
            "eligible_count": 0, "total_considered": 0, "chosen": None,
            "eligible": [], "excluded": [], "excluded_total": 0,
            "no_match": "selection_policy_invalid", "execution_authority": False,
        }

    include = set(model_include_pairs(profile))
    exclude = {tuple(p) for p in ((row.get("provider"), row.get("model")) for row in contract["hard_eligibility"]["exclude"])}

    reader = ReadOnlyStateStore(db_path)
    state = {
        "policy": profile.get("ranking_policy") or "auto",
        "free_only": True,
        "paid_authorized": False,
        "providers": list(contract["hard_eligibility"]["authorized_providers"]),
        "cooldown_seconds": int(cooldown_seconds) if isinstance(cooldown_seconds, int) else 60,
        "store": reader,
    }
    router = Router(state)

    try:
        candidates = router._resolved_candidates(now=now)
    except Exception:
        candidates = []

    if include:
        try:
            catalog_rows = router._candidates_from_store()
            catalog_pairs = {(r.get("provider"), r.get("model")) for r in catalog_rows}
            extra = {(p, m) for (p, m) in catalog_pairs} - include
            exclude = exclude | extra
        except Exception:
            return {
                "available": True, "profile_id": profile.get("id"), "generated_at": now,
                "eligible_count": 0, "total_considered": 0, "chosen": None,
                "eligible": [], "excluded": [], "excluded_total": 0,
                "no_match": "catalog_unreadable", "execution_authority": False,
            }

    result = evaluate_snapshot(
        [dict(c) for c in candidates],
        policy=state["policy"],
        providers=state["providers"],
        now=now,
        requires_tools=bool(profile.get("requires_tools")),
        min_context=int(profile.get("min_context") or 8192),
        exclude=exclude,
        max_in_flight=None,
        strict_no_charge=False,
        selection_policy=contract,
    )

    considered = result.get("considered") or []
    eligible = [c for c in considered if c.get("eligible")]
    excluded = [c for c in considered if not c.get("eligible")]
    ranked_by_key = {(r.get("provider"), r.get("model")): r for r in (result.get("ranked") or [])}
    ranked = [ranked_by_key[(r.get("provider"), r.get("model"))] for r in eligible
              if (r.get("provider"), r.get("model")) in ranked_by_key]

    no_match = result.get("no_match")
    if not candidates:
        no_match = no_match or "no_catalog_candidates"

    return {
        "available": True,
        "profile_id": profile.get("id"),
        "generated_at": now,
        "eligible_count": result.get("eligible_count", 0),
        "total_considered": result.get("total_considered", len(considered)),
        "chosen": _scrub_chosen(result.get("chosen")),
        "eligible": [_scrub_ranked(c) for c in ranked[:eligible_limit]],
        "excluded": [
            {"provider": c.get("provider"), "model": c.get("model"),
             "reason_codes": list(c.get("reason_codes") or [])[:8]}
            for c in excluded[:excluded_limit]
        ],
        "excluded_total": len(excluded),
        "no_match": no_match,
        "constraints": {"requires_tools": bool(profile.get("requires_tools")),
                        "min_context": int(profile.get("min_context") or 8192),
                        "verified_free_only": True},
        "selection_policy_version": result.get("selection_policy_version"),
        "execution_authority": False,
        "routing_active": False,
    }
