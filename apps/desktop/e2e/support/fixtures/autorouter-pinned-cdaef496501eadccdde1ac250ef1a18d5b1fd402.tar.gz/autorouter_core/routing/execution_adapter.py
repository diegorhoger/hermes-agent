"""Selection-only Hermes handoff. No execution, host mutation or credential access."""

from dataclasses import dataclass
import math
import re
import shlex
import time
from ..configuration.selection_policy import MISSING

VERSION = 1
PROVIDERS = frozenset(("nvidia", "openrouter", "groq", "gemini", "mistral"))


@dataclass(frozen=True)
class ExecutionContext:
    """Adapter-owned opaque binding; never authority supplied by public JSON."""

    profile_id: str | None = None
    session_id: str | None = None
    agent_id: str | None = None
    request_id: str | None = None
    schema_version: int = 1


def capabilities():
    return dict(
        schema_version=VERSION,
        adapter="hermes_manual",
        selection_handoff=True,
        host_confirmed_apply=False,
        host_confirmed_restore=False,
        execution=False,
        streaming=False,
        retries=False,
        spending_enforcement=False,
        blocker="host_context_bound_apply_contract_unavailable",
    )


def _receipt(state, reason, now, *, target=None, bound=False, decision=None):
    return dict(
        schema_version=VERSION,
        adapter="hermes_manual",
        state=state,
        reason=reason,
        generated_at=now,
        target=target,
        context_state="bound" if bound else "unknown",
        capabilities=capabilities(),
        applied=False,
        restored=False,
        executed=False,
        actual_request_target="unobserved",
        execution_authority=False,
        evidence_report=decision.get("evidence_report") if decision else None,
        manual_command=None,
        manual_argv=None,
        limitations=[
            "manual handoff is not completed application",
            "new chat; no current-session mutation",
            "provider authentication and account scope remain host-owned",
            "run in the intended Hermes profile; this command does not select a profile or account",
            "recommendation is not a billing guarantee",
            "no restore confirmation or automatic replay",
        ],
    )


def _context_matches(context, current):
    if context is None and current is None:
        return True, False
    if type(context) is not ExecutionContext or type(current) is not ExecutionContext:
        return False, False
    for item in (context, current):
        if type(item.schema_version) is not int or item.schema_version != VERSION:
            return False, False
        if any(
            v is not None
            and (not isinstance(v, str) or re.fullmatch(r"[0-9a-f]{32}", v) is None)
            for v in (item.profile_id, item.session_id, item.agent_id, item.request_id)
        ):
            return False, False
    bound = all(
        v is not None
        for v in (
            current.profile_id,
            current.session_id,
            current.agent_id,
            current.request_id,
        )
    )
    return context == current, bound


class ManualHermesAdapter:
    def __init__(self, router):
        self.router = router

    def validate_target(
        self,
        selection,
        context=None,
        *,
        current_context=None,
        selection_policy=MISSING,
        requires_tools=False,
        min_context=8192,
        now=None,
    ):
        now = time.time() if now is None else now
        safe_now = (
            now
            if type(now) in (int, float) and math.isfinite(now) and now > 0
            else None
        )
        invalid = _receipt("validation_failed", "selection_invalid", safe_now)
        if (
            safe_now is None
            or not isinstance(selection, dict)
            or set(selection) != {"schema_version", "provider", "model", "generated_at"}
        ):
            return invalid
        if (
            type(selection["schema_version"]) is not int
            or selection["schema_version"] != VERSION
        ):
            return _receipt(
                "validation_failed", "selection_version_unsupported", safe_now
            )
        provider, model, stamp = (
            selection[k] for k in ("provider", "model", "generated_at")
        )
        if (
            not isinstance(provider, str)
            or provider not in PROVIDERS
            or not isinstance(model, str)
            or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}", model) is None
            or "://" in model
            or re.search(
                r"(?i)(sk[-_]|bearer|api[_-]?key|scope_[0-9a-f]+|[0-9a-f]{32,})", model
            )
        ):
            return invalid
        if (
            type(stamp) not in (int, float)
            or not math.isfinite(stamp)
            or not 0 < stamp <= safe_now
            or safe_now - stamp >= 120
        ):
            return _receipt("validation_failed", "selection_expired", safe_now)
        matches, bound = _context_matches(context, current_context)
        if not matches:
            return _receipt(
                "validation_failed", "context_mismatch_or_unavailable", safe_now
            )
        if (
            type(requires_tools) is not bool
            or type(min_context) is not int
            or not 1 <= min_context <= 1000000000
        ):
            return invalid
        if self.router is None:
            return _receipt(
                "unavailable_evidence", "router_unavailable", safe_now, bound=bound
            )
        try:
            decision = self.router.preview(
                now=safe_now,
                selection_policy=selection_policy,
                requires_tools=requires_tools,
                min_context=min_context,
            )
        except Exception:
            return _receipt(
                "unavailable_evidence",
                "selection_evidence_unavailable",
                safe_now,
                bound=bound,
            )
        chosen = decision.get("chosen")
        if (
            not chosen
            and not decision.get("total_considered")
            and not decision.get("contract_error")
        ):
            return _receipt(
                "unavailable_evidence",
                "selection_evidence_absent",
                safe_now,
                bound=bound,
                decision=decision,
            )
        if not chosen or (chosen["provider"], chosen["model"]) != (provider, model):
            return _receipt(
                "validation_failed",
                "target_not_current_recommendation",
                safe_now,
                bound=bound,
                decision=decision,
            )
        policy = decision.get("selection_policy") or {}
        restrictions = policy.get("connection_restrictions") or {}
        if (
            restrictions.get("require_authority")
            or restrictions.get("connection_id") is not None
            or restrictions.get("shared_quota_scope") is not None
            or restrictions.get("models")
            or policy.get("quota_policy") == "require_fresh_account_allowance"
        ):
            return _receipt(
                "unavailable_evidence",
                "manual_cli_cannot_preserve_connection_authority",
                safe_now,
                bound=bound,
                decision=decision,
            )
        return _receipt(
            "recommendation",
            "target_revalidated",
            safe_now,
            target=dict(provider=provider, model=model),
            bound=bound,
            decision=decision,
        )

    def handoff(self, selection, context=None, *, confirmed=False, **kwargs):
        receipt = self.validate_target(selection, context, **kwargs)
        if type(confirmed) is not bool:
            return _receipt(
                "validation_failed", "confirmation_invalid", receipt["generated_at"]
            )
        if receipt["state"] != "recommendation" or not confirmed:
            return receipt
        target = receipt["target"]
        argv = [
            "hermes",
            "chat",
            "--provider",
            target["provider"],
            "--model",
            target["model"],
        ]
        return dict(
            receipt,
            state="manual_handoff_pending",
            reason="owner_must_run_supported_cli",
            manual_argv=argv,
            manual_command=shlex.join(argv),
        )

    def apply(self, *args, **kwargs):
        return _receipt(
            "unavailable_evidence",
            "host_context_bound_apply_contract_unavailable",
            time.time(),
        )

    def restore(self, *args, **kwargs):
        return _receipt(
            "unavailable_evidence",
            "host_confirmed_restore_contract_unavailable",
            time.time(),
        )
