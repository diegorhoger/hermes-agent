"""Explicit V1 task declarations; operational preferences are not competence claims."""

from copy import deepcopy
from ..configuration.selection_policy import PolicyError

VERSION = 1
_LABELS = {"general": "General", "coding": "Coding", "fast-response": "Fast response"}


def resolve(value):
    if not isinstance(value, dict) or set(value) != {"schema_version", "id"}:
        raise PolicyError("task_profile_invalid")
    if type(value["schema_version"]) is not int or value["schema_version"] != VERSION:
        raise PolicyError("task_profile_version_unsupported")
    key = value["id"]
    if not isinstance(key, str) or key not in _LABELS:
        raise PolicyError("task_profile_unsupported")
    return dict(
        schema_version=VERSION,
        id=key,
        label=_LABELS[key],
        hard_capabilities={},
        min_context=8192,
        preference="fast-response" if key == "fast-response" else "general",
        tools_requirement="explicit workload only",
        semantic_quality="unknown",
        evidence_provenance={
            "capabilities": "field_evidence: original independent sources",
            "performance": "observed_final_requests: bounded decayed measurements",
        },
        freshness={
            "capabilities": "original retrieved_at/expires_at; no extension",
            "performance_max_age_seconds": 604800,
        },
        unsupported=[
            "semantic competence",
            "automatic task detection",
            "execution authority",
            "live provider entitlement",
            "no-charge guarantee",
        ],
        no_match="no eligible model; do not execute or fall back",
    )


def catalog():
    return [resolve(dict(schema_version=VERSION, id=key)) for key in _LABELS]


def compose(value):
    """Resolve explicit profile requirements without relaxing caller constraints."""
    task = value["task_requirements"]
    if "profile" not in task:
        return value
    profile = resolve(task["profile"])
    if task["label"] != profile["id"]:
        raise PolicyError("task_profile_conflict")
    from ..configuration.policies import resolve as resolve_policy

    if (
        resolve_policy(value["preferences"]["policy"])["ranking_policy"]
        != resolve_policy(profile["preference"])["ranking_policy"]
    ):
        raise PolicyError("task_profile_preference_conflict")
    result = deepcopy(value)
    result["task_requirements"]["min_context"] = max(
        task["min_context"], profile["min_context"]
    )
    return result


def scoring_candidate(candidate, profile, now):
    """Use the existing scorer, with unknown rather than stale latency evidence."""
    if not profile or profile["id"] != "fast-response":
        return candidate
    from .scoring import summarize_observations
    import math

    observed = candidate.get("outcome_observations")
    stamp = (
        observed.get("last_latency_observed_at") if isinstance(observed, dict) else None
    )
    if (
        isinstance(observed, dict)
        and observed.get("source") == "observed_final_requests"
        and type(stamp) in (int, float)
        and math.isfinite(stamp)
        and 0 < stamp <= now
        and now - stamp < 604800
    ):
        return candidate
    unknown = summarize_observations([], now=now, available=False)
    if (
        isinstance(observed, dict)
        and observed.get("source") == "observed_final_requests"
    ):
        # Preserve independent reliability observations; remove only unusable speed evidence.
        clean = dict(observed)
        for key in (
            "latency_ewma_ms",
            "latency_samples",
            "latency_confidence",
            "latency_p50_ms",
            "latency_p95_ms",
            "speed",
        ):
            clean[key] = unknown[key]
    else:
        clean = unknown
    return dict(candidate, outcome_observations=clean)


def request(profile_id, providers, *, requires_tools=False):
    """Portable public-evidence preview template; never infer account authority."""
    profile = resolve(dict(schema_version=VERSION, id=profile_id))
    if type(requires_tools) is not bool:
        raise PolicyError("task_profile_invalid")
    value = dict(
        schema_version=1,
        hard_eligibility=dict(
            verified_free_only=True,
            required_capabilities={},
            min_context=8192,
            authorized_providers=providers,
            exclude=[],
            max_in_flight=None,
            health=dict(
                respect_failures=True, respect_cooldowns=True, require_observed=False
            ),
        ),
        preferences=dict(policy=profile["preference"]),
        task_requirements=dict(
            schema_version=1,
            label=profile_id,
            profile=dict(schema_version=VERSION, id=profile_id),
            required_capabilities={"tools": "required"} if requires_tools else {},
            min_context=8192,
        ),
        connection_restrictions=dict(
            provider_id=None,
            connection_id=None,
            require_authority=False,
            models=[],
            shared_quota_scope=None,
        ),
        quota_policy="avoid_verified_exhaustion",
    )
    from ..configuration.selection_policy import validate

    return validate(value)
