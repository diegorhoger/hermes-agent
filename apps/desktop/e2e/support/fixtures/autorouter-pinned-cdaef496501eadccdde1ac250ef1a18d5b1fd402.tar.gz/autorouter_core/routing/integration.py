"""Integration adapter between AutoRouter and Hermes agent runtime."""

from __future__ import annotations

from typing import Any

from ..integration import runtime as rt


def build_fallback_chain(*, requires_tools: bool = True, min_context: int = 8192,
                         limit: int = 5) -> list[dict[str, Any]]:
    """Build an ordered list of {provider, model} fallback entries using AutoRouter.

    Compatibility recommendations only; never automatically apply or replay them.
    """
    r = rt.get_router()
    if r is None:
        return []
    if type(limit) is not int or not 1 <= limit <= 5:
        return []
    result = r.preview(requires_tools=requires_tools, min_context=min_context)
    return [{"provider": row["provider"], "model": row["model"]} for row in result["ranked"][:limit]]


def apply_to_agent(agent: Any, **kwargs) -> bool:
    """Compatibility refusal: private agent mutation is not sanctioned application."""
    return False
