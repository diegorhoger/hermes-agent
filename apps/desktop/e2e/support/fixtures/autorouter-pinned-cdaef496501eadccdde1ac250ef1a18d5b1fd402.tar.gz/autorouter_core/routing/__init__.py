"""AutoRouter routing package."""
