"""Routing engine for AutoRouter."""

from __future__ import annotations

import logging
import time
from ..configuration.selection_policy import MISSING

from typing import Any, Optional

logger = logging.getLogger(__name__)


class Router:
    def __init__(self, state: dict[str, Any]):
        self.state = state

    @property
    def policy(self) -> str:
        return str(self.state.get("policy", "auto"))

    @property
    def store(self):
        return self.state.get("store")

    def _candidates_from_store(self) -> list[dict[str, Any]]:
        store = self.store
        if store is None:
            return []
        try:
            rows = store.get_catalog()
        except Exception:
            return []
        out = []
        for r in rows:
            caps = r.get("capabilities")
            if isinstance(caps, str):
                try:
                    import json
                    caps = json.loads(caps)
                except Exception:
                    caps = None
            out.append({
                "provider": r["provider"],
                "model": r["model"],
                "context_length": r.get("context_length"),
                "capabilities": caps,
                "cost_tier": r.get("cost_tier"),
            })
        return out

    def _resolved_candidates(self, cands: Optional[list[dict[str, Any]]] = None, *, now=None) -> list[dict[str, Any]]:
        """Require current source-attributed evidence, shared by selection and dashboard.

        Catalog claims never substitute for absent, expired or unreadable proof.
        """
        if cands is None:
            cands = self._candidates_from_store()
        now = time.time() if now is None else now
        from ..discovery.metadata import verified_fields
        import json
        resolved = []
        for candidate in cands:
            c = dict(candidate)
            c.update(context_length=None, capabilities={"tools": "unknown"}, cost_tier="unknown",
                     metadata_freshness="unknown", field_freshness={}, field_evidence={})
            try:
                row = self.store.get_capability(c["provider"], c["model"]) if self.store else None
                cap = json.loads(row["capability_json"]) if row else {}
                fields, statuses, evidence = verified_fields(cap, c["provider"], c["model"], now)
                c.update(context_length=fields["context_window"], capabilities={"tools": fields["tools"]},
                         cost_tier=fields["cost_tier"], field_freshness=statuses, field_evidence=evidence,
                         metadata_freshness="fresh" if all(v == "fresh" for v in statuses.values()) else "incomplete_or_stale",
                         metadata_source=cap.get("metadata_source", "unknown"), retrieved_at=cap.get("retrieved_at", 0))
            except Exception:
                logger.warning("autorouter: capability evidence unavailable or invalid")
                c["verification_error"] = "capability evidence unavailable or invalid"
            resolved.append(c)
        return resolved

    def select(self, *, requires_tools: bool = False, min_context: int = 8192,
               exclude: Optional[set] = None, max_in_flight: Optional[int] = None,
               strict_no_charge: bool = False, policy: str | None = None,
               return_decision: bool = False, selection_policy=MISSING) -> Optional[dict[str, Any]]:
        if policy is not None:
            return Router(dict(self.state, policy=policy)).select(requires_tools=requires_tools,
                min_context=min_context, exclude=exclude, max_in_flight=max_in_flight,
                strict_no_charge=strict_no_charge, return_decision=return_decision, selection_policy=selection_policy)

        providers = self.state.get("providers") or []
        store = self.store
        free_only = bool(self.state.get("free_only", True))
        paid_authorized = bool(self.state.get("paid_authorized", False))

        from ..configuration.policies import resolve
        from ..discovery import discovery as dc
        try:
            resolve(self.policy)
        except ValueError:
            return evaluate_snapshot([], policy=self.policy, now=time.time()) if return_decision else None

        from ..configuration.selection_policy import validate, requirements
        selected_contract = self.state.get("selection_policy", MISSING) if selection_policy is MISSING else selection_policy
        if selected_contract is not MISSING:
            try:
                validate(selected_contract)
                requirements(selected_contract, requires_tools, min_context)
                providers = [p for p in providers if p in selected_contract["hard_eligibility"]["authorized_providers"]]
            except (ValueError, TypeError):
                denied = evaluate_snapshot([], policy=self.policy, now=time.time(), selection_policy=selected_contract)
                return denied if return_decision else None

        from ..discovery import discovery as dc
        # refresh catalog if empty
        cands = self._resolved_candidates()
        if not cands:
            try:
                dc.discover_all(providers, store=store)
                cands = self._resolved_candidates()
            except Exception as exc:
                logger.warning("autorouter: discovery failed: %s", exc)
                # try LKG
                if store is not None:
                    lkg = store.get_lkg()
                    if isinstance(lkg, dict):
                        cands = []
                        for p, ms in lkg.items():
                            for m in ms or []:
                                cands.append(m)
                        cands = self._resolved_candidates(cands)

        result = self._evaluate(cands, requires_tools=requires_tools, min_context=min_context,
                                exclude=exclude, max_in_flight=max_in_flight, strict_no_charge=strict_no_charge, selection_policy=selection_policy, now=time.time())
        if result["chosen"] is None:
            return result if return_decision else None
        chosen = next(c for c in cands if (c["provider"], c["model"]) ==
                      (result["chosen"]["provider"], result["chosen"]["model"]))
        eligible_count = result["eligible_count"]
        try:
            if store is not None:
                store.record_decision(result["policy"], chosen["provider"], chosen["model"], "selected", eligible_count)
        except Exception:
            pass
        return result if return_decision else chosen

    def _evaluate(self, candidates, *, now, **constraints):
        from ..evidence import free_access
        selected_contract = constraints.pop("selection_policy", MISSING)
        if selected_contract is MISSING:
            selected_contract = self.state.get("selection_policy", MISSING)
        quota_cache = {}
        snapshot = []
        for c in candidates:
            item = dict(c)
            from ..health.health import decision
            scopes = (self.state.get("credential_scopes") or {}) if selected_contract is MISSING else {}
            scope = scopes.get(c["provider"], "")
            health = decision(self.store, c["provider"], c["model"], scope, now=now)
            item["health"] = health["health"]
            item["health_reason"] = health["reason"]
            item["circuit_state"] = health["circuit"]
            item["scope_state"] = health["scope"]
            contexts = self.state.get("connection_contexts") or {}
            connection = contexts.get(c["provider"]) if isinstance(contexts, dict) else None
            from ..configuration.selection_policy import authority
            active = self.state.get("selection_context")
            authorized_observation = authority(connection, active, c["provider"], now)
            if authorized_observation:
                scope = c["provider"] + ":" + connection.connection_id
                health = decision(self.store, c["provider"], c["model"], scope, now=now)
                item.update(health=health["health"],health_reason=health["reason"],circuit_state=health["circuit"],scope_state=health["scope"])
            item["observation_scope"] = "authorized_observation" if authorized_observation else "legacy_configured" if scope else "unknown"
            item["health_observations"] = health.get("observations", [])
            item["connection_context"] = connection
            quota_key=(c["provider"],free_access.canonical_scope(scope))
            if quota_key not in quota_cache:
                quota_cache[quota_key]=free_access.read_snapshot(self.store,c["provider"],scope)
            item["quota_snapshot"] = quota_cache[quota_key]
            item["free_access"]=free_access.evaluate(quota_cache[quota_key],c["provider"],c["model"],scope,now)
            item["free_access"]["advertised_zero_price"]=c.get("cost_tier")=="free"
            try:
                item["in_flight"] = self.store.get_in_flight(c["provider"], c["model"]) if self.store else None
            except Exception:
                item["in_flight"] = None
            from .scoring import summarize_observations
            from ..eligibility.eligibility import rejection_reasons
            observed = {"available": False, "rows": []}
            # Reuse the hard gates before reading ranking samples for catalog-only rows.
            if not rejection_reasons(item, requires_tools=constraints.get("requires_tools", False),
                                     min_context=constraints.get("min_context", 8192)):
                try:
                    observed = self.store.get_scoring_observations(c["provider"], c["model"], scope)
                except Exception:
                    pass
            item["outcome_observations"] = summarize_observations(observed["rows"], now=now, available=observed["available"])
            snapshot.append(item)
        return evaluate_snapshot(snapshot, policy=self.policy, providers=self.state.get("providers"),
                                 now=now, selection_policy=selected_contract,
                                 selection_context=self.state.get("selection_context"),
                                 quota_evaluator=self.state.get("quota_policy_evaluator", free_access.evaluate_policy), **constraints)

    def preview(self, *, requires_tools=False, min_context=8192, exclude=None,
                max_in_flight=None, now=None, strict_no_charge=False, policy=None, selection_policy=MISSING):
        """Read existing snapshots only; never discover, read credentials or record decisions."""
        now = time.time() if now is None else now
        from ..storage.snapshot import ReadOnlyStateStore
        state = dict(self.state)
        if policy is not None:
            state["policy"] = policy
        db_path = getattr(self.store, "db_path", None)
        state["store"] = ReadOnlyStateStore(db_path) if db_path is not None else None
        reader = Router(state)
        return reader._evaluate(reader._resolved_candidates(now=now), now=now,
                                requires_tools=requires_tools, min_context=min_context,
                                exclude=exclude, max_in_flight=max_in_flight, strict_no_charge=strict_no_charge, selection_policy=selection_policy)

    def inflight(self, provider: str, model: str):
        """Context manager: reserve a concurrent slot for (provider, model).

        Safe even if the store is missing or errors — releasing is best-effort.
        """
        import contextlib
        store = self.store
        if store is None:
            return contextlib.nullcontext(None)

        @contextlib.contextmanager
        def _mgr():
            try:
                store.reserve(provider, model)
            except Exception as exc:
                logger.debug("autorouter: reserve failed: %s", exc)
            try:
                yield
            finally:
                try:
                    store.release(provider, model)
                except Exception as exc:
                    logger.debug("autorouter: release failed: %s", exc)

        return _mgr()

    def select_free_model(self, *, requires_tools: bool = False, min_context: int = 8192,
                          exclude: Optional[set] = None, max_in_flight: Optional[int] = None) -> Optional[dict[str, Any]]:
        """Select an eligible FREE model only.

        Fail-closed: paid, premium, unknown, and missing cost tiers are all ineligible.
        The deprecated paid_authorized flag has no effect — paid inference remains
        disabled in v0.1.0.

        This method does not mutate self.state. A shallow state copy with
        free_only=True and paid_authorized=False is used for the selection,
        so concurrent selections cannot observe or modify each other's
        configuration. The shallow copy shares the same state store reference,
        so health/quota observations remain consistent.

        Returns the chosen candidate dict or None when no safe free route exists.
        """
        # Build a state copy with free-only enforced — no mutation of self.state.
        # The shallow copy shares the store reference, so health/quota observations
        # remain consistent across Router instances.
        safe_state = dict(self.state)
        safe_state["free_only"] = True
        safe_state["paid_authorized"] = False
        safe_router = Router(safe_state)
        return safe_router.select(
            requires_tools=requires_tools,
            min_context=min_context,
            exclude=exclude,
            max_in_flight=max_in_flight,
        )

    def record_outcome(self, provider, model, success, *,
                       key_scope="",
                       status_code: int | None = None,
                       latency_ms: float | None = None,
                       error_type: str | None = None,
                       error_message: str | None = None, retry_after=None, trusted_reason=None) -> None:
        store = self.store
        if store is None:
            return
        try:
            store.record_outcome(provider, model, success, key_scope=key_scope,
                                 status_code=status_code, latency_ms=latency_ms,
                                 error_type=error_type, error_message=error_message,
                                 retry_after=retry_after, trusted_reason=trusted_reason)
        except Exception as exc:
            logger.debug("autorouter: record_outcome error: %s", exc)

    def refresh(self) -> dict:
        providers = self.state.get("providers") or []
        store = self.store
        from ..discovery import discovery as dc
        try:
            out = dc.discover_all(providers, store=store)
            return {"ok": True, "providers": {k: len(v) for k, v in out.items()}}
        except Exception as exc:
            logger.warning("autorouter: refresh failed: %s", exc)
            return {"ok": False, "error": str(exc)}

    def status(self) -> dict:
        store = self.store
        if store is None:
            return {"enabled": True, "policy": self.policy, "store": None}
        try:
            return {"enabled": True, "policy": self.policy, "store": store.summary()}
        except Exception as exc:
            return {"enabled": True, "policy": self.policy, "error": str(exc)}


REASONS = {
    "unavailable": "Model is retired or unavailable.",
    "verified_account_quota_exhausted": "Fresh quota evidence reports this connection allowance exhausted.",
    "no_charge_guarantee_unverified": "No independent provider hard-stop guarantee establishes no-charge execution.",
    "provider_disabled": "Provider is not configured for selection.",
    "excluded": "Model was explicitly excluded.",
    "retired": "Model is retired.",
    "auth_failed": "Observed authentication failure.",
    "cooldown": "Model is cooling down.",
    "concurrency_limit": "Observed concurrency limit reached.",
    "health_invalid": "Health snapshot is invalid.",
    "tools_unverified_or_unsupported": "Required tool support is unknown or unsupported.",
    "context_unknown_or_insufficient": "Context is unknown or below the required minimum.",
    "cost_not_verified_free": "Fresh verified zero-price evidence is unavailable.",
    "policy_invalid": "Unknown policy; choose a policy from the V1 contract.",
    "selection_policy_invalid": "Unsupported, malformed or contradictory selection requirements.",
    "tools_forbidden": "Explicit task or user requirements forbid tool-capable candidates.",
    "health_observation_required": "An observed available health state is required.",
    "connection_model_scope_unavailable": "An authoritative model scope is unavailable for this connection requirement.",
    "connection_authority_unavailable": "Current authorized connection context is unavailable.",
    "connection_restriction_mismatch": "Current connection or its model/shared scope does not match the requirement.",
    "fresh_account_allowance_required": "A fresh, authorized account allowance is required.",
    "quota_policy_denied": "The versioned quota preflight denied this requirement.",
}


def evaluate_snapshot(candidates, *, policy="auto", providers=None, now, requires_tools=False,
                      min_context=8192, exclude=None, max_in_flight=None, limit=500, strict_no_charge=False,
                      selection_policy=MISSING, selection_context=None, quota_evaluator=None):
    """Pure evaluation of an explicit, already proof-resolved snapshot. No I/O."""
    from ..eligibility.eligibility import rejection_reasons
    from .scoring import score_breakdown
    from ..configuration import selection_policy as sp
    from ..routing import task_profiles
    from ..configuration.policies import contract, resolve
    try:
        preference = resolve(policy)
    except ValueError:
        preference = None
    normalized = None
    invalid_contract = False
    contract_error = None
    forbidden_tools = False
    if selection_policy is not MISSING:
        try:
            normalized = sp.validate(selection_policy)
            if (type(requires_tools) is not bool or type(min_context) is not int or min_context < 1
                    or type(strict_no_charge) is not bool
                    or max_in_flight is not None and (type(max_in_flight) is not int or max_in_flight < 1)
                    or providers is not None and (not isinstance(providers,(list,tuple,set)) or any(not isinstance(v,str) for v in providers))
                    or exclude is not None and (not isinstance(exclude,(list,tuple,set)) or any(not isinstance(v,(tuple,list)) or len(v)!=2 or any(not isinstance(x,str) for x in v) for v in exclude))
                    or type(limit) is not int or limit < 1):
                raise ValueError("invalid constraints")
            requires_tools, min_context, forbidden_tools = sp.requirements(normalized, requires_tools, min_context)
            preference = resolve(normalized["preferences"]["policy"])
        except (ValueError, TypeError) as error:
            contract_error = error.code if isinstance(error, sp.PolicyError) else "selection_policy_invalid"
            invalid_contract = True
            normalized = None
            requires_tools, min_context, max_in_flight, providers, exclude, limit, strict_no_charge = False, 8192, None, None, None, 500, False
    task_profile = task_profiles.resolve(normalized["task_requirements"]["profile"]) if normalized is not None and "profile" in normalized["task_requirements"] else None
    considered = []
    for c in candidates:
        reasons = rejection_reasons(c, requires_tools=requires_tools, min_context=min_context)
        if preference is None:
            reasons.append("policy_invalid")
        if invalid_contract:
            reasons.append("selection_policy_invalid")
        quota = None
        known = sp.authority(c.get("connection_context"), selection_context, c["provider"], now)
        if normalized is not None:
            extra, known = sp.restriction_reasons(normalized, c, c.get("connection_context"), selection_context, now)
            reasons.extend(extra)
            from ..discovery.metadata import valid_evidence
            fields = c.get("field_evidence") if isinstance(c.get("field_evidence"), dict) else {}
            if not valid_evidence(fields.get("cost_tier", {}), now):
                reasons.append("cost_not_verified_free")
            if not valid_evidence(fields.get("context_window", {}), now):
                reasons.append("context_unknown_or_insufficient")
            if (requires_tools or forbidden_tools) and not valid_evidence(fields.get("tools", {}), now):
                reasons.append("tools_unverified_or_unsupported")
            if forbidden_tools:
                from ..eligibility.eligibility import is_tool_capable
                if is_tool_capable(c["provider"], c["model"], c.get("capabilities")) or (c.get("capabilities") if isinstance(c.get("capabilities"),dict) else {}).get("tools") not in (False, "unsupported"):
                    reasons.append("tools_forbidden")
            quota = sp.quota_decision(quota_evaluator, c.get("quota_snapshot"), c["provider"], c["model"],
                c.get("connection_context"), known, now, normalized["quota_policy"])
            if not quota["allowed"]:
                reasons.append("no_charge_guarantee_unverified" if normalized["quota_policy"] == "require_no_charge_guarantee"
                    else "verified_account_quota_exhausted" if quota["state"] == "exhausted"
                    else "fresh_account_allowance_required" if normalized["quota_policy"] == "require_fresh_account_allowance" else "quota_policy_denied")
        if providers is not None and c["provider"] not in providers:
            reasons.append("provider_disabled")
        if (c["provider"], c["model"]) in (exclude or set()):
            reasons.append("excluded")
        access=c.get("free_access") or {}
        if normalized is not None:
            from ..evidence.free_access import evaluate as evaluate_access
            scope = c["provider"] + ":" + c["connection_context"].connection_id if known else ""
            access = evaluate_access(c.get("quota_snapshot"), c["provider"], c["model"], scope, now)
        if access.get("allowed") is False and access.get("reason")=="verified_account_quota_exhausted":
            reasons.append("verified_account_quota_exhausted")
        if strict_no_charge:
            reasons.append("no_charge_guarantee_unverified")
        h = c.get("health") or {}
        if c.get("health_reason") == "health_invalid":
            reasons.append("health_invalid")
        try:
            for flag in ("retired", "auth_failed"):
                if int(h.get(flag) or 0):
                    reasons.append(flag)
            if float(h.get("cooldown_until") or 0) > now:
                reasons.append("cooldown")
            if max_in_flight and max_in_flight > 0 and c.get("in_flight") is not None and c["in_flight"] >= max_in_flight:
                reasons.append("concurrency_limit")
            score = score_breakdown(task_profiles.scoring_candidate(dict(c, observation_scope="authorized_observation" if known else "legacy_configured" if c.get("observation_scope") == "legacy_configured" else "unknown"), task_profile, now), policy=preference["ranking_policy"], health=h, now=now) if not reasons else None
        except (TypeError, ValueError, OverflowError):
            reasons.append("health_invalid")
            score = None
        reasons = list(dict.fromkeys(reasons))
        from ..health.health_guidance import describe
        guidance = describe(dict(c, evaluated_quota=quota, free_access=access), reasons, now=now, authorized=known)
        considered.append({"provider": c["provider"], "model": c["model"], "eligible": not reasons,
                           "reason_codes": reasons, "reasons": [REASONS[r] for r in reasons],
                           "health_guidance": guidance,
                           "quota_policy_evidence": quota, "connection_authority": "authorized_observation" if known else "unknown",
                           "score": score, "metadata_freshness": c.get("metadata_freshness", "unknown"),
                           "field_evidence": c.get("field_evidence", {}),
                           "health_reason": c.get("health_reason", "health_unknown"),
                           "circuit_state": c.get("circuit_state", "closed"),
                           "scope_state": c.get("scope_state", "scope_unknown"),
                           "free_access": dict(access,allowed=False,reason="no_charge_guarantee_unverified") if strict_no_charge else access})
    considered.sort(key=lambda c: (c["provider"], c["model"]))
    ranked = sorted((c for c in considered if c["eligible"]),
                    key=lambda c: (-int(bool((c.get("quota_policy_evidence") or {}).get("preference_available"))), -c["score"]["total"], c["provider"], c["model"]))
    limit = max(1, min(int(limit), 50000))
    result = {"chosen": ranked[0] if ranked else None, "policy": normalized["preferences"]["policy"] if normalized is not None else policy, "generated_at": now,
            "considered": considered[:limit], "ranked": ranked[:limit],
            "total_considered": len(considered), "eligible_count": len(ranked), "truncated": len(considered) > limit,
            "semantic_quality": "unknown", "policy_contract": contract(),
            "selection_policy": sp.public(normalized) if normalized is not None else None,
            "task_profile": task_profile,
            "selection_policy_version": 1, "execution_authority": False, "contract_error": contract_error,
            "ranking_order": (["fresh_supported_allowance", "score", "provider", "model"] if normalized is not None and normalized["quota_policy"] == "prefer_available_allowance" else ["score", "provider", "model"]),
            "policy_metadata": preference, "cost_mode": "verified-free-only",
            "constraints": {"requires_tools": bool(requires_tools), "min_context": min_context,
                            "strict_no_charge": bool(strict_no_charge)},
            "no_match": "selection_policy_invalid" if invalid_contract else "policy_invalid" if preference is None else "no_eligible_model" if not ranked else None}
    from ..telemetry.decision_report import build
    result["evidence_report"] = build(result)
    return result
