"""Sample-aware operational ranking; semantic quality remains unknown."""
from __future__ import annotations

import math
import time
from typing import Any

SAMPLE_LIMIT = 64
HALF_LIFE_SECONDS = 7 * 86400
EWMA_ALPHA = 0.3
PRIOR_SUCCESSES = PRIOR_FAILURES = 2.0
WEIGHTS = {
    "auto": (0.35, 0.25, 0.25, 0.15, 0),
    "fastest": (0.2, 0.6, 0.1, 0.1, 0),
    "reliable": (0.6, 0.2, 0.1, 0.1, 0),
    "smartest": (0.3, 0.1, 0.5, 0.1, 0),
    "coding": (0.3, 0, 0.4, 0.1, 0.2),
    "priority": (0.5, 0, 0.2, 0.3, 0),
}


def _number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def summarize_observations(rows, *, now, available=True):
    """Decay at most 64 observed final outcomes toward a Beta(2,2) prior."""
    valid = []
    for row in list(rows)[:SAMPLE_LIMIT]:
        observed = row.get("ended_at")
        if row.get("status") not in ("success", "error") or not _number(observed) or not 0 < observed <= now:
            continue
        valid.append((observed, row))
    valid.sort(key=lambda pair: (pair[0], pair[1].get("id", 0)))
    total = successes = latency_weight = latency_sum = latency_effective = 0.0
    latency_samples = 0
    last_latency_observed_at = None
    latencies = []
    for observed, row in valid:
        decay = 2.0 ** (-min((now - observed) / HALF_LIFE_SECONDS, 1075))
        total += decay
        successes += decay if row["status"] == "success" else 0
        latency = row.get("latency_ms")
        if _number(latency):
            latency_sum = (1 - EWMA_ALPHA) * latency_sum + EWMA_ALPHA * decay * latency
            latency_weight = (1 - EWMA_ALPHA) * latency_weight + EWMA_ALPHA * decay
            latency_effective += decay
            latency_samples += 1
            last_latency_observed_at = observed
            latencies.append(latency)
    confidence = total / (total + 5)
    latency_confidence = latency_effective / (latency_effective + 5)
    ewma = latency_sum / latency_weight if latency_weight else None
    raw_speed = 1 / (1 + ewma / 1000) if ewma is not None else .5
    ordered = sorted(latencies)
    def percentile(fraction):
        return ordered[max(0, math.ceil(len(ordered) * fraction) - 1)] if ordered else None
    return {
        "available": available, "source": "observed_final_requests", "sample_limit": SAMPLE_LIMIT,
        "samples": len(valid), "effective_samples": total, "confidence": confidence,
        "last_observed_at": valid[-1][0] if valid else None,
        "stale": bool(valid and now - valid[-1][0] >= HALF_LIFE_SECONDS),
        "half_life_seconds": HALF_LIFE_SECONDS,
        "reliability": (PRIOR_SUCCESSES + successes) / (PRIOR_SUCCESSES + PRIOR_FAILURES + total),
        "latency_ewma_ms": ewma, "latency_samples": latency_samples,
        "last_latency_observed_at": last_latency_observed_at,
        "latency_confidence": latency_confidence,
        "latency_p50_ms": percentile(.5), "latency_p95_ms": percentile(.95),
        "speed": .5 + latency_confidence * (raw_speed - .5),
        "semantic_quality": "unknown",
    }


def observation_coverage(observations, *, now, attribution="unknown"):
    """Versioned evidence coverage, not another reliability or speed estimator."""
    obs = observations if isinstance(observations, dict) else {}
    available = (
        obs.get("available") is True and obs.get("source") == "observed_final_requests"
    )
    samples = obs.get("samples")
    valid_samples = type(samples) is int and 0 <= samples <= SAMPLE_LIMIT
    available = available and valid_samples
    samples = samples if available else None
    stamp = obs.get("last_observed_at")
    valid_stamp = _number(stamp) and 0 < stamp <= now
    age = now - stamp if available and valid_stamp else None
    state = (
        "unavailable"
        if not available
        else "cold_start"
        if not samples
        else "unknown"
        if not valid_stamp
        else "stale"
        if age >= HALF_LIFE_SECONDS
        else "bounded_sample"
        if samples == SAMPLE_LIMIT
        else "sample_limited"
    )
    latency_stamp = obs.get("last_latency_observed_at")
    latency_age = (
        now - latency_stamp
        if available and _number(latency_stamp) and 0 < latency_stamp <= now
        else None
    )
    latency_state = (
        "unavailable"
        if not available
        else "unknown"
        if latency_age is None
        else "stale"
        if latency_age >= HALF_LIFE_SECONDS
        else "observed"
    )
    attribution = (
        attribution
        if attribution in ("authorized_observation", "legacy_configured")
        else "unknown"
    )

    def metric(name):
        value = obs.get(name)
        return value if available and _number(value) else None

    return dict(
        schema_version=1,
        state=state,
        source="observed_final_requests" if available else "unknown",
        attribution=attribution,
        active_account_authority=attribution == "authorized_observation",
        sample_limit=SAMPLE_LIMIT,
        samples=samples,
        effective_samples=metric("effective_samples"),
        confidence=metric("confidence"),
        last_observed_at=stamp if available and valid_stamp else None,
        age_seconds=age,
        half_life_seconds=HALF_LIFE_SECONDS,
        stale_after=stamp + HALF_LIFE_SECONDS if available and valid_stamp else None,
        expiry_meaning="display staleness boundary; historical evidence still decays",
        latency_state=latency_state,
        latency_samples=metric("latency_samples"),
        latency_confidence=metric("latency_confidence"),
        latency_age_seconds=latency_age,
        last_latency_observed_at=latency_stamp
        if available and latency_age is not None
        else None,
        latency_ewma_ms=metric("latency_ewma_ms"),
        measurement_boundary="host-reported final-request elapsed latency; not token-normalized or a semantic benchmark",
        reliability_state="neutral_prior" if not samples else "historical_estimate",
        semantic_quality="unknown",
        current_availability="unknown",
    )


def score_breakdown(candidate: dict[str, Any], *, policy: str, health=None, now=None) -> dict:
    """Use the same bounded observations for routing and its pure preview."""
    now = time.time() if now is None else now
    h = health or {}
    for name in ("successes", "failures", "last_latency_ms", "cooldown_until"):
        value = h.get(name)
        if value is not None and not _number(value):
            raise ValueError("invalid health measurement")
    observations = candidate.get("outcome_observations")
    if not isinstance(observations, dict):
        observations = summarize_observations([], now=now, available=False)
    for key in ("reliability", "speed", "confidence", "latency_confidence"):
        if not _number(observations.get(key)) or observations[key] > 1:
            raise ValueError("invalid outcome statistics")
    # Context is a hard capability constraint, never a semantic-quality estimate.
    values = dict(reliability=observations["reliability"], speed=observations["speed"],
                  semantic_quality=.5, cooldown=float((h.get("cooldown_until") or 0) <= now),
                  tools=float(_tool_capable(candidate)))
    factors = {name: {"value": value, "weight": weight, "contribution": value * weight}
               for (name, value), weight in zip(values.items(), WEIGHTS.get(policy, WEIGHTS["auto"]))}
    return {"total": sum(f["contribution"] for f in factors.values()), "factors": factors,
            "semantic_quality": "unknown", "observations_available": bool(observations["samples"]),
            "observations": observations,
            "coverage": observation_coverage(observations, now=now, attribution=candidate.get("observation_scope"))}


def score_candidate(candidate: dict[str, Any], *, policy: str, store=None) -> float:
    candidate = dict(candidate)
    now = time.time()
    try:
        snapshot = store.get_scoring_observations(candidate["provider"], candidate["model"])
        candidate["outcome_observations"] = summarize_observations(snapshot["rows"], now=now, available=snapshot["available"])
        health = store.get_health(candidate["provider"], candidate["model"])
    except Exception:
        health = {}
    return score_breakdown(candidate, policy=policy, health=health, now=now)["total"]


def _tool_capable(candidate: dict[str, Any]) -> bool:
    from ..eligibility.eligibility import is_tool_capable
    return is_tool_capable(candidate["provider"], candidate["model"], candidate.get("capabilities"))
