"""Failover classification for AutoRouter."""

from __future__ import annotations

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Map HTTP status -> (reason_name, retryable, should_fallback)
STATUS_MAP = {
    429: ("rate_limit", True, True),
    401: ("auth", False, True),
    403: ("auth", False, True),
    404: ("model_not_found", False, True),
    410: ("model_not_found", False, True),
    500: ("server_error", True, True),
    502: ("server_error", True, True),
    503: ("server_error", True, True),
    504: ("server_error", True, True),
}


def _reason_value(name: str):
    try:
        from agent.error_classifier import FailoverReason
        # try attribute
        for attr in (name, name.upper(), name.lower()):
            if hasattr(FailoverReason, attr):
                return getattr(FailoverReason, attr)
        # try by value
        try:
            return FailoverReason(name)
        except Exception:
            pass
    except Exception:
        pass
    return name


def classify(kwargs: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Consult ``transform_api_error_classification`` hooks BEFORE the built-in classifier.

    Commitment safety: when commitment indicators are present and True, both
    ``retryable`` and ``should_fallback`` are forced to False to prevent unsafe
    tool replay or postcommit provider retry.

    NOTE: Hermes does not supply ``tool_side_effects_committed`` or
    ``streamed_committed`` to the classifier in real execution. The real
    commitment boundaries live in Hermes' agent execution layer (stream output
    delivered to client, tool side effects persisted to session DB). AutoRouter
    can only recommend fallback; it cannot enforce postcommit safety at runtime
    because Hermes does not communicate commitment state back to the classifier.
    These checks are defense-in-depth only and apply when a test harness or
    future Hermes version supplies the flags.
    """
    # ── COMMITMENT SAFETY GATE (defense-in-depth only) ────────────────────
    # These flags are never supplied by Hermes real execution today. They are
    # retained for the case where a test harness or future Hermes version
    # communicates commitment state. They do not constitute runtime enforcement.
    tool_side_effects_committed = kwargs.get("tool_side_effects_committed", False)
    streamed_committed = kwargs.get("streamed_committed", False)

    status = kwargs.get("status_code")
    error_type = kwargs.get("error_type") or ""
    provider = kwargs.get("provider") or ""
    model = kwargs.get("model") or ""

    # determine reason
    reason_name = None
    retryable = True
    should_fallback = False
    if isinstance(status, int) and status in STATUS_MAP:
        reason_name, retryable, should_fallback = STATUS_MAP[status]
    else:
        # inspect error_type / message
        et = str(error_type).lower()
        msg = str(kwargs.get("error_message") or kwargs.get("error") or "").lower()
        if "timeout" in et or "timeout" in msg:
            reason_name, retryable, should_fallback = "timeout", True, True
        elif "connection" in et:
            reason_name, retryable, should_fallback = "connection_error", True, True
        elif "rate" in msg or "429" in msg:
            reason_name, retryable, should_fallback = "rate_limit", True, True
        elif "not found" in msg or "gone" in msg or "retired" in msg:
            reason_name, retryable, should_fallback = "model_not_found", False, True

    if reason_name is None:
        return None

    # Commitment override: when verified committed, disable both retry and fallback
    if tool_side_effects_committed is True or streamed_committed is True:
        retryable = False
        should_fallback = False

    # Update health store via runtime
    try:
        from ..integration import runtime as rt
        r = rt.get_router()
        if r is not None:
            r.record_outcome(
                provider=provider,
                model=model,
                success=False,
                status_code=status if isinstance(status, int) else None,
                error_type=error_type,
                error_message=str(kwargs.get("error_message") or kwargs.get("error") or "")[:500],
            )
    except Exception:
        pass

    # Handle cooldown with Retry-After if present
    ra = kwargs.get("retry_after")
    if ra is not None:
        try:
            from ..integration import runtime as rt
            store = rt.get_store()
            if store is not None:
                store.set_cooldown(provider, model, float(ra))
        except Exception:
            pass

    result = {
        "reason": _reason_value(reason_name),
        "retryable": retryable,
        "should_fallback": should_fallback,
        "preserve_session": True,
        "message": f"AutoRouter classified {status or error_type}",
    }
    return result


def exhaustion(attempts: Optional[list] = None) -> dict[str, Any]:
    """Structured result when no eligible provider/model remains."""
    return {
        "condition": "PROVIDERS_EXHAUSTED",
        "retryable": False,
        "task_complete": False,
        "no_kanban_respawn": True,
        "preserve_task": True,
        "preserve_session": True,
        "attempts": list(attempts or []),
    }


def on_pre_api_request(**kwargs) -> None:
    """Called once per turn before the API request is built and sent."""

def on_post_api_request(**kwargs) -> None:
    """Called once per turn after the API request completed."""

def on_api_request_error(**kwargs) -> None:
    """Called once per API-request error attempt (per-retry, not per-turn)."""

def on_api_error_classification(**kwargs):
    """Consulted by Hermes before built-in classifier. We classify and signal fallback."""
    try:
        return fv.classify(kwargs)
    except Exception as exc:
        logger.debug("autorouter: classification error: %s", exc)
        return None