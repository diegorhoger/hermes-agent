"""Canonical AutoRouter virtual-model selector (installed within the plugin).

This is the "one configurable automatic strategy" that chooses the best
eligible, available, free model for a chat. It is pure logic over the existing
AutoRouter catalog + eligibility + scoring engine; it deliberately does not
discover models itself (the discovery module already persists a catalog) and
it does not execute any request.

The selector is what the chat-router adapter hands to Hermes' sanctioned
provider path once a user picks the ``autorouter/auto-free`` virtual model.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Optional

import eligibility as el
import router as rt
import state as st

logger = logging.getLogger(__name__)

# Strategies map to AutoRouter policies. Each strategy = a policy the engine
# already implements; we don't invent new scoring — we reuse the engine.
_STRATEGY_TO_POLICY = {
    "auto": "auto",          # Auto Balanced
    "fast": "fastest",       # Auto Fast
    "reliable": "reliable",  # Auto Reliable
    "smartest": "smartest",  # Auto Smartest
    "coding": "coding",      # Auto Coding
    "priority": "priority",  # Auto Priority
}


def strategy_names() -> list[str]:
    """Return the configured strategy labels (auto is always first)."""
    return ["auto", "fast", "reliable", "smartest", "coding", "priority"]


def strategy_label(strategy: str) -> str:
    """Human label for a strategy."""
    return {
        "auto": "Auto Balanced",
        "fast": "Auto Fast",
        "reliable": "Auto Reliable",
        "smartest": "Auto Smartest",
        "coding": "Auto Coding",
        "priority": "Auto Priority",
    }.get(strategy, strategy)


def validate_strategy(strategy: str) -> str:
    """Return a valid strategy name, defaulting to 'auto'."""
    if strategy in _STRATEGY_TO_POLICY:
        return strategy
    return "auto"


def select_eligible_free_model(
    config: dict[str, Any],
    *,
    store: Optional[st.StateStore] = None,
    now: Optional[float] = None,
) -> dict[str, Any]:
    """Select the single best eligible free model for a chat (synchronous).

    Returns a candidate dict from :class:`autorouter.router.Router` or
    ``None`` when no safe free route exists. The selection is fail-closed:
    paid, premium, unknown-cost, and unavailable models are excluded.

    This does NOT mutate the caller's config/state.
    """
    policy = validate_strategy(str(config.get("strategy") or config.get("policy") or "auto"))

    # Build the router exactly as AutoRouter v0.2 does, but force free-only.
    base_state: dict[str, Any] = {
        "policy": policy,
        "free_only": True,
        "paid_authorized": False,  # deprecated + no effect
        "providers": list(config.get("providers") or ["openrouter", "nvidia"]),
        "cooldown_seconds": int(config.get("cooldown_seconds") or 60),
        "store": store,
    }

    # Allow an explicit override catalogue (e.g. the dashboard's read-only model
    # view) to feed selection rather than re-discovering.
    catalog = base_state.get("catalog") if isinstance(base_state.get("catalog"), list) else None
    if catalog:
        base_state["_catalog"] = catalog

    r = rt.Router(base_state)
    try:
        chosen = r.select_free_model(requires_tools=False, min_context=8192)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("autorouter plugin select failed: %s", exc)
        chosen = None

    if chosen is None:
        return {"chosen": None, "reason": "no eligible free model available"}

    # Record a routing decision so the dashboard's recent_decisions tab sees it.
    try:
        if store is not None:
            store.record_decision(
                policy=policy,
                provider=chosen["provider"],
                model=chosen["model"],
                reason="selected via " + policy,
                candidates=1,  # exact count is context-dependent; caller may augment
            )
    except Exception:
        pass

    return {
        "chosen": chosen,
        "policy": policy,
        "strategy": policy,
        "reason": "selected single eligible free model",
        "at": now if now is not None else time.time(),
    }


def resolve_virtual_model(config: dict[str, Any], *, store: Optional[st.StateStore] = None) -> dict[str, Any]:
    """Convenience: resolve the AutoRouter virtual model to a real provider+model.

    Used by the chat-router adapter when the user picks
    ``autorouter/auto-free`` in the native picker.
    """
    out = {"virtual_model": "autorouter/auto-free", "resolved": False, "error": None}
    try:
        result = select_eligible_free_model(config=config, store=store)
        chosen = result.get("chosen")
        if chosen is None:
            out["reason"] = result.get("reason", "no eligible free model")
            return out
        out.update(
            {
                "resolved": True,
                "virtual_model": "autorouter/auto-free",
                "provider": chosen["provider"],
                "model": chosen["model"],
                "strategy": result.get("policy"),
            }
        )
    except Exception as exc:
        out["resolved"] = False
        out["error"] = f"selection raised: {exc!r}"
    return out
