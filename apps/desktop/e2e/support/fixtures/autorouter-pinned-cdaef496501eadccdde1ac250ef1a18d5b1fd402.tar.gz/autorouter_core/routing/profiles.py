"""User-created AutoRouter routing profiles (issue #100).

A profile is a versioned, immutable-semantics record that narrows the shared
selection engine — it is configuration for the existing selector, never a
second selection engine. It may never relax a mandatory hard gate (verified
free-only, authorized providers, provider evidence), and it never carries
credential, account-scope or execution-authority material.

The built-in task templates in ``task_profiles.py`` are unrelated to these
user-created records and remain untouched.
"""

from __future__ import annotations

import json
import re
import secrets
import time
from typing import Any, Optional

SCHEMA_VERSION = 1
PROFILE_ID_PREFIX = "rp_"
_NAME_RE = re.compile(r"^[^\x00-\x1f\x7f]{1,80}$")
_DESCRIPTION_MAX = 500
_TAG_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._+/#-]{0,39}$")
_TAGS_MAX = 12
_MODELS_MAX = 128
_MIN_CONTEXT = 2048
_MAX_CONTEXT = 2_000_000
_FALLBACK_POLICIES = ("refuse",)
RANKING_POLICIES = ("auto", "coding", "fastest", "reliable", "smartest", "priority")
_PROVIDER_RE = re.compile(r"[a-z][a-z0-9-]{0,63}")
_MODEL_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}")
_FORBIDDEN_FRAGMENTS = re.compile(r"(?i)(?:sk-|sk_|bearer|api[_-]?key|token[=:])")

SELECTION_POLICY_LABEL = "explicit"


class ProfileError(ValueError):
    """Stable machine codes; the API layer maps them to HTTP statuses."""

    def __init__(self, code: str, message: str = "", fields: Optional[dict] = None):
        self.code = code
        self.message = message or code
        self.fields = fields or {}
        super().__init__(self.message)


def _clean_str(value: Any, *, field: str, max_len: int, allow_empty: bool = True) -> str:
    if not isinstance(value, str):
        raise ProfileError("profile_invalid", f"{field} must be a string", {field: "must be a string"})
    text = value.strip()
    if not allow_empty and not text:
        raise ProfileError("profile_invalid", f"{field} must not be empty", {field: "must not be empty"})
    if len(text) > max_len:
        raise ProfileError("profile_invalid", f"{field} is too long", {field: f"at most {max_len} characters"})
    return text


def _provider_id(value: Any, field: str) -> str:
    if not isinstance(value, str) or not _PROVIDER_RE.fullmatch(value.strip()):
        raise ProfileError("profile_invalid", f"{field} entries must be provider IDs",
                           {field: "must match ^[a-z][a-z0-9-]{0,63}$"})
    token = value.strip()
    from ..providers.connections import valid_provider_list
    if not valid_provider_list([token]):
        raise ProfileError("profile_invalid", f"{field} contains an unsupported provider: {token}",
                           {field: f"unsupported provider: {token}"})
    return token


def _model_ref(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ProfileError("profile_invalid", f"{field} entries must be strings", {field: "must be a string"})
    text = value.strip()
    provider, sep, model = text.partition("/")
    if not sep or not _PROVIDER_RE.fullmatch(provider.strip()) or not _MODEL_RE.fullmatch(model.strip()):
        raise ProfileError("profile_invalid", f"{field} entries must look like provider/model",
                           {field: "expected format: provider/model"})
    if _FORBIDDEN_FRAGMENTS.search(text):
        raise ProfileError("profile_invalid", f"{field} must not contain credential-like material",
                           {field: "credential-like content is not allowed"})
    provider = provider.strip()
    from ..providers.connections import valid_provider_list
    if not valid_provider_list([provider]):
        raise ProfileError("profile_invalid", f"{field} contains an unsupported provider: {provider}",
                           {field: f"unsupported provider: {provider}"})
    return f"{provider}/{model.strip()}"


def _string_list(value: Any, *, field: str, max_items: int, item_fn):
    if value is None:
        return []
    if not isinstance(value, list):
        raise ProfileError("profile_invalid", f"{field} must be a list", {field: "must be a list"})
    if len(value) > max_items:
        raise ProfileError("profile_invalid", f"{field} must contain at most {max_items} entries",
                           {field: f"at most {max_items} entries"})
    out: list[str] = []
    seen = set()
    for item in value:
        cleaned = item_fn(item, field)
        if cleaned not in seen:
            seen.add(cleaned)
            out.append(cleaned)
    return out


def _health(value: Any) -> dict[str, bool]:
    if value is None:
        return {"respect_failures": True, "respect_cooldowns": True, "require_observed": False}
    if not isinstance(value, dict):
        raise ProfileError("profile_invalid", "health must be an object", {"health": "must be an object"})
    unknown = set(value) - {"respect_failures", "respect_cooldowns", "require_observed"}
    if unknown:
        raise ProfileError("profile_invalid", f"health contains unknown keys: {sorted(unknown)}",
                           {"health": f"unknown keys: {sorted(unknown)}"})
    respect_failures = value.get("respect_failures", True)
    respect_cooldowns = value.get("respect_cooldowns", True)
    require_observed = value.get("require_observed", False)
    if respect_failures is not True:
        raise ProfileError("profile_invalid", "health.respect_failures must be true",
                           {"health.respect_failures": "may not be disabled"})
    if respect_cooldowns is not True:
        raise ProfileError("profile_invalid", "health.respect_cooldowns must be true",
                           {"health.respect_cooldowns": "may not be disabled"})
    if not isinstance(require_observed, bool):
        raise ProfileError("profile_invalid", "health.require_observed must be a boolean",
                           {"health.require_observed": "must be a boolean"})
    return {"respect_failures": True, "respect_cooldowns": True, "require_observed": require_observed}


def _task_tags(value: Any) -> list[str]:
    tags = _string_list(value, field="task_tags", max_items=_TAGS_MAX,
                        item_fn=lambda v, f: _clean_str(v, field=f, max_len=40, allow_empty=False))
    for tag in tags:
        if not _TAG_RE.fullmatch(tag):
            raise ProfileError("profile_invalid", "task_tags entries contain unsupported characters",
                               {"task_tags": tag})
    return tags


def validate_profile(data: Any, *, existing: Optional[dict] = None) -> dict[str, Any]:
    """Validate + normalize a profile payload. Raises ProfileError on any defect."""
    if not isinstance(data, dict):
        raise ProfileError("profile_invalid", "profile must be an object")
    allowed = {"id", "name", "description", "ranking_policy", "providers", "model_include",
               "model_exclude", "min_context", "requires_tools", "health", "task_tags",
               "fallback_policy", "verified_free_only"}
    unknown = set(data) - allowed
    if unknown:
        raise ProfileError("profile_invalid", f"unknown profile keys: {sorted(unknown)}",
                           {"unknown": sorted(unknown)})
    base = dict(existing) if existing else {}
    out: dict[str, Any] = {}
    name = _clean_str(data.get("name", base.get("name")), field="name", max_len=80, allow_empty=False)
    if not _NAME_RE.fullmatch(name):
        raise ProfileError("profile_invalid", "name contains control characters", {"name": "no control characters"})
    out["name"] = name
    description = data.get("description", base.get("description", ""))
    out["description"] = _clean_str(description, field="description", max_len=_DESCRIPTION_MAX) if description is not None else ""

    ranking_policy = data.get("ranking_policy", base.get("ranking_policy", "auto"))
    if not isinstance(ranking_policy, str) or ranking_policy not in RANKING_POLICIES:
        raise ProfileError("profile_invalid", f"ranking_policy must be one of: {', '.join(RANKING_POLICIES)}",
                           {"ranking_policy": f"must be one of: {', '.join(RANKING_POLICIES)}"})
    out["ranking_policy"] = ranking_policy

    providers = data.get("providers", base.get("providers", []))
    out["providers"] = _string_list(providers, field="providers", max_items=16, item_fn=_provider_id)

    include = data.get("model_include", base.get("model_include", []))
    exclude = data.get("model_exclude", base.get("model_exclude", []))
    out["model_include"] = _string_list(include, field="model_include", max_items=_MODELS_MAX, item_fn=_model_ref)
    out["model_exclude"] = _string_list(exclude, field="model_exclude", max_items=_MODELS_MAX, item_fn=_model_ref)

    min_context = data.get("min_context", base.get("min_context", 8192))
    if isinstance(min_context, bool) or not isinstance(min_context, int):
        raise ProfileError("profile_invalid", "min_context must be an integer", {"min_context": "must be an integer"})
    if not (_MIN_CONTEXT <= min_context <= _MAX_CONTEXT):
        raise ProfileError("profile_invalid", f"min_context must be between {_MIN_CONTEXT} and {_MAX_CONTEXT}",
                           {"min_context": f"between {_MIN_CONTEXT} and {_MAX_CONTEXT}"})
    out["min_context"] = min_context

    requires_tools = data.get("requires_tools", base.get("requires_tools", False))
    if not isinstance(requires_tools, bool):
        raise ProfileError("profile_invalid", "requires_tools must be a boolean",
                           {"requires_tools": "must be a boolean"})
    out["requires_tools"] = requires_tools

    out["health"] = _health(data.get("health", base.get("health")))
    out["task_tags"] = _task_tags(data.get("task_tags", base.get("task_tags", [])))

    fallback = data.get("fallback_policy", base.get("fallback_policy", "refuse"))
    if fallback != "refuse":
        raise ProfileError("profile_invalid", "fallback_policy must be 'refuse' (no automatic fallback exists)",
                           {"fallback_policy": "only 'refuse' is supported"})
    out["fallback_policy"] = "refuse"

    verified = data.get("verified_free_only", base.get("verified_free_only", True))
    if verified is not True:
        raise ProfileError("profile_invalid", "verified_free_only may not be disabled",
                           {"verified_free_only": "verified-free eligibility is mandatory"})
    out["verified_free_only"] = True
    return out


def default_profile() -> dict[str, Any]:
    return {
        "name": "", "description": "", "ranking_policy": "auto", "providers": [],
        "model_include": [], "model_exclude": [], "min_context": 8192, "requires_tools": False,
        "health": {"respect_failures": True, "respect_cooldowns": True, "require_observed": False},
        "task_tags": [], "fallback_policy": "refuse", "verified_free_only": True,
    }


def new_profile_id() -> str:
    return PROFILE_ID_PREFIX + secrets.token_hex(6)


def selection_policy(profile: dict[str, Any], authorized_providers: list[str]) -> dict[str, Any]:
    """Translate a stored profile into the canonical v1 selection_policy contract.

    Mandatory hard gates from the host policy (verified free-only, provider
    authorization) are always present; the profile can only narrow them.
    """
    providers = [p for p in profile.get("providers") or [] if p in authorized_providers]

    def _pairs(refs):
        out = []
        for ref in refs:
            provider, _, model = str(ref).partition("/")
            if provider and model:
                out.append({"provider": provider, "model": model})
        return out

    exclude_pairs = _pairs(profile.get("model_exclude") or [])
    return {
        "schema_version": 1,
        "hard_eligibility": {
            "verified_free_only": True,
            "required_capabilities": {"tools": "required"} if profile.get("requires_tools") else {},
            "min_context": int(profile.get("min_context") or 8192),
            "authorized_providers": providers,
            "exclude": exclude_pairs,
            "max_in_flight": None,
            "health": {
                "respect_failures": True,
                "respect_cooldowns": True,
                "require_observed": bool((profile.get("health") or {}).get("require_observed")),
            },
        },
        "preferences": {"policy": profile.get("ranking_policy") or "auto"},
        "task_requirements": {
            "schema_version": 1,
            "label": SELECTION_POLICY_LABEL,
            "required_capabilities": {"tools": "required"} if profile.get("requires_tools") else {},
            "min_context": int(profile.get("min_context") or 8192),
        },
        "connection_restrictions": {
            "provider_id": None, "connection_id": None, "require_authority": False,
            "models": [], "shared_quota_scope": None,
        },
        "quota_policy": "avoid_verified_exhaustion",
    }


def _pick(refs_dict, key):
    """Read a list from either 'model_x' or 'model_x_pairs' keys (both are in use)."""
    return refs_dict.get(key) or refs_dict.get(key + "_pairs") or []


def _as_pairs(refs):
    """Normalize refs to (provider, model) tuples.

    Accepts both 'provider/model' strings (profile storage) and pre-split
    (provider, model) pairs (internal settings form).
    """
    out: list[tuple[str, str]] = []
    for ref in refs or []:
        if isinstance(ref, (list, tuple)) and len(ref) == 2:
            provider, model = str(ref[0]).strip(), str(ref[1]).strip()
        else:
            provider, sep, model = str(ref).partition("/")
            provider, model = provider.strip(), model.strip()
        if provider and model:
            out.append((provider, model))
    return out


def model_include_pairs(profile: dict[str, Any]) -> list[tuple[str, str]]:
    return _as_pairs(_pick(profile, "model_include"))


def model_exclude_pairs(profile: dict[str, Any]) -> list[tuple[str, str]]:
    return _as_pairs(_pick(profile, "model_exclude"))


def public_profile(row: dict[str, Any]) -> dict[str, Any]:
    out = {
        "id": row["id"],
        "schema_version": row.get("schema_version", SCHEMA_VERSION),
        "name": row["name"],
        "description": row.get("description", ""),
        "ranking_policy": row["ranking_policy"],
        "providers": list(row.get("providers") or []),
        "model_include": list(row.get("model_include") or []),
        "model_exclude": list(row.get("model_exclude") or []),
        "min_context": int(row["min_context"]),
        "requires_tools": bool(row["requires_tools"]),
        "health": dict(row.get("health") or {}),
        "task_tags": list(row.get("task_tags") or []),
        "fallback_policy": row.get("fallback_policy", "refuse"),
        "verified_free_only": True,
        "created_at": row.get("created_at"),
        "updated_at": row.get("updated_at"),
    }
    return out


def encode_row(profile: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": profile["name"],
        "description": profile.get("description", ""),
        "ranking_policy": profile["ranking_policy"],
        "providers": json.dumps(profile.get("providers") or [], separators=(",", ":")),
        "model_include": json.dumps(profile.get("model_include") or [], separators=(",", ":")),
        "model_exclude": json.dumps(profile.get("model_exclude") or [], separators=(",", ":")),
        "min_context": int(profile["min_context"]),
        "requires_tools": 1 if profile.get("requires_tools") else 0,
        "health": json.dumps(profile.get("health") or {}, separators=(",", ":"), sort_keys=True),
        "task_tags": json.dumps(profile.get("task_tags") or [], separators=(",", ":")),
        "fallback_policy": profile.get("fallback_policy", "refuse"),
    }


def decode_row(row: Any) -> dict[str, Any]:
    def _load(value, default):
        try:
            loaded = json.loads(value) if isinstance(value, str) else value
        except (ValueError, TypeError):
            return default
        return loaded if isinstance(loaded, list) else default

    def _load_obj(value, default):
        try:
            loaded = json.loads(value) if isinstance(value, str) else value
        except (ValueError, TypeError):
            return default
        return loaded if isinstance(loaded, dict) else default

    return {
        "id": row["id"],
        "schema_version": row["schema_version"],
        "name": row["name"],
        "description": row["description"],
        "ranking_policy": row["ranking_policy"],
        "providers": _load(row["providers"], []),
        "model_include": _load(row["model_include"], []),
        "model_exclude": _load(row["model_exclude"], []),
        "min_context": int(row["min_context"]),
        "requires_tools": bool(row["requires_tools"]),
        "health": _load_obj(row["health"], {"respect_failures": True, "respect_cooldowns": True, "require_observed": False}),
        "task_tags": _load(row["task_tags"], []),
        "fallback_policy": row["fallback_policy"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def canonical_pairs(pairs) -> list[tuple[str, str]]:
    return _as_pairs(list(pairs or []))


def validate_stored_profile(row: Any) -> dict[str, Any]:
    """Strict validation for a profile read back from disk.

    The write path already validates, but rows can be corrupted by manual
    store surgery or a bad downgrade. Any defect here makes the profile
    unusable — callers must fail closed rather than route through it.
    """
    if not isinstance(row, dict):
        raise ProfileError("stored_profile_invalid", "stored profile is not an object")
    candidate = dict(row)
    for required in ("id", "name", "ranking_policy", "providers", "model_include",
                     "model_exclude", "min_context", "requires_tools", "health",
                     "task_tags", "fallback_policy", "created_at", "updated_at"):
        if required not in candidate:
            raise ProfileError("stored_profile_invalid", f"missing field {required}")
    if not isinstance(candidate["id"], str) or not candidate["id"].startswith("rp_"):
        raise ProfileError("stored_profile_invalid", "id does not carry the profile prefix")
    out = validate_profile({
        "name": candidate["name"],
        "description": candidate.get("description", ""),
        "ranking_policy": candidate["ranking_policy"],
        "providers": candidate["providers"],
        "model_include": candidate["model_include"],
        "model_exclude": candidate["model_exclude"],
        "min_context": candidate["min_context"],
        "requires_tools": candidate["requires_tools"],
        "health": candidate["health"],
        "task_tags": candidate["task_tags"],
        "fallback_policy": candidate["fallback_policy"],
    })
    out["id"] = candidate["id"]
    out["created_at"] = candidate["created_at"]
    out["updated_at"] = candidate["updated_at"]
    out["verified_free_only"] = True
    return out


def merge_global_and_profile(global_settings: dict[str, Any], profile: dict[str, Any],
                             *, authorized_providers: list[str]) -> tuple[dict[str, Any], Optional[str]]:
    """Merge global routing settings with an active profile.

    The profile can only NARROW. Hard gates compose as the strictest of the
    two sides; nothing the operator configured globally can be relaxed by a
    profile, and nothing mandatory (verified-free, authorized providers) can
    be relaxed at all:

    * ``providers`` — intersection of the profile's list with the authorized
      providers configured for the plugin; empty ⇒ error (fail closed).
    * ``requires_tools`` — logical OR of the two sides.
    * ``min_context`` — max() of the two sides.
    * ``model_exclude`` — union of both sides.
    * ``model_include`` — intersection when both sides set one; otherwise the
      side that is set; empty means unrestricted on either side. An empty
      intersection (or a global ``none`` preference mode) yields the explicit
      ``none`` mode — zero selectable models — never a widened selection.
    * ``model_mode`` — ``none``/``allowlist``/``unrestricted``; profiles can
      only keep or narrow the global mode, never widen it.
    * ``cooldown_seconds`` — the global value; profiles cannot lower it.
    * ``policy`` — the profile's ranking preference (an ordering choice among
      already-hard-gated candidates; relaxes no gate).
    """
    if not isinstance(profile, dict):
        return {}, "active profile is not an object"
    try:
        ranking = profile.get("ranking_policy") or "auto"
        if ranking not in RANKING_POLICIES:
            return {}, "active profile carries an unsupported ranking_policy"
        g_inc = set(model_include_pairs(global_settings) or [])
        p_inc = set(model_include_pairs(profile) or [])
        g_mode = global_settings.get("model_mode")
        if g_mode not in ("none", "allowlist", "unrestricted"):
            # Legacy fallback: an include list implies allowlist mode. A
            # global mode of "allowlist" with an empty include is corrupt and
            # fails closed to none.
            if g_mode == "allowlist":
                g_mode = "allowlist" if g_inc else "none"
            else:
                g_mode = "allowlist" if g_inc else "unrestricted"
        if g_mode == "none":
            # Global none is absolute: a profile can never re-enable models.
            include = []
            merged_mode = "none"
        elif g_inc and p_inc:
            include = sorted(g_inc & p_inc)
            merged_mode = "allowlist" if include else "none"
        elif p_inc or g_inc:
            include = sorted(p_inc or g_inc)
            merged_mode = "allowlist"
        else:
            include = []
            merged_mode = "unrestricted"
        if merged_mode == "allowlist" and not include:
            merged_mode = "none"
        excluded = set(model_exclude_pairs(global_settings) or []) | set(model_exclude_pairs(profile) or [])
        merged = {
            "policy": ranking,
            "min_context": max(int(global_settings.get("min_context") or 8192),
                               int(profile.get("min_context") or 8192)),
            "requires_tools": bool(global_settings.get("requires_tools")) or bool(profile.get("requires_tools")),
            "cooldown_seconds": int(global_settings.get("cooldown_seconds") or 60),
            "model_exclude_pairs": sorted(excluded),
            "model_include_pairs": include,
            "model_mode": merged_mode,
            "providers": [p for p in (profile.get("providers") or []) if p in set(authorized_providers)],
            "profile_id": profile.get("id"),
            "profile_name": profile.get("name"),
        }
        if not merged["providers"]:
            return {}, "active profile authorizes no provider that is enabled for AutoRouter"
        merged["model_exclude_pairs"] = [tuple(p) for p in merged["model_exclude_pairs"]]
        merged["model_include_pairs"] = [tuple(p) for p in merged["model_include_pairs"]]
        return merged, None
    except Exception:
        return {}, "active profile could not be applied"


def public_active(profile: Optional[dict[str, Any]]) -> Optional[dict[str, Any]]:
    if not profile:
        return None
    return {
        "id": profile.get("id"),
        "name": profile.get("name"),
        "ranking_policy": profile.get("ranking_policy"),
        "providers": list(profile.get("providers") or [])[:16],
        "min_context": profile.get("min_context"),
        "requires_tools": bool(profile.get("requires_tools")),
        "scope": "global_default",
        "scope_note": ("Default routing profile for sessions created after activation. "
                       "Sessions already running keep their resolved model; /resume re-resolves "
                       "with the current default. Never changes the global Hermes default model."),
    }
