"""AutoRouter eligibility package."""
