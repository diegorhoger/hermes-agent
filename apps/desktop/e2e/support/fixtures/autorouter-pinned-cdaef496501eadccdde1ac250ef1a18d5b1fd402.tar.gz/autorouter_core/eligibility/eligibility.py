"""Eligibility filtering for AutoRouter candidates."""

from __future__ import annotations

from typing import Any

# Tool support requires explicit model-specific evidence.

def is_tool_capable(provider: str, model: str, capabilities: Any = None) -> bool:
    caps = capabilities or {}
    tools = caps.get("tools") if isinstance(caps, dict) else None
    if tools is True or tools == "supported":
        return True
    if tools is False or tools == "unsupported":
        return False
    return False


def has_sufficient_context(context_length: Any, minimum: int = 8192) -> bool:
    if context_length is None:
        return False  # unknown -> not sufficient (conservative)
    try:
        return int(context_length) >= minimum
    except Exception:
        return False


def cost_allowed(cost_tier: Any, free_only: bool = True, paid_authorized: bool = False,
                 strict: bool = True) -> bool:
    """Fail-closed cost eligibility boundary for v0.1.0.

    Rules apply for ALL combinations of free_only and paid_authorized:
    - Verified free model: eligible (subject to other requirements)
    - Paid model: denied — paid inference remains disabled until a real backend
      can enforce scoped approvals, budget reservations, expiration, and revocation
    - Unknown-cost model: denied — missing cost metadata means we cannot verify safety
    - Missing cost metadata: denied

    The paid_authorized flag is deprecated and has no effect on eligibility.
    It exists only for manifest compatibility and will be removed in a future
    release when a backend-backed authorization boundary is implemented.
    """
    tier = (cost_tier or "unknown").lower()

    # Fail-closed: free is the only allowed cost tier
    if tier in ("free",):
        return True

    # Paid, premium, unknown, or missing cost metadata: all denied
    return False


def rejection_reasons(candidate: dict[str, Any], *, requires_tools: bool, min_context: int,
                      free_only: bool = True, paid_authorized: bool = False) -> list[str]:
    reasons = []
    if candidate.get("retired") or candidate.get("available") is False:
        reasons.append("unavailable")
    if requires_tools and not is_tool_capable(candidate["provider"], candidate["model"], candidate.get("capabilities")):
        reasons.append("tools_unverified_or_unsupported")
    if not has_sufficient_context(candidate.get("context_length"), min_context):
        reasons.append("context_unknown_or_insufficient")
    if not cost_allowed(candidate.get("cost_tier"), free_only, paid_authorized):
        reasons.append("cost_not_verified_free")
    return reasons


def is_eligible(candidate: dict[str, Any], *, requires_tools: bool, min_context: int,
                free_only: bool, paid_authorized: bool, store=None) -> bool:
    if store is not None:
        try:
            if not store.is_available(candidate["provider"], candidate["model"]):
                return False
        except Exception:
            pass
    return not rejection_reasons(candidate, requires_tools=requires_tools, min_context=min_context,
                                 free_only=free_only, paid_authorized=paid_authorized)
