"""AutoRouter core runtime, organized by feature responsibility."""
