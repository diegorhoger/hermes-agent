"""AutoRouter discovery package."""
