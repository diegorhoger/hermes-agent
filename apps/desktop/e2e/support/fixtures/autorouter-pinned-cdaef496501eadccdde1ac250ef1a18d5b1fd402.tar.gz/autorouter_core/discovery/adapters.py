"""Bounded read-only catalogs for three explicitly configured provider IDs.

These catalogs do not publish model pricing. They never grant free eligibility.
No catalog row or custom profile URL determines a network destination.
"""
from __future__ import annotations

import json
import time
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from .provider_registry import validate_text

TTL = 86400
MAX_BYTES = 2 * 1024 * 1024
MAX_MODELS = 1000
SPECS = {
    'groq': ('https://api.groq.com/openai/v1/models', ('GROQ_API_KEY',), 'bearer'),
    'gemini': ('https://generativelanguage.googleapis.com/v1beta/models', ('GEMINI_API_KEY', 'GOOGLE_API_KEY'), 'google'),
    'mistral': ('https://api.mistral.ai/v1/models', ('MISTRAL_API_KEY',), 'bearer'),
}


class DiscoveryError(Exception):
    """Only a fixed classification crosses the transport boundary."""
    pass


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Never forward a credential to a redirected destination.


def _read_json(url, headers):
    try:
        request = Request(url, headers=headers, method='GET')
        with build_opener(_NoRedirect()).open(request, timeout=10) as response:
            raw = response.read(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES:
            raise DiscoveryError('catalog_too_large')
        return json.loads(raw)
    except HTTPError as exc:
        category = ('authentication' if exc.code in (401, 403) else 'rate_limited' if exc.code == 429
                    else 'provider_unavailable' if exc.code >= 500 else 'http_error')
        raise DiscoveryError(category) from None
    except (URLError, TimeoutError, OSError):
        raise DiscoveryError('transport_error') from None
    except (ValueError, TypeError):
        raise DiscoveryError('malformed_catalog') from None


def _model_id(value):
    try:
        validate_text(value)
    except ValueError:
        return False
    return (isinstance(value, str) and 0 < len(value) <= 240
            and all(c.isalnum() or c in '-_./:' for c in value))


def _sanitize_model_ids(models, max_models=MAX_MODELS):
    """Skip alias/invalid catalog rows instead of failing the whole catalog.

    Nous and OpenRouter live catalogs carry '~alias' pointers that are not
    themselves selectable models; rejecting the entire catalog over them
    would deny the user a usable inventory. Returns (accepted, rejected_ids).
    Raises DiscoveryError('malformed_catalog') when nothing valid remains.
    """
    if not isinstance(models, (list, tuple)) or len(models) > max_models:
        raise DiscoveryError('malformed_catalog')
    accepted, rejected, seen = [], [], set()
    for mid in models:
        if not _model_id(mid):
            rejected.append(mid)
            continue
        if mid in seen:
            raise DiscoveryError('malformed_catalog')
        seen.add(mid)
        accepted.append(mid)
    if not accepted and rejected:
        raise DiscoveryError('malformed_catalog')
    return accepted, rejected


def normalize(provider, payload, now):
    """Normalize only documented fields; omitted prices remain unknown."""
    key = 'models' if provider == 'gemini' else 'data'
    if not isinstance(payload, dict) or not isinstance(payload.get(key), list):
        raise DiscoveryError('malformed_catalog')
    result = {}
    for row in payload[key]:
        if not isinstance(row, dict):
            raise DiscoveryError('malformed_catalog')
        mid = row.get('name' if provider == 'gemini' else 'id')
        if provider == 'gemini':
            if not isinstance(mid, str) or not mid.startswith('models/'):
                raise DiscoveryError('malformed_catalog')
            mid = mid[len('models/'):]
        if not _model_id(mid) or mid in result:
            raise DiscoveryError('malformed_catalog')
        ctx = row.get('inputTokenLimit' if provider == 'gemini' else 'max_context_length' if provider == 'mistral' else 'no_documented_context_field')
        ctx = ctx if type(ctx) is int and ctx > 0 else None
        tools = 'unknown'
        if provider == 'mistral':
            caps = row.get('capabilities')
            tool_flag = caps.get('function_calling') if isinstance(caps, dict) else None
            if type(tool_flag) is bool:
                tools = 'supported' if tool_flag else 'unsupported'
        # GenerateContent and model identifiers do not establish tool support.
        available = row.get('archived') is not True if provider == 'mistral' else row.get('active') is not False
        source = SPECS[provider][0]
        result[mid] = dict(provider=provider, model=mid, context_window=ctx,
                           tools=tools if available else 'unsupported', cost_tier='unknown',
                           available=available, discovery_status='discovered' if available else 'removed', metadata_source=source,
                           discovery_evidence=dict(metadata_source=source, retrieved_at=now, expires_at=now+TTL), retrieved_at=now, expires_at=now + TTL,
                           pricing_status='omitted', supplied_fields=['context_window', 'tools'] + (['cost_tier'] if not available else []),
                           provenance={field: source for field in ('context_window', 'tools', 'cost_tier')})
    if len(result) > MAX_MODELS:
        raise DiscoveryError('catalog_too_large')
    return result


def fetch_catalog(provider, api_key, now=None):
    """Fetch metadata only, with fixed origins and bounded native pagination."""
    if provider not in SPECS:
        raise DiscoveryError('unsupported_provider')
    if not isinstance(api_key, str) or not api_key.strip():
        raise DiscoveryError('credential_missing')
    endpoint, _, mode = SPECS[provider]
    headers = {'Accept': 'application/json'}
    headers['x-goog-api-key' if mode == 'google' else 'Authorization'] = api_key if mode == 'google' else 'Bearer ' + api_key
    now = time.time() if now is None else now
    result, seen, token = {}, set(), None
    for _ in range(10):
        url = endpoint
        if provider == 'gemini':
            params = {'pageSize': 1000}
            if token is not None:
                params['pageToken'] = token
            url += '?' + urlencode(params)
        payload = _read_json(url, headers)
        page = normalize(provider, payload, now)
        if result.keys() & page.keys():
            raise DiscoveryError('malformed_catalog')
        result.update(page)
        if len(result) > MAX_MODELS:
            raise DiscoveryError('catalog_too_large')
        token = payload.get('nextPageToken') if provider == 'gemini' else None
        if token is None or token == '':
            return result
        if not isinstance(token, str) or len(token) > 2048 or token in seen:
            raise DiscoveryError('malformed_pagination')
        seen.add(token)
    raise DiscoveryError('pagination_limit')
