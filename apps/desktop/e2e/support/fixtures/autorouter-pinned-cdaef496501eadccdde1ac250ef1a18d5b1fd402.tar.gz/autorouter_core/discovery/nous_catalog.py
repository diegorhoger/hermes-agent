"""Read-only Nous Portal catalog discovery.

The Nous Portal inference API exposes ``GET {base_url}/models`` — a bounded,
read-only list of model identifiers with published context windows and
pricing. This module is the only place a Nous credential is consulted, and
only for that read-only call.

Guarantees kept by this module:

* never executes inference — no /chat/completions, no token spend
* never refreshes, writes or quarantines Hermes OAuth state; the token is
  read from the Hermes auth store (read-only) and used as a bearer for one
  fixed models endpoint
* never redirects — a credential is never forwarded to a redirected origin
* never publishes a zero-charge guarantee: per-token published prices are
  recorded as price evidence only (a model with all-zero published prices is
  labelled ``free`` price metadata, never "no charge guaranteed"). Paid,
  premium and unknown-cost models remain ineligible in V1 exactly as with
  every other provider.
* absent or expired credentials yield no catalog rows — never invented models
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone

from urllib.parse import urlsplit

from .adapters import DiscoveryError, MAX_MODELS, _read_json, _model_id

logger = logging.getLogger(__name__)

NOUS_MODELS_URL = 'https://inference-api.nousresearch.com/v1/models'
NOUS_BASE_URL = 'https://inference-api.nousresearch.com/v1'
TTL = 86400


def _expiry_ok(value) -> bool:
    if not isinstance(value, str) or not value.strip():
        return False
    try:
        parsed = datetime.fromisoformat(value.strip())
    except ValueError:
        return False
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.timestamp() > time.time()


def _canonical_base_url(value):
    """Validate an auth-store ``inference_base_url`` against the fixed origin.

    The Nous credential destination is contractually fixed. An absent value
    yields the canonical base URL; anything present must describe exactly
    ``https://inference-api.nousresearch.com/v1`` — no other scheme, origin,
    port, userinfo, path, query or fragment is accepted. Anything else fails
    closed with ``DiscoveryError('unexpected_base_url')`` and no HTTP request
    is made.
    """
    if value is None or value == '':
        return NOUS_BASE_URL
    if not isinstance(value, str):
        raise DiscoveryError('unexpected_base_url')
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError:
        raise DiscoveryError('unexpected_base_url') from None
    if (parsed.scheme != 'https'
            or parsed.hostname != 'inference-api.nousresearch.com'
            or parsed.username is not None
            or parsed.password is not None
            or port is not None
            or parsed.query
            or parsed.fragment
            or parsed.path.rstrip('/') != '/v1'):
        raise DiscoveryError('unexpected_base_url')
    return NOUS_BASE_URL


def _nous_credential():
    """Read the Hermes-managed Nous OAuth state. Never refreshes or writes it.

    Returns ``(api_key, base_url)`` where ``base_url`` is always the fixed
    canonical Nous base URL. A non-canonical auth-store URL raises
    ``DiscoveryError('unexpected_base_url')`` before any HTTP request is
    made; the bearer is never dispatched anywhere else. Absent Nous sign-in
    state raises ``DiscoveryError('credential_missing')``.
    """
    try:
        from hermes_cli.auth import read_credential_pool
        entries = read_credential_pool('nous')
    except Exception:
        raise DiscoveryError('credential_unavailable') from None
    if not isinstance(entries, list):
        raise DiscoveryError('credential_unavailable')
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        key = entry.get('agent_key') or entry.get('access_token')
        if (not isinstance(key, str) or not 1 <= len(key) <= 8192
                or any(c.isspace() or not c.isprintable() for c in key)):
            # A bearer is opaque; it is only ever sent to the fixed models
            # endpoint, and a malformed state can never be dispatched.
            continue
        expires = entry.get('agent_key_expires_at') or entry.get('expires_at')
        if not _expiry_ok(expires):
            continue
        base_url = _canonical_base_url(entry.get('inference_base_url'))
        return key, base_url
    raise DiscoveryError('credential_missing')



def normalize(payload, now):
    """Normalize only documented fields; omitted or malformed prices stay unknown."""
    if not isinstance(payload, dict) or not isinstance(payload.get('data'), list):
        raise DiscoveryError('malformed_catalog')
    from .metadata import price_tier
    rows = payload['data']
    if len(rows) > MAX_MODELS:
        raise DiscoveryError('catalog_too_large')
    result = {}
    skipped_aliases = 0
    for row in rows:
        if not isinstance(row, dict):
            raise DiscoveryError('malformed_catalog')
        mid = row.get('id')
        if not _model_id(mid):
            # Nous aliases float onto canonical ids with a '~' prefix; they are
            # not catalog members themselves.
            skipped_aliases += 1
            continue
        if mid in result:
            raise DiscoveryError('malformed_catalog')
        ctx = row.get('context_length')
        ctx = ctx if type(ctx) is int and ctx > 0 else None
        params = row.get('supported_parameters')
        tools = ('supported' if 'tools' in params else 'unsupported') if isinstance(params, list) else 'unknown'
        pricing = row.get('pricing')
        cost = price_tier(pricing) if isinstance(pricing, dict) else 'unknown'
        result[mid] = dict(provider='nous', model=mid, context_window=ctx,
                           tools=tools, cost_tier=cost, discovery_status='discovered',
                           metadata_source=NOUS_MODELS_URL,
                           discovery_evidence=dict(metadata_source=NOUS_MODELS_URL,
                                                   retrieved_at=now, expires_at=now + TTL),
                           retrieved_at=now, expires_at=now + TTL,
                           pricing_status=('omitted' if not isinstance(pricing, dict)
                                           else 'invalid_or_unknown' if cost == 'unknown' else cost),
                           supplied_fields=[k for k, raw in [('context_window', 'context_length'),
                                                             ('tools', 'supported_parameters'),
                                                             ('cost_tier', 'pricing')] if raw in row],
                           provenance={field: NOUS_MODELS_URL for field in ('context_window', 'tools', 'cost_tier')})
        if isinstance(pricing, dict):
            result[mid]['access_evidence'] = [dict(
                provider='nous', model=mid, scope='model', account_scope=None,
                classification={'free': 'VERIFIED_ZERO_PRICE_MODEL', 'paid': 'PAID_ONLY'}.get(cost, 'UNKNOWN'),
                source_url=NOUS_MODELS_URL, source_type='provider_api', issuer='nous',
                source_of_truth=True, observed_at=now, expires_at=now + TTL,
                currency='USD', prices=pricing, auth_required=True, regions=None,
                payment_required=None, kyc_required=None, logging_policy=None,
                training_policy=None, reset_window=None, cap_scope=None)]
    if not result and payload['data']:
        raise DiscoveryError('malformed_catalog')
    return result


def fetch_catalog(now=None):
    """Fetch the Nous model list. Read-only; never executes inference."""
    key, _base_url = _nous_credential()
    now = time.time() if now is None else now
    # Fixed origin only: the credential is never dispatched to any other URL.
    payload = _read_json(NOUS_MODELS_URL, {'Accept': 'application/json', 'Authorization': 'Bearer ' + key})
    return normalize(payload, now)
