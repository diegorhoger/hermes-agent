"""Offline, source-derived candidates. Nothing here authorizes discovery or selection."""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import ipaddress
import json
from pathlib import Path
import re
from urllib.parse import unquote, urlsplit, urlunsplit

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'data/provider_registry/source-2026-11.csv'
OUTPUT = ROOT / 'data/provider_registry/registry-v1.json'
SOURCE_COMMIT = 'e683ebd293e4eed1c95c52036aaefd9281488054'
SOURCE_SHA256 = '15f4b936e6a3368273451855ef8ff90c83d6f99c00bf1ada9ee4ca5408a160c2'
CAPTURED = '2026-11'  # Source precision is month, not an invented retrieval timestamp.
COLUMNS = ('index', 'name', 'provider_id', 'classification', 'source_free_token_estimate',
           'notes', 'urls', 'status', 'verification', 'autorouter_default_eligible')
SECRET = re.compile(r'(?i)(?:\b(?:sk-|gh[pousr]_|xox[baprs]-)[a-z0-9_-]{12,}|\bbearer\s+(?!authentication\b)[a-z0-9_.=-]{12,}|(?:api[_-]?key|(?:access[_-]?)?token|secret|password)\s*[=:]\s*[^\s,;]{4,})')

# Structural annotations only, attributed to the pinned source descriptions.
PLANS = {'bailian-coding-plan':'alibaba', 'glm':'bigmodel', 'glmt':'bigmodel',
         'minimax':'minimax-cn', 'opencode-go':'opencode-zen',
         'qwen-cloud-token-plan':'qwen-cloud', 'volcengine-agent-plan':'volcengine',
         'volcengine-coding-plan':'volcengine', 'xiaomi-mimo-token-plan':'xiaomi-mimo'}
REGIONS = {'agnes-cn':'agnes', 'glm-cn':'glm', 'minimax-cn':'minimax'}
SPECIALIZED = {
    'runwayml': ('video', 'async_video'), 'deepai': ('image', 'endpoint_rest'),
    'jina-ai': ('embedding/rerank/search', 'specialized_rest'),
    'jina-reader': ('document', 'url_to_markdown'), 'mixedbread': ('embedding', None),
    'voyage-ai': ('embedding/rerank', None), 'magnific': ('image', None),
    'segmind': ('image/video', None), 'typesafe': ('structured_questions', 'typed_questions'),
    'tinyfish': ('web_fetch', None),
}


def validate_text(value):
    if not isinstance(value, str) or len(value) > 16000 or any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError('invalid source text')
    decoded = unquote(unquote(unquote(value)))
    if SECRET.search(decoded) or re.search(r'https?://[^/\s]*@', decoded, re.I):
        raise ValueError('credential-like source text rejected')
    return value


def safe_url(value):
    """Evidence links only; no URL is executed or promoted to an API endpoint."""
    value = validate_text(value).strip().rstrip('.,)')
    try:
        parts = urlsplit(value)
        host = parts.hostname
        if parts.scheme not in ('https', 'http') or not host or parts.username or parts.password:
            return None
        if parts.query or parts.fragment or parts.port not in (None, 80, 443):
            return None  # Never retain query-carried credentials or arbitrary ports.
        if ('.' not in host or len(host) > 253 or host.endswith(('.local', '.localhost'))
                or any(not re.fullmatch(r'[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?', label) for label in host.split('.'))):
            return None
        try:
            ipaddress.ip_address(host)
            return None  # Registry links must be DNS names, never literal network targets.
        except ValueError:
            pass
        if any(c.isspace() for c in value) or '\\' in value:
            return None
        return urlunsplit((parts.scheme, parts.netloc.lower(), parts.path, '', ''))
    except ValueError:
        return None


def annotations(row):
    source_id, note = row['provider_id'], row['notes'].lower()
    kind, related, modalities, protocol = 'provider', None, [], None
    if source_id in PLANS:
        kind, related = 'plan', PLANS[source_id]
    if source_id in REGIONS:
        kind, related = 'region', REGIONS[source_id]
    if source_id.startswith('g4f-'):
        kind, related = 'gateway', source_id.removeprefix('g4f-')
        if source_id == 'g4f-ollama': related = None  # No matching native source ID; do not invent an alias.
    elif 'gateway' in note or 'proxy' in note or 'third-party upstream' in note:
        kind = 'gateway'
    if 'openai-compatible' in note:
        protocol = 'openai_compatible_claim'
    if source_id in ('oneminai', 'nlpcloud'):
        protocol, modalities = 'proprietary_chat', ['chat']
    if source_id in SPECIALIZED:
        kind = 'specialized'
        modality, protocol = SPECIALIZED[source_id]
        modalities = modality.split('/')
    if source_id == 'bedrock':
        protocol, modalities = 'bedrock_converse', ['chat']
    if row['status'] == 'deprecated':
        kind = 'deprecated'
    auth = 'api_key_claim' if 'api key' in note or 'api token' in note or 'bearer' in note else None
    if 'session cookie' in note: auth = 'session_cookie_claim'
    if 'service account' in note: auth = 'service_account_or_oauth_claim'
    if 'without api key' in note or 'keyless' in note: auth = 'optional_key_claim'
    return kind, related, modalities, protocol, auth


def ingest(text):
    """Validate all records before returning deterministic, lossless candidate rows."""
    if len(text) > 2_000_000:
        raise ValueError('source too large')
    reader = csv.DictReader(io.StringIO(text))
    if tuple(reader.fieldnames or ()) != COLUMNS:
        raise ValueError('unexpected source columns')
    entries, seen = [], set()
    for row in reader:
        if None in row or any(value is None for value in row.values()):
            raise ValueError('malformed source row')
        for value in row.values(): validate_text(value)
        index = row['index']
        if not re.fullmatch(r'0|[1-9][0-9]{0,5}', index) or index in seen:
            raise ValueError('invalid or duplicate source index')
        seen.add(index)
        source_id = row['provider_id']
        if source_id and not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', source_id):
            raise ValueError('invalid source provider ID')
        if not row['name'].strip() or row['status'] not in ('candidate', 'deprecated'):
            raise ValueError('invalid source identity or status')
        if row['classification'] not in ('paid_or_unknown', 'promotional_credit', 'recurring_or_free_models', 'claimed_free_unverified', 'paid_only_reported', 'deprecated_free_claim'):
            raise ValueError('invalid source classification')
        if row['verification'] != 'unverified_source_claim' or row['autorouter_default_eligible'] != 'False':
            raise ValueError('source cannot authorize activation or verification')
        kind, related, modalities, protocol, auth = annotations(row)
        urls = [safe_url(v) for v in row['urls'].split(';') if v.strip()]
        entries.append(dict(
            canonical_id=f"pir-{int(index):03d}-{source_id or 'unidentified'}",
            source_index=int(index), source_provider_id=source_id or None, name=row['name'],
            aliases=sorted(set(filter(None, [source_id, row['name']]))),
            variant_kind=kind, related_source_provider_id=related,
            modalities=modalities, protocol_hint=protocol, auth_hint=auth,
            url_evidence=sorted(set(filter(None, urls))), rejected_url_count=urls.count(None),
            source_claim=dict(row), source_captured=CAPTURED,
            verification_state='unverified_source_claim', registry_status=row['status'],
            experimental=source_id.startswith('g4f-') or 'experimental' in row['notes'].lower(),
            trust_state='unverified', operationally_integrated=False, active=False,
            autorouter_default_eligible=False,
            models=None, context_length=None, tools=None, streaming=None, pricing=None,
            quota=None, verified_at=None, expires_at=None))
    return sorted(entries, key=lambda entry: entry['source_index'])


def build(text):
    entries = ingest(text)
    if hashlib.sha256(text.encode()).hexdigest() != SOURCE_SHA256:
        raise ValueError('pinned source checksum mismatch')
    if len(entries) != 249 or [e['source_index'] for e in entries] != list(range(249)):
        raise ValueError('pinned inventory requires all 249 source indexes')
    return dict(registry_version=1, source_commit=SOURCE_COMMIT, source_captured=CAPTURED,
                source_sha256=hashlib.sha256(text.encode()).hexdigest(), entries=entries)


def serialize(document):
    return json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + '\n'


def load_registry():
    """Validate the shipped source and generated snapshot before returning candidates."""
    expected = build(SOURCE.read_text(encoding='utf-8'))
    if OUTPUT.read_text(encoding='utf-8') != serialize(expected):
        raise ValueError('registry snapshot differs from validated source')
    return expected


def find_candidates(query, document=None):
    """Return every exact canonical ID/source ID/name/alias match; never overwrite collisions."""
    entries = (document if document is not None else load_registry())['entries']
    query = query.casefold().strip()
    return [e for e in entries if query in [e['canonical_id'].casefold(), *[a.casefold() for a in e['aliases']]]]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='verify the shipped snapshot without writing')
    args = parser.parse_args()
    output = serialize(build(SOURCE.read_text(encoding='utf-8')))
    if args.check:
        if not OUTPUT.is_file() or OUTPUT.read_text(encoding='utf-8') != output:
            parser.exit(1, 'registry snapshot requires regeneration\n')
    else:
        OUTPUT.write_text(output, encoding='utf-8')
    print('249 unverified candidate rows; no activation or eligibility changes')


if __name__ == '__main__':
    main()
