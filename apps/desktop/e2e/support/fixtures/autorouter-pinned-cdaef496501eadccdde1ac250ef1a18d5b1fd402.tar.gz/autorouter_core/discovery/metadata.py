"""Provider metadata adapters. Only allowlisted public catalog endpoints are read."""
import time
import math
from ..evidence.evidence import price_tier, access_allowed, merge_access_evidence
from ..evidence.quota import merge_quota_evidence

OPENROUTER = 'https://openrouter.ai/api/v1/models'
TTL = 86400


def fetch_metadata(provider):
    # NVIDIA's identifier catalog does not establish pricing or capabilities.
    if provider != 'openrouter':
        return {}
    from .adapters import _read_json
    return normalize_openrouter(_read_json(OPENROUTER, {"Accept": "application/json"}))


def normalize_openrouter(payload, now=None):
    now = time.time() if now is None else now
    from .adapters import DiscoveryError, MAX_MODELS, _model_id
    if (not isinstance(payload, dict) or not isinstance(payload.get('data'), list)
            or len(payload['data']) > MAX_MODELS):
        raise DiscoveryError('malformed_catalog')
    result = {}
    for row in payload['data']:
        if not isinstance(row, dict):
            raise DiscoveryError('malformed_catalog')
        mid = row.get('id')
        if not _model_id(mid):
            # Nous/OpenRouter '~' alias pointers are not catalog members.
            continue
        if mid in result:
            raise DiscoveryError('malformed_catalog')
        pricing = row.get('pricing')
        cost = price_tier(pricing)
        params = row.get('supported_parameters')
        tools = ('supported' if 'tools' in params else 'unsupported') if isinstance(params, list) else 'unknown'
        ctx = row.get('context_length')
        ctx = ctx if type(ctx) is int and ctx > 0 else None
        result[mid] = dict(provider='openrouter', model=mid, context_window=ctx,
                                 tools=tools, cost_tier=cost, discovery_status='discovered', metadata_source=OPENROUTER,
                                 discovery_evidence=dict(metadata_source=OPENROUTER, retrieved_at=now, expires_at=now+TTL),
                                 retrieved_at=now, expires_at=now + TTL,
                                 pricing_status=('omitted' if 'pricing' not in row else 'invalid_or_unknown' if cost == 'unknown' else cost),
                                 supplied_fields=[k for k, raw in [('context_window', 'context_length'), ('tools', 'supported_parameters'), ('cost_tier', 'pricing')] if raw in row],
                                 provenance={k: OPENROUTER for k in ('context_window', 'tools', 'cost_tier')})
        if 'pricing' in row:
            result[mid]['access_evidence'] = [dict(
                provider='openrouter', model=mid, scope='model', account_scope=None,
                classification={'free': 'VERIFIED_ZERO_PRICE_MODEL', 'paid': 'PAID_ONLY'}.get(cost, 'UNKNOWN'),
                source_url=OPENROUTER, source_type='provider_api', issuer='openrouter',
                source_of_truth=True, observed_at=now, expires_at=now + TTL,
                currency='USD', prices=pricing, auth_required=True, regions=None,
                payment_required=None, kyc_required=None, logging_policy=None,
                training_policy=None, reset_window=None, cap_scope=None)]
    if not result and payload['data']:
        raise DiscoveryError('malformed_catalog')
    return result


def merge_metadata(fresh, previous, now=None):
    """Fresh provider evidence wins; partial responses retain original field ages."""
    now = time.time() if now is None else now
    if previous and any(fresh.get(k) and fresh[k] != previous.get(k) for k in ('provider', 'model')):
        previous = None
    out = dict(previous or {})
    out.update(fresh)
    if 'access_evidence' in fresh and previous and 'access_evidence' in previous:
        out['access_evidence'] = merge_access_evidence(fresh['access_evidence'], previous['access_evidence'])
    if 'quota_evidence' in fresh and previous and 'quota_evidence' in previous:
        out['quota_evidence'] = merge_quota_evidence(fresh['quota_evidence'], previous['quota_evidence'])
    evidence = {}
    for key, unknown in [('context_window', None), ('tools', 'unknown'), ('cost_tier', 'unknown')]:
        source = fresh
        supplied = key in fresh.get('supplied_fields', fresh.keys())
        if not supplied and previous:
            source = previous
        old_fields = source.get('field_evidence', {})
        info = old_fields.get(key) or {k: source.get(k) for k in ('metadata_source', 'retrieved_at', 'expires_at')}
        info = dict(info, provider=source.get('provider'), model=source.get('model'))
        evidence[key] = info
        value = source.get(key, unknown)
        if not valid_evidence(info, now):
            value = unknown
        out[key] = value
    timestamps = [e.get('retrieved_at') for e in evidence.values() if e.get('retrieved_at')]
    out['retrieved_at'] = min(timestamps) if timestamps else fresh.get('retrieved_at', 0)
    out['field_evidence'] = evidence
    return out


def valid_evidence(info, now):
    if not isinstance(info, dict):
        return False
    source = info.get('metadata_source')
    start, end = info.get('retrieved_at'), info.get('expires_at')
    return (isinstance(source, str) and source.strip().lower() not in ('', 'unknown', 'none')
            and type(start) in (int, float) and type(end) in (int, float)
            and math.isfinite(start) and math.isfinite(end) and 0 < start <= now < end)


def verified_fields(cap, provider, model, now, *, account_scope=None, region=None):
    """Validate each field independently; never consult optimistic catalog values."""
    out = dict(context_window=None, tools='unknown', cost_tier='unknown')
    statuses = {key: 'unknown' for key in out}
    evidence = {}
    if not isinstance(cap, dict) or cap.get('provider') != provider or cap.get('model') != model:
        return out, statuses, evidence
    if cap.get('discovery_status') == 'candidate':
        return out, statuses, evidence
    for key in out:
        info = cap.get('field_evidence', {}).get(key, cap)
        if info.get('provider', provider) != provider or info.get('model', model) != model:
            continue
        evidence[key] = {k: info.get(k) for k in ('metadata_source', 'retrieved_at', 'expires_at')}
        value = cap.get(key)
        valid_value = (type(value) is int and value > 0) if key == 'context_window' else value in (
            ('supported', 'unsupported') if key == 'tools' else ('free', 'paid', 'premium'))
        if valid_evidence(info, now) and valid_value:
            out[key] = value
            statuses[key] = 'fresh'
        elif valid_value:
            statuses[key] = 'stale_or_unverified'
    if 'access_evidence' in cap and not access_allowed(
            cap['access_evidence'], provider, model, now, account_scope=account_scope, region=region):
        out['cost_tier'] = 'unknown'
        statuses['cost_tier'] = 'access_denied_or_unverified'
    return out, statuses, evidence
