"""Zero-price evidence, one coherent read (ADR-0016, Slice B repair).

The previous revision read the cache file's age via ``_disk_cache_age_seconds()``
and then deferred price resolution to ``agent.models_dev._registry_models(...)``.
Those are two independent calls that may observe different underlying data
(in-memory registry served from before the disk write vs. the disk file itself).
An attacker or an unfortunate race could make a fresh disk file vouch for stale
in-memory prices.

This module instead performs ONE bounded, validated, single-file read at
evaluation time and pins provenance to the exact descriptor it consumed:

1. **Source identity** — the host's configured models.dev URL must be exactly
   the default ``https://models.dev/api.json``. Any custom mirror (from the
   ``models_dev.url`` config or a patched ``MODELS_DEV_URL``) is untrusted and
   yields UNKNOWN — no trust contract exists that would admit it.
2. **Timestamp** — freshness is the file's mtime obtained via fstat on the
   OPENED descriptor, never ``time.time()`` at read, never the in-memory TTL.
   The before/after fstat of the open descriptor must be consistent, and the
   pre-open stat must agree with the descriptor's identity (dev/inode/mtime)
   — a file replaced between stat and open is refused, not trusted.
3. **Content** — the read is bounded (≤8 MiB); the payload must parse as a
   non-empty models.dev-shaped dict with depth ≤8 and ≤4096 providers; every
   provider entry must be dict-with-dict; provider IDs and model IDs must
   pass the strict grammar; the model entry under the trusted provider must
   exist.
4. **Provider/model identity** — the entry consulted must belong to the
   provider the caller asked for (host mapping honored, case-insensitive
   exact match) and the exact requested model id (case-insensitive). A
   provider or model mismatch yields nothing — never borrowed
   neighbour-price.
5. **Prices** — ``cost.input``/``cost.output`` must be finite, non-negative
   numbers (bools rejected, NaN/Inf rejected). Zero/zero prices on a fresh
   validated snapshot are the *only* route to a ``free`` classification.
   Positive prices are paid; anything else is unknown.
6. **In-memory is never consulted** for any field of an eligibility proof;
   quota stays UNKNOWN regardless (catalog price is not account entitlement).
"""

from __future__ import annotations

import json
import math
import os
import re
import time
from typing import Any, Optional

_MAX_ENTRIES = 5000
_MAX_BYTES = 8 * 1024 * 1024
_MAX_DEPTH = 8
_ID_RE = re.compile(r"[\w./:+-]{1,200}")
_PROVIDER_RE = re.compile(r"[a-z][a-z0-9-]{0,63}")
_CACHE_HINT = "models.dev disk cache (allow_network=False)"
_FALLBACK_TTL_SECONDS = 4 * 3600
_CANONICAL_SOURCE_URL = "https://models.dev/api.json"
_FUTURE_SKEW_SECONDS = 120.0


def _provider_id(provider: str) -> Optional[str]:
    provider = (provider or "").strip().lower()
    return provider if _PROVIDER_RE.fullmatch(provider) else None


def _numeric(value: Any) -> Optional[float]:
    if isinstance(value, bool):
        return None
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    if math.isfinite(out) and out >= 0.0:
        return out
    return None


def _host_ttl() -> float:
    try:
        from agent import models_dev as _md

        ttl = getattr(_md, "_MODELS_DEV_CACHE_TTL", None)
        if isinstance(ttl, (int, float)) and ttl > 0:
            return float(ttl)
    except Exception:
        pass
    return float(_FALLBACK_TTL_SECONDS)


def _source_url() -> Optional[str]:
    try:
        from agent import models_dev as _md

        url = _md._get_models_dev_url()
        if not isinstance(url, str):
            return None
        url = url.strip()
        default = getattr(_md, "MODELS_DEV_URL", _CANONICAL_SOURCE_URL)
        # A custom mirror — from config or a patched global — is untrusted here.
        if url != _CANONICAL_SOURCE_URL or default != _CANONICAL_SOURCE_URL:
            return None
        return url
    except Exception:
        return None


def _cache_path():
    try:
        from hermes_constants import get_hermes_home

        return get_hermes_home() / "models_dev_cache.json"
    except Exception:
        try:
            from agent import models_dev as _md

            return _md._get_cache_path()
        except Exception:
            return None


def _json_depth(node: Any, depth: int = 0) -> bool:
    if depth > _MAX_DEPTH:
        return False
    if isinstance(node, dict):
        if len(node) > _MAX_ENTRIES:
            return False
        return all(isinstance(k, str) and _json_depth(v, depth + 1) for k, v in node.items())
    if isinstance(node, list):
        if len(node) > _MAX_ENTRIES:
            return False
        return all(_json_depth(v, depth + 1) for v in node)
    return True


def _snapshot():
    """The ONE coherent trusted cache snapshot, or None. Never raises."""
    path = _cache_path()
    if path is None:
        return None
    source_url = _source_url()
    if source_url is None:
        return None

    try:
        pre = path.stat(follow_symlinks=False)
    except OSError:
        return None
    if not path.is_file() or not (1 <= pre.st_size <= _MAX_BYTES):
        return None
    now = time.time()
    if pre.st_mtime > now + _FUTURE_SKEW_SECONDS:
        return None
    age = now - pre.st_mtime
    ttl = _host_ttl()
    if age < 0 or age > ttl:
        return None

    try:
        with path.open("rb") as fh:
            before = os.fstat(fh.fileno())
            if (before.st_dev, before.st_ino, before.st_mtime_ns, before.st_size) != \
               (pre.st_dev, pre.st_ino, pre.st_mtime_ns, pre.st_size):
                # File replaced between stat and open — refuse the swap.
                return None
            data = fh.read(_MAX_BYTES + 1)
            after = os.fstat(fh.fileno())
            if (before.st_dev, before.st_ino, before.st_mtime_ns, before.st_size, before.st_ctime_ns) != \
               (after.st_dev, after.st_ino, after.st_mtime_ns, after.st_size, after.st_ctime_ns):
                # File changed while we were reading — refuse.
                return None
    except OSError:
        return None
    if len(data) != before.st_size or len(data) == 0:
        return None
    try:
        registry = json.loads(data)
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
        return None
    if not isinstance(registry, dict) or not registry:
        return None
    if not _json_depth(registry):
        return None
    return {
        "providers": registry,
        "observed_at": float(after.st_mtime),
        "cache_age_seconds": float(max(0.0, now - after.st_mtime)),
        "source_url": source_url,
        "source": _CACHE_HINT,
        "freshness_seconds": ttl,
    }


def _entry(provider: str, model: str, snap: dict) -> Optional[dict[str, Any]]:
    pid = _provider_id(provider)
    if pid is None:
        return None
    providers = snap.get("providers") or {}
    try:
        from agent import models_dev as _md

        try:
            mid = _md._models_dev_id(pid)
        except Exception:
            mid = None
        lookup_id = mid or pid
    except Exception:
        lookup_id = pid
    provider_data = providers.get(lookup_id) or providers.get(lookup_id.lower() if isinstance(lookup_id, str) else lookup_id)
    if not isinstance(provider_data, dict):
        return None
    models = provider_data.get("models")
    if not isinstance(models, dict) or len(models) > _MAX_ENTRIES:
        return None
    target = str(model).strip()
    if not _ID_RE.fullmatch(target):
        return None
    entry = models.get(target)
    if not isinstance(entry, dict):
        lowered = target.lower()
        for key, row in models.items():
            if isinstance(key, str) and key.lower() == lowered and isinstance(row, dict):
                entry = row
                break
        else:
            return None
    return entry


def enrich(provider: str, model: str) -> Optional[dict[str, Any]]:
    """Resolve catalog metadata for one model against ONE coherent snapshot.

    Never raises. Returns None (no evidence, safe-refuse) whenever the cache
    is absent, replaced, corrupt, untrusted, stale, malformed, or the provider
    or model does not match. ``free`` is reachable only with zero price
    literally in the bytes that were fstat-verified.
    """
    pid = _provider_id(provider)
    if pid is None:
        return None
    try:
        snap = _snapshot()
    except Exception:
        return None
    if snap is None:
        return None
    try:
        entry = _entry(pid, model, snap)
    except Exception:
        return None
    if entry is None:
        return None

    context_window: Optional[int] = None
    limit = entry.get("limit")
    if isinstance(limit, dict):
        ctx = limit.get("context")
        if isinstance(ctx, bool):
            ctx = None
        try:
            ctx = int(ctx) if ctx is not None else None
        except (TypeError, ValueError, OverflowError):
            ctx = None
        if ctx is not None and 0 < ctx <= 20_000_000:
            context_window = ctx

    tools = "supported" if entry.get("tool_call") is True else "unknown"

    pricing_status = "unknown"
    cost_tier = "unknown"
    cost = entry.get("cost")
    if isinstance(cost, dict):
        ci = _numeric(cost.get("input"))
        co = _numeric(cost.get("output"))
        if ci is not None and co is not None:
            if ci == 0.0 and co == 0.0:
                cost_tier, pricing_status = "free", "zero_price"
            elif ci > 0.0 or co > 0.0:
                cost_tier, pricing_status = "paid", "positive_price"

    observed_at = float(snap["observed_at"])
    ttl = float(snap["freshness_seconds"])
    return {
        "context_window": context_window,
        "tools": tools,
        "cost_tier": cost_tier,
        "pricing_status": pricing_status,
        "provenance": {"cost_tier": snap["source"], "context_window": snap["source"], "tools": snap["source"]},
        "retrieved_at": observed_at,
        "expires_at": observed_at + ttl,
        "cache_age_seconds": snap["cache_age_seconds"],
        "cache_source": snap["source_url"],
    }
