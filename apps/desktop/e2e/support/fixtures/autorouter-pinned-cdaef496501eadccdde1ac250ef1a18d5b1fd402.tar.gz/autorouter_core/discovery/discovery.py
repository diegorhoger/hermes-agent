"""Model catalog discovery for AutoRouter."""

from __future__ import annotations

import logging
import os
import time
import json
from types import SimpleNamespace
from typing import Any, Optional

from . import metadata as _metadata
from . import adapters as _adapters
from . import nous_catalog as _nous_catalog
from . import catalog_enrich as _catalog_enrich

metadata = _metadata
adapters = _adapters
nous_catalog = _nous_catalog
catalog_enrich = _catalog_enrich

logger = logging.getLogger(__name__)

# Known context windows / capabilities are best-effort; unknown -> None/"unknown".
KNOWN_CONTEXT: dict[str, int] = {
    # small set; everything else unknown
}


def _resolve_api_key(provider: str, profile) -> Optional[str]:
    """Resolve an API key for a provider using Hermes credential handling (no raw storage)."""
    try:
        from hermes_cli.auth import resolve_api_key_provider
        # best-effort
    except Exception:
        pass
    # Try env vars declared by profile
    for var in getattr(profile, "env_vars", ()) or ():
        val = os.environ.get(var)
        if val:
            return val.strip()
    # Try dotenv via hermes config
    try:
        from hermes_cli.config import get_env_value_prefer_dotenv
        for var in getattr(profile, "env_vars", ()) or ():
            val = get_env_value_prefer_dotenv(var)
            if val:
                return str(val).strip()
    except Exception:
        pass
    return None


def discover_provider(provider_name: str, store=None) -> list[dict[str, Any]]:
    """Discover models for one provider. Returns list of {provider, model, context_length, capabilities, cost_tier}."""
    result: list[dict[str, Any]] = []
    if provider_name == 'nous':
        # Nous Portal authenticates with Hermes-managed OAuth state, not an
        # env var; the read-only catalog adapter resolves it itself.
        try:
            verified = nous_catalog.fetch_catalog()
        except adapters.DiscoveryError as exc:
            logger.warning("autorouter: Nous catalog discovery unavailable: %s", exc)
            return []
        models = list(verified)
        _revoke_absent('nous', models, verified, store, nous_catalog.NOUS_MODELS_URL)
        return _resolved_models('nous', models, verified, store)
    try:
        import providers
        profile = providers.get_provider_profile(provider_name)
    except Exception:
        if provider_name not in adapters.SPECS:
            logger.warning("autorouter: providers module unavailable")
            return result
        profile = None
    if profile is None and provider_name in adapters.SPECS:
        profile = SimpleNamespace(env_vars=adapters.SPECS[provider_name][1])
    if profile is None:
        logger.warning("autorouter: unknown provider %s", provider_name)
        return result

    api_key = _resolve_api_key(provider_name, profile)
    base_url = getattr(profile, "base_url", None)

    if provider_name in adapters.SPECS:
        try:
            verified = adapters.fetch_catalog(provider_name, api_key)
        except adapters.DiscoveryError as exc:
            logger.warning("autorouter: adapter discovery failed: %s", exc)
            return []
        models = list(verified)
        _revoke_absent(provider_name, models, verified, store, adapters.SPECS[provider_name][0])
        return _resolved_models(provider_name, models, verified, store)

    models: Optional[list[str]] = None
    try:
        models = profile.fetch_models(api_key=api_key, base_url=base_url, timeout=10.0)
    except Exception as exc:
        logger.warning("autorouter: fetch_models failed")
        models = None

    fallback = models is None
    if fallback:
        # Static fallback IDs are candidates, not a successful catalog observation.
        fb = getattr(profile, "fallback_models", None)
        if fb:
            models = list(fb)

    if models is None:
        return result
    try:
        models, rejected = adapters._sanitize_model_ids(models)
    except adapters.DiscoveryError:
        logger.warning("autorouter: malformed provider catalog")
        return result
    if rejected:
        logger.info("autorouter: skipped %d alias/invalid catalog rows from %s",
                    len(rejected), provider_name)
    complete = not fallback
    try:
        verified = metadata.fetch_metadata(provider_name)
    except Exception:
        logger.warning("autorouter: metadata refresh failed")
        verified = {}
        complete = False
    source = {"nvidia": "https://integrate.api.nvidia.com/v1/models",
              "openrouter": metadata.OPENROUTER}.get(provider_name, "unknown")
    observed = time.time()
    for mid in models:
        verified.setdefault(mid, dict(provider=provider_name, model=mid, supplied_fields=[],
            metadata_source=source, retrieved_at=time.time(), expires_at=time.time()+adapters.TTL))
        if not fallback:
            verified[mid]["available"] = True
        verified[mid]["discovery_status"] = "candidate" if fallback else "discovered"
        verified[mid]["discovery_evidence"] = {} if fallback else dict(
            metadata_source=source, retrieved_at=observed, expires_at=observed+adapters.TTL)
    if complete and provider_name in ("nvidia", "openrouter"):
        _revoke_absent(provider_name, models, verified, store, source)
    return _resolved_models(provider_name, models, verified, store)


def _revoke_absent(provider, models, verified, store, source):
    """Only a complete successful catalog can revoke absent cached identifiers."""
    if store is None:
        return
    now = time.time()
    present = set(models)
    for old in store.get_catalog():
        if old['provider'] == provider and old['model'] not in present:
            mid = old['model']
            verified[mid] = dict(provider=provider, model=mid, context_window=None,
                tools='unsupported', cost_tier='unknown', available=False,
                discovery_status='removed', metadata_source=source,
                discovery_evidence=dict(metadata_source=source, retrieved_at=now, expires_at=now+adapters.TTL),
                retrieved_at=now, expires_at=now+adapters.TTL,
                supplied_fields=['context_window', 'tools', 'cost_tier'])
            models.append(mid)


def _resolved_models(provider_name, models, verified, store):
    result = []
    for mid in models:
        mid = str(mid).strip()
        if not mid:
            continue
        fresh = verified.get(mid) or dict(provider=provider_name, model=mid, retrieved_at=time.time(),
                                         expires_at=0, metadata_source="unknown")
        if provider_name not in ("nvidia", "openrouter", "groq", "gemini", "mistral", "nous"):
            # ADR-0016 Slice B: catalog-backed enrichment for recognized non-adapter providers.
            enrich = catalog_enrich.enrich(provider_name, mid)
            if enrich:
                # Field-level freshness is carried from the cache's real
                # observation time (its mtime). An old cache yields an old
                # retrieval time and a matching expiry — never restamped to now.
                observed_at = enrich["retrieved_at"]
                observed_expires = enrich["expires_at"]
                fresh["metadata_source"] = enrich["provenance"]["cost_tier"]
                fresh["retrieved_at"] = observed_at
                fresh["expires_at"] = observed_expires
                if enrich.get("context_window") is not None:
                    fresh["context_window"] = enrich["context_window"]
                if enrich.get("tools") == "supported":
                    fresh["tools"] = "supported"
                if enrich.get("cost_tier") in ("free", "paid"):
                    fresh["cost_tier"] = enrich["cost_tier"]
                    fresh["pricing_status"] = enrich["pricing_status"]
                fresh["provenance"] = dict(enrich.get("provenance") or {})
        previous = None
        if store is not None:
            row = store.get_capability(provider_name, mid)
            if row:
                previous = json.loads(row["capability_json"])
        resolved = metadata.merge_metadata(fresh, previous)
        ctx_len = resolved.get("context_window")
        # Unknown cost never becomes eligibility; see eligibility.cost_allowed.
        result.append({
            "provider": provider_name,
            "model": mid,
            "context_length": ctx_len,
            "capabilities": {"tools": resolved.get("tools", "unknown")},
            "cost_tier": resolved.get("cost_tier", "unknown"),
            "metadata": resolved,
        })
    return result


def discover_all(providers: list[str], store=None) -> dict[str, list[dict[str, Any]]]:
    out: dict[str, list[dict[str, Any]]] = {}
    all_models = []
    for p in providers:
        try:
            ms = discover_provider(p, store=store)
        except Exception as exc:
            logger.warning("autorouter: discovery failed")
            ms = []
        out[p] = ms
        all_models.extend(ms)

    # persist
    if store is not None:
        try:
            for m in all_models:
                store.persist_discovered_model(m)
            previous = store.get_lkg() or {}
            for provider, models in out.items():
                if models:
                    previous[provider] = models
            store.save_lkg(previous)
        except Exception as exc:
            logger.warning("autorouter: catalog/capability persistence failed")
            raise RuntimeError("catalog/capability persistence failed") from None
    return out


def load_last_known_good(store) -> Optional[dict]:
    if store is None:
        return None
    try:
        return store.get_lkg()
    except Exception:
        return None
