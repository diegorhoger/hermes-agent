"""Read-only first-use guidance from existing configuration and evidence snapshots."""

from ..providers.connections import GUIDANCE, valid_provider_list

VERSION = 1
PROVIDERS = ("nvidia", "openrouter", "groq", "gemini", "mistral")
DOCS = "https://hermes-agent.nousresearch.com/docs/developer-guide/plugins"


def _integer(value):
    return value if type(value) is int and value >= 0 else None


def build(config, inventory, models, *, now, capabilities):
    """No activation, credential handling, refresh, selection writes or execution."""
    readable = config.get("available") is True
    values = config.get("values") or {}
    enabled = values.get("enabled") is True if readable else None
    configured = values.get("providers")
    valid = (
        valid_provider_list(configured)
        and config.get("provider_configuration_valid", True) is True
    )
    configured = [p for p in PROVIDERS if p in configured] if readable and valid else []
    raw = inventory.get("connections") or []
    by_id = {
        row.get("provider_id"): row
        for row in raw
        if isinstance(row, dict) and row.get("provider_id") in PROVIDERS
    }
    providers = []
    for provider in configured:
        row = by_id.get(provider, {})
        presence = (
            row.get("presence")
            if row.get("presence") in ("configured", "not_observed")
            else "unknown"
        )
        observed_auth_failure = row.get("health") == "provider_auth_failure_observed"
        guidance = GUIDANCE.get(provider, {})
        supplied = row.get("guidance") or {}
        setup = supplied.get("key_issuance_url")
        setup = setup if setup and setup == guidance.get("key_issuance_url") else None
        providers.append(
            dict(
                provider_id=provider,
                configured=True,
                presence=presence,
                presence_scope="process_environment_only",
                authentication="unverified",
                observed_auth_failure=observed_auth_failure,
                active_credential_binding="unknown",
                model_count=_integer(row.get("discovered_model_count")),
                setup_url=setup,
                next_action="review_host_auth_failure"
                if observed_auth_failure
                else "review_host_setup"
                if presence != "configured"
                else "inspect_model_evidence",
                disclosure="Presence is not credential validity or account entitlement; an unbound auth failure may belong to another credential.",
            )
        )
    preview = models.get("preview") or {}
    report = preview.get("evidence_report") or {}
    chosen = report.get("recommendation")
    chosen = (
        chosen
        if isinstance(chosen, dict)
        and chosen.get("provider") in configured
        and isinstance(chosen.get("model"), str)
        and chosen["model"] != "[redacted_identity]"
        else None
    )
    displayed = models.get("models") or []
    fresh = sum(
        1
        for row in displayed
        if isinstance(row, dict)
        and (row.get("field_freshness") or {}).get("cost_tier") == "fresh"
    )
    eligible = _integer(preview.get("eligible_count"))
    catalog_available = models.get("available") is True and "preview" in models
    missing = [
        provider
        for provider in configured
        if not any(
            isinstance(row, dict) and row.get("provider") == provider
            for row in displayed
        )
    ]
    if not readable or not valid:
        stage = "configuration_unavailable"
    elif not enabled:
        stage = "activation_required"
    elif not configured:
        stage = "providers_required"
    elif models.get("available") is False:
        stage = "evidence_unavailable"
    elif not catalog_available or not displayed:
        stage = "catalog_refresh_required"
    elif chosen and eligible and report.get("outcome") == "recommended":
        stage = "recommendation_ready"
    else:
        stage = "no_eligible_recommendation"
    presence_state = (
        "observed_presence"
        if providers and all(p["presence"] == "configured" for p in providers)
        else "unknown_or_partial"
    )
    limitations = [
        "authentication and live provider entitlement are unverified",
        "active account scope and quota may be unknown",
        "catalog refresh success/completeness cannot be inferred from cached row counts",
        "recommendation is not applied or executed",
        "no-charge guarantee is unavailable",
    ]
    return dict(
        schema_version=VERSION,
        generated_at=now,
        stage=stage,
        completion_scope="recommendation evidence only",
        ready_for_recommendation=stage == "recommendation_ready",
        host_activation="unverified",
        runtime_opt_in=enabled,
        managed=config.get("managed") is True,
        providers=providers,
        provider_inventory_scope=inventory.get("provider_scope")
        if inventory.get("provider_scope")
        in (
            "existing_nvidia_openrouter_integrations_only",
            "five_supported_discovery_providers",
            "five_fixed_discovery_adapters_only",
            "six_fixed_discovery_adapters_only",
        )
        else "unknown",
        steps=[
            dict(
                id="activation",
                state="runtime_opted_in"
                if enabled
                else "required"
                if enabled is False
                else "unknown",
                instructions="Ask the Hermes administrator to enable this managed plugin; no override is offered."
                if config.get("managed") is True
                else "Use Hermes Plugins to opt in, and set the plugin runtime enabled setting deliberately; recheck after the host loads it.",
                commands=[]
                if config.get("managed") is True
                else [
                    "hermes plugins enable autorouter",
                    "hermes config set plugins.entries.autorouter.settings.enabled true",
                ],
                docs_url=DOCS,
            ),
            dict(
                id="providers",
                state="configured" if configured else "required",
                target_tab="settings",
                instructions="Select authorized provider IDs in the Settings tab; keys remain in Hermes.",
            ),
            dict(
                id="credentials",
                state=presence_state,
                target_tab="providers",
                instructions="Inspect presence and official setup guidance in Providers; no connected/valid assertion is made.",
            ),
            dict(
                id="catalog",
                state="cached_evidence" if displayed else "unavailable",
                target_tab="models",
                instructions="Ask Hermes to run autorouter_refresh explicitly, then recheck this guide. Cached counts do not prove a complete successful refresh.",
                tool_request="autorouter_refresh",
            ),
            dict(
                id="recommendation",
                state="ready" if stage == "recommendation_ready" else "not_ready",
                target_tab="models",
                instructions="Choose an explicit task, inspect current proof and preview; unknown/stale/paid evidence cannot authorize selection.",
            ),
            dict(
                id="handoff",
                state="manual_user_action_required",
                target_tab="models",
                instructions="Prepare a validated manual handoff only after confirmation; host-confirmed apply/restore is unavailable.",
            ),
        ],
        evidence=dict(
            storage="available" if catalog_available else "unavailable",
            displayed_models=len(displayed),
            display_truncated=models.get("truncated") is True,
            fresh_price_proofs=fresh,
            eligible_models=eligible,
            configured_providers_without_displayed_models=missing,
            provider_refresh_outcome="unknown",
            scope="bounded displayed snapshot; not a full catalog or live account test",
        ),
        recommendation=chosen,
        decision_report=report or None,
        execution_capabilities=capabilities,
        next_action="review_and_preview_in_models"
        if stage == "recommendation_ready"
        else "explicit_catalog_refresh_then_recheck"
        if stage == "catalog_refresh_required"
        else "inspect_requirements_and_evidence"
        if stage == "no_eligible_recommendation"
        else "follow_required_steps",
        limitations=limitations,
        execution_authority=False,
    )
