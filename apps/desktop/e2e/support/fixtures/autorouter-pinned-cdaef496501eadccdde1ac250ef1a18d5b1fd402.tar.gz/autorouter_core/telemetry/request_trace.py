"""Bounded evidence projection; persisted observations do not prove application."""

import math
import re

VERSION = 1
ATTEMPT_LIMIT = 100


def _metric(value, *, integer=False):
    valid = (
        type(value) in ((int,) if integer else (int, float))
        and math.isfinite(value)
        and value >= 0
    )
    return dict(
        state="observed" if valid else "unavailable", value=value if valid else None
    )


def _identity(value):
    return (
        isinstance(value, str) and re.fullmatch(r"id_[0-9a-f]{64}", value) is not None
    )


def build(request, attempts, *, truncated=False):
    """Input is internal persisted rows; output never includes raw/hash identity."""
    rows = attempts[:ATTEMPT_LIMIT]
    ordinals = [a.get("ordinal") for a in rows]
    valid = all(type(n) is int and n >= 0 for n in ordinals)
    complete = (
        valid and bool(rows) and ordinals == list(range(len(rows))) and not truncated
    )
    target = (request.get("provider"), request.get("model"))
    target_known = all(isinstance(v, str) and v for v in target)
    known_attempts = all(
        isinstance(a.get(k), str) and a.get(k)
        for a in rows
        for k in ("provider", "model")
    )
    mismatch = target_known and any(
        (a.get("provider"), a.get("model")) != target
        for a in rows
        if a.get("provider") and a.get("model")
    )
    status = request.get("status")
    terminal = status in ("success", "error", "canceled")
    ended = _metric(request.get("ended_at"))
    started = _metric(request.get("started_at"))
    clock_valid = (
        started["state"] == ended["state"] == "observed"
        and ended["value"] >= started["value"]
    )
    return dict(
        schema_version=VERSION,
        source="persisted_host_observer_records",
        decision=dict(
            state="unavailable", reason="sanctioned_decision_identifier_not_observed"
        ),
        apply=dict(
            state="unavailable", reason="host_context_bound_apply_contract_unavailable"
        ),
        end_to_end_correlation="unavailable",
        request=dict(
            identity="observed"
            if _identity(request.get("api_request_id"))
            else "unavailable",
            session_context="observed"
            if _identity(request.get("session_hash"))
            else "unknown",
            account_scope="observed_hashed_bucket"
            if isinstance(request.get("key_scope"), str)
            and re.fullmatch(r"k_[0-9a-f]{12}", request["key_scope"])
            else "unknown",
            active_account_authority=False,
        ),
        attempts=dict(
            observed_count=len(rows),
            completeness="contiguous_observed_ordinals"
            if complete
            else "partial_or_unavailable",
            truncated=truncated is True,
            limit=ATTEMPT_LIMIT,
            target_consistency="different_observed_target"
            if mismatch
            else "matching_observed_target"
            if target_known and rows and known_attempts
            else "unknown",
            retry_count=None,
            observed_additional_attempts=len(rows) - 1 if complete else None,
            retry_count_meaning="total host retries unavailable; ordinals may be assigned during ingestion",
        ),
        completion=dict(
            state="observed" if terminal else "pending_or_unknown",
            outcome=status if terminal else None,
            started_at=started["value"],
            ended_at=ended["value"],
            timestamp_order="valid" if clock_valid else "unknown_or_invalid",
            timestamp_source="persisted event time; host versus ingestion origin not recorded",
        ),
        metrics={
            name: _metric(request.get(name), integer=name.endswith("tokens"))
            for name in ("input_tokens", "output_tokens", "latency_ms", "ttft_ms")
        },
        limitations=[
            "request/attempt observations do not establish a selected-and-applied decision",
            "account bucket is not current credential authorization or per-attempt account proof",
            "attempt order is ordinal order, not proof all callbacks arrived",
            "missing usage is unavailable, not zero; telemetry is not a billing ledger",
            "no prompts, raw errors, credentials or identity values in this trace",
        ],
        execution_authority=False,
    )
