"""Typed telemetry contracts, pure calculations and Hermes-hook ingestion.

Analytics layer for AutoRouter (Hermes plugin).

This module is deliberately dependency-free (stdlib only) and side-effect free:
every function is a pure calculation over already-collected values. All SQLite
writes live in :mod:`state`; all Hermes-hook specifics (which kwargs exist) are
isolated in the ``from_*_kwargs`` mappers below, so the supported/unsupported
host-observation boundary is explicit and tested.

Host-observation rule (never fabricate production data):
* Only fields Hermes actually delivers via ``pre_api_request`` /
  ``post_api_request`` / ``api_request_error`` are mapped to real values.
* Anything Hermes does not deliver (client IP / User-Agent, raw credential
  identity, cache and search backend internals) is recorded as ``None`` /
  ``"unknown"`` and surfaced as such. A bounded ingestion contract exists for
  future host callbacks (see :func:`ingest_bounded_event`); until Hermes ships
  the callback, the ingestion path accepts the event shape but no production
  caller supplies it, so the corresponding analytics section reports
  ``observed: false`` honestly.

Privacy rule: ``user_message``, ``conversation_history``,
``request_messages``, ``system_prompt``, ``request`` / ``response`` payloads
and assistant content are NEVER stored. Only counters, identifiers and timings
are persisted, so telemetry cannot leak prompt content or secrets.
"""

from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass, field
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Range handling (24h / 7d / 30d / 90d / all)
# ---------------------------------------------------------------------------

ANALYTICS_RANGES = ("24h", "7d", "30d", "90d", "all")
_RANGE_SECONDS = {
    "24h": 24 * 3600,
    "7d": 7 * 86400,
    "30d": 30 * 86400,
    "90d": 90 * 86400,
    "all": None,
}


def normalize_range(value: Any) -> str:
    """Return a supported range; unknown values fall back to ``7d``."""
    if isinstance(value, str) and value in ANALYTICS_RANGES:
        return value
    return "7d"


def since_timestamp(range_value: str, now: float) -> Optional[float]:
    """Epoch cutoff for a range. ``None`` for ``all`` (no lower bound)."""
    range_value = normalize_range(range_value)
    seconds = _RANGE_SECONDS[range_value]
    if seconds is None:
        return None
    return now - seconds


# ---------------------------------------------------------------------------
# Typed inference telemetry contracts
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class TokenUsage:
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None

    def __post_init__(self) -> None:
        for name in ("input_tokens", "output_tokens"):
            value = getattr(self, name)
            if value is not None and (not isinstance(value, int) or isinstance(value, bool) or value < 0):
                raise ValueError(f"{name} must be a non-negative int or None")


@dataclass(frozen=True)
class InferenceRequest:
    """One logical inference request (a ``pre_api_request`` → terminal pair)."""
    provider: Optional[str] = None
    model: Optional[str] = None
    response_model: Optional[str] = None
    status: str = "pending"  # pending | success | error | canceled
    latency_ms: Optional[float] = None
    ttft_ms: Optional[float] = None
    tokens: TokenUsage = field(default_factory=TokenUsage)
    error_category: Optional[str] = None
    error_summary: Optional[str] = None
    agent_id: Optional[str] = None  # hashed session bucket, never raw session id
    platform: Optional[str] = None
    api_request_id: Optional[str] = None
    key_scope: str = ""  # opaque hashed credential scope; "" == unknown

    def __post_init__(self) -> None:
        if self.status not in ("pending", "success", "error", "canceled"):
            raise ValueError(f"invalid status: {self.status!r}")
        if self.latency_ms is not None and self.latency_ms < 0:
            raise ValueError("latency_ms must be >= 0")
        if self.ttft_ms is not None and self.ttft_ms < 0:
            raise ValueError("ttft_ms must be >= 0")


@dataclass(frozen=True)
class ExecutionAttempt:
    """One dispatched attempt (retry / failover hop) of a request."""
    request_ref: str
    ordinal: int
    provider: Optional[str] = None
    model: Optional[str] = None
    status_code: Optional[int] = None
    retryable: Optional[bool] = None
    reason: Optional[str] = None
    error_category: Optional[str] = None
    duration_ms: Optional[float] = None

    def __post_init__(self) -> None:
        if not isinstance(self.ordinal, int) or self.ordinal < 0:
            raise ValueError("ordinal must be a non-negative int")


@dataclass(frozen=True)
class CacheEvent:
    """Prompt/response cache observation. Hermes has no cache hook: only the
    bounded ingestion contract produces these (never fabricated)."""
    provider: Optional[str] = None
    model: Optional[str] = None
    hit: bool = False
    latency_ms: Optional[float] = None


@dataclass(frozen=True)
class SearchEvent:
    """Search-backend observation. Hermes has no search hook: only the bounded
    ingestion contract produces these (never fabricated)."""
    provider: Optional[str] = None
    query_length: Optional[int] = None
    latency_ms: Optional[float] = None
    results_count: Optional[int] = None


@dataclass(frozen=True)
class CredentialScopeEvent:
    """Credential-scope observation. Raw secrets are never accepted: any
    label is hashed before persistence (see :func:`redact_key_scope`)."""
    provider: Optional[str] = None
    key_scope_hash: str = ""
    auth_ok: Optional[bool] = None
    reason: Optional[str] = None


# ---------------------------------------------------------------------------
# Error classification
# ---------------------------------------------------------------------------

ERROR_CATEGORIES = (
    "Rate Limited (429)",
    "Auth Error (401)",
    "Forbidden (403)",
    "Not Found (404)",
    "Timeout/Connection",
    "Server Error (500)",
    "Unavailable (503)",
    "Other",
)


def classify_error(
    status_code: Optional[int] = None,
    error_type: Optional[str] = None,
    message: Optional[str] = None,
) -> str:
    """Map an error to a stable dashboard category. Status wins; otherwise
    fall back to textual signals; otherwise ``Other``."""
    if isinstance(status_code, bool):
        status_code = None
    if isinstance(status_code, int):
        if status_code == 429:
            return "Rate Limited (429)"
        if status_code == 401:
            return "Auth Error (401)"
        if status_code == 403:
            return "Forbidden (403)"
        if status_code == 404 or status_code == 410:
            return "Not Found (404)"
        if status_code == 500 or status_code == 502:
            return "Server Error (500)"
        if status_code == 503 or status_code == 504:
            return "Unavailable (503)"
        if 400 <= status_code < 500:
            return "Other"
        if 500 <= status_code < 600:
            return "Server Error (500)"
    text = f"{error_type or ''} {message or ''}".lower()
    if "rate limit" in text or "rate_limit" in text or "ratelimit" in text \
            or "too many" in text or "quota" in text or "429" in text:
        return "Rate Limited (429)"
    if "unauthorized" in text or "invalid api key" in text or "invalid_api_key" in text \
            or "incorrect api key" in text or "authentication" in text or "401" in text:
        return "Auth Error (401)"
    if "forbidden" in text or "403" in text:
        return "Forbidden (403)"
    if "not found" in text or "no such model" in text or "404" in text or "gone" in text or "retired" in text:
        return "Not Found (404)"
    if "timeout" in text or "timed out" in text or "etimedout" in text or "econnrefused" in text \
            or "connection" in text or "connect" in text or "reset" in text:
        return "Timeout/Connection"
    if "internal server" in text or "500" in text:
        return "Server Error (500)"
    if "unavailable" in text or "503" in text:
        return "Unavailable (503)"
    return "Other"


# ---------------------------------------------------------------------------
# Pure calculations (deterministic, unit-tested)
# ---------------------------------------------------------------------------

def percentile(sorted_values: list[float], fraction: float) -> Optional[float]:
    """Nearest-rank percentile over pre-sorted non-empty values."""
    if not sorted_values:
        return None
    if not 0.0 <= fraction <= 1.0:
        raise ValueError("fraction must be within [0, 1]")
    offset = max(0, min(len(sorted_values) - 1, math.ceil(len(sorted_values) * fraction) - 1))
    return sorted_values[offset]


def latency_percentiles(latencies: list[float]) -> tuple[Optional[float], Optional[float]]:
    """Return (p50, p95) over the non-null latency sample; (None, None) when empty."""
    cleaned = sorted(v for v in latencies if v is not None)
    if not cleaned:
        return None, None
    return percentile(cleaned, 0.5), percentile(cleaned, 0.95)


def success_rate(success_count: int, error_count: int) -> Optional[float]:
    """Success % over decided (success+error) requests; None when no decided rows.
    Canceled requests are deliberately excluded from the denominator."""
    decided = success_count + error_count
    if decided <= 0:
        return None
    return round(success_count / decided * 100, 1)


def tokens_per_second(output_tokens: int, latency_ms: float) -> Optional[float]:
    if output_tokens <= 0 or latency_ms <= 0:
        return None
    return round(output_tokens / (latency_ms / 1000.0), 1)


def hour_key(epoch: float) -> str:
    """UTC hour bucket key ``YYYY-MM-DD HH:00:00``."""
    import datetime

    dt = datetime.datetime.fromtimestamp(epoch, tz=datetime.timezone.utc)
    return dt.strftime("%Y-%m-%d %H:00:00")


def avg(values: list[float]) -> Optional[float]:
    cleaned = [v for v in values if v is not None]
    if not cleaned:
        return None
    return round(sum(cleaned) / len(cleaned), 1)


# ---------------------------------------------------------------------------
# Hermes-hook field extraction (supported interfaces only)
# ---------------------------------------------------------------------------

_USAGE_INPUT_KEYS = ("input_tokens", "prompt_tokens", "promptTokens", "inputTokens")
_USAGE_OUTPUT_KEYS = ("output_tokens", "completion_tokens", "completionTokens", "outputTokens")


def _first_int(mapping: dict, keys: tuple[str, ...]) -> Optional[int]:
    for key in keys:
        value = mapping.get(key)
        if isinstance(value, bool):
            continue
        if isinstance(value, int) and value >= 0:
            return value
        if isinstance(value, float) and value >= 0 and float(value).is_integer():
            return int(value)
    return None


def extract_usage(kwargs: dict) -> TokenUsage:
    """Read token usage from a ``post_api_request`` payload. Missing usage
    (non-streaming / unsupported provider) yields ``None`` fields, never zeros."""
    if not isinstance(kwargs, dict):
        return TokenUsage()
    usage = kwargs.get("usage")
    if isinstance(usage, dict):
        return TokenUsage(
            input_tokens=_first_int(usage, _USAGE_INPUT_KEYS),
            output_tokens=_first_int(usage, _USAGE_OUTPUT_KEYS),
        )
    # Some providers report totals flat on the payload.
    return TokenUsage(
        input_tokens=_first_int(kwargs, ("input_tokens", "prompt_tokens")),
        output_tokens=_first_int(kwargs, ("output_tokens", "completion_tokens")),
    )


def latency_ms_from_kwargs(kwargs: dict) -> Optional[float]:
    """Latency in ms from ``api_duration`` (seconds) or explicit ``latency_ms``."""
    if not isinstance(kwargs, dict):
        return None
    explicit = kwargs.get("latency_ms")
    if isinstance(explicit, (int, float)) and not isinstance(explicit, bool) and explicit >= 0:
        return float(explicit)
    duration = kwargs.get("api_duration")
    if isinstance(duration, (int, float)) and not isinstance(duration, bool) and duration >= 0:
        return round(duration * 1000.0, 3)
    started, ended = kwargs.get("started_at"), kwargs.get("ended_at")
    if isinstance(started, (int, float)) and isinstance(ended, (int, float)):
        delta = (ended - started) * 1000.0
        if delta >= 0:
            return round(delta, 3)
    return None


def ttft_ms_from_kwargs(kwargs: dict) -> Optional[float]:
    """Time-to-first-token in ms from ``first_chunk_at - started_at`` (seconds)."""
    if not isinstance(kwargs, dict):
        return None
    explicit = kwargs.get("ttft_ms")
    if isinstance(explicit, (int, float)) and not isinstance(explicit, bool) and explicit >= 0:
        return float(explicit)
    started = kwargs.get("started_at")
    first_chunk = kwargs.get("first_chunk_at")
    if isinstance(started, (int, float)) and isinstance(first_chunk, (int, float)):
        delta = (first_chunk - started) * 1000.0
        if delta >= 0:
            return round(delta, 3)
    return None


def status_from_kwargs(kwargs: dict, *, default: str = "success") -> str:
    """Terminal status from a hook payload (``error`` / ``status_code`` win)."""
    if not isinstance(kwargs, dict):
        return default
    if kwargs.get("error") is not None:
        return "error"
    status = kwargs.get("status_code") or kwargs.get("status")
    if isinstance(status, bool):
        status = None
    if isinstance(status, int):
        return "success" if 200 <= status < 300 else "error"
    if isinstance(status, str):
        lowered = status.strip().lower()
        if lowered in ("success", "succeeded", "ok", "2xx"):
            return "success"
        if lowered in ("error", "failed", "failure", "4xx", "5xx"):
            return "error"
        if lowered == "canceled":
            return "canceled"
    return default


def error_parts(kwargs: dict) -> tuple[Optional[str], Optional[str]]:
    """Return (error_type, message) from ``error`` dict / flat fields."""
    if not isinstance(kwargs, dict):
        return None, None
    err = kwargs.get("error")
    if isinstance(err, dict):
        return str(err.get("type")) if err.get("type") is not None else None, \
            str(err.get("message")) if err.get("message") is not None else None
    if isinstance(err, str) and err:
        return None, err
    error_type = kwargs.get("error_type")
    message = kwargs.get("error_message") or kwargs.get("error")
    return (
        str(error_type) if error_type is not None else None,
        str(message) if isinstance(message, str) and message else None,
    )


def agent_id_from_kwargs(kwargs: dict) -> Optional[str]:
    """Stable hashed agent bucket from ``session_id`` (first 12 hex chars of
    SHA-256). The raw session id is never persisted."""
    if not isinstance(kwargs, dict):
        return None
    session = kwargs.get("session_id")
    if not isinstance(session, str) or not session.strip():
        return None
    return hashlib.sha256(session.strip().encode("utf-8")).hexdigest()[:12]


def redact_key_scope(raw: Any) -> str:
    """Hash an opaque credential label for analytics grouping. Raw secrets are
    never stored: str -> ``"k_" + sha256[:12]``; empty/unknown -> ``""``."""
    if not isinstance(raw, str):
        return ""
    text = raw.strip()
    if not text or text.lower() in ("unknown", "default", "none"):
        return ""
    return "k_" + hashlib.sha256(text.encode("utf-8")).hexdigest()[:12]


# ---------------------------------------------------------------------------
# Bounded ingestion contract (unsupported host callbacks)
# ---------------------------------------------------------------------------

# Hermes does NOT supply cache events, search events or client IP / User-Agent.
# Compatible builds optionally supply opaque credential-entry scope on request
# hooks; it is separate from this explicit bounded ingestion contract.
# These callables accept the bounded event
# shape ONLY from an explicit caller (e.g. a test or a future Hermes
# callback). Production hook paths never call them with fabricated data, so
# the corresponding analytics sections stay ``observed: false`` until a real
# producer exists. This is the exact missing host-callback contract.

BOUNDED_INGESTION_KEYS = (
    "cache_event",
    "search_event",
    "credential_scope_event",
    "token_adjustment",
)


def ingest_bounded_event(kind: str, payload: dict) -> dict[str, Any]:
    """Validate a bounded ingestion payload. Returns a normalized dict or
    raises ``ValueError``. Never synthesizes production data."""
    if kind not in BOUNDED_INGESTION_KEYS:
        raise ValueError(f"unknown bounded ingestion kind: {kind!r}")
    if not isinstance(payload, dict):
        raise ValueError("payload must be a dict")

    if kind == "cache_event":
        hit = payload.get("hit")
        if not isinstance(hit, bool):
            raise ValueError("cache_event requires boolean 'hit'")
        latency = payload.get("latency_ms")
        if latency is not None and (not isinstance(latency, (int, float)) or isinstance(latency, bool) or latency < 0):
            raise ValueError("cache_event latency_ms must be a non-negative number")
        return {
            "kind": kind,
            "provider": str(payload.get("provider") or "")[:80] or None,
            "model": str(payload.get("model") or "")[:160] or None,
            "hit": hit,
            "latency_ms": round(float(latency), 3) if latency is not None else None,
        }
    if kind == "search_event":
        latency = payload.get("latency_ms")
        results = payload.get("results_count")
        if latency is not None and (not isinstance(latency, (int, float)) or isinstance(latency, bool) or latency < 0):
            raise ValueError("search_event latency_ms must be a non-negative number")
        if results is not None and (not isinstance(results, int) or isinstance(results, bool) or results < 0):
            raise ValueError("search_event results_count must be a non-negative int")
        return {
            "kind": kind,
            "provider": str(payload.get("provider") or "")[:80] or None,
            "query_length": payload.get("query_length") if isinstance(payload.get("query_length"), int) else None,
            "latency_ms": round(float(latency), 3) if latency is not None else None,
            "results_count": results,
        }
    if kind == "credential_scope_event":
        raw_scope = payload.get("key_scope", "")
        if not isinstance(raw_scope, str):
            raise ValueError("credential_scope_event key_scope must be a string")
        auth_ok = payload.get("auth_ok")
        if auth_ok is not None and not isinstance(auth_ok, bool):
            raise ValueError("credential_scope_event auth_ok must be a boolean or null")
        return {
            "kind": kind,
            "provider": str(payload.get("provider") or "")[:80] or None,
            "key_scope_hash": redact_key_scope(raw_scope),
            "auth_ok": auth_ok,
            "reason": str(payload.get("reason") or "")[:120] or None,
        }
    # token_adjustment: explicit correction of a previously recorded usage.
    for name in ("input_tokens", "output_tokens"):
        value = payload.get(name)
        if value is not None and (not isinstance(value, int) or isinstance(value, bool) or value < 0):
            raise ValueError(f"token_adjustment {name} must be a non-negative int or null")
    return {
        "kind": kind,
        "api_request_id": str(payload.get("api_request_id") or "")[:128] or None,
        "input_tokens": payload.get("input_tokens"),
        "output_tokens": payload.get("output_tokens"),
    }


def host_observation_matrix() -> dict[str, list[dict[str, str]]]:
    """Supported vs unsupported Hermes host-observation matrix."""
    return {
        "supported": [
            {"measurement": "provider / model / response_model", "source": "pre/post_api_request kwargs"},
            {"measurement": "request latency (api_duration)", "source": "post_api_request / api_request_error kwargs"},
            {"measurement": "TTFT (first_chunk_at - started_at)", "source": "post_api_request kwargs (streaming only)"},
            {"measurement": "token consumption (usage dict)", "source": "post_api_request kwargs"},
            {"measurement": "error classification (status_code / reason / error)", "source": "api_request_error + post_api_request kwargs"},
            {"measurement": "agent breakdown (hashed session bucket)", "source": "session_id / task_id / turn_id kwargs"},
            {"measurement": "execution attempts (retry_count / api_call_count)", "source": "pre/api_request_error kwargs"},
            {"measurement": "opaque credential-entry scope (optional)", "source": "structured credential_scope on pre/post/error hooks; requires a compatible Hermes build and llm.credential_scope consent; absent/unknown stays unknown"},
        ],
        "unsupported": [
            {"measurement": "client IP / User-Agent", "missing_callback": "Hermes supplies no client_ip / client_user_agent field on any api hook"},
            {"measurement": "raw credential identity", "missing_callback": "Raw keys and billing-account identity are not exposed; optional opaque entry scopes do not establish account equivalence or an authenticated quota collector"},
            {"measurement": "prompt-cache hits", "missing_callback": "No cache_event hook; bounded ingestion contract only"},
            {"measurement": "search backend observations", "missing_callback": "No search_event hook; bounded ingestion contract only"},
            {"measurement": "dollar cost / savings", "missing_callback": "No pricing feed; dashboard reports counts only"},
        ],
    }
