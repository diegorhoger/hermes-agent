"""Bounded read-only projection of canonical decisions; no selection or authority."""

import math
import re
from urllib.parse import urlsplit

VERSION = 1
MAX_CANDIDATES = 500
_ACTIONS = {
    "cost_not_verified_free": "refresh_public_evidence",
    "context_unknown_or_insufficient": "review_context_requirement",
    "tools_unverified_or_unsupported": "review_tool_requirement",
    "tools_forbidden": "review_tool_requirement",
    "provider_disabled": "review_provider_configuration",
    "auth_failed": "review_credentials_in_hermes",
    "cooldown": "wait_for_cooldown",
    "circuit_open": "wait_for_cooldown",
    "retired": "choose_another_model",
    "unavailable": "choose_another_model",
    "verified_account_quota_exhausted": "wait_for_authoritative_quota_refresh",
    "fresh_account_allowance_required": "obtain_supported_host_allowance_evidence",
    "connection_authority_unavailable": "obtain_supported_host_authority",
    "connection_restriction_mismatch": "review_connection_requirements",
    "no_charge_guarantee_unverified": "do_not_execute_without_enforceable_boundary",
    "selection_policy_invalid": "correct_explicit_requirements",
    "policy_invalid": "choose_supported_policy",
    "concurrency_limit": "wait_for_available_slot",
}


_GATE_REASONS = {
    "verified_free_price": {"cost_not_verified_free"},
    "context": {"context_unknown_or_insufficient"},
    "tools": {"tools_unverified_or_unsupported", "tools_forbidden"},
    "availability_health": {
        "unavailable",
        "retired",
        "auth_failed",
        "cooldown",
        "health_invalid",
        "health_observation_required",
    },
    "provider_exclusions": {"provider_disabled", "excluded"},
    "concurrency": {"concurrency_limit"},
    "connection": {
        "connection_authority_unavailable",
        "connection_restriction_mismatch",
        "connection_model_scope_unavailable",
    },
    "quota": {
        "verified_account_quota_exhausted",
        "fresh_account_allowance_required",
        "quota_policy_denied",
        "no_charge_guarantee_unverified",
    },
    "contract": {"policy_invalid", "selection_policy_invalid"},
}


def _checks(reasons):
    return [
        dict(
            name=name,
            result="denied" if codes.intersection(reasons) else "not_rejected",
            reason_codes=sorted(codes.intersection(reasons)),
        )
        for name, codes in _GATE_REASONS.items()
    ]


def _identity(value):
    if (
        not isinstance(value, str)
        or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}", value) is None
        or re.search(
            r"(?i)(sk[-_]|bearer|api[_-]?key|scope_[0-9a-f]+|[0-9a-f]{32,})", value
        )
    ):
        return "[redacted_identity]"
    return value


def _number(value):
    return (
        value
        if type(value) in (int, float) and math.isfinite(value) and value >= 0
        else None
    )


def _source(value):
    # Stored source strings may contain query credentials or diagnostics. Only
    # known public catalog endpoints and fixed synthetic labels are serialized.
    from ..discovery.adapters import SPECS
    from ..discovery.metadata import OPENROUTER

    urls = {
        OPENROUTER,
        "https://openrouter.ai/api/v1/key",
        *(spec[0] for spec in SPECS.values()),
    }
    if isinstance(value, str) and value in urls:
        parsed = urlsplit(value)
        if not parsed.query and not parsed.fragment and not parsed.username:
            return value
    if isinstance(value, str) and value in (
        "controlled-test-fixture",
        "fixture",
        "isolated synthetic fixture",
    ):
        return "synthetic_fixture"
    return "unknown"


def fields(evidence, now):
    from ..discovery.metadata import valid_evidence

    evidence = evidence if isinstance(evidence, dict) else {}
    result = {}
    for name in ("cost_tier", "context_window", "tools"):
        row = evidence.get(name)
        row = row if isinstance(row, dict) else {}
        start, end = _number(row.get("retrieved_at")), _number(row.get("expires_at"))
        result[name] = dict(
            source=_source(row.get("metadata_source")),
            retrieved_at=start,
            expires_at=end,
            freshness="fresh"
            if valid_evidence(row, now)
            else "expired"
            if end is not None and end <= now
            else "unknown",
            basis="advertised_capability",
            execution_entitlement="unknown",
        )
    return result


def _metrics(score, now, attribution):
    if not isinstance(score, dict):
        return None
    from ..routing.scoring import observation_coverage

    obs = score.get("observations") or {}
    available = (
        obs.get("available") is True and obs.get("source") == "observed_final_requests"
    )
    factors = {}
    for name in ("reliability", "speed", "semantic_quality", "cooldown", "tools"):
        row = (score.get("factors") or {}).get(name) or {}
        factors[name] = {
            key: _number(row.get(key)) for key in ("value", "weight", "contribution")
        }
    return dict(
        total=_number(score.get("total")),
        factors=factors,
        observations={
            key: _number(obs.get(key)) if available else None
            for key in (
                "samples",
                "effective_samples",
                "confidence",
                "latency_confidence",
                "latency_samples",
                "last_observed_at",
                "last_latency_observed_at",
                "latency_ewma_ms",
                "latency_p50_ms",
                "latency_p95_ms",
            )
        },
        source="observed_final_requests" if available else "unknown",
        measurement_state="unavailable"
        if not available
        else "observed"
        if obs.get("samples")
        else "cold_start",
        measurement_boundary="host-observed final request; not a semantic benchmark",
        semantic_quality="unknown",
        coverage=observation_coverage(obs, now=now, attribution=attribution),
    )


def _windows(quota):
    from ..evidence.quota import DIMENSIONS, WINDOWS, decimal_value

    result = []
    for row in (quota.get("evidence") or [])[:32]:
        if not isinstance(row, dict):
            continue
        result.append(
            dict(
                dimension=row.get("dimension")
                if row.get("dimension") in DIMENSIONS
                else "unknown",
                window=row.get("window") if row.get("window") in WINDOWS else "unknown",
                remaining=str(decimal_value(row.get("remaining")))
                if decimal_value(row.get("remaining")) is not None
                else None,
                limit=str(decimal_value(row.get("limit")))
                if decimal_value(row.get("limit")) is not None
                else None,
                source=_source(row.get("source_url")),
                basis="observed"
                if row.get("source") in ("provider_api", "mapped_headers")
                else "estimated"
                if row.get("source") == "estimated"
                else "unknown",
                observed_at=_number(row.get("observed_at")),
                expires_at=_number(row.get("expires_at")),
                reset_at=_number(row.get("reset_at")),
                grant_expires_at=_number(row.get("grant_expires_at")),
                currency=row.get("currency")
                if isinstance(row.get("currency"), str)
                and re.fullmatch(r"[A-Z]{3}", row["currency"])
                else None,
            )
        )
    return result


def build(decision, *, schema_version=VERSION):
    """Project an already evaluated decision; never re-evaluate eligibility/scoring."""
    if type(schema_version) is not int or schema_version != VERSION:
        raise ValueError("decision_report_version_unsupported")
    from ..routing.router import REASONS
    from ..configuration.policies import resolve

    now = decision["generated_at"]
    selected = decision.get("chosen")
    profile = decision.get("task_profile")
    contract = decision.get("selection_policy") or {}
    task = contract.get("task_requirements") or {}
    constraints = decision.get("constraints") or {}
    candidates = []
    projected = decision.get("considered", [])[:MAX_CANDIDATES]
    if selected and not any(
        (row["provider"], row["model"]) == (selected["provider"], selected["model"])
        for row in projected
    ):
        # Reserve an existing display slot for the canonical winner's full evidence.
        projected = projected[:-1] + [selected]
    for row in projected:
        reasons = [r for r in row.get("reason_codes", []) if r in REASONS]
        quota = row.get("quota_policy_evidence") or {}
        access = row.get("free_access") or {}
        if (
            not quota
            or "verified_account_quota_exhausted" in reasons
            and quota.get("state") != "exhausted"
        ):
            quota = dict(
                quota,
                state="exhausted"
                if "verified_account_quota_exhausted" in reasons
                else access.get("state", "unknown"),
                allowed=False
                if "verified_account_quota_exhausted" in reasons
                else access.get("allowed"),
                evidence=access.get("quota_evidence", []),
                evaluator_available=access.get("state")
                in ("healthy", "approaching_limit", "exhausted"),
            )
        scope = (
            "authorized_observation"
            if row.get("connection_authority") == "authorized_observation"
            else "unknown"
        )
        proof = fields(row.get("field_evidence"), now)
        candidates.append(
            dict(
                provider=_identity(row["provider"]),
                model=_identity(row["model"]),
                eligible=row["eligible"] is True,
                reason_codes=reasons,
                reasons=[REASONS[r] for r in reasons],
                next_actions=sorted(
                    {
                        _ACTIONS.get(r, "inspect_evidence_and_requirements")
                        for r in reasons
                    }
                ),
                hard_gates=dict(
                    result="passed" if row["eligible"] else "denied",
                    checks=_checks(reasons),
                    meaning="canonical checks; not_rejected is not independent proof of an unknown fact",
                    mandatory_verified_free_only=True,
                    capability_evidence=proof,
                ),
                active_connection=dict(state=scope, execution_authority=False),
                health_guidance=row.get("health_guidance"),
                health=dict(
                    state=row.get("health_reason")
                    if row.get("health_reason") in REASONS
                    or row.get("health_reason") == "available"
                    else "unknown",
                    scope="known" if row.get("scope_state") == "known" else "unknown",
                    circuit=row.get("circuit_state")
                    if row.get("circuit_state") in ("open", "closed", "half_open")
                    else "unknown",
                    basis="observed"
                    if row.get("health_reason") == "available"
                    else "unknown_or_denied",
                ),
                quota=dict(
                    policy=quota.get("quota_policy"),
                    state=quota.get("state", "unknown"),
                    allowed=quota.get("allowed")
                    if type(quota.get("allowed")) is bool
                    else None,
                    basis="observed"
                    if quota.get("evaluator_available") is True
                    else "unknown",
                    freshness="original window timestamps; see sanitized quota evidence",
                    guaranteed_no_charge=False,
                    windows=_windows(quota),
                ),
                ranking=_metrics(
                    row.get("score"),
                    now,
                    (row.get("score") or {}).get("coverage", {}).get("attribution"),
                ),
            )
        )
    try:
        policy = resolve(decision.get("policy"))
        policy_id = policy["id"]
    except ValueError:
        policy_id = None
    actions = sorted({a for c in candidates for a in c["next_actions"]})
    if not candidates:
        actions = [
            "correct_explicit_requirements"
            if decision.get("contract_error")
            else "refresh_public_evidence"
        ]
    return dict(
        schema_version=VERSION,
        generated_at=_number(now),
        recommendation=dict(
            provider=_identity(selected["provider"]), model=_identity(selected["model"])
        )
        if selected
        else None,
        policy=dict(schema_version=1, id=policy_id, verified_free_only=True),
        task=dict(
            schema_version=task.get("schema_version"),
            profile_id=profile["id"] if profile else None,
            profile_version=profile["schema_version"] if profile else None,
            semantic_quality="unknown",
        ),
        requirements=dict(
            requires_tools=constraints.get("requires_tools"),
            min_context=constraints.get("min_context"),
            strict_no_charge=constraints.get("strict_no_charge"),
        ),
        selection_requirements=contract or None,
        outcome="recommended" if selected else "no_match",
        no_match=decision.get("no_match"),
        contract_error=decision.get("contract_error"),
        evidence_availability="available" if candidates else "absent",
        candidates=candidates,
        total_considered=decision["total_considered"],
        eligible_count=decision["eligible_count"],
        truncated=decision["truncated"],
        next_actions=actions if not selected else ["deliberate_hermes_handoff"],
        execution_authority=False,
        semantic_quality="unknown",
        limitations=[
            "catalog evidence is not live entitlement",
            "quota observations are not reservations",
            "unknown is not zero or healthy",
            "no semantic benchmark",
            "no automatic execution or replay",
        ],
    )


def unavailable(code, now):
    """Unavailable is distinct from an evaluated empty catalog or a healthy state."""
    if code not in ("database_missing", "database_unreadable", "evidence_unavailable"):
        code = "evidence_unavailable"
    return dict(
        schema_version=VERSION,
        generated_at=_number(now),
        outcome="unavailable",
        recommendation=None,
        evidence_availability=code,
        candidates=[],
        execution_authority=False,
        semantic_quality="unknown",
        next_actions=[
            "initialize_plugin_state"
            if code == "database_missing"
            else "inspect_plugin_storage_without_overwriting"
        ],
    )
