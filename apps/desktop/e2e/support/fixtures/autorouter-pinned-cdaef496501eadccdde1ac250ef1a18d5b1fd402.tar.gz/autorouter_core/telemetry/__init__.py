"""AutoRouter telemetry package."""
