"""Consume the optional host quota contract; never resolve credentials."""
import math
import time
from . import free_access
from .credential_scope import observed_scope


def observe(state, payload):
    if payload.get("provider") != "openrouter":
        return
    ctx = state.get("ctx")
    if ctx is None or not callable(getattr(ctx, "quota_fetch", None)):
        return
    if not ctx.get_config("scope_bound_quota", False):
        return
    scope = observed_scope(payload.get("provider"), payload.get("credential_scope"))
    if not scope or not isinstance(payload.get("credential_scope"), dict):
        return
    store = state.get("store")
    if store is None:
        return
    # Commit the shared SQLite lease before host I/O; failures keep the cooldown.
    canonical = free_access.canonical_scope(scope)
    _, reserved = free_access._reserve_refresh(store, "openrouter", canonical,
        time.time(), interval=free_access.TTL)
    if not reserved:
        return
    # Stay in this callback: moving to a worker would lose attempt authorization.
    # The supported private host bounds collection at two seconds, including failure.
    # A last-observed account is not authority for a future pool selection.
    try:
        result = ctx.quota_fetch(provider_id=payload["provider"],
            credential_scope_id=payload["credential_scope"]["credential_scope_id"], quota_source="official_key_limits")
    except Exception:
        # Do not let optional host failures stop inference or expose exception data.
        free_access.invalidate_cached(store, "openrouter", scope, 503)
        return
    if not ingest(store, "openrouter", scope, result):
        free_access.invalidate_cached(store, "openrouter", scope, 503)


def ingest(store, provider, scope, result):
    if (store is None or provider != "openrouter" or not isinstance(result, dict)
            or result.get("status") != "ok" or result.get("provider_id") != provider
            or scope != provider + ":" + str(result.get("credential_scope_id"))
            or result.get("quota_source") != "official_key_limits"):
        return False
    observed, expires = result.get("observed_at"), result.get("expires_at")
    now = time.time()
    if (any(type(v) not in (int, float) or not math.isfinite(v) for v in (observed, expires))
            or not observed <= now < expires <= observed + free_access.TTL):
        return False
    values = [result.get(k) for k in ("limit", "remaining", "used")]
    if any(type(v) is not int or v < 0 for v in values) or values[1] + values[2] != values[0]:
        return False
    canonical = free_access.canonical_scope(scope)
    evidence = free_access.normalize_openrouter_quota({"data": {"free_model_daily_requests":
        dict(zip(("limit", "remaining", "used"), values))}}, canonical, observed)
    if not evidence:
        return False
    evidence[0]["expires_at"] = expires
    # An older concurrent callback must not overwrite a newer observation.
    with free_access._LOCK:
        old = free_access.read_snapshot(store, provider, canonical)
        if any(row.get("observed_at", 0) > observed for row in old["quota_evidence"]):
            return False
        snapshot = free_access.FreeAccessSnapshot(provider, canonical, quota_evidence=evidence,
            state="exhausted" if values[1] == 0 else "healthy",
            next_refresh_at=max(old["next_refresh_at"], observed + free_access.MIN_REFRESH)).to_dict()
        free_access._save(store, snapshot)
    return True
