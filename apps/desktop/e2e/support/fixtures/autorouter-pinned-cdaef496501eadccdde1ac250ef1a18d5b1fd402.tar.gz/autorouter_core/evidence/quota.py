"""Descriptive quota evidence and conservative projections, never eligibility proof.

Records live in capability JSON alongside access evidence. Advertised limits,
account observations and estimates are distinct; no network or billing is performed.
"""
from decimal import Decimal, InvalidOperation
from fractions import Fraction
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import math
import re
from .evidence import fresh

DIMENSIONS = frozenset({'input_tokens', 'output_tokens', 'aggregate_tokens', 'requests', 'credits'})
SOURCES = frozenset({'advertised', 'provider_api', 'mapped_headers', 'configured', 'estimated', 'unknown'})
WINDOWS = frozenset({'minute', 'day', 'month', 'one_time', 'unknown'})


def decimal_value(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        text = str(value)
        if len(text) > 128:
            return None
        result = Decimal(text)
        return result if result.is_finite() and result >= 0 and abs(result.as_tuple().exponent) <= 30 and result <= Decimal("1e30") else None
    except (InvalidOperation, ValueError, TypeError):
        return None


def normalize_quota(record):
    """Allowlist JSON metadata without inventing availability, reset or recurrence."""
    if not isinstance(record, dict):
        return {}
    fields = ('provider', 'model', 'account_scope', 'shared_scope', 'dimension', 'limit',
              'remaining', 'currency', 'window', 'reset_at', 'timezone', 'rollover',
              'grant_expires_at', 'signup_required', 'kyc_required', 'source',
              'source_url', 'source_type', 'issuer', 'source_of_truth', 'observed_at',
              'expires_at', 'confidence', 'spendable', 'state')
    out = {key: record.get(key) for key in fields}
    if not isinstance(out['dimension'], str) or out['dimension'] not in DIMENSIONS:
        out['dimension'] = 'unknown'
    if not isinstance(out['source'], str) or out['source'] not in SOURCES:
        out['source'] = 'unknown'
    if not isinstance(out['window'], str) or out['window'] not in WINDOWS:
        out['window'] = 'unknown'
    for key in ('limit', 'remaining'):
        value = decimal_value(out[key])
        out[key] = str(value) if value is not None else None
        if record.get(key) is not None and value is None:
            out['state'] = 'unknown'
    if out['timezone'] is not None:
        try:
            ZoneInfo(out['timezone'])
        except (ZoneInfoNotFoundError, ValueError, TypeError):
            out['timezone'] = None
    # A one-time grant is never a recurring monthly allowance.
    if out['window'] == 'one_time':
        out['rollover'] = False
    return out


def quota_status(record, now):
    """Only fresh account observations describe operational remaining allowance."""
    if not isinstance(record, dict):
        return 'unknown'
    for key in ('grant_expires_at', 'reset_at'):
        value = record.get(key)
        if value is not None and (type(value) not in (int, float) or not math.isfinite(value) or value <= 0):
            return 'unknown'
    for key in ('limit', 'remaining'):
        if record.get(key) is not None and decimal_value(record[key]) is None:
            return 'unknown'
    for key in ('provider', 'account_scope'):
        if not isinstance(record.get(key), str) or not record[key].strip():
            return 'unknown'
    for key in ('model', 'shared_scope'):
        if record.get(key) is not None and (not isinstance(record[key], str) or not record[key].strip()):
            return 'unknown'
    record = normalize_quota(record)
    if not record or record['dimension'] == 'unknown' or record['window'] == 'unknown':
        return 'unknown'
    if not fresh(record, now):
        return 'unknown'
    grant_end = record.get('grant_expires_at')
    if isinstance(grant_end, (int, float)) and grant_end <= now:
        return 'expired'
    reset = record.get('reset_at')
    if isinstance(reset, (int, float)) and reset <= now:
        return 'unknown'  # Do not assume a reset happened or replenish the balance.
    if record['dimension'] == 'credits' and (not isinstance(record['currency'], str) or not re.fullmatch(r'[A-Z]{3}', record['currency'])):
        return 'unknown'
    if record['source'] not in ('provider_api', 'mapped_headers') or not record['account_scope']:
        return 'unknown'
    remaining = decimal_value(record['remaining'])
    if remaining is None:
        return 'unknown'
    limit = decimal_value(record['limit'])
    if limit is not None and remaining > limit:
        return 'unknown'
    state = record.get('state')
    if state is not None:
        if state not in ('healthy', 'available', 'approaching_limit', 'exhausted'):
            return 'unknown'
        if (state == 'exhausted') != (remaining == 0):
            return 'unknown'
    return 'exhausted' if remaining == 0 else 'available'


def estimate_credit_tokens(credit, pricing, *, input_share, workload_source, now):
    """Floor credit/(input share*input price + output share*output price).

    Prices are per-token, not per million tokens. Extra billable charges make
    this projection unavailable. This result never changes free-only routing.
    """
    unknown = {'state': 'unknown', 'tokens': None, 'kind': 'estimate'}
    observed_status = quota_status(credit, now)
    credit = normalize_quota(credit)
    if not credit or not isinstance(pricing, dict) or not fresh(credit, now) or not fresh(pricing, now):
        return unknown
    if credit['dimension'] != 'credits' or credit['spendable'] is not True:
        return unknown
    if observed_status not in ('available', 'exhausted'):
        return unknown
    if (pricing.get('scope') != 'model' or pricing.get('provider') != credit['provider']
            or not pricing.get('model') or pricing.get('currency') != credit['currency']
            or not credit['currency'] or pricing.get('account_scope') not in (None, credit['account_scope'])
            or credit['model'] not in (None, pricing.get('model'))):
        return unknown
    prices = pricing.get('prices')
    if not isinstance(prices, dict) or not {'prompt', 'completion'} <= prices.keys():
        return unknown
    values = {key: decimal_value(value) for key, value in prices.items()}
    if any(value is None for value in values.values()) or any(value != 0 for key, value in values.items() if key not in ('prompt', 'completion')):
        return unknown
    share = decimal_value(input_share)
    if share is None or share > 1 or not isinstance(workload_source, str) or not workload_source.strip():
        return unknown
    rate = Fraction(share) * Fraction(values['prompt']) + (1-Fraction(share)) * Fraction(values['completion'])
    if rate <= 0:
        return unknown  # Zero price does not imply infinite allowance.
    balance = decimal_value(credit['remaining'])
    validity = [credit['expires_at'], pricing['expires_at']]
    validity.extend(credit[key] for key in ('grant_expires_at', 'reset_at') if credit.get(key) is not None)
    return dict(state='estimated', kind='estimate', tokens=Fraction(balance) // rate,
                formula='floor(spendable_credit / (input_share * input_price_per_token + (1-input_share) * output_price_per_token))',
                currency=credit['currency'], spendable_credit=str(balance), input_share=str(share),
                input_price_per_token=str(values['prompt']), output_price_per_token=str(values['completion']),
                workload_source=workload_source, recurring=False if credit['window'] == 'one_time' else None,
                observed_at=credit['observed_at'], pricing_observed_at=pricing['observed_at'],
                credit_source_url=credit['source_url'], pricing_source_url=pricing['source_url'],
                expires_at=min(validity))


def merge_quota_evidence(new, previous):
    """Replace only matching dimensions/scopes/sources; retain original other ages."""
    if not isinstance(new, list):
        return new
    if not isinstance(previous, list):
        return new
    keys = ('provider', 'model', 'account_scope', 'shared_scope', 'dimension',
            'window', 'source_url', 'source_type', 'issuer')
    def identity(record):
        return {key: record.get(key) for key in keys} if isinstance(record, dict) else None
    identities = [identity(record) for record in new]
    return [record for record in previous if identity(record) is None or identity(record) not in identities] + new
