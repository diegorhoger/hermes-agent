"""Decode host observations without resolving credentials or a current account."""
from __future__ import annotations

import re


def observed_scope(provider, metadata):
    """Return a provider-bound opaque reference, or empty for unknown identity.

    Hermes' optional llm.credential_scope hook field is a structured object.
    Explicit legacy string references remain supported for existing callers.
    Neither form establishes billing-account equivalence or authorizes polling.
    """
    if isinstance(metadata, str):
        value = metadata.strip()
        return value if value.lower() not in ("", "unknown", "default", "none", "scope_unknown") else ""
    if not isinstance(metadata, dict) or set(metadata) != {
        "provider_id", "credential_scope_id", "identity_status"
    }:
        return ""
    identity = metadata["credential_scope_id"]
    if (not isinstance(provider, str) or not provider or len(provider) > 128
            or metadata["provider_id"] != provider
            or metadata["identity_status"] != "known"
            or not isinstance(identity, str)
            or re.fullmatch(r"[0-9a-f]{32}", identity) is None):
        return ""
    return f"{provider}:{identity}"
