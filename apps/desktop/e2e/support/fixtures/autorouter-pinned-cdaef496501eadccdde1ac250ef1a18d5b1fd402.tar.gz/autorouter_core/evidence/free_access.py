"""Opt-in, cached connection quota observations; never intercepts inference."""
from dataclasses import asdict, dataclass, field
import json
import math
import threading
import time
from .quota import decimal_value, normalize_quota, quota_status

ENDPOINT = 'https://openrouter.ai/api/v1/key'
MIN_REFRESH = 60
TTL = 120
_LOCK = threading.Lock()


@dataclass
class FreeAccessSnapshot:
    provider: str
    account_scope: str
    quota_evidence: list[dict] = field(default_factory=list)
    state: str = 'unknown'
    hard_stop_guaranteed: bool = False
    verified_no_charge_execution: bool = False
    error_category: str | None = None
    next_refresh_at: float = 0

    def to_dict(self):
        return asdict(self)


def canonical_scope(raw):
    # Shared with scoped health once available; no inferred account identity.
    from ..health.health import scope_id
    if raw in (None, '', 'unknown', 'scope_unknown'):
        return ''
    return scope_id(raw)


def _row_model(scope):
    return '__quota__:' + scope


def _safe_observation(record, provider, scope):
    if (not isinstance(record, dict) or provider != 'openrouter'
            or record.get('provider') != provider or record.get('account_scope') != scope
            or record.get('source_url') != ENDPOINT or record.get('source') != 'provider_api'
            or record.get('source_type') != 'provider_api' or record.get('issuer') != 'openrouter'
            or record.get('dimension') != 'requests'
            or record.get('window') != 'day'):
        return None
    def timestamp(key):
        value = record.get(key)
        return value if type(value) in (int,float) and math.isfinite(value) else None
    return normalize_quota(dict(provider=provider, model=None, account_scope=scope,
        shared_scope=scope, dimension='requests', limit=record.get('limit'),
        remaining=record.get('remaining'), window='day', timezone='UTC',
        source='provider_api', source_type='provider_api', source_url=ENDPOINT,
        issuer='openrouter', source_of_truth=record.get('source_of_truth') is True,
        observed_at=timestamp('observed_at'), expires_at=timestamp('expires_at'),
        confidence=1.0 if record.get('source_of_truth') is True else None,
        state=record.get('state') if record.get('state') in ('healthy','approaching_limit','exhausted','unavailable','unknown') else 'unknown'))


def _unknown_window(raw):
    """Retain a required unknown window without retaining untrusted diagnostics."""
    from .quota import DIMENSIONS, WINDOWS
    raw = raw if isinstance(raw, dict) else {}
    return dict(dimension=raw.get('dimension') if isinstance(raw.get('dimension'), str) and raw['dimension'] in DIMENSIONS else 'unknown',
                window=raw.get('window') if isinstance(raw.get('window'), str) and raw['window'] in WINDOWS else 'unknown',
                state='unknown', source_supported=False)


def _decode_snapshot(row, provider, scope):
    try:
        result = json.loads(row['capability_json']) if row else {}
        if result.get('provider') == provider and result.get('account_scope') == scope:
            clean = {key: result.get(key, default) for key, default in FreeAccessSnapshot(provider, scope).to_dict().items()}
            clean['quota_evidence'] = [_safe_observation(row,provider,scope) or _unknown_window(row) for row in clean['quota_evidence']] if isinstance(clean['quota_evidence'],list) else []
            if clean['state'] not in ('healthy','approaching_limit','exhausted','unavailable','unknown'):
                clean['state'] = 'unknown'
            if not any(_safe_observation(row, provider, scope) is not None for row in clean['quota_evidence']) and clean['state'] in ('healthy','approaching_limit','exhausted'):
                clean['state']='unknown'
            next_time=clean['next_refresh_at']
            if type(next_time) not in (int,float) or not math.isfinite(next_time):
                clean['next_refresh_at']=0
            clean['hard_stop_guaranteed'] = False
            clean['verified_no_charge_execution'] = False
            if clean['error_category'] not in (None, 'auth_unavailable', 'rate_limited', 'metadata_unavailable', 'state_unavailable'):
                clean['error_category'] = None
            return clean
    except Exception:
        pass
    return FreeAccessSnapshot(provider, scope).to_dict()


def read_snapshot(store, provider, account_scope):
    scope = canonical_scope(account_scope)
    if not scope or store is None:
        return FreeAccessSnapshot(provider, scope).to_dict()
    try:
        return _decode_snapshot(store.get_capability(provider,_row_model(scope)),provider,scope)
    except Exception:
        return FreeAccessSnapshot(provider,scope).to_dict()


def _reserve_refresh(store, provider, scope, now, *, interval=MIN_REFRESH):
    """SQLite serializes refresh leases across threads and independent processes."""
    conn=store._connect()
    try:
        conn.execute('BEGIN IMMEDIATE')
        row=conn.execute('SELECT capability_json FROM capabilities WHERE provider=? AND model=?',
                         (provider,_row_model(scope))).fetchone()
        old=_decode_snapshot(row,provider,scope)
        if now < old['next_refresh_at']:
            return old,False
        pending=dict(old,next_refresh_at=now+interval)
        conn.execute("""INSERT INTO capabilities(provider,model,capability_json,metadata_source,retrieved_at,expires_at,version)
            VALUES(?,?,?,?,0,0,1) ON CONFLICT(provider,model) DO UPDATE SET capability_json=excluded.capability_json""",
            (provider,_row_model(scope),json.dumps(pending),ENDPOINT))
        conn.commit()
        return pending,True
    finally:
        conn.close()

def _save(store, snapshot):
    store.upsert_capability(snapshot['provider'], _row_model(snapshot['account_scope']),
                            json.dumps(snapshot), metadata_source=ENDPOINT,
                            retrieved_at=min((record.get('observed_at',0) for record in snapshot['quota_evidence']),default=0), expires_at=0)


def normalize_openrouter_quota(payload, scope, now):
    """Only documented free-model request counters; spend caps are not allowance."""
    data = payload.get('data') if isinstance(payload, dict) else None
    row = data.get('free_model_daily_requests') if isinstance(data, dict) else None
    if not isinstance(row, dict):
        return []
    values = [decimal_value(row.get(key)) for key in ('limit','remaining','used')]
    if any(value is None or value != value.to_integral_value() for value in values):
        return []
    limit, remaining, used = map(int, values)
    if remaining > limit or used > limit or remaining + used != limit:
        return []
    return [normalize_quota(dict(provider='openrouter', model=None, account_scope=scope,
        shared_scope=scope, dimension='requests', limit=str(limit), remaining=str(remaining),
        window='day', timezone='UTC', source='provider_api', source_type='provider_api',
        source_url=ENDPOINT, issuer='openrouter', source_of_truth=True,
        observed_at=now, expires_at=min(now+TTL,(int(now)//86400+1)*86400), confidence=1.0,
        state='exhausted' if remaining == 0 else 'healthy'))]


def refresh(router, *, now=None, quota_policy='avoid_verified_exhaustion'):
    """Return cached scope observations. Only the host callback may collect quota.

    A plugin-chosen scope id never authorizes env/dotenv credentials, and an
    explicit dashboard refresh cannot infer which pooled account Hermes will use.
    """
    scopes = router.state.get('credential_scopes') or {}
    now = time.time() if now is None else now
    results = []
    for provider in router.state.get('providers') or []:
        scope = scopes.get(provider)
        snapshot = read_snapshot(router.store, provider, scope)
        current = evaluate_policy(snapshot, provider, None, scope, now, quota_policy=quota_policy)
        results.append(dict(snapshot, state=current['state'], preflight=current))
    return {'providers': results, 'network_mode': 'cached_scope_observations'}


def evaluate(snapshot, provider, model, account_scope, now, *, strict_no_charge=False):
    """Cached diagnostic/selection decision; it does not promise billing enforcement."""
    unknown = dict(allowed=not strict_no_charge, state='unknown', reason='quota_unknown',
                   hard_stop_guaranteed=False, verified_no_charge_execution=False, advertised_zero_price=None, quota_evidence=[])
    scope = canonical_scope(account_scope)
    if (not isinstance(snapshot, dict) or not scope or snapshot.get('provider') != provider
            or snapshot.get('account_scope') != scope):
        return unknown
    records = snapshot.get('quota_evidence')
    records = records if isinstance(records,list) else []
    safe_records = [_safe_observation(record,provider,scope) for record in records]
    if any(record is None for record in safe_records):
        return unknown
    unknown = dict(unknown,quota_evidence=safe_records)
    # No inspected source establishes a hard billing stop. Explicit strict mode denies.
    if strict_no_charge:
        return dict(unknown, allowed=False, reason='no_charge_guarantee_unverified')
    if snapshot.get('state') == 'unavailable':
        return dict(unknown, state='unavailable', reason='quota_observation_unavailable')
    if snapshot.get('state') not in ('healthy', 'approaching_limit', 'exhausted'):
        return unknown
    states = []
    for record in safe_records:
        if not isinstance(record, dict) or record.get('provider') != provider or record.get('account_scope') != scope:
            return unknown
        if record.get('model') not in (None, model):
            continue
        states.append(quota_status(record, now))
    if snapshot.get('state') == 'exhausted' and (not states or any(state != 'exhausted' for state in states)):
        return unknown
    if snapshot.get('state') in ('healthy','approaching_limit') and 'exhausted' in states:
        return unknown
    if 'exhausted' in states:
        return dict(unknown, allowed=False, state='exhausted', reason='verified_account_quota_exhausted')
    if states and all(value == 'available' for value in states):
        return dict(unknown, state='healthy', reason='observed_allowance_available')
    return unknown


def invalidate_cached(store, provider, account_scope, status_code):
    """Observed connection errors invalidate availability, never synthesize exhaustion."""
    if type(status_code) is not int or status_code not in (401,403,429,500,502,503,504):
        return
    scope = canonical_scope(account_scope)
    if not scope or store is None:
        return
    snapshot = read_snapshot(store,provider,scope)
    if not snapshot['quota_evidence']:
        return
    category = 'auth_unavailable' if status_code in (401,403) else 'rate_limited' if status_code==429 else 'metadata_unavailable'
    try:
        _save(store,dict(snapshot,state='unavailable',error_category=category))
    except Exception:
        pass


QUOTA_POLICY_VERSION = 1
QUOTA_POLICIES = frozenset({'prefer_available_allowance', 'require_fresh_account_allowance',
    'avoid_verified_exhaustion', 'require_no_charge_guarantee'})


def connection_allowance(snapshot, provider, model, account_scope, now):
    """Versioned, bounded window view; unsupported sources remain descriptive unknowns."""
    scope = canonical_scope(account_scope)
    view = dict(schema_version=1, provider=provider, account_scope=scope,
                quota_windows=[], complete=False, reason='quota_unknown')
    if (not scope or not isinstance(snapshot, dict) or snapshot.get('provider') != provider
            or snapshot.get('account_scope') != scope):
        return view
    rows = snapshot.get('quota_evidence')
    if not isinstance(rows, list) or not rows or len(rows) > 32:
        return view
    identities = set()
    complete = snapshot.get('state') in ('healthy', 'approaching_limit')
    for raw in rows:
        if not isinstance(raw, dict):
            complete = False
            continue
        safe = _safe_observation(raw, provider, scope)
        if safe is None:
            # Do not echo untrusted labels/URLs or promote a new provider/window source.
            view['quota_windows'].append(_unknown_window(raw))
            complete = False
            continue
        if safe.get('model') not in (None, model):
            continue
        identity = (safe.get('model'), safe.get('shared_scope'), safe['dimension'],
                    safe['window'], safe.get('reset_at'), safe.get('currency'))
        if identity in identities:
            complete = False
        identities.add(identity)
        status = quota_status(safe, now)
        complete = complete and status == 'available'
        view['quota_windows'].append(dict(safe, observation_state=status, source_supported=True))
    view['complete'] = complete and bool(view['quota_windows'])
    view['reason'] = 'fresh_supported_windows' if view['complete'] else 'incomplete_or_conflicting_windows'
    return view


def evaluate_policy(snapshot, provider, model, account_scope, now, *,
                    quota_policy='avoid_verified_exhaustion'):
    """Pure preflight evidence policy, never credential authority or spending reservation."""
    windows = connection_allowance(snapshot, provider, model, account_scope, now)
    rows = snapshot.get('quota_evidence') if isinstance(snapshot, dict) else None
    bounded = snapshot if not isinstance(rows, list) or len(rows) <= 32 else {}
    base = evaluate(bounded, provider, model, account_scope, now)
    known = isinstance(quota_policy, str) and quota_policy in QUOTA_POLICIES
    result = dict(base, quota_policy=quota_policy if known else 'unsupported',
                  quota_policy_version=QUOTA_POLICY_VERSION, allowance=windows,
                  preference_available=False)
    if not known:
        return dict(result, allowed=False, reason='quota_policy_unsupported')
    if quota_policy == 'require_no_charge_guarantee':
        # No current source provides an independently enforceable billing boundary.
        return dict(result, allowed=False, reason='no_charge_guarantee_unverified')
    if (isinstance(snapshot, dict) and snapshot.get('state') == 'exhausted'
            and any(row.get('source_supported') and row.get('observation_state') == 'exhausted'
                    for row in windows['quota_windows'])):
        result.update(allowed=False, state='exhausted', reason='verified_account_quota_exhausted')
    fresh = result['state'] == 'healthy' and windows['complete']
    if quota_policy == 'require_fresh_account_allowance' and not fresh:
        return dict(result, allowed=False, reason='fresh_account_allowance_required')
    if quota_policy == 'prefer_available_allowance':
        result['preference_available'] = fresh
    return result
