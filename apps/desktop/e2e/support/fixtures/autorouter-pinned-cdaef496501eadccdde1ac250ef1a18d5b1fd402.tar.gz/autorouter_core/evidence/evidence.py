"""Source-attributed access evidence stored in existing capability JSON.

Catalog/provider claims describe access; only fresh model price proof can authorize
zero-price selection. This contract does not promise account allowance or billing stops.
"""
from decimal import Decimal, InvalidOperation
from urllib.parse import urlsplit
import math

CLASSIFICATIONS = frozenset({
    'VERIFIED_RECURRING_FREE', 'VERIFIED_ZERO_PRICE_MODEL', 'PROMOTIONAL_CREDIT',
    'TRIAL', 'PAID_ONLY', 'UNKNOWN', 'EXPERIMENTAL', 'DEPRECATED',
})
FREE = frozenset({'VERIFIED_RECURRING_FREE', 'VERIFIED_ZERO_PRICE_MODEL'})


def price_tier(prices, currency='USD'):
    """Every supplied billable component must be finite, nonnegative USD pricing."""
    if currency != 'USD' or not isinstance(prices, dict) or not {'prompt', 'completion'} <= prices.keys():
        return 'unknown'
    try:
        values = [Decimal(str(v)) for v in prices.values()]
        if not values or not all(v.is_finite() and v >= 0 for v in values):
            return 'unknown'
        return 'free' if all(v == 0 for v in values) else 'paid'
    except (InvalidOperation, ValueError, TypeError):
        return 'unknown'


def normalize_evidence(record):
    """Allowlist descriptive fields; opaque account scope is never a credential."""
    if not isinstance(record, dict):
        return {}
    fields = ('provider', 'model', 'scope', 'account_scope', 'classification',
              'source_url', 'source_type', 'issuer', 'source_of_truth',
              'observed_at', 'expires_at', 'currency', 'prices', 'auth_required',
              'regions', 'payment_required', 'kyc_required', 'logging_policy',
              'training_policy', 'reset_window', 'cap_scope', 'credits_exhausted')
    out = {key: record.get(key) for key in fields}
    if not isinstance(out['classification'], str) or out['classification'] not in CLASSIFICATIONS:
        out['classification'] = 'UNKNOWN'
    return out


def fresh(record, now):
    try:
        url = urlsplit(record.get('source_url') or '')
        start, end = record.get('observed_at'), record.get('expires_at')
        return (url.scheme == 'https' and bool(url.hostname) and not url.username and not url.password
                and bool(record.get('issuer')) and bool(record.get('source_type'))
                and record.get('source_of_truth') is True
                and type(start) in (int, float) and type(end) in (int, float)
                and math.isfinite(start) and math.isfinite(end) and 0 < start <= now < end)
    except (ValueError, TypeError):
        return False


def access_allowed(records, provider, model, now, *, account_scope=None, region=None):
    """All applicable evidence must agree; provider evidence cannot grant model access."""
    if not isinstance(records, list) or not records:
        return False
    model_proof = False
    for raw in records:
        rec = normalize_evidence(raw)
        if not rec or rec.get('provider') != provider or rec.get('scope') not in ('provider', 'account', 'model'):
            return False
        if rec.get('model') not in (None, model):
            return False
        if not fresh(rec, now):
            return False
        if rec.get('account_scope') is not None and rec['account_scope'] != account_scope:
            return False
        if rec.get('scope') == 'account' and not rec.get('account_scope'):
            return False
        regions = rec.get('regions')
        if regions is not None and (not isinstance(regions, list) or not regions or region not in regions):
            return False
        if rec.get('credits_exhausted') is True or rec.get('classification') not in FREE:
            return False
        if rec.get('prices') is not None and price_tier(rec['prices'], rec.get('currency')) != 'free':
            return False
        if rec.get('scope') == 'model' and rec.get('model') == model:
            model_proof = price_tier(rec.get('prices'), rec.get('currency')) == 'free'
    return model_proof


def merge_access_evidence(fresh, previous):
    """Refresh only matching source/scope identities; preserve independent denials."""
    if not isinstance(fresh, list):
        return fresh  # Explicit malformed evidence must continue to deny access.
    if not isinstance(previous, list):
        return fresh
    identity_fields = ('provider', 'model', 'scope', 'account_scope',
                       'source_url', 'source_type', 'issuer')
    def identity(record):
        if not isinstance(record, dict):
            return None
        # Compare dictionaries rather than hash untrusted, possibly malformed values.
        return {key: record.get(key) for key in identity_fields}
    identities = [identity(record) for record in fresh]
    retained = [record for record in previous
                if identity(record) is None or identity(record) not in identities]
    return retained + fresh
