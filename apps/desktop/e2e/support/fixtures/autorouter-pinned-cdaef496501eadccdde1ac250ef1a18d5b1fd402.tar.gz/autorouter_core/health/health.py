"""Scoped, selection-only circuits. No request execution or active probes."""
from __future__ import annotations
import hashlib
import math
import re
import time
from email.utils import parsedate_to_datetime

MAX_RETRY_AFTER = 86400
FAILURE_THRESHOLD = 3


def scope_id(value):
    if not isinstance(value, str) or not value:
        return ""
    if re.fullmatch(r"scope_[0-9a-f]{64}", value):
        return value
    return "scope_" + hashlib.sha256(value.encode()).hexdigest()


def parse_retry_after(value, *, now=None):
    if value is None or isinstance(value, bool):
        return None
    now = time.time() if now is None else now
    try:
        seconds = float(str(value).strip())
    except (TypeError, ValueError):
        try:
            stamp = parsedate_to_datetime(str(value))
            if stamp.tzinfo is None:
                return None
            seconds = stamp.timestamp() - now
        except (TypeError, ValueError, OverflowError):
            return None
    return min(MAX_RETRY_AFTER, max(0.0, seconds)) if math.isfinite(seconds) and seconds >= 0 else None


def classify_failure(status_code=None, error_type=None, trusted_reason=None):
    if status_code in (401, 403):
        return "credential", "auth", 3600, 1
    if status_code == 429:
        reason = trusted_reason if trusted_reason in ("quota_exhausted", "concurrency_limited") else "rate_limit"
        return "connection", reason, 30, 1
    if status_code in (404, 410) and error_type in ("model_not_found", "ModelNotFound", "model_gone"):
        return "model", "model_retired", 86400, 1
    if isinstance(status_code, int) and 500 <= status_code <= 599:
        return "provider", "provider_error", 30, FAILURE_THRESHOLD
    if error_type in ("TimeoutError", "ReadTimeout", "ConnectTimeout", "ConnectionError"):
        return "connection", "transport_error", 15, FAILURE_THRESHOLD
    return "connection", "unknown_error", 15, FAILURE_THRESHOLD


def _valid_number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def _validate_observation(health, circuits):
    # Validate before truthiness/conversion, and never put private values in errors.
    for field in ('retired', 'auth_failed'):
        if field in health and (type(health[field]) not in (int, bool) or health[field] not in (0, 1)):
            raise ValueError('Invalid stored health')
    for field in ('successes', 'failures', 'consecutive_failures'):
        if field in health and (type(health[field]) is not int or health[field] < 0):
            raise ValueError('Invalid stored health')
    for field in ('cooldown_until', 'last_latency_ms', 'last_success_at', 'last_failure_at'):
        if health.get(field) is not None and not _valid_number(health[field]):
            raise ValueError('Invalid stored health')
    if health.get('last_status') is not None and (type(health['last_status']) is not int or not 100 <= health['last_status'] <= 599):
        raise ValueError('Invalid stored health')
    for row in circuits:
        if row.get('layer') not in ('provider', 'model', 'credential', 'connection') or row.get('reason') not in (
                'auth', 'rate_limit', 'quota_exhausted', 'concurrency_limited', 'provider_error',
                'transport_error', 'unknown_error', 'model_retired'):
            raise ValueError('Invalid stored circuit')
        for field, minimum in (('failures', 0), ('threshold', 1)):
            if type(row.get(field)) is not int or row[field] < minimum:
                raise ValueError('Invalid stored circuit')
        for field in ('opened_until', 'updated_at', 'event_observed_at'):
            if row.get(field) is not None and not _valid_number(row[field]):
                raise ValueError('Invalid stored circuit')


def _decision(store, provider, model, key_scope="", *, now=None):
    now = time.time() if now is None else now
    scope = scope_id(key_scope)
    try:
        h = dict(store.get_health(provider, model, key_scope)) if store else {}
        circuits = store.get_health_circuits(provider, model, scope) if store and hasattr(store, "get_health_circuits") else []
    except Exception:
        return {"available": True, "circuit": "closed", "reason": "health_unknown", "scope": "known" if scope else "scope_unknown", "health": {}}
    _validate_observation(h, circuits)
    reasons = []
    states = []
    observations = []
    if circuits:
        # New circuit records supersede permanent legacy flags for the same observation.
        if any(row.get("layer") == "credential" for row in circuits):
            h["auth_failed"] = 0
        if any(row.get("layer") in ("connection", "credential", "model") for row in circuits):
            h["cooldown_until"] = 0
        for row in circuits:
            until = float(row.get("opened_until") or 0)
            state = "open" if until > now else "half_open" if row.get("failures", 0) >= row.get("threshold", 1) else "closed"
            if row.get("reason") == "model_retired":
                state = "open"
                h["retired"] = 1
            states.append(state)
            observations.append({"layer":row["layer"],"reason":row["reason"],"state":state,
                "failures":row.get("failures",0),"observed_at":row.get("event_observed_at"),
                "source":"persisted_health_record" if row.get("event_observed_at") is not None else "unknown",
                "local_reconsider_at":None if row["reason"] == "model_retired" else row.get("opened_until")})
            if state == "open":
                reasons.append(row["reason"])
                h["cooldown_until"] = max(float(h.get("cooldown_until") or 0), until)
                h["auth_failed"] = int(row["reason"] == "auth") or h.get("auth_failed", 0)
    else:
        # Existing v1/v2 health remains meaningful until superseded by a circuit record.
        if h.get("retired"): reasons.append("model_retired")
        if h.get("auth_failed"): reasons.append("auth")
        if float(h.get("cooldown_until") or 0) > now: reasons.append("rate_limit")
    if h.get("retired") and "model_retired" not in reasons:
        reasons.append("model_retired")
    if h.get("auth_failed") and "auth" not in reasons:
        reasons.append("auth")
    if float(h.get("cooldown_until") or 0) > now and not reasons:
        reasons.append("rate_limit")
    return {"available": not reasons, "circuit": "open" if reasons else "half_open" if "half_open" in states else "closed",
            "reason": reasons[0] if reasons else "available" if h.get("last_success_at") and h.get("last_success_at") >= (h.get("last_failure_at") or 0) and "half_open" not in states else "health_unknown",
            "scope": "known" if scope else "scope_unknown", "health": h, "observations": observations}


def decision(store, provider, model, key_scope="", *, now=None):
    try:
        return _decision(store, provider, model, key_scope, now=now)
    except (TypeError, ValueError, OverflowError):
        return {"available": False, "circuit": "open", "reason": "health_invalid",
                "scope": "known" if scope_id(key_scope) else "scope_unknown",
                "health": {"available": False}}


class HealthTracker:
    def __init__(self, store): self.store = store
    def record(self, provider, model, success, **kwargs):
        self.store.record_outcome(provider, model, success, **kwargs)
    def is_available(self, provider, model, key_scope=""):
        return decision(self.store, provider, model, key_scope)["available"]
    def note_retry_after(self, provider, model, retry_after, key_scope=""):
        seconds = parse_retry_after(retry_after)
        if seconds is not None:
            self.store.set_cooldown(provider, model, seconds, key_scope=key_scope)
