"""AutoRouter health package."""
