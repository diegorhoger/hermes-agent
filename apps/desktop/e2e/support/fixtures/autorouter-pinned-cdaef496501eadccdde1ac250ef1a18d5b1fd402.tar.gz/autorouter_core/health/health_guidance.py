"""Read-only explanations of the existing selection-only health state machine."""

import math

VERSION = 1
DISPLAY_STALE_SECONDS = 7 * 86400
_REASONS = {
    "auth": ("authentication", "credential", "review_credentials_in_hermes"),
    "rate_limit": ("rate_limit", "connection", "wait_then_reconsider_cached_selection"),
    "quota_exhausted": (
        "rate_limit",
        "connection",
        "inspect_authoritative_quota_evidence",
    ),
    "concurrency_limited": (
        "concurrency",
        "connection",
        "wait_then_reconsider_cached_selection",
    ),
    "provider_error": (
        "temporary_service",
        "provider",
        "wait_then_reconsider_cached_selection",
    ),
    "transport_error": (
        "transport",
        "connection",
        "inspect_connectivity_then_reconsider",
    ),
    "model_retired": (
        "model_unavailable",
        "model",
        "refresh_catalog_then_choose_another_model",
    ),
    "unknown_error": (
        "unknown_failure",
        "connection",
        "inspect_host_diagnostics_without_exporting_secrets",
    ),
}
_TEXT = {
    "authentication": "A local observer recorded authentication denial; key presence is not validity.",
    "rate_limit": "A local observer recorded rate limiting; this does not establish exhausted allowance.",
    "concurrency": "A local observer recorded a concurrency limitation, not exhausted allowance.",
    "temporary_service": "A local observer recorded a temporary provider service failure.",
    "transport": "A local observer recorded a transport failure; current connectivity is unknown.",
    "model_unavailable": "An observed model-unavailable condition requires fresh catalog evidence before reconsideration.",
    "unknown_failure": "A local observer recorded a failure with no supported specific explanation.",
    "verified_quota_exhaustion": "The canonical quota gate found matching verified exhausted allowance; an HTTP status alone is insufficient.",
    "observed_success": "A past success is recorded; current availability remains unknown.",
    "unknown": "No supported recent health observation establishes current availability.",
    "invalid": "Health evidence is unavailable or invalid; no healthy state is implied.",
}


def _number(value):
    return (
        value
        if type(value) in (int, float) and math.isfinite(value) and value > 0
        else None
    )


def describe(candidate, reasons, *, now, authorized=False):
    health = candidate.get("health")
    health = health if isinstance(health, dict) else {}
    observations = []
    rows = candidate.get("health_observations")
    for row in (rows if isinstance(rows, list) else [])[:16]:
        if (
            not isinstance(row, dict)
            or not isinstance(row.get("reason"), str)
            or row["reason"] not in _REASONS
        ):
            continue
        kind, boundary, action = _REASONS[row["reason"]]
        if row.get("layer") != boundary:
            kind, boundary, action = (
                "unknown_failure",
                "unknown",
                "inspect_local_storage_without_overwriting",
            )
        stamp = _number(row.get("observed_at"))
        valid = stamp is not None and stamp <= now
        deadline = _number(row.get("local_reconsider_at"))
        observations.append(
            dict(
                category=kind,
                boundary=boundary,
                state=row.get("state")
                if row.get("state") in ("open", "half_open", "closed")
                else "unknown",
                source="persisted_health_record" if valid else "unknown",
                unrecovered=type(row.get("failures")) is int and row["failures"] > 0,
                observed_at=stamp if valid else None,
                age_seconds=now - stamp if valid else None,
                local_reconsider_at=deadline,
                account_binding="not_applicable"
                if boundary in ("provider", "model")
                else "authorized_observation"
                if authorized
                else "unknown",
                next_action=action,
                confidence="observed_failure"
                if valid and type(row.get("failures")) is int and row["failures"] > 0
                else "observed_recovery"
                if valid and row.get("failures") == 0
                else "unknown",
            )
        )
    priority = {
        "model_unavailable": 0,
        "authentication": 1,
        "rate_limit": 2,
        "concurrency": 3,
        "temporary_service": 4,
        "transport": 5,
        "unknown_failure": 6,
    }
    observations.sort(
        key=lambda item: (
            not item["unrecovered"],
            item["state"] != "open",
            priority.get(item["category"], 7),
            item["boundary"],
            item["observed_at"] or 0,
        )
    )
    active = [o for o in observations if o["state"] in ("open", "half_open")]
    representative = active[0] if active else observations[0] if observations else None
    raw = candidate.get("health_reason")
    raw = raw if isinstance(raw, str) else None
    kind, boundary, action = _REASONS.get(
        raw, ("unknown", "unknown", "reconsider_cached_selection")
    )
    if representative:
        kind, boundary, action = (
            representative[k] for k in ("category", "boundary", "next_action")
        )
        if (
            representative["confidence"] == "observed_recovery"
            and representative["state"] == "closed"
        ):
            kind, action = "observed_success", "reconsider_cached_selection"
    stamp = _number(health.get("last_failure_at")) or _number(
        health.get("last_success_at")
    )
    if representative:
        stamp = representative["observed_at"]
    if stamp is not None and stamp > now:
        stamp = None
    if "health_invalid" in reasons:
        kind, boundary, action = (
            "invalid",
            "unknown",
            "inspect_local_storage_without_overwriting",
        )
    elif "verified_account_quota_exhausted" in reasons:
        kind, boundary, action = (
            "verified_quota_exhaustion",
            "connection",
            "wait_for_authoritative_quota_refresh",
        )
    elif (
        not representative
        and kind == "unknown"
        and _number(health.get("last_success_at"))
        and health.get("last_success_at") <= now
        and health.get("last_success_at")
        >= (_number(health.get("last_failure_at")) or 0)
    ):
        kind, action = "observed_success", "reconsider_cached_selection"
        stamp = _number(health.get("last_success_at"))
    elif (
        not representative
        and kind == "unknown"
        and isinstance(health.get("last_error"), str)
        and health["last_error"] in _REASONS
        and _number(health.get("last_failure_at")) is not None
        and health["last_failure_at"] <= now
    ):
        kind, boundary, action = _REASONS[health["last_error"]]
        stamp = _number(health["last_failure_at"])
    quota_expires_at = None
    quota_source = None
    if kind == "verified_quota_exhaustion":
        from ..evidence.quota import decimal_value
        from ..telemetry.decision_report import _source

        stamp = None  # Health-event time never establishes quota provenance.
        evaluated = candidate.get("evaluated_quota") or {}
        access = candidate.get("free_access") or {}
        evidence = (
            evaluated.get("evidence")
            if evaluated.get("state") == "exhausted"
            and evaluated.get("allowed") is False
            else access.get("quota_evidence")
        )
        evidence = evidence or []
        evidence = evidence if isinstance(evidence, list) else []
        for row in evidence[:32]:
            if not isinstance(row, dict):
                continue
            start, end = _number(row.get("observed_at")), _number(row.get("expires_at"))
            if (
                start is not None
                and end is not None
                and start <= now < end
                and decimal_value(row.get("remaining")) == 0
            ):
                stamp, quota_expires_at, quota_source = (
                    start,
                    end,
                    _source(row.get("source_url")),
                )
                break
    if stamp is None and kind not in ("invalid", "verified_quota_exhaustion"):
        kind = "unknown"
    age = now - stamp if stamp is not None else None
    state = (
        "unknown"
        if stamp is None
        else "stale"
        if age >= DISPLAY_STALE_SECONDS
        else "observed"
    )
    if kind == "invalid":
        state = "unavailable"
    circuit = candidate.get("circuit_state")
    circuit = circuit if circuit in ("open", "closed", "half_open") else "unknown"
    return dict(
        schema_version=VERSION,
        category=kind,
        explanation=_TEXT[kind],
        evidence_state=state,
        boundary=boundary,
        active_account_authority=authorized is True,
        account_binding="not_applicable"
        if boundary in ("provider", "model")
        else "authorized_observation"
        if authorized
        else "unknown",
        source=quota_source
        or ("persisted_health_record" if stamp is not None else "unknown"),
        quota_observation_expires_at=quota_expires_at,
        observed_at=stamp,
        age_seconds=age,
        display_stale_after=stamp + DISPLAY_STALE_SECONDS if stamp else None,
        expiration_meaning="local selection cooldown or display staleness, never provider retry authorization",
        circuit_state=circuit,
        local_reconsider_at=representative["local_reconsider_at"]
        if representative
        else _number(health.get("cooldown_until")),
        provider_retry_after=None,
        confidence="local_observation" if stamp else "unknown",
        current_availability="unknown",
        observations=observations,
        next_actions=[action, "reconsider_cached_selection"],
        refresh_guidance="Use autorouter_refresh deliberately for catalog metadata; it does not validate credentials, quota or live availability.",
        automatic_retry=False,
        execution_authority=False,
    )
