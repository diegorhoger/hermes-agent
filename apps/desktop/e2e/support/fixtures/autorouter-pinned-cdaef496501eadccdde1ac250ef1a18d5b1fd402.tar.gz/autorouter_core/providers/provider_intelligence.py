"""Bounded, read-only presentation of existing registry and capability evidence."""
import math
from ..evidence import evidence, quota
from ..discovery import metadata, provider_registry
from ..health.health import scope_id

ADAPTERS = ('nvidia', 'openrouter', 'groq', 'gemini', 'mistral', 'nous')


def _number(value):
    return value if type(value) in (int, float) and math.isfinite(value) else None


def _url(value):
    try:
        return provider_registry.safe_url(value) if isinstance(value, str) else None
    except ValueError:
        return None


def model_details(cap, now, scrub):
    cap = cap if isinstance(cap, dict) else {}
    access, quotas = [], []
    for raw in (cap.get('access_evidence') or [])[:30] if isinstance(cap.get('access_evidence'), list) else []:
        rec = evidence.normalize_evidence(raw)
        if not rec:
            continue
        public = {key: scrub(rec.get(key)) if isinstance(rec.get(key), str) else None for key in (
            'scope', 'classification', 'source_type', 'issuer', 'currency', 'reset_window',
            'cap_scope', 'logging_policy', 'training_policy')}
        public.update(source_url=_url(rec.get('source_url')),
                      observed_at=_number(rec.get('observed_at')), expires_at=_number(rec.get('expires_at')),
                      freshness='fresh' if evidence.fresh(rec, now) else 'stale_or_unverified',
                      account_scope=scope_id(rec.get('account_scope')) or None,
                      regions=[scrub(r, 80) for r in rec['regions'][:20] if isinstance(r, str)] if isinstance(rec.get('regions'), list) else None,
                      source_of_truth=rec.get('source_of_truth') is True)
        for key in ('auth_required', 'payment_required', 'kyc_required'):
            public[key] = rec.get(key) if type(rec.get(key)) is bool else None
        public['prices'] = {key: str(quota.decimal_value(rec['prices'][key]))
                            for key in ('prompt', 'completion', 'request', 'image', 'input_cache_read', 'input_cache_write')
                            if isinstance(rec.get('prices'), dict) and key in rec['prices'] and quota.decimal_value(rec['prices'][key]) is not None}
        access.append(public)
    for raw in (cap.get('quota_evidence') or [])[:30] if isinstance(cap.get('quota_evidence'), list) else []:
        rec = quota.normalize_quota(raw)
        if not rec:
            continue
        public = {key: scrub(rec.get(key)) if isinstance(rec.get(key), str) else None for key in (
            'dimension', 'limit', 'remaining', 'currency', 'window', 'timezone', 'source', 'shared_scope')}
        public.update(source_url=_url(rec.get('source_url')),
                      account_scope=scope_id(rec.get('account_scope')) or None,
                      shared_scope=scope_id(rec.get('shared_scope')) or None,
                      status=quota.quota_status(raw, now),
                      **{key: _number(rec.get(key)) for key in ('observed_at', 'expires_at', 'reset_at', 'grant_expires_at', 'confidence')})
        quotas.append(public)
    fields = metadata.verified_fields(cap, cap.get('provider'), cap.get('model'), now)[0]
    classes = {r['classification'] for r in access if r['freshness'] == 'fresh' and r['source_of_truth']}
    if fields['cost_tier'] == 'free':
        classes.add('VERIFIED_ZERO_PRICE_MODEL')
    if fields['cost_tier'] in ('paid', 'premium'):
        classes.add('PAID_ONLY')
    # Fresh descriptive classifications do not grant execution eligibility.
    discovery_status = cap.get('discovery_status', 'unknown')
    if discovery_status not in ('candidate', 'discovered', 'removed', 'unknown'):
        discovery_status = 'unknown'
    info = cap.get('discovery_evidence')
    info = info if isinstance(info, dict) else {}
    if discovery_status == 'discovered' and not metadata.valid_evidence(info, now):
        discovery_status = 'unknown'
    discovery_evidence = dict(metadata_source=_url(info.get('metadata_source')),
        retrieved_at=_number(info.get('retrieved_at')), expires_at=_number(info.get('expires_at')))
    return dict(discovery_status=discovery_status, discovery_evidence=discovery_evidence, access_classes=sorted(classes) or ['UNKNOWN'], access_evidence=access,
                quota_evidence=quotas, token_estimate={'state': 'unknown', 'tokens': None,
                'reason': 'No operator-selected workload mix is available; no token allowance is inferred.'})


def registry_details(configured, models):
    entries = provider_registry.load_registry()['entries']
    by_provider = {}
    for model in models:
        by_provider.setdefault(model['provider'], []).append(model)
    candidates = []
    for entry in entries:
        provider = entry['source_provider_id']
        rows = by_provider.get(provider, [])
        classes = sorted({c for row in rows for c in row.get('access_classes', ['UNKNOWN'])}) or ['UNKNOWN']
        if entry['experimental']: classes = sorted(set(classes) | {'EXPERIMENTAL'})
        if entry['registry_status'] == 'deprecated': classes = sorted(set(classes) | {'DEPRECATED'})
        candidates.append(dict(id=entry['canonical_id'], provider_id=provider, name=entry['name'],
            variant_kind=entry['variant_kind'], configured=provider in configured,
            discovery_adapter=provider in ADAPTERS, access_classes=classes,
            protocol=entry.get('protocol_hint') or 'unknown', modalities=entry.get('modalities') or ['unknown'],
            jurisdiction='unknown', auth_condition=entry.get('auth_hint') or 'unknown',
            source_classification=entry['source_claim']['classification'], verification='unverified_source_claim',
            source_captured=entry['source_captured'], source_urls=entry['url_evidence']))
    discovery_states = []
    for provider in ADAPTERS:
        rows = by_provider.get(provider, [])
        discovery_states.append(dict(provider_id=provider, discovery_capable=True,
            configured=provider in configured, catalog_model_count=len(rows),
            discovered_model_count=sum(row.get('discovery_status') == 'discovered' for row in rows),
            eligible_model_count=sum(row.get('eligible') is True for row in rows),
            operationally_usable='unknown',
            limitation='Catalog discovery and selection eligibility do not prove credential entitlement or successful inference.'))
    eligible = [m for m in models if m.get('eligible')]
    return dict(candidate_count=len(entries), configured_provider_count=len(set(configured)),
                discovery_adapter_count=len(ADAPTERS), discovery_adapters=list(ADAPTERS),
                verified_eligible_model_count=len(eligible), verified_eligible_provider_count=len({m['provider'] for m in eligible}),
                verified_count_scope='displayed model snapshot (maximum 500 rows)',
                discovery_states=discovery_states, candidates=candidates)
