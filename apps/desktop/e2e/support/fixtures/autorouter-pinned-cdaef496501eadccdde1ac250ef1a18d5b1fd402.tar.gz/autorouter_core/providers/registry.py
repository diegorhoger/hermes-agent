"""Host-backed provider registry (ADR-0016, Slice A).

Enumerates provider profiles the running Hermes host exposes through its
public ``providers`` package and reduces them to bounded, secret-free
records the authorization and inventory layers can consume. This module
never grants permission, never reads a credential value, never opens a
network connection, and never caches beyond one call.

Failing closed is the contract: if the host registry is unavailable,
unimportable, empty, or enumeration raises, the six adapter-backed static
IDs remain the complete known set — indistinguishable from pre-ADR-0016
behavior. Host entries are data the operator can explicitly authorize; an
entry's presence never implies authorization, credential validity, inference
capability, or free eligibility.

Import boundary: only the host's own ``providers`` package and optional
``hermes_cli.version_info`` are imported, inside the public entry points,
never at module import time, and every host access is exception-guarded.
"""

from __future__ import annotations

import os
import re
from typing import Any, Iterable

# Static adapter-backed set — always known, regardless of host state.
ADAPTER_PROVIDERS = ("nvidia", "openrouter", "groq", "gemini", "mistral", "nous")

MAX_ENTRIES = 256
MAX_SCAN = 1024  # hard bound on raw host rows ever examined (ADR-0016)
MAX_ALIASES = 16
MAX_ENV_VARS = 16
MAX_ALIAS_LEN = 64

_ID_RE = re.compile(r"[a-z][a-z0-9-]{0,63}")
_ENV_RE = re.compile(r"[A-Z_][A-Z0-9_]{0,63}")

# Deterministic test seam: when set (even to a failing shape), replaces the
# host enumeration entirely. Never read by production code paths.
_OVERRIDE: Any = None



def _host_version() -> str | None:
    try:
        from hermes_cli.version_info import get_version_info

        version = getattr(get_version_info(), "base_version", None)
        return str(version)[:64] if version else None
    except Exception:
        return None


def _entry_ok(name: Any) -> bool:
    return isinstance(name, str) and bool(_ID_RE.fullmatch(name))


def _entry(name: str, profile: Any, *, host_version: str | None) -> dict[str, Any] | None:
    try:
        aliases_raw = getattr(profile, "aliases", ()) or ()
    except Exception:
        aliases_raw = ()
    aliases: set[str] = set()
    try:
        for alias in aliases_raw:
            if not isinstance(alias, str):
                continue
            alias = alias.strip().lower()
            if not _ID_RE.fullmatch(alias) or alias == name:
                continue
            aliases.add(alias)
            if len(aliases) >= MAX_ALIASES:
                break
    except Exception:
        return None

    try:
        env_raw = getattr(profile, "env_vars", ()) or ()
    except Exception:
        env_raw = ()
    env_vars: list[str] = []
    try:
        for var in env_raw:
            if not isinstance(var, str):
                continue
            var = var.strip()
            if not _ENV_RE.fullmatch(var):
                continue
            if var not in env_vars:
                env_vars.append(var)
            if len(env_vars) >= MAX_ENV_VARS:
                break
    except Exception:
        env_vars = []

    def _bounded_str(value, length):
        value = value if isinstance(value, str) else ""
        return value.strip()[:length] or ""

    label = _bounded_str(getattr(profile, "display_name", "") or "", 64) or name
    listing = getattr(profile, "supports_model_listing", None)
    if listing is True:
        model_listing = "supported"
    elif listing is False:
        model_listing = "disabled"
    elif isinstance(listing, (int, bool)) or listing is None:
        model_listing = "unknown"  # host did not declare; never advertise a catalog
    else:
        model_listing = "unknown"
    return {
        "name": name,
        "label": label,
        "aliases": tuple(sorted(aliases)),
        "auth_type": _bounded_str(getattr(profile, "auth_type", "api_key"), 32) or "unknown",
        "api_mode": _bounded_str(getattr(profile, "api_mode", ""), 48),
        # Env-var NAMES by construction — never values, never fragments.
        "env_var_names": tuple(sorted(env_vars)),
        "hidden": bool(getattr(profile, "hidden", False)),
        "supports_model_listing": model_listing == "supported",
        "model_listing": model_listing,
        "source": "host",
        "host_version": host_version,
    }


def _unavailable(error: str, host_version: str | None = None) -> dict[str, Any]:
    return {
        "available": False,
        "host_version": host_version,
        "error": error,
        "providers": {},
        "aliases": {},
        "dropped_aliases": [],
        "collisions": [],
        "truncated": False,
    }


def _collect_scan(profiles: Iterable[Any]) -> tuple[list, str]:
    """Bounded raw scan of the host enumeration.

    Never materializes more than MAX_SCAN items. Returns (items, status) where
    status is 'ok', 'enumeration_failed', or 'enumeration_truncated'.
    """
    items: list = []
    try:
        iterator = iter(profiles)
    except TypeError:
        return [], "enumeration_failed"
    count = 0
    try:
        for item in iterator:
            items.append(item)
            count += 1
            if count >= MAX_SCAN:
                return items, "enumeration_truncated"
    except Exception:
        return items, "enumeration_failed"
    return items, "ok"


def _normalize(profiles: Iterable[Any], *, source: str, host_version: str | None) -> dict[str, Any]:
    raw, scan_status = _collect_scan(profiles)
    if scan_status != "ok":
        # Fail closed for a partially trusted host enumeration: partial knowledge
        # must never unlock a new provider.
        return _unavailable(scan_status, host_version)

    entries: list[tuple[str, dict[str, Any]]] = []
    seen: set[str] = set()
    collisions: set[str] = set()
    invalid = 0
    for profile in raw:
        name = getattr(profile, "name", None)
        name = name.strip().lower() if isinstance(name, str) else None
        if not _entry_ok(name):
            invalid += 1
            continue
        if name in seen:
            # Deterministic dedup: keep the first occurrence after stable sort.
            collisions.add(name)
            continue
        entry = _entry(name, profile, host_version=host_version)
        if entry is None:
            invalid += 1
            continue
        seen.add(name)
        entries.append((name, entry))

    entries.sort(key=lambda item: item[0])
    if len(entries) > MAX_ENTRIES:
        # More valid, distinct providers than we can vouch for: partial trust is not trust.
        return _unavailable("enumeration_truncated", host_version)
    truncated = False

    providers = {name: entry for name, entry in entries}
    alias_owner: dict[str, str | None] = {}
    for name, entry in providers.items():
        for alias in entry["aliases"]:
            owner = alias_owner.get(alias)
            if owner is None and alias not in alias_owner:
                alias_owner[alias] = name
            elif owner != name:
                alias_owner[alias] = None
    # Canonical-name collisions with aliases are fatal to the alias, not the provider.
    for name in providers:
        if name in alias_owner:
            alias_owner[name] = None
    aliases = {a: n for a, n in alias_owner.items() if n is not None}
    dropped_aliases = sorted(a for a, n in alias_owner.items() if n is None)
    collisions.update(dropped_aliases)

    return {
        "available": True,
        "host_version": host_version,
        "error": None,
        "source": source,
        "providers": providers,
        "aliases": aliases,
        "dropped_aliases": dropped_aliases,
        "collisions": sorted(collisions),
        "invalid_ids": invalid,
        "truncated": truncated,
    }


def host_inventory() -> dict[str, Any]:
    """Return the host provider inventory, or the static fault-tolerant result."""
    if os.environ.get("AUTOROUTER_REGISTRY_OFFLINE"):
        # Explicit fail-closed switch; honored by every copy of this module,
        # including the dashboard's standalone-loaded package instance.
        return _unavailable("registry_offline")
    if _OVERRIDE is not None:
        profiles = _OVERRIDE
        try:
            return _normalize(profiles, source="override", host_version=_host_version())
        except Exception:
            return _unavailable("enumeration_failed")
    try:
        import providers  # host package, import guarded, never executed at module import
    except Exception:
        return _unavailable("registry_unavailable")
    host_version = _host_version()
    try:
        profiles = providers.list_providers()
    except Exception:
        return _unavailable("enumeration_failed", host_version)
    return _normalize(profiles, source="host", host_version=host_version)


def recognized_ids() -> set[str]:
    """Canonical host-registered IDs (adapter IDs are handled by callers)."""
    return set(host_inventory()["providers"])


def known_ids() -> set[str]:
    """Static adapter IDs ∪ host-recognized canonical IDs."""
    return set(ADAPTER_PROVIDERS) | recognized_ids()


def is_recognized(provider: str) -> bool:
    return provider in known_ids()


def capability_record(provider: str) -> dict[str, Any] | None:
    """Truthful capability summary for one ID, or None when unknown."""
    if not isinstance(provider, str) or not _ID_RE.fullmatch(provider):
        return None
    if provider in ADAPTER_PROVIDERS:
        return {
            "name": provider,
            "registry": "adapter_backed",
            "host_recognized": True,
            "aliases": (),
            "auth_type": "n/a",
            "api_mode": "n/a",
            "env_var_names": (),
            "hidden": False,
            "supports_model_listing": True,
            "source": "static_adapter",
            "host_version": _host_version(),
        }
    inventory = host_inventory()
    entry = inventory["providers"].get(provider)
    if entry is None:
        return None
    return {**entry, "registry": "host"}
