"""AutoRouter providers package."""
