"""Read-only provider connection metadata; never resolves or stores credentials.

Presence states are strictly tri-state and additive — never collapsed into a
single Boolean:

* ``presence`` — whether a Hermes-visible credential configuration exists for
  the provider (``configured`` / ``not_observed`` / ``unknown``). Observed via
  Hermes' sanctioned read APIs only; presence is never verification.
* ``authorized`` — whether the operator enabled the provider for AutoRouter's
  own catalog discovery and selection (the ``providers`` plugin setting).
  Presence never implies authorization; authorization never implies presence.
* ``verification`` — whether a request was authenticated end-to-end. Always
  ``unverified``; nothing here proves inference authority or allowance.
* ``account_allowance`` — always ``unknown``; per-attempt account scope is
  not available to plugins on standard Hermes (issue #41).

Provider IDs outside the six adapter-backed set split into two families.
IDs the running host recognizes (ADR-0016 Slice A) appear as
``family: 'llm_host'``: visible inventory with independent status axes,
authorizable only through the operator's explicit ``providers`` list, and
never marked ready without verified-free evidence. IDs in neither set
appear as ``family: 'llm_unsupported'`` with no discovery adapter and are
never authorizable.

Credential boundary (deliberately narrow, honoured everywhere below)
-------------------------------------------------------------------
Raw credential values are touched ONLY inside the two host-seam helpers
below, each reducing values to booleans/counts in place:

1. ``_host_env_present(name)`` evaluates exactly
   ``has_usable_secret(get_env_value_prefer_dotenv(name) or "")`` (falling
   back to ``False`` on any host failure). The credential string is bound
   only inside that expression, is never assigned to a name, never logged,
   stringified, hashed, persisted or returned; the result is a bare bool.
   The same single-expression reduction applies to ``os.environ`` when the
   host reader itself is unreachable.
2. ``_host_pool_snapshot()`` makes ONE call to ``read_credential_pool(None)``
   purely to enumerate which provider IDs have pool rows and whether any row
   is OAuth-shaped. The returned mapping is iterated once; per provider only
   ``{'entries': int (capped at 8 rows examined), 'oauth': bool}`` is kept,
   with provider IDs validated by ``_valid_provider_id``. Entry payloads
   (keys, tokens, fingerprints, labels, arbitrary ``source``/``auth_type``
   strings) are never read past this function and never leave it.
3. ``_nous_oauth_presence()`` reduces ``read_credential_pool('nous')`` to a
   bool; nothing from the rows is retained.

Everything that crosses the module boundary — the inventory payload, error
messages, logs — is therefore built from fixed literals and validated
provider IDs only. No arbitrary paths, no unbounded source labels, no token
material, no account identity. This is a trusted-boundary contract: the
helpers operate in-process inside the same host that already holds those
values; anything wider would violate the plugin isolation contract.
"""
from __future__ import annotations

import os
import re

try:  # ADR-0016 Slice A: host-backed registry, fail-closed to the static six.
    from . import registry as _registry
except Exception:  # pragma: no cover - standalone loading fallback
    _registry = None


def _host_ids() -> set[str]:
    """Canonical IDs the running host recognizes (never raises, one call)."""
    try:
        if _registry is None:
            return set()
        return set(_registry.host_inventory()["providers"])
    except Exception:
        return set()


def _known_ids_once() -> set[str]:
    """One authoritative known-ID snapshot (six static adapters ∪ host-recognized
    canonical IDs). Take it once per authorization decision, not once per item."""
    try:
        if _registry is not None:
            return set(_registry.known_ids())
    except Exception:
        pass
    return set(ADAPTER_PROVIDERS)


# Existing operational provider IDs only; candidate registry entries are not adapters.
PROVIDERS = {
    'nvidia': ('NVIDIA NIM', 'NVIDIA_API_KEY'),
    'openrouter': ('OpenRouter', 'OPENROUTER_API_KEY'),
    'groq': ('Groq', 'GROQ_API_KEY'),
    'gemini': ('Gemini', 'GOOGLE_API_KEY'),
    'mistral': ('Mistral', 'MISTRAL_API_KEY'),
    # Nous Portal authenticates through Hermes-managed OAuth state; presence
    # is observed on the auth store only — never through an environment slot.
    'nous': ('Nous Portal', None),
}
ADAPTER_PROVIDERS = tuple(PROVIDERS)

def valid_provider_list(value):
    """An explicit malformed authorization list must grant no provider access.

    An ID is authorizable when it is one of the six static adapters or a
    canonical ID the running host recognizes (ADR-0016). One authoritative
    snapshot is taken up front and every item is validated against the same
    set; an item may not pass under one host state and fail under another.

    Aliases are never operator input — they are ambiguous by construction.
    A duplicate ID is ambiguous input and fails closed. Empty list means
    nothing is authorized; a non-list fails closed."""
    if not isinstance(value, list):
        return False
    known = _known_ids_once()
    seen: set[str] = set()
    for item in value:
        if not _valid_provider_id(item):
            return False
        if item in seen:
            return False
        seen.add(item)
        if item not in known:
            return False
    return True

GUIDANCE = {
    'nvidia': {
        'key_issuance_url': 'https://build.nvidia.com/settings/api-keys',
        'source_url': 'https://docs.nvidia.com/nemo/retriever/latest/extraction/api-keys/',
        'auth_prerequisite': 'NVIDIA developer account and NVIDIA-hosted API key',
    },
    'openrouter': {
        'key_issuance_url': 'https://openrouter.ai/keys',
        'source_url': 'https://openrouter.ai/docs/api_reference/authentication',
        'auth_prerequisite': 'OpenRouter account and provider API key',
    },
}
GUIDANCE.update({
    'groq': {'key_issuance_url':'https://console.groq.com/keys',
        'source_url':'https://console.groq.com/docs/quickstart',
        'auth_prerequisite':'Groq account and API key; native Hermes profile support must be verified'},
    'gemini': {'key_issuance_url':'https://aistudio.google.com/apikey',
        'source_url':'https://ai.google.dev/gemini-api/docs/api-key',
        'auth_prerequisite':'Google AI Studio project and authorized Gemini API key'},
    'mistral': {'key_issuance_url':'https://console.mistral.ai/',
        'source_url':'https://docs.mistral.ai/getting-started/quickstarts/studio/activate-and-generate-api-key',
        'auth_prerequisite':'Mistral account with API access; native Hermes profile support must be verified'},
    'nous': {'key_issuance_url':'https://portal.nousresearch.com/manage-subscription',
        'source_url':'https://hermes-agent.nousresearch.com/docs/user-guide/features/tool-gateway',
        'auth_prerequisite':'Nous Portal account with an active OAuth login via `hermes portal`; presence is observed without reading tokens'},
})
UNSUPPORTED_GUIDANCE = {
    'guidance': None,
    'environment_slot': None,
    'source_type': None,
    'verified_on': None,
    'auth_prerequisite': 'AutoRouter has no discovery or selection adapter for this provider. '
        'Hermes uses its configured credentials natively; AutoRouter never reads or selects them.',
}
ENV_ALIASES = {'gemini': ('GOOGLE_API_KEY', 'GEMINI_API_KEY')}

OPERATIONS = ('add', 'replace', 'remove', 'enable', 'disable', 'test')
INSTRUCTIONS = 'Configure provider credentials through Hermes setup/auth; AutoRouter cannot manage them.'

_PROVIDER_ID = re.compile(r'[a-z][a-z0-9-]{0,63}')


class ConnectionError(Exception):
    def __init__(self, code, status, message):
        super().__init__(message)
        self.code, self.status, self.message = code, status, message


def _valid_provider_id(provider) -> bool:
    return isinstance(provider, str) and _PROVIDER_ID.fullmatch(provider) is not None


def validate_provider(provider):
    if not _valid_provider_id(provider):
        raise ConnectionError('invalid_provider', 400, 'Invalid provider ID')
    if provider not in ADAPTER_PROVIDERS and provider not in _host_ids():
        raise ConnectionError('unsupported_provider', 404, 'Provider integration is unavailable')
    return provider


# ---------------------------------------------------------------------------
# Presence observation (read-only; presence is never verification)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Host seams — every call into the running Hermes host goes through these.
# They never return, log, compare, hash or persist secret material; they are
# monkeypatched in unit tests so tests never observe (or depend on) the live
# installation.
# ---------------------------------------------------------------------------

# Strict enums for ANY metadata that may cross this module boundary.
# Anything not in these sets is mapped to 'unknown' before it can reach the
# API, the Desktop, logs or tests.
_SOURCE_KIND = frozenset({'env', 'device_code', 'gh_cli', 'manual', 'loopback_pkce',
                          'hermes_pkce', 'oauth', 'aws_sdk', 'external_process'})
_AUTH_TYPE_KIND = frozenset({'api_key', 'oauth', 'oauth_device_code', 'oauth_external',
                             'bearer', 'aws_sdk', 'external_process'})
_MAX_POOL_ROWS = 8


_SOURCE_SCHEME = re.compile(r'^[a-z][a-z0-9_]{0,31}$')


def _pool_entry_oauth(entry) -> bool:
    """True when a pool row is OAuth/device-code shaped.

    Reads only the ``source`` scheme label under a strict character-class and
    length rule; the row's credential values are never read, compared or
    retained by this module.
    """
    source = entry.get('source')
    if not isinstance(source, str):
        return False
    scheme = source.split(':', 1)[0].strip().lower()
    if not _SOURCE_SCHEME.fullmatch(scheme):
        return False
    return scheme in _SOURCE_KIND and scheme not in ('env', 'aws_sdk', 'external_process')


def _read_env_present(name: str):
    """Usability of one environment-backed credential name (real path).

    The credential value is bound only inside the ``has_usable_secret(...)``
    expression; it is never assigned, stored, logged, stringified, hashed,
    persisted or returned by this function.
    """
    try:
        from hermes_cli.config import get_env_value_prefer_dotenv
        from hermes_cli.auth import has_usable_secret
        usable = bool(has_usable_secret(get_env_value_prefer_dotenv(name) or ""))
    except Exception:
        try:
            usable = bool(os.environ.get(name))  # presence only; value never bound to a name
        except Exception:
            usable = None
    return usable


def _host_env_present(name: str):
    """Seam: delegates to the real reader; monkeypatched in unit tests."""
    return _read_env_present(name)

def _host_explicit(provider: str):
    """Hermes' explicit-configuration check; None when the host cannot answer.

    Registry-backed providers use the host's own check (offline inside it).
    Non-registry providers fall back to pool-entry and active/config evidence
    only: the host's models.dev fallback downloads its catalog on cache miss,
    which must never be triggered inside an existence probe (it would also
    defeat offline/isolated operation). Absence of evidence there is reported
    as False, never as an error.
    """
    try:
        from hermes_cli.auth import PROVIDER_REGISTRY
        registry_backed = provider in PROVIDER_REGISTRY
    except Exception:
        registry_backed = False
    if registry_backed:
        try:
            from hermes_cli.auth import is_provider_explicitly_configured
            return bool(is_provider_explicitly_configured(provider))
        except Exception:
            return None
    try:
        from hermes_cli.auth import _explicit_pool_entry_present
        if _explicit_pool_entry_present(provider):
            return True
    except Exception:
        pass
    try:
        from hermes_cli.auth import _active_provider_is, _config_selects_provider
        if _active_provider_is(provider) or _config_selects_provider(provider):
            return True
    except Exception:
        pass
    return False


def _read_pool_snapshot():
    """Bounded existence enumeration of the Hermes credential pool (real path).

    ONE call to ``read_credential_pool(None)`` enumerates which provider IDs
    have pool rows. The value-bearing mapping is iterated once and discarded
    here; per provider only ``{'entries': int, 'oauth': bool}`` is retained.
    Entry keys, tokens, fingerprints, labels and arbitrary source strings are
    never read past this function. Provider IDs are validated; the returned
    dict is all that leaves this function. Returns None when the host cannot
    answer.
    """
    try:
        from hermes_cli.auth import read_credential_pool
        raw = read_credential_pool(None)
    except Exception:
        return None
    if not isinstance(raw, dict):
        return None
    out = {}
    for key, entries in raw.items():
        if not _valid_provider_id(key):
            continue
        if not isinstance(entries, list):
            continue
        oauth = False
        examined = 0
        for entry in entries:
            if examined >= _MAX_POOL_ROWS:
                break
            examined += 1
            if isinstance(entry, dict) and _pool_entry_oauth(entry):
                oauth = True
        if examined:
            out[key] = {'entries': examined, 'oauth': oauth}
    return out


def _host_pool_snapshot():
    """Seam: delegates to the real reader; monkeypatched in unit tests."""
    return _read_pool_snapshot()


def _read_suppressed_sources(provider: str):
    """Sanitized suppressed source categories for one provider (public host API).

    Strict allowlist: only shape-valid schemes from the fixed enum are kept;
    anything else reports as ``unknown``. At most four entries are returned.
    """
    try:
        from hermes_cli.auth import suppressed_credential_sources
        raw = suppressed_credential_sources(provider)
    except Exception:
        return None
    if not isinstance(raw, (set, frozenset, list, tuple)):
        return None
    out = set()
    for entry in raw:
        if not isinstance(entry, str):
            out.add('unknown')
            continue
        scheme = entry.split(':', 1)[0].strip().lower()
        out.add(scheme if (_SOURCE_SCHEME.fullmatch(scheme) and scheme in _SOURCE_KIND) else 'unknown')
    return sorted(out)[:4]


def _host_suppressed(provider: str):
    """Seam: delegates to the real reader; monkeypatched in unit tests."""
    return _read_suppressed_sources(provider)


def _host_registered(provider: str) -> bool:
    try:
        import providers
        return providers.get_provider_profile(provider) is not None
    except Exception:
        return False


def _explicitly_configured(provider: str):
    return _host_explicit(provider)


def _pool_observations():
    return _host_pool_snapshot()


_SOURCE_VALID = re.compile(r'^[a-z][a-z0-9_]{0,31}$')


def _suppressed_sources(provider: str):
    """Allowlist-filtered suppressed source categories.

    Applies the same allowlist to the host seam's answer so no seam, even a
    misbehaving one, can push an arbitrary label into the output boundary.
    """
    raw = _host_suppressed(provider)
    if not isinstance(raw, (list, tuple, set, frozenset)):
        return []
    out = set()
    for entry in raw:
        if not isinstance(entry, str):
            out.add('unknown')
            continue
        scheme = entry.split(':', 1)[0].strip().lower()
        out.add(scheme if (_SOURCE_VALID.fullmatch(scheme) and scheme in _SOURCE_KIND) else 'unknown')
    return sorted(out)[:4]


def _nous_oauth_presence():
    """Presence-only observation of Hermes-managed Nous Portal OAuth state.

    Reads nothing beyond existence and sanitized category; token material is
    never compared, printed, stored or sent anywhere. Presence is not verification.
    """
    try:
        from hermes_cli.auth import read_credential_pool
        entries = read_credential_pool('nous')
    except Exception:
        return None, 'host_presence_unavailable'
    if isinstance(entries, list):
        return bool(entries[:_MAX_POOL_ROWS]), None
    return None, 'host_presence_unavailable'


def _presence_six(provider: str):
    """Presence for the six adapter-backed providers.

    Order: (1) provider profile declares env vars and at least one resolves
    through Hermes' dotenv-aware reader (or the process environment) → the
    credential is configured; (2) profile resolution succeeded but nothing
    resolves → fall back to Hermes' explicit-configuration check (pool rows
    from explicit flows count); (3) profile unreadable → unknown.
    """
    try:
        import providers
        profile = providers.get_provider_profile(provider)
    except PermissionError:
        return None, 'permission_denied'
    except Exception:
        profile = None
    if profile is None:
        # The host cannot name the provider — do not pretend.
        return None, 'host_presence_unavailable'
    if provider == 'nous':
        return _nous_oauth_presence()
    expected = ENV_ALIASES.get(provider) or ((PROVIDERS[provider][1],) if PROVIDERS[provider][1] else ())
    declared = getattr(profile, 'env_vars', ())
    if not isinstance(declared, (tuple, list)):
        return None, 'host_presence_unavailable'
    supported = [name for name in expected if name in declared]
    if supported:
        results = [_host_env_present(name) for name in supported]
        if any(r is True for r in results):
            return True, None
        if any(r is None for r in results):
            return None, 'host_presence_unavailable'
        # Nothing resolves via env/dotenv — the pool may still hold an
        # explicit credential (e.g. seeded by `hermes auth`).
        explicit = _host_explicit(provider)
        if explicit is True:
            return True, None
        if explicit is False:
            return False, None
        return None, 'host_presence_unavailable'
    # Profile found but no resolvable expected env slot: with nothing to affirm,
    # only an explicit pool/OAuth observation settles presence; otherwise unknown.
    explicit = _host_explicit(provider)
    if explicit is True:
        return True, None
    return None, 'host_presence_unavailable'


def host_presence(provider):
    """Observe presence for one of the six adapter-backed providers."""
    validate_provider(provider)
    return _presence_six(provider)


def _generic_presence(provider: str, pool):
    """Presence for a provider ID outside the six (e.g. observed through the
    Hermes credential pool). Never confirms beyond Hermes' own signals."""
    if provider == 'nous':
        state, reason = _nous_oauth_presence()
        suppressed = _host_suppressed(provider) or []
        if suppressed:
            return False, 'suppressed_by_hermes', 'suppressed', state
        return state, reason, ('hermes_oauth_store' if state is not False else 'none'), True if state else state
    row = (pool or {}).get(provider)
    explicit = _host_explicit(provider)
    suppressed = _host_suppressed(provider) or []
    entries = int((row or {}).get('entries') or 0) if row else 0
    row_oauth = bool((row or {}).get('oauth')) if row else False
    source = 'none'
    if row:
        source = 'hermes_oauth_store' if row_oauth else 'hermes_credential_pool'
    elif explicit is True:
        source = 'process_environment'
    # Fail closed on suppression: if the operator suppressed 'env' and the
    # only pool rows we can see are non-OAuth (typically env-seeded), do not
    # affirm an unusable credential. OAuth rows are never downgraded by an
    # 'env'-scoped suppression.
    if suppressed and (entries == 0 or ('env' in suppressed and not row_oauth)):
        return False, 'suppressed_by_hermes', 'suppressed', explicit
    if explicit is True:
        return True, None, source, True
    if explicit is False:
        return False, None, source, False
    if row:
        # Pool entries exist but explicit-configuration checks cannot run;
        # report presence with the sanitized source category.
        return True, None, source, None
    return None, 'host_presence_unavailable', source, None


def credential_source_category(provider: str, pool=None):
    """Sanitized source category (never values): one of the fixed literals
    ``hermes_oauth_store`` / ``hermes_credential_pool`` / ``none``."""
    pool = pool if pool is not None else _pool_observations()
    if provider == 'nous':
        row = (pool or {}).get('nous')
        return 'hermes_oauth_store' if row else 'none'
    row = (pool or {}).get(provider)
    if row:
        return 'hermes_oauth_store' if row.get('oauth') else 'hermes_credential_pool'
    return 'none'


def hermes_registered(provider: str) -> bool:
    """True when Hermes ships a provider profile for the ID."""
    return _host_registered(provider)


def _host_row(provider, entry, authorized, observed, config_readable, valid_config, pool=None):
    """Truthful row for a host-recognized non-six provider.

    Visible to the operator with independent status axes; never implies
    authorization, and never reports usable/routable without verified-free
    evidence — the free-only gate treats unknown cost as ineligible."""
    if not config_readable or not valid_config:
        # No readable operator configuration — never probe anything.
        present, reason, source, explicit = None, 'configuration_unavailable', 'none', None
    else:
        present, reason, source, explicit = _generic_presence(provider, pool)
    suppressed = _suppressed_sources(provider)
    if present is not True and present is not False:
        present = None
    if reason not in (None, 'provider_not_authorized', 'configuration_unavailable',
                      'permission_denied', 'host_presence_unavailable', 'suppressed_by_hermes',
                      'suppressed_by_hermes'):
        reason = 'host_presence_unavailable'
    if not authorized and reason is None:
        reason = 'provider_not_authorized'
    auth_failed = bool(observed.get('auth_failed')) if isinstance(observed, dict) else False

    def _count(key):
        value = observed.get(key) if isinstance(observed, dict) else None
        return value if type(value) is int and value >= 0 else None

    listing = entry.get('model_listing')
    if listing == 'supported':
        discovery_kind = 'host_catalog'
    elif listing == 'disabled':
        discovery_kind = 'host_catalog_disabled'
    else:  # host did not declare a model catalog; recognition alone is not a catalog
        discovery_kind = 'catalog_unknown'
    row = _row_base(provider, entry.get('label') or provider)
    row.update({
        'id': f'hermes-host:{provider}', 'provider_id': provider, 'label': entry.get('label') or provider,
        'family': 'llm_host',
        'authorized': bool(authorized),
        'credential_source': source,
        'hermes_explicitly_configured': explicit, 'hermes_registered': True,
        'discovery': discovery_kind,
        'inference_authenticated': 'unknown', 'account_allowance': 'unknown',
        'usable_for_routing': 'not_authorized' if not authorized else 'unknown',
        'masked_credential': '••••••••' if present is True else None,
        'presence': 'configured' if present is True else 'not_observed' if present is False else 'unknown',
        'credential_source_scope': (source if source in ('hermes_credential_pool', 'hermes_oauth_store', 'process_environment', 'suppressed', 'none', 'unknown') else 'unknown'),
        'authentication_requirement': entry.get('auth_type') or 'unknown',
        'authenticated_note': 'Presence only — never proof the credential is accepted upstream.',
        'suppressed_sources': suppressed if suppressed else [],
        'onboarding_url': '/autorouter?provider=' + provider,
        'readiness': {'configured': authorized, 'presence_observed': present,
            'authentication_validated': 'unknown', 'models_discovered': _count('discovered_model_count'),
            'models_eligible': None, 'model_count_scope': 'displayed proof snapshot (maximum 500 rows)',
            'operationally_usable': 'unknown'},
        'discovered_model_count': _count('model_count') if _count('model_count') is not None else _count('discovered_model_count'),
        'guidance': None,
        'health': 'provider_auth_failure_observed' if auth_failed else 'unknown',
        'health_scope': 'provider/model observation; not bound to the current credential',
        'reason': reason or ('authentication_failure_observed' if auth_failed else None),
        'instructions': 'Host-recognized provider; discovery runs through the host catalog/runtime. '
                        'Authorization, credential presence, catalog and free eligibility are independent gates.',
        'capability_evidence': dict(entry, provider_id=provider),
        'operations': capability_matrix(),
    })
    return row


def _row_base(provider, label):
    return {
        'authorized': False, 'enabled': None, 'activation_state': 'not_observable',
        'presence': 'unknown', 'masked_credential': None, 'verification': 'unverified',
        'verified': False, 'last_tested_at': None, 'credential_count': None,
        'account_count': None, 'connection_slots': None,
        'connection_slots_status': 'host_capability_unavailable',
        'onboarding_url': None, 'readiness': None,
        'credential_source_scope': None, 'account_scope': 'not_observable', 'region_scope': 'unknown',
        'authentication_requirement': 'api_key', 'model_scope': None,
        'guidance': None, 'discovered_model_count': None, 'health': 'unknown',
        'health_scope': 'provider/model observation; not bound to the current credential',
        'reason': None, 'instructions': INSTRUCTIONS, 'operations': capability_matrix(),
    }


def _adapter_row(provider, label, authorized, observed, config_readable, valid_config,
                 presence_reader=None, pool=None):
    present, reason = None, 'provider_not_authorized'
    if not config_readable or not valid_config:
        # No readable operator configuration — never probe anything.
        present, reason = None, 'configuration_unavailable'
    elif presence_reader is not None:
        try:
            out = presence_reader(provider)
            if isinstance(out, tuple) and len(out) == 2:
                present, reason = out
            elif isinstance(out, tuple) and len(out) == 3:
                present, reason = out[0], out[1]
        except PermissionError:
            present, reason = None, 'permission_denied'
        except Exception:
            present, reason = None, 'host_presence_unavailable'
    else:
        present, reason = _presence_six(provider)
    if present is not True and present is not False:
        present = None
    if reason not in (None, 'provider_not_authorized', 'configuration_unavailable',
                      'permission_denied', 'host_presence_unavailable'):
        reason = 'host_presence_unavailable'
    if not authorized and reason is None:
        # The probe ran and produced an answer; the operator's reason it is not
        # routable is the missing authorization, not a credential failure.
        reason = 'provider_not_authorized'
    row = _row_base(provider, label)
    auth_failed = bool(observed.get('auth_failed')) if isinstance(observed, dict) else False
    explicit = _host_explicit(provider) if presence_reader is None else None

    def _count(key):
        value = observed.get(key) if isinstance(observed, dict) else None
        return value if type(value) is int and value >= 0 else None

    discovered = _count('discovered_model_count')
    eligible = _count('eligible_model_count')
    row.update({
        'id': ('hermes-oauth:nous' if provider == 'nous' else f'hermes-env:{provider}'),
        'provider_id': provider, 'label': label, 'family': 'llm_adapter',
        'authorized': bool(authorized),
        'credential_source': credential_source_category(provider, pool),
        'hermes_explicitly_configured': explicit,
        'hermes_registered': True, 'discovery': 'adapter',
        'inference_authenticated': 'unknown', 'account_allowance': 'unknown',
        'usable_for_routing': ('ready' if (authorized and present is True)
                               else 'not_authorized' if not authorized
                               else 'not_configured' if present is False else 'unknown'),
        'masked_credential': '••••••••' if present is True else None,
        'presence': 'configured' if present is True else 'not_observed' if present is False else 'unknown',
        'credential_source_scope': ('hermes_credential_pool_and_environment' if provider != 'nous' else 'hermes_oauth_store'),
        'authentication_requirement': 'api_key' if provider != 'nous' else 'oauth_portal',
        'authenticated_note': 'Presence only — never proof the credential is accepted upstream.',
        'onboarding_url': '/autorouter?provider=' + provider,
        'readiness': {'configured': authorized, 'presence_observed': present,
            'authentication_validated': 'unknown', 'models_discovered': discovered,
            'models_eligible': eligible, 'model_count_scope': 'displayed proof snapshot (maximum 500 rows)',
            'operationally_usable': 'unknown'},
        'discovered_model_count': _count('model_count') if _count('model_count') is not None else discovered,
        'guidance': dict(GUIDANCE[provider], environment_slot=(PROVIDERS[provider][1] if provider != 'nous' else 'Nous Portal OAuth (managed by Hermes)'),
                         source_type='official_provider_documentation', verified_on='2026-11-07' if provider in ('groq', 'gemini', 'mistral') else ('2026-11-13' if provider == 'nous' else '2026-11-06')),
        'health': 'provider_auth_failure_observed' if auth_failed else 'unknown',
        'health_scope': 'provider/model observation; not bound to the current credential',
        'reason': reason or ('authentication_failure_observed' if auth_failed else None),
        'operations': capability_matrix(),
    })
    return row


def _unsupported_row(provider, pool):
    row = _row_base(provider, provider)
    present, reason, source, explicit = _generic_presence(provider, pool)
    suppressed = _suppressed_sources(provider)
    if present is not True and present is not False:
        present = None
    row.update({
        'id': f'hermes-pool:{provider}', 'provider_id': provider, 'label': provider,
        'family': 'llm_unsupported',
        'authorized': False, 'credential_source': source,
        'hermes_explicitly_configured': explicit, 'hermes_registered': hermes_registered(provider),
        'discovery': 'unsupported',
        'inference_authenticated': 'unknown', 'account_allowance': 'unknown',
        'usable_for_routing': 'unsupported',
        'masked_credential': '••••••••' if present is True else None,
        'presence': 'configured' if present is True else 'not_observed' if present is False else 'unknown',
        'credential_source_scope': (source if source in ('hermes_credential_pool', 'hermes_oauth_store', 'process_environment', 'suppressed', 'none', 'unknown') else 'unknown'),
        'authentication_requirement': 'unknown',
        'authenticated_note': 'Presence only — never proof the credential is accepted upstream.',
        'suppressed_sources': suppressed if suppressed else [],
        'onboarding_url': None,
        'readiness': {'configured': False, 'presence_observed': present,
            'authentication_validated': 'unknown', 'models_discovered': None,
            'models_eligible': None, 'model_count_scope': 'unsupported by AutoRouter',
            'operationally_usable': 'unsupported'},
        'discovered_model_count': None,
        'guidance': dict(UNSUPPORTED_GUIDANCE),
        'health': 'unknown',
        'reason': 'suppressed_by_hermes' if reason == 'suppressed_by_hermes' else ('unsupported_by_autorouter' if present is not False else 'not_configured'),
        'instructions': UNSUPPORTED_GUIDANCE['auth_prerequisite'],
        'operations': capability_matrix(),
    })
    return row


def _pool_keys(pool):
    return sorted(k for k in (pool or {}) if _valid_provider_id(k))


def inventory_provider_ids(config=None):
    """Bounded set of provider IDs the inventory covers: six adapter-backed
    providers, every Hermes-observed pool key, and every host-recognized
    canonical ID (ADR-0016)."""
    pool = _pool_observations()
    host = _host_ids()
    ids = list(ADAPTER_PROVIDERS) + [k for k in _pool_keys(pool) if k not in ADAPTER_PROVIDERS]
    ids.extend(p for p in sorted(host) if p not in ADAPTER_PROVIDERS and p not in ids)
    return ids[:_MAX_INVENTORY_ROWS]


def inventory(config, observations=None, state_status='unavailable', presence_reader=None):
    pool = _pool_observations()
    observations = observations or {}
    readable = config.get('available') is True
    values = config.get('values') or {}
    configured = values.get('providers')
    valid_config = valid_provider_list(configured)
    authorized_adapters = set(configured) & set(ADAPTER_PROVIDERS) if readable and valid_config else set()
    authorized_host = set(configured) & _host_ids() if readable and valid_config else set()
    authorized = authorized_adapters | authorized_host
    host_inventory = _registry.host_inventory() if _registry is not None else None
    host_entries = (host_inventory or {}).get("providers", {})

    connections = []
    for provider, (label, _) in PROVIDERS.items():
        suppressed = _suppressed_sources(provider)
        row = _adapter_row(
            provider, label, provider in authorized_adapters,
            observations.get(provider, {}) if isinstance(observations.get(provider), dict) else {},
            readable, valid_config,
            presence_reader=presence_reader,
            pool=pool)
        if suppressed:
            row['reason'] = row['reason'] or 'suppressed_by_hermes'
            row['suppressed_sources'] = suppressed
        row.setdefault('suppressed_sources', [])
        connections.append(row)
    others = sorted({p for p in _pool_keys(pool) if p} | authorized_host | set(host_entries))
    for provider in sorted(set(others) - set(PROVIDERS)):
        entry = host_entries.get(provider)
        if entry is not None:
            connections.append(_host_row(
                provider, entry, provider in authorized_host,
                observations.get(provider, {}) if isinstance(observations.get(provider), dict) else {},
                readable, valid_config, pool=pool))
        else:
            connections.append(_unsupported_row(provider, pool))

    return {'available': True, 'mode': 'read_only', 'connections': connections,
            'local_state': state_status, 'configuration_available': readable and valid_config,
            'managed': config.get('managed') is True,
            'provider_scope': 'adapter_backed_six_plus_hermes_observed',
            'capabilities': capability_matrix(),
            'instructions': INSTRUCTIONS,
            'account_allowance': 'unknown',
            'inference_authentication': 'unverified'}


def capability_matrix():
    return {
        'inventory': {'supported': True, 'scope': 'hermes-observed presence (pool + dotenv-resolved environment + OAuth store); read-only'},
        **{op: {'supported': False, 'reason': 'host_capability_unavailable'} for op in OPERATIONS},
        'authorize_provider': {
            'supported': True,
            'scope': 'add an adapter-backed provider ID to plugins.entries.autorouter.settings.providers via the settings API',
            'effect': 'authorizes catalog discovery and selection only; never mutates Hermes credentials or the global model'},
        'enumerate_accounts': {'supported': False, 'reason': 'host_capability_unavailable'},
        'named_connections': {'supported': False, 'reason': 'host_capability_unavailable'},
        'reveal': {'supported': False, 'reason': 'host_reauthentication_unavailable'},
        'export': {'supported': False, 'reason': 'credential_export_disabled'},
    }


def unavailable_operation(provider, operation, config):
    validate_provider(provider)
    if operation not in OPERATIONS:
        raise ConnectionError('unsupported_operation', 400, 'Operation is unavailable')
    if config.get('managed') is True:
        raise ConnectionError('managed_configuration', 403, 'Hermes configuration is managed')
    if config.get('available') is not True:
        raise ConnectionError('configuration_unavailable', 503, 'Hermes configuration is unavailable')
    configured = (config.get('values') or {}).get('providers')
    if not valid_provider_list(configured) or provider not in configured:
        raise ConnectionError('provider_not_authorized', 403, 'Provider is not authorized by operator configuration')
    raise ConnectionError('host_capability_unavailable', 501, INSTRUCTIONS)


_MAX_INVENTORY_ROWS = 256


def inventory_summary(config, observations=None, state_status='unavailable'):
    """Compact, secret-free summary for the dashboard header."""
    result = inventory(config, observations, state_status)
    return {
        'available': result['available'],
        'adapter_backed': len([c for c in result['connections'] if c['family'] == 'llm_adapter']),
        'host_recognized': len([c for c in result['connections'] if c['family'] == 'llm_host']),
        'authorized_host': sum(1 for c in result['connections'] if c['family'] == 'llm_host' and c['authorized']),
        'hermes_observed_unsupported': len([c for c in result['connections'] if c['family'] == 'llm_unsupported']),
        'configured_adapters': sum(1 for c in result['connections'] if c['family'] == 'llm_adapter' and c['presence'] == 'configured'),
        'authorized_adapters': sum(1 for c in result['connections'] if c['family'] == 'llm_adapter' and c['authorized']),
        'account_allowance': result['account_allowance'],
        'inference_authentication': result['inference_authentication'],
    }
