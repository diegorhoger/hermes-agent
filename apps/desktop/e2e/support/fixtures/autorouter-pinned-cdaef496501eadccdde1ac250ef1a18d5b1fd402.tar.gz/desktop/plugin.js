/* AutoRouter — Desktop management console (runtime plugin).
 *
 * Registers a sidebar entry + a full page at `/autorouter` inside Hermes
 * Desktop with the five AutoRouter management tabs (Overview, Providers,
 * Models, Analytics, Settings). Everything is driven by the SAME backend the
 * Hermes web dashboard uses: this plugin talks to the gateway's
 * `/api/plugins/autorouter/*` namespace through `ctx.rest` — no second
 * server, no second state reader, no copied data.
 *
 * Plain ESM; imports are limited to `@hermes/plugin-sdk` and `react`
 * (the Desktop runtime door's import allowlist). No build step.
 */

import {
  Badge,
  Button,
  Codicon,
  EmptyState,
  ErrorState,
  Input,
  PALETTE_AREA,
  ROUTES_AREA,
  SegmentedControl,
  SIDEBAR_NAV_AREA,
  SearchField,
  Tabs,
  TabsList,
  TabsTrigger,
  Textarea,
  ToggleRow,
  host,
  cn,
} from '@hermes/plugin-sdk'
import { useEffect, useRef, useState } from 'react'
import { jsx, jsxs, Fragment } from 'react/jsx-runtime'

const VERSION = '0.2.0'
const PAGE_PATH = '/autorouter'

const TABS = [
  { id: 'overview', label: 'Overview' },
  { id: 'providers', label: 'Providers' },
  { id: 'models', label: 'Models' },
  { id: 'profiles', label: 'Profiles' },
  { id: 'analytics', label: 'Analytics' },
  { id: 'settings', label: 'Settings' },
]

/* ---------------------------------------------------------------- *
 *  Formatting helpers (display only; never mutate payloads)
 * ---------------------------------------------------------------- */

function fmtNum(value) {
  if (value == null || Number.isNaN(Number(value))) {
    return '—'
  }
  return Number(value).toLocaleString()
}

function fmtCtx(value) {
  const n = Number(value)
  if (!Number.isFinite(n) || n <= 0) {
    return 'unknown'
  }
  if (n >= 1_000_000) {
    return `${(n / 1_000_000).toFixed(n % 1_000_000 === 0 ? 0 : 1)}M`
  }
  if (n >= 1_000) {
    return `${Math.round(n / 1_000)}K`
  }
  return String(Math.round(n))
}

function fmtAbs(epochSeconds) {
  const n = Number(epochSeconds)
  if (!Number.isFinite(n) || n <= 0) {
    return '—'
  }
  return new Date(n * 1000).toLocaleString()
}

function fmtRel(epochSeconds) {
  const n = Number(epochSeconds)
  if (!Number.isFinite(n) || n <= 0) {
    return '—'
  }
  const delta = Math.round(Date.now() / 1000 - n)
  if (delta < 0) {
    return 'just now'
  }
  if (delta < 60) {
    return `${delta}s ago`
  }
  if (delta < 3600) {
    return `${Math.floor(delta / 60)}m ago`
  }
  if (delta < 86400) {
    return `${Math.floor(delta / 3600)}h ago`
  }
  return `${Math.floor(delta / 86400)}d ago`
}

function fmtMs(ms) {
  const n = Number(ms)
  if (!Number.isFinite(n) || n < 0) {
    return '—'
  }
  if (n >= 10_000) {
    return `${Math.round(n / 1000)}s`
  }
  if (n >= 1_000) {
    return `${(n / 1000).toFixed(2)}s`
  }
  return `${Math.round(n)}ms`
}

/* ---------------------------------------------------------------- *
 *  Backend error plumbing
 * ---------------------------------------------------------------- *
 * `ctx.rest` rejects with a one-line message of the form
 * `"<status>: <body>"` (produced by the Electron bridge). Validation
 * failures carry a JSON body: `{"detail": {"errors": [...]}}` — FastAPI's
 * `HTTPException(detail={"errors": errors})` shape. Unwrap both.
 * ---------------------------------------------------------------- */

function httpStatusOf(error) {
  if (error && typeof error === 'object' && Number.isFinite(Number(error.statusCode))) {
    return Number(error.statusCode)
  }
  const match = /^(\d{3}):/.exec(String(error?.message ?? error))
  return match ? Number(match[1]) : null
}

function parseBodyOf(error) {
  const message = String(error?.message ?? error ?? '')
  const match = /^\d{3}:\s*([\s\S]*)$/.exec(message)
  const raw = match ? match[1] : ''
  try {
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

function errorText(error) {
  if (!error) {
    return 'Unknown error'
  }
  const body = parseBodyOf(error)
  const detail = body && (body.detail ?? body)
  if (Array.isArray(detail?.errors)) {
    return detail.errors.join(' · ')
  }
  if (typeof detail === 'string') {
    return detail
  }
  if (detail && typeof detail.message === 'string') {
    return detail.message
  }
  const message = String(error?.message ?? error)
  return message.length > 300 ? `${message.slice(0, 300)}…` : message
}

function errorListOf(error) {
  const body = parseBodyOf(error)
  const detail = body && (body.detail ?? body)
  if (Array.isArray(detail?.errors)) {
    return detail.errors.map(String)
  }
  if (body && Array.isArray(body.detail?.errors)) {
    return body.detail.errors.map(String)
  }
  return null
}

/* ---------------------------------------------------------------- *
 *  Data hook — one small, dependency-free fetcher per panel
 * ---------------------------------------------------------------- */

function useRest(ctx, path) {
  const [state, setState] = useState({ data: null, error: null, loading: true })
  const [nonce, setNonce] = useState(0)

  useEffect(() => {
    if (!path) {
      setState({ data: null, error: null, loading: false })
      return undefined
    }
    let alive = true
    setState((prev) => ({ data: prev.data, error: null, loading: true }))
    ctx.rest(path).then(
      (data) => {
        if (alive) {
          setState({ data, error: null, loading: false })
        }
      },
      (error) => {
        if (alive) {
          setState({ data: null, error, loading: false })
        }
      },
    )
    return () => {
      alive = false
    }
  }, [ctx, path, nonce])

  return { ...state, reload: () => setNonce((n) => n + 1) }
}

function useDebounced(value, delayMs) {
  const [debounced, setDebounced] = useState(value)
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delayMs)
    return () => clearTimeout(id)
  }, [value, delayMs])
  return debounced
}

/* ---------------------------------------------------------------- *
 *  Small presentational pieces (SDK-composed; no raw HTML injection)
 * ---------------------------------------------------------------- */

function Panel({ title, action, children }) {
  return jsxs('section', {
    className: 'rounded-lg border border-(--ui-stroke-secondary) bg-(--ui-bg-elevated)',
    children: [
      jsxs('header', {
        className: 'flex items-center justify-between gap-2 border-b border-(--ui-stroke-tertiary) px-3 py-2',
        children: [
          jsx('h2', {
            className: 'text-xs font-semibold uppercase tracking-wide text-(--ui-text-tertiary)',
            children: title,
          }),
          action ?? null,
        ],
      }),
      jsx('div', { className: 'p-3', children }),
    ],
  })
}

function StatCard({ label, value, hint, tone }) {
  return jsxs('div', {
    className: 'rounded-lg border border-(--ui-stroke-secondary) bg-(--ui-bg-elevated) px-3 py-2.5',
    children: [
      jsx('div', {
        className: 'text-[0.65rem] font-medium uppercase tracking-wide text-(--ui-text-tertiary)',
        children: label,
      }),
      jsx('div', {
        className: cn(
          'mt-0.5 text-lg font-semibold tabular-nums',
          tone === 'ok' && 'text-emerald-600 dark:text-emerald-300',
          tone === 'warn' && 'text-amber-600 dark:text-amber-300',
          tone === 'bad' && 'text-destructive',
        ),
        children: value,
      }),
      hint
        ? jsx('div', {
            className: 'mt-0.5 text-[0.65rem] leading-snug text-(--ui-text-tertiary)',
            children: hint,
          })
        : null,
    ],
  })
}

function LoadingRow({ label }) {
  return jsx('div', {
    className: 'flex h-32 items-center justify-center text-xs text-(--ui-text-tertiary)',
    role: 'status',
    'aria-live': 'polite',
    children: label ?? 'Loading…',
  })
}

function ErrorBox({ error, onRetry }) {
  return jsx(ErrorState, {
    title: 'AutoRouter evidence is unavailable',
    description: errorText(error),
    className: 'py-8',
    children: onRetry
      ? jsx('div', {
          className: 'flex justify-center',
          children: jsx(Button, {
            variant: 'secondary',
            size: 'sm',
            onClick: onRetry,
            children: 'Retry',
          }),
        })
      : null,
  })
}

function UnavailableNote({ items }) {
  if (!Array.isArray(items) || items.length === 0) {
    return null
  }
  return jsxs('div', {
    className: 'flex items-start gap-2 rounded-md border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-[0.7rem] leading-snug text-amber-700 dark:text-amber-300',
    role: 'status',
    children: [
      jsx(Codicon, { name: 'warning', size: '0.8rem', className: 'mt-0.5 shrink-0' }),
      jsxs('span', {
        children: ['Some evidence is unavailable: ', items.join(', '), '.'],
      }),
    ],
  })
}

function healthBadge(model) {
  const h = model?.health ?? {}
  if (h.retired) {
    return jsx(Badge, { variant: 'destructive', children: 'retired' })
  }
  if (h.auth_failed) {
    return jsx(Badge, { variant: 'destructive', children: 'auth failed' })
  }
  if (h.available === false) {
    const reason = h.reason && h.reason !== 'health_unknown' ? h.reason : 'unavailable'
    return jsx(Badge, { variant: 'warn', children: reason.replaceAll('_', ' ') })
  }
  return jsx(Badge, { variant: 'success', children: 'available' })
}

const tableHead = 'px-2 py-1.5 text-left text-[0.6rem] font-semibold uppercase tracking-wide text-(--ui-text-tertiary)'
const tableCell = 'px-2 py-1.5 align-top text-[0.72rem]'

function DataTable({ caption, columns, rows, stickyLast }) {
  // stickyLast pins the final column (the table's action cell) to the right
  // edge of the scrollport so primary actions stay reachable without a
  // horizontal scroll at narrow panel widths. Opt-in per table.
  const stickyCell = 'sticky right-0 bg-(--ui-bg-elevated)'
  return jsx('div', {
    className: 'overflow-x-auto',
    children: jsxs('table', {
      className: 'w-full border-collapse',
      'aria-label': caption,
      children: [
        jsx('thead', {
          children: jsx('tr', {
            className: 'border-b border-(--ui-stroke-secondary)',
            children: columns.map((col, i) =>
              jsx('th', {
                key: i,
                scope: 'col',
                className: stickyLast && i === columns.length - 1 ? cn(tableHead, stickyCell) : tableHead,
                children: col,
              }),
            ),
          }),
        }),
        jsx('tbody', { children: rows }),
      ],
    }),
  })
}

/* ---------------------------------------------------------------- *
 *  TAB — Overview
 * ---------------------------------------------------------------- */

function OverviewTab({ ctx }) {
  const { data, error, loading, reload } = useRest(ctx, '/overview')

  if (loading && !data) {
    return jsx(LoadingRow, { label: 'Reading AutoRouter state…' })
  }
  if (error) {
    return jsx(ErrorBox, { error, onRetry: reload })
  }

  const d = data ?? {}
  if (d.available === false) {
    return jsxs('div', {
      className: 'flex flex-col gap-3',
      children: [
        jsx(ErrorState, {
          title: 'AutoRouter state is not ready',
          description: d.reason ?? 'The plugin state store could not be read.',
          className: 'py-6',
        }),
        jsx(UnavailableNote, { items: d.unavailable }),
      ],
    })
  }

  const p = d.plugin ?? {}
  const c = d.counts ?? null
  const routing = d.routing ?? {}
  const decisions = Array.isArray(d.recent_decisions) ? d.recent_decisions : []
  const failures = Array.isArray(d.recent_failures) ? d.recent_failures : []
  const vpg = d.virtual_pin_guard
  const arp = d.active_routing_profile

  const attention = c ? (c.cooldown ?? 0) + (c.retired ?? 0) + (c.auth_failed ?? 0) + (c.health_invalid ?? 0) : null

  const lastDecision = routing.last_decision ?? null

  return jsxs('div', {
    className: 'flex flex-col gap-3',
    children: [
      vpg && vpg.state === 'unresolved_pin'
        ? jsxs('div', {
            role: 'alert',
            className: 'flex items-start gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-[0.72rem] leading-snug text-destructive',
            children: [
              jsx(Codicon, { name: 'error', size: '0.85rem', className: 'mt-0.5 shrink-0' }),
              jsxs('span', {
                children: [
                  jsx('strong', { children: 'Virtual default route unresolved. ' }),
                  vpg.detail ??
                    "The virtual model 'autorouter/auto-free' cannot be routed while chat routing is disabled.",
                  vpg.action ? jsx('br', {}) : null,
                  vpg.action ?? null,
                ],
              }),
            ],
          })
        : null,

      arp
        ? jsxs('div', {
            role: 'status',
            className: 'flex items-start gap-2 rounded-md border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-[0.72rem] leading-snug text-emerald-700 dark:text-emerald-300',
            children: [
              jsx(Codicon, { name: 'zap', size: '0.85rem', className: 'mt-0.5 shrink-0' }),
              jsxs('span', {
                children: [
                  jsx('strong', { children: 'Default routing profile. ' }),
                  `${arp.name ?? 'profile'} · ranking ${arp.ranking_policy ?? 'auto'}${arp.providers?.length ? ` · ${arp.providers.length} provider(s)` : ''}. Applies to AutoRouter sessions created after activation — sessions already running keep their resolved model; /resume re-resolves with the current default. Your global Hermes default model is unchanged.`,
                ],
              }),
            ],
          })
        : null,

      // Headline stats.
      jsxs('div', {
        className: 'grid grid-cols-2 gap-2 @xl:grid-cols-4',
        children: [
          jsx(StatCard, {
            label: 'Plugin status',
            value: p.enabled === true ? 'Enabled' : p.enabled === false ? 'Disabled' : 'Unknown',
            hint: p.config_managed ? 'administrator-managed config' : 'plugins.entries.autorouter',
            tone: p.enabled === true ? 'ok' : 'warn',
          }),
          jsx(StatCard, {
            label: 'Routing policy',
            value: String(p.policy ?? 'auto'),
            hint: 'V1 selection strategy (verified-free only)',
          }),
          jsx(StatCard, {
            label: 'Chat routing',
            value: routing.chat_routing_enabled ? 'Active' : 'Inactive',
            hint: routing.chat_routing_enabled
              ? 'Virtual route autorouter/auto-free resolves at session create'
              : 'Virtual route disabled — explicit /model selection unaffected',
            tone: routing.chat_routing_enabled ? 'ok' : undefined,
          }),
          jsx(StatCard, {
            label: 'Configured providers',
            value: fmtNum((p.providers ?? []).length),
            hint: (p.providers ?? []).join(', ') || 'none configured',
          }),
          jsx(StatCard, {
            label: 'Discovered models',
            value: c ? fmtNum(c.discovered_models) : '—',
            hint: c ? `${fmtNum(c.providers)} provider(s) in catalog` : 'catalog not available',
          }),
          jsx(StatCard, {
            label: 'Observed healthy',
            value: c ? fmtNum(c.healthy) : '—',
            hint: c
              ? `Recent evidence; current availability unknown. Unobserved: ${fmtNum(c.health_unknown)}`
              : 'catalog not available',
          }),
          jsx(StatCard, {
            label: 'Needs attention',
            value: attention == null ? '—' : fmtNum(attention),
            hint: c
              ? `cooldown ${fmtNum(c.cooldown)} · retired ${fmtNum(c.retired)} · auth ${fmtNum(c.auth_failed)}`
              : 'catalog not available',
            tone: attention && attention > 0 ? 'warn' : undefined,
          }),
          jsx(StatCard, {
            label: 'Paid inference',
            value: 'Disabled',
            hint: 'Verified-free only; paid fallback is not available',
          }),
        ],
      }),

      // Last routing decision (from the plugin's own decision ledger).
      lastDecision
        ? jsx(Panel, {
            title: 'Last routing decision',
            children: jsxs('div', {
              className: 'flex flex-wrap items-baseline gap-x-4 gap-y-1 text-[0.75rem]',
              children: [
                jsx('span', { className: 'font-mono text-(--ui-text-tertiary)', children: fmtRel(lastDecision.ts) }),
                jsx('span', { className: 'font-mono', children: `${lastDecision.provider ?? '—'} / ${lastDecision.model ?? '—'}` }),
                jsx(Badge, { variant: 'muted', children: lastDecision.policy ?? 'unknown policy' }),
                lastDecision.candidates != null
                  ? jsx('span', { className: 'text-(--ui-text-tertiary)', children: `${fmtNum(lastDecision.candidates)} candidates` })
                  : null,
                lastDecision.reason
                  ? jsx('span', { className: 'text-(--ui-text-tertiary)', children: `reason: ${lastDecision.reason}` })
                  : null,
              ],
            }),
          })
        : null,

      // Recent activity — side by side on wide panes.
      jsxs('div', {
        className: 'grid min-w-0 grid-cols-1 gap-3 @3xl:grid-cols-2',
        children: [
          jsx(Panel, {
            title: `Recent selection activity (${decisions.length})`,
            children:
              decisions.length === 0
                ? jsx(EmptyState, {
                    title: 'No selection activity yet',
                    description: 'AutoRouter records a decision each time its select interface runs.',
                    className: 'min-h-24',
                  })
                : jsx(DataTable, {
                    caption: 'recent selection activity',
                    columns: ['When', 'Policy', 'Provider / Model', 'Cand.'],
                    rows: decisions.map((row, i) =>
                      jsxs('tr', {
                        key: i,
                        className: 'border-b border-(--ui-stroke-tertiary) last:border-0',
                        children: [
                          jsx('td', { className: cn(tableCell, 'whitespace-nowrap text-(--ui-text-tertiary)'), children: fmtRel(row.ts), title: fmtAbs(row.ts) }),
                          jsx('td', { className: tableCell, children: jsx(Badge, { variant: 'muted', children: row.policy ?? '?' }) }),
                          jsxs('td', {
                            className: cn(tableCell, 'font-mono'),
                            children: [
                              jsx('div', { children: row.provider ?? '—' }),
                              jsx('div', { className: 'text-[0.68rem] text-(--ui-text-tertiary)', children: row.model ?? '—' }),
                            ],
                          }),
                          jsx('td', { className: cn(tableCell, 'tabular-nums'), children: fmtNum(row.candidates) }),
                        ],
                      }),
                    ),
                  }),
          }),
          jsx(Panel, {
            title: `Recent provider failures (${failures.length})`,
            children:
              failures.length === 0
                ? jsx(EmptyState, {
                    title: 'No failures recorded',
                    description: 'Failures appear here once providers report errors, cooldowns or retirements.',
                    className: 'min-h-24',
                  })
                : jsx(DataTable, {
                    caption: 'recent provider failures',
                    columns: ['When', 'Provider / Model', 'Status', 'Error'],
                    rows: failures.map((row, i) =>
                      jsxs('tr', {
                        key: i,
                        className: 'border-b border-(--ui-stroke-tertiary) last:border-0',
                        children: [
                          jsx('td', { className: cn(tableCell, 'whitespace-nowrap text-(--ui-text-tertiary)'), children: fmtRel(row.ts), title: fmtAbs(row.ts) }),
                          jsxs('td', {
                            className: cn(tableCell, 'font-mono'),
                            children: [
                              jsx('div', { children: row.provider ?? '—' }),
                              jsx('div', { className: 'text-[0.68rem] text-(--ui-text-tertiary)', children: row.model ?? '—' }),
                            ],
                          }),
                          jsx('td', { className: cn(tableCell, 'tabular-nums'), children: row.status_code != null ? String(row.status_code) : '—' }),
                          jsx('td', {
                            className: cn(tableCell, 'max-w-[16rem] truncate text-destructive/90'),
                            title: row.error ?? '',
                            children: row.error ?? 'no error detail recorded',
                          }),
                        ],
                      }),
                    ),
                  }),
          }),
        ],
      }),

      // Catalog facts.
      jsx(Panel, {
        title: 'Catalog & runtime',
        children: jsxs('dl', {
          className: 'grid grid-cols-1 gap-x-6 gap-y-1.5 text-[0.72rem] sm:grid-cols-2',
          children: [
            factRow('Last catalog refresh', d.last_catalog_refresh != null ? `${fmtAbs(d.last_catalog_refresh)} · ${fmtRel(d.last_catalog_refresh)}` : 'Not recorded'),
            factRow('Routing decisions recorded', c?.decisions != null ? fmtNum(c.decisions) : 'Not recorded'),
            factRow('Request outcomes', c ? `${fmtNum(c.successes)} ok · ${fmtNum(c.failures)} failed` : 'Not recorded'),
            factRow('Events logged', c?.events != null ? fmtNum(c.events) : 'Not recorded'),
          ],
        }),
      }),

      jsx(UnavailableNote, { items: d.unavailable }),
    ],
  })
}

function factRow(term, value) {
  return jsxs('div', {
    key: term,
    className: 'flex items-baseline justify-between gap-3 border-b border-(--ui-stroke-tertiary) pb-1.5',
    children: [
      jsx('dt', { className: 'text-(--ui-text-tertiary)', children: term }),
      jsx('dd', { className: 'font-mono text-right', children: value }),
    ],
  })
}

/* ---------------------------------------------------------------- *
 *  TAB — Providers
 * ---------------------------------------------------------------- */

function authBadge(auth) {
  if (auth === 'configured') {
    return jsx(Badge, { variant: 'success', children: 'Credential present' })
  }
  if (auth === 'missing') {
    return jsx(Badge, { variant: 'warn', children: 'Credential not observed' })
  }
  return jsx(Badge, { variant: 'muted', children: 'Unknown' })
}

function renderCredentialRow(row, onEnable, enabling) {
  const adapter = row.family === 'llm_adapter'
  const host = row.family === 'llm_host'
  const known = adapter || host
  const presence = row.presence
  const presenceBadge =
    presence === 'configured'
      ? jsx(Badge, { variant: 'success', children: 'configured' })
      : presence === 'not_observed'
        ? jsx(Badge, { variant: 'warn', children: 'not observed' })
        : jsx(Badge, { variant: 'muted', children: 'unknown' })
  const sourceText =
    { 'hermes_credential_pool': 'Hermes credential pool', 'hermes_oauth_store': 'Hermes OAuth store',
      'process_environment': 'process environment', 'suppressed': 'suppressed in Hermes', 'none': 'no source observed', 'unknown': 'source unknown' }[row.credential_source] ?? row.credential_source ?? 'source unknown'
  const suppressedNote = Array.isArray(row.suppressed_sources) && row.suppressed_sources.length > 0
  const recognitionCell = jsxs('div', {
    className: 'flex flex-col gap-1 items-start',
    children: [
      !known
        ? jsx(Badge, { variant: 'muted', children: 'host unrecognized' })
        : host
          ? jsx(Badge, { variant: 'success', children: 'host recognized' })
          : jsx(Badge, { variant: 'success', children: 'supported' }),
      jsx(Badge, {
        variant: row.discovery === 'host_catalog' || row.discovery === 'adapter' ? 'success' : row.discovery === 'host_catalog_disabled' ? 'warn' : 'muted',
        children: row.discovery === 'host_catalog' ? 'host catalog'
          : row.discovery === 'catalog_unknown' ? 'catalog unknown'
          : row.discovery === 'host_catalog_disabled' ? 'catalog disabled'
          : row.discovery === 'adapter' ? 'verified adapter'
          : 'no catalog',
      }),
    ],
  })
  const autoCell = !known
    ? jsx(Badge, { variant: 'warn', children: 'requires provider support' })
    : row.authorized
      ? jsx(Badge, { variant: 'success', children: 'enabled for discovery' })
      : presence === 'configured'
        ? jsx(Badge, { variant: 'warn', children: 'configured — not enabled' })
        : presence === 'unknown'
          ? jsx(Badge, { variant: 'muted', children: 'presence unknown' })
          : jsx(Badge, { variant: 'muted', children: 'not configured' })
  const busy = enabling?.state === 'saving' && enabling.providerId === row.provider_id
  const enabledNow = enabling?.state === 'ok' && enabling.providerId === row.provider_id
  const canEnable = known && !row.authorized && presence === 'configured' && !busy
  const action = !known
    ? jsx('span', { className: 'text-[0.65rem] text-(--ui-text-tertiary)', children: 'not declared' })
    : row.authorized || enabledNow
      ? jsx('span', { className: 'text-[0.65rem] text-emerald-600 dark:text-emerald-400', children: 'enabled' })
      : canEnable
        ? jsx(Button, { size: 'sm', variant: 'ghost', disabled: busy, onClick: () => onEnable(row.provider_id), children: busy ? 'Enabling…' : 'Enable for AutoRouter' })
        : jsx('span', { className: 'text-[0.65rem] text-(--ui-text-tertiary)', children: presence === 'configured' ? 'not eligible' : '—' })
  return jsxs('tr', {
    key: row.provider_id,
    className: 'border-b border-(--ui-stroke-tertiary) last:border-0',
    children: [
      jsxs('td', {
        className: tableCell,
        children: [
          jsxs('div', { className: 'flex items-center gap-1.5', children: [
            jsx('span', { className: 'font-mono font-medium', children: row.label ?? row.provider_id }),
            row.health === 'provider_auth_failure_observed'
              ? jsx(Badge, { variant: 'destructive', children: 'auth failure observed' })
              : null,
          ] }),
          jsx('div', { className: 'text-[0.6rem] text-(--ui-text-tertiary)', children: row.id }),
          suppressedNote
            ? jsx('div', { className: 'text-[0.6rem] text-amber-600 dark:text-amber-400', children: 'source suppressed in Hermes' })
            : null,
        ],
      }),
      jsxs('td', { className: tableCell, children: [presenceBadge, jsx('div', { className: 'mt-0.5 text-[0.6rem] text-(--ui-text-tertiary)', children: sourceText })] }),
      jsx('td', { className: tableCell, children: recognitionCell }),
      jsx('td', { className: tableCell, children: autoCell }),
      jsx('td', {
        className: cn(tableCell, 'tabular-nums'),
        children: known ? fmtNum(row.readiness?.models_eligible) : '—',
      }),
      jsx('td', { className: cn(tableCell, 'sticky right-0 bg-(--ui-bg-elevated) whitespace-nowrap'), children: action }),
    ],
  })
}

function ProvidersTab({ ctx }) {
  const { data, error, loading, reload } = useRest(ctx, '/providers')
  const [enabling, setEnabling] = useState({ state: 'idle', providerId: null, message: null })
  const enableProvider = (id) => {
    // Authoritative source of truth: a fresh read of the persisted settings,
    // never the (possibly stale) inventory snapshot this tab rendered.
    setEnabling({ state: 'saving', providerId: id, message: null })
    ctx.rest('/settings').then(
      (fresh) => {
        const current = Array.isArray(fresh?.values?.providers)
          ? fresh.values.providers.filter((p) => typeof p === 'string')
          : []
        if (current.includes(id)) {
          // A concurrent writer already enabled it — keep their change, do not write.
          setEnabling({ state: 'ok', providerId: id, message: 'Already enabled (a concurrent change was kept).' })
          reload()
          return
        }
        ctx.rest('/settings', { method: 'PUT', body: { updates: { providers: [...current, id] } } }).then(
          () =>
            ctx.rest('/settings').then(
              (verify) => {
                const after = Array.isArray(verify?.values?.providers) ? verify.values.providers : []
                if (after.includes(id)) {
                  setEnabling({ state: 'ok', providerId: id, message: null })
                } else {
                  // The write landed but the provider is gone afterwards — another
                  // writer won; the user's intervening change is preserved.
                  setEnabling({
                    state: 'error', providerId: id,
                    message: 'A concurrent change removed the provider — your settings kept the other writer. Re-check Settings.',
                  })
                }
                reload()
              },
              () => {
                setEnabling({ state: 'error', providerId: id, message: 'The provider was enabled but could not be re-read to verify.' })
                reload()
              },
            ),
          (err) => {
            setEnabling({ state: 'error', providerId: id, message: errorText(err) ?? 'The provider could not be enabled.' })
            reload()
          },
        )
      },
      () => setEnabling({ state: 'error', providerId: id, message: 'Settings could not be read; the provider was not enabled.' }),
    )
  }

  if (loading && !data) {
    return jsx(LoadingRow, { label: 'Reading provider evidence…' })
  }
  if (error) {
    return jsx(ErrorBox, { error, onRetry: reload })
  }

  const d = data ?? {}
  const providers = Array.isArray(d.providers) ? d.providers : []
  const inventory = d.connection_inventory ?? null
  const inventoryConnections = Array.isArray(inventory?.connections) ? inventory.connections : []

  return jsxs('div', {
    className: 'flex flex-col gap-3',
    children: [
      d.available === false
        ? jsx(ErrorState, {
            title: 'Provider evidence is unavailable',
            description: d.reason ?? 'The provider summary could not be assembled.',
            className: 'py-6',
          })
        : null,

      jsx(Panel, {
        title: 'Authorized providers',
        children:
          providers.length === 0
            ? jsx(EmptyState, {
                title: 'No providers configured',
                description: 'Add provider ids to plugins.entries.autorouter.settings.providers, then run a catalog refresh.',
                className: 'min-h-24',
              })
            : jsx(DataTable, {
                caption: 'configured providers',
                columns: ['Provider', 'Auth', 'Models', 'Available', 'Attention', 'Last refresh'],
                rows: providers.map((p) => {
                  const attentionCount =
                    (p.cooldown ?? 0) + (p.retired ?? 0) + (p.auth_failed ?? 0) + (p.health_invalid ?? 0)
                  return jsxs('tr', {
                    key: p.name,
                    className: 'border-b border-(--ui-stroke-tertiary) last:border-0',
                    children: [
                      jsxs('td', {
                        className: tableCell,
                        children: [
                          jsx('div', { className: 'font-mono font-medium', children: p.name }),
                          jsx('div', {
                            className: 'text-[0.65rem] text-(--ui-text-tertiary)',
                            children: p.configured ? 'authorized in config' : 'observed in catalog',
                          }),
                        ],
                      }),
                      jsx('td', { className: tableCell, children: authBadge(p.auth) }),
                      jsx('td', { className: cn(tableCell, 'tabular-nums'), children: fmtNum(p.discovered_models) }),
                      jsx('td', {
                        className: cn(tableCell, 'tabular-nums'),
                        children: `${fmtNum(p.healthy)}${p.health_unknown ? ` (+${fmtNum(p.health_unknown)} unknown)` : ''}`,
                      }),
                      jsx('td', {
                        className: tableCell,
                        children:
                          attentionCount > 0
                            ? jsx(Badge, {
                                variant: 'warn',
                                children: `${fmtNum(attentionCount)} (cd ${fmtNum(p.cooldown)} · ret ${fmtNum(p.retired)} · auth ${fmtNum(p.auth_failed)})`,
                              })
                            : jsx(Badge, { variant: 'success', children: 'none' }),
                      }),
                      jsx('td', {
                        className: cn(tableCell, 'whitespace-nowrap text-(--ui-text-tertiary)'),
                        title: fmtAbs(p.last_catalog_refresh),
                        children: fmtRel(p.last_catalog_refresh),
                      }),
                    ],
                  })
                }),
              }),
      }),

      jsx(Panel, {
        title: 'Hermes credential inventory (existence-only)',
        children:
          inventoryConnections.length === 0
            ? jsx(EmptyState, {
                title: 'Credential inventory unavailable',
                description: inventory?.reason ?? 'Presence could not be read; values are never shown.',
                className: 'min-h-24',
              })
            : jsxs(Fragment, {
                children: [
                  jsx('p', {
                    className: 'px-1 text-[0.65rem] leading-snug text-(--ui-text-tertiary)',
                    children:
                      'Existence-only, read-only. Presence is never proof a key is valid, never an account identity, and never authorizes a provider. Enabling a provider only adds it to AutoRouter\u2019s discovery/selection allowlist.',
                  }),
                  jsx(DataTable, {
                    caption: 'credential inventory',
                    columns: ['Provider', 'Hermes credential', 'Recognized / Catalog', 'AutoRouter', 'Eligible', 'Action'],
                    rows: inventoryConnections.map((row) => renderCredentialRow(row, enableProvider, enabling)),
                    stickyLast: true,
                  }),
                  enabling.message
                    ? jsx('p', { className: 'px-1 text-[0.68rem] text-amber-600 dark:text-amber-400', children: enabling.message })
                    : null,
                ],
              }),
      }),

      jsx(UnavailableNote, { items: d.unavailable }),
    ],
  })
}

/* ---------------------------------------------------------------- *
 *  TAB — Models (server-side search + pagination)
 * ---------------------------------------------------------------- */

function ModelsTab({ ctx }) {
  const [query, setQuery] = useState('')
  const [provider, setProvider] = useState('')
  const [eligibility, setEligibility] = useState('all')
  const [preference, setPreference] = useState('all')
  const [page, setPage] = useState(1)
  const [refreshing, setRefreshing] = useState(false)
  const [refreshNote, setRefreshNote] = useState(null)
  const [toggleBusy, setToggleBusy] = useState({})
  const [toggleNote, setToggleNote] = useState(null)
  const debouncedQuery = useDebounced(query, 250)

  // A filter change resets to page 1.
  const filterKey = `${debouncedQuery}|${provider}|${eligibility}|${preference}`
  const prevKey = useRef(filterKey)
  useEffect(() => {
    if (prevKey.current !== filterKey) {
      prevKey.current = filterKey
      setPage(1)
    }
  }, [filterKey])

  const path =
    `/models?page=${page}&page_size=50` +
    `&query=${encodeURIComponent(debouncedQuery)}` +
    `&provider=${encodeURIComponent(provider)}` +
    `&eligibility=${encodeURIComponent(eligibility)}` +
    `&preference=${encodeURIComponent(preference)}` +
    '&sort=provider'
  const { data, error, loading, reload } = useRest(ctx, path)

  const providerOptions = Array.isArray(data?.provider_options) ? data.provider_options : []

  const preferenceMeta = data?.preference ?? null
  const preferenceMode = preferenceMeta?.mode ?? 'unrestricted'
  const toggleKey = (m) => `${m?.provider ?? ''}/${m?.model ?? ''}`
  const preferenceBase = () => preferenceMeta?.preference_hash ?? ''
  const preferenceRequest = (toggles) =>
    ctx.rest('/models/preference', { method: 'POST', body: { toggles, base: preferenceBase() } })
  // On HTTP 409 (another writer persisted the preference first) re-fetch the
  // authoritative state instead of replaying blindly: if the mode changed
  // (e.g. unrestricted → allowlist or anything → none) the meaning of the
  // operation changed and the user must confirm against fresh state; if the
  // mode is unchanged the absolute ON/OFF intent is intact and a single
  // rebase-and-retry is safe.
  const rebaseAndRetry = (toggles) => (err) => {
    if (httpStatusOf(err) !== 409) return Promise.reject(err)
    return ctx
      .rest('/models/preference', { method: 'GET' })
      .then((freshSummary) => {
        const freshMode = freshSummary?.mode ?? 'unrestricted'
        const freshHash = freshSummary?.preference_hash ?? null
        if (freshHash && freshMode === preferenceMode) {
          return ctx.rest('/models/preference', { method: 'POST', body: { toggles, base: freshHash } })
        }
        // Same carrier shape as the bridge ("409: <body>") so errorText unwraps it.
        const conflict = new Error('409: ' + JSON.stringify({ detail: {
          message: `Another writer changed the model preference (mode: ${freshMode}). Your change was not applied — review the current state and apply it again.`,
        } }))
        conflict.statusCode = 409
        conflict.conflict = true
        throw conflict
      })
  }
  const [resetArmed, setResetArmed] = useState(false)
  const resetPreference = () => {
    // Two-step confirmation: first click arms the button, second executes.
    if (!resetArmed) {
      setResetArmed(true)
      setToggleNote({ kind: 'notice', text: 'Reset is armed — press Confirm reset to allow every otherwise eligible model.' })
      return
    }
    setResetArmed(false)
    ctx.rest('/models/preference', { method: 'POST', body: { reset: 'unrestricted', base: preferenceBase() } })
      .then(() => {
        setToggleNote({ kind: 'ok', text: 'Model preference reset to unrestricted.' })
        reload()
      })
      .catch((err) => {
        setToggleNote({ kind: 'error', text: `Reset failed: ${errorText(err)}` })
        reload()
      })
  }
  const toggleModel = (m, enabled) => {
    const key = toggleKey(m)
    setToggleBusy((prev) => ({ ...prev, [key]: true }))
    setToggleNote(null)
    preferenceRequest([{ provider: m.provider, model: m.model, enabled }])
      .catch(rebaseAndRetry([{ provider: m.provider, model: m.model, enabled }]))
      .then(() => {
        setToggleBusy((prev) => ({ ...prev, [key]: false }))
        setToggleNote({ kind: 'ok', text: `${enabled ? 'Enabled' : 'Disabled'} ${key}.` })
        reload()
      })
      .catch((err) => {
        setToggleBusy((prev) => ({ ...prev, [key]: false }))
        setToggleNote(err?.conflict
          ? { kind: 'conflict', text: errorText(err) }
          : { kind: 'error', text: `Could not save the change for ${key}: ${errorText(err)}` })
        reload()
      })
  }
  const bulkToggle = (enabled) => {
    const rows = Array.isArray(data?.models) ? data.models : []
    if (!rows.length) {
      setToggleNote({ kind: 'error', text: 'Nothing on this page to change.' })
      return
    }
    const toggles = rows.map((m) => ({ provider: m.provider, model: m.model, enabled }))
    setToggleBusy((prev) => {
      const next = { ...prev }
      for (const m of rows) next[toggleKey(m)] = true
      return next
    })
    setToggleNote(null)
    preferenceRequest(toggles)
      .catch(rebaseAndRetry(toggles))
      .then(() => {
        setToggleBusy({})
        setToggleNote({ kind: 'ok', text: `${enabled ? 'Enabled' : 'Disabled'} ${toggles.length} model(s) on this page.` })
        reload()
      })
      .catch((err) => {
        setToggleBusy({})
        setToggleNote(err?.conflict
          ? { kind: 'conflict', text: errorText(err) }
          : { kind: 'error', text: `Bulk change failed: ${errorText(err)}` })
        reload()
      })
  }

  const doRefresh = () => {
    if (refreshing) {
      return
    }
    setRefreshing(true)
    setRefreshNote(null)
    ctx.rest('/models/refresh', { method: 'POST' }).then(
      (result) => {
        setRefreshing(false)
        const total = result?.total_models ?? null
        setRefreshNote(
          result?.available === false
            ? `Refresh did not complete: ${result?.reason ?? 'unknown reason'}`
            : total != null
              ? `Catalog refreshed (${fmtNum(total)} model(s) discovered).`
              : 'Catalog refresh completed.',
        )
        reload()
      },
      (err) => {
        setRefreshing(false)
        setRefreshNote(`Refresh failed: ${errorText(err)}`)
      },
    )
  }

  const models = Array.isArray(data?.models) ? data.models : []
  const total = Number(data?.total ?? 0)
  const totalPages = Math.max(1, Number(data?.total_pages ?? 1))
  const safePage = Math.min(Math.max(1, page), totalPages)

  return jsxs('div', {
    className: 'flex flex-col gap-3',
    children: [
      // Toolbar: search + filters + refresh.
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-2',
        children: [
          jsx(SearchField, {
            placeholder: 'Filter by provider or model…',
            value: query,
            onChange: setQuery,
            variant: 'box',
            containerClassName: 'min-w-56 flex-1',
            onKeyDown: (event) => {
              if (event.key === 'Enter') {
                event.preventDefault()
              }
            },
          }),
          jsxs('label', {
            className: 'flex items-center gap-1.5 text-[0.7rem] text-(--ui-text-tertiary)',
            children: [
              'Provider',
              jsxs('select', {
                className:
                  'h-8 rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-elevated) px-2 text-xs text-foreground',
                value: provider,
                onChange: (event) => setProvider(event.target.value),
                'aria-label': 'Filter by provider',
                children: [
                  jsx('option', { value: '', children: 'All' }),
                  ...providerOptions.map((name) => jsx('option', { key: name, value: name, children: name })),
                ],
              }),
            ],
          }),
          jsxs('label', {
            className: 'flex items-center gap-1.5 text-[0.7rem] text-(--ui-text-tertiary)',
            children: [
              'Preference',
              jsxs('select', {
                className:
                  'h-8 rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-elevated) px-2 text-xs text-foreground',
                value: preference,
                onChange: (event) => setPreference(event.target.value),
                'aria-label': 'Filter by inclusion preference',
                children: [
                  jsx('option', { value: 'all', children: 'All models' }),
                  jsx('option', { value: 'on', children: 'Enabled only' }),
                  jsx('option', { value: 'off', children: 'Disabled only' }),
                ],
              }),
            ],
          }),
          jsx(SegmentedControl, {
            options: [
              { id: 'all', label: 'All' },
              { id: 'eligible', label: 'Eligible' },
              { id: 'ineligible', label: 'Excluded' },
            ],
            value: eligibility,
            onChange: setEligibility,
            sizing: 'content',
          }),
          jsx(Button, {
            variant: 'secondary',
            size: 'sm',
            loading: refreshing,
            disabled: refreshing,
            onClick: doRefresh,
            children: 'Refresh catalog',
          }),
          jsx(Button, {
            variant: 'ghost',
            size: 'sm',
            onClick: () => bulkToggle(true),
            children: 'Enable page',
            title: 'Enable every model on this page',
          }),
          jsx(Button, {
            variant: 'ghost',
            size: 'sm',
            onClick: () => bulkToggle(false),
            children: 'Disable page',
            title: 'Disable every model on this page',
          }),
        ],
      }),

      refreshNote
        ? jsx('div', {
            role: 'status',
            className: 'rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-tertiary) px-3 py-1.5 text-[0.7rem] text-(--ui-text-secondary)',
            children: refreshNote,
          })
        : null,

      toggleNote
        ? jsx('div', {
            role: toggleNote.kind === 'error' || toggleNote.kind === 'conflict' ? 'alert' : 'status',
            className:
              toggleNote.kind === 'error'
                ? 'rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-elevated) px-3 py-1.5 text-[0.7rem] text-(--ui-text-secondary)'
                : 'rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-tertiary) px-3 py-1.5 text-[0.7rem] text-(--ui-text-secondary)',
            children: toggleNote.text,
          })
        : null,

      preferenceMeta && (preferenceMeta.mode === 'none' || preferenceMeta.enabled_count === 0)
        ? jsxs('div', {
            role: 'alert',
            className: 'rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-elevated) px-3 py-1.5 text-[0.7rem] text-(--ui-text-secondary)',
            children: [
              jsx('span', { children: 'No model is enabled — AutoRouter refuses to route until you enable at least one model below. ' }),
              jsx(Button, { variant: 'ghost', size: 'sm', onClick: resetPreference,
                children: resetArmed ? 'Confirm reset' : 'Reset to unrestricted' }),
            ],
          })
        : preferenceMeta && preferenceMeta.allowlist_mode
          ? jsxs('div', {
              role: 'status',
              className: 'rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-tertiary) px-3 py-1.5 text-[0.7rem] text-(--ui-text-tertiary)',
              children: [
                jsx('span', { children: 'Allowlist mode: only allowlisted models are selectable. Disabling the last allowlist entry turns every model off — it never re-enables everything. ' }),
                jsx(Button, { variant: 'ghost', size: 'sm', onClick: resetPreference,
                  children: resetArmed ? 'Confirm reset' : 'Reset to unrestricted' }),
              ],
            })
          : null,

      // Body.
      loading && !data
        ? jsx(LoadingRow, { label: 'Loading catalog…' })
        : error
          ? jsx(ErrorBox, { error, onRetry: reload })
          : data?.available === false
            ? jsx(ErrorState, {
                title: 'Model catalog is unavailable',
                description: data?.reason ?? 'The catalog snapshot could not be read.',
                className: 'py-6',
              })
            : jsxs(Fragment, {
                children: [
                  jsxs('div', {
                    className: 'flex items-center justify-between gap-3 text-[0.7rem] text-(--ui-text-tertiary)',
                    children: [
                      jsx('span', {
                        children:
                          total === 0
                            ? 'No models match the current filters.'
                            : `${fmtNum(total)} model(s) match · page ${safePage} of ${fmtNum(totalPages)}${
                                preferenceMeta && typeof preferenceMeta.enabled_count === 'number'
                                  ? ` · ${preferenceMeta.enabled_count} enabled / ${preferenceMeta.disabled_count} off`
                                  : ''
                              }`,
                      }),
                      jsxs('div', {
                        className: 'flex items-center gap-1',
                        children: [
                          jsx(Button, {
                            variant: 'ghost',
                            size: 'icon-xs',
                            disabled: safePage <= 1,
                            onClick: () => setPage((p) => Math.max(1, p - 1)),
                            'aria-label': 'Previous page',
                            children: jsx(Codicon, { name: 'chevron-left', size: '0.9rem' }),
                          }),
                          jsx(Button, {
                            variant: 'ghost',
                            size: 'icon-xs',
                            disabled: safePage >= totalPages,
                            onClick: () => setPage((p) => Math.min(totalPages, p + 1)),
                            'aria-label': 'Next page',
                            children: jsx(Codicon, { name: 'chevron-right', size: '0.9rem' }),
                          }),
                        ],
                      }),
                    ],
                  }),
                  models.length === 0
                    ? jsx(EmptyState, {
                        title: 'Nothing matches',
                        description: 'Clear the search or filters to see the full catalog.',
                        className: 'min-h-32',
                      })
                    : jsx(DataTable, {
                        caption: 'model catalog',
                        columns: ['On', 'Provider / Model', 'Context', 'Tools', 'Cost', 'Eligibility', 'Health'],
                        rows: models.map((m) =>
                          jsxs('tr', {
                            key: `${m.provider}/${m.model}`,
                            className: 'border-b border-(--ui-stroke-tertiary) last:border-0',
                            children: [
                              jsx('td', {
                                className: cn(tableCell, 'whitespace-nowrap'),
                                children: jsx('button', {
                                  type: 'button',
                                  role: 'switch',
                                  'aria-checked': m.user_preference === 'off' ? 'false' : 'true',
                                  'aria-label': `Enable ${m.provider}/${m.model} in AutoRouter`,
                                  'data-model-toggle': `${m.provider}/${m.model}`,
                                  disabled: toggleBusy[toggleKey(m)] === true,
                                  onClick: () => toggleModel(m, m.user_preference === 'off'),
                                  className:
                                    'relative inline-flex h-5 w-9 items-center rounded-full border transition-colors duration-150 ' +
                                    (m.user_preference === 'off'
                                      ? 'border-(--ui-stroke-secondary) bg-(--ui-bg-tertiary)'
                                      : 'border-(--ui-accent) bg-(--ui-accent)') +
                                    ' disabled:cursor-wait disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-(--ui-accent)',
                                  children: jsx('span', {
                                    'aria-hidden': 'true',
                                    className:
                                      'absolute left-0.5 h-3.5 w-3.5 rounded-full transition-transform duration-150 ' +
                                      (m.user_preference === 'off'
                                        ? 'translate-x-0 bg-(--ui-text-tertiary)'
                                        : 'translate-x-[1.125rem] bg-(--ui-bg-elevated)'),
                                  }),
                                }),
                              }),
                              jsxs('td', {
                                className: cn(tableCell, 'max-w-[22rem]'),
                                children: [
                                  jsx('div', { className: 'font-mono text-[0.68rem] text-(--ui-text-tertiary)', children: m.provider }),
                                  jsx('div', { className: 'truncate font-mono', title: m.model, children: m.model }),
                                  m.blocked_by_profile || m.preference_note
                                    ? jsx('div', {
                                        className: 'text-[0.65rem] text-(--ui-text-tertiary)',
                                        children: m.blocked_by_profile
                                          ? `Blocked by routing profile '${m.blocked_by_profile}'`
                                          : m.preference_note,
                                      })
                                    : null,
                                ],
                              }),
                              jsx('td', { className: cn(tableCell, 'whitespace-nowrap tabular-nums'), children: fmtCtx(m.context_length) }),
                              jsx('td', { className: tableCell, children: String(m.tools ?? 'unknown') }),
                              jsx('td', {
                                className: tableCell,
                                children: jsx(Badge, {
                                  variant: String(m.cost_tier).toLowerCase() === 'free' ? 'success' : 'muted',
                                  children: String(m.cost_tier ?? 'unknown'),
                                }),
                              }),
                              jsx('td', {
                                className: tableCell,
                                title: (m.reasons ?? []).join(' · '),
                                children: m.eligible
                                  ? jsx(Badge, { variant: 'success', children: 'eligible' })
                                  : jsx(Badge, { variant: 'outline', children: 'excluded' }),
                              }),
                              jsx('td', { className: tableCell, children: healthBadge(m) }),
                            ],
                          }),
                        ),
                      }),
                  jsx(UnavailableNote, { items: data?.unavailable }),
                ],
              }),
    ],
  })
}

/* ---------------------------------------------------------------- *
 *  TAB — Profiles (user-created routing profiles)
 * ---------------------------------------------------------------- */

const PROFILE_ADAPTERS = ['nvidia', 'openrouter', 'groq', 'gemini', 'mistral', 'nous']
const PROFILE_POLICY_LABELS = {
  auto: 'General · auto (balanced)',
  coding: 'Coding · coding',
  fastest: 'Fast response · fastest',
  reliable: 'Reliability-first · reliable',
  smartest: 'Legacy smartest · quality unknown',
  priority: 'Legacy priority',
}
const LINES_PROVIDER_MODEL = /^([a-z][a-z0-9-]{0,63})\/([A-Za-z0-9][A-Za-z0-9._:/-]{0,199})$/

function profileFromDraft(id, draft) {
  return {
    name: draft.name.trim(),
    description: draft.description.trim(),
    ranking_policy: draft.ranking_policy,
    providers: draft.providers,
    model_include: splitLines(draft.model_include).filter(Boolean),
    model_exclude: splitLines(draft.model_exclude).filter(Boolean),
    min_context: Number(draft.min_context),
    requires_tools: Boolean(draft.requires_tools),
    task_tags: splitComma(draft.task_tags).filter(Boolean),
    fallback_policy: 'refuse',
    verified_free_only: true,
  }
}

function validateProfileDraft(draft) {
  const errors = []
  if (!draft.name.trim()) errors.push('Name is required.')
  else if (draft.name.trim().length > 80) errors.push('Name must be at most 80 characters.')
  if (draft.description.length > 500) errors.push('Description must be at most 500 characters.')
  const min = Number(draft.min_context)
  if (!Number.isInteger(min)) errors.push('Minimum context must be a whole number of tokens.')
  else if (min < 2048 || min > 2000000) errors.push('Minimum context must be between 2048 and 2000000 tokens.')
  for (const ref of splitLines(draft.model_include).filter(Boolean)) {
    if (!LINES_PROVIDER_MODEL.test(ref)) errors.push(`Include entry "${ref}" must look like provider/model (lower-case provider id).`)
    else if (!PROFILE_ADAPTERS.includes(ref.split('/')[0])) errors.push(`Include entry "${ref}" uses a provider AutoRouter has no adapter for.`)
  }
  for (const ref of splitLines(draft.model_exclude).filter(Boolean)) {
    if (!LINES_PROVIDER_MODEL.test(ref)) errors.push(`Exclude entry "${ref}" must look like provider/model (lower-case provider id).`)
    else if (!PROFILE_ADAPTERS.includes(ref.split('/')[0])) errors.push(`Exclude entry "${ref}" uses a provider AutoRouter has no adapter for.`)
  }
  return errors
}

function emptyDraft() {
  return {
    id: null, name: '', description: '', ranking_policy: 'auto', providers: [],
    model_include: '', model_exclude: '', min_context: '8192', requires_tools: false,
    task_tags: '',
  }
}

function draftFromProfile(p) {
  return {
    id: p.id, name: p.name ?? '', description: p.description ?? '', ranking_policy: p.ranking_policy ?? 'auto',
    providers: Array.isArray(p.providers) ? [...p.providers] : [],
    model_include: (p.model_include ?? []).join('\n'),
    model_exclude: (p.model_exclude ?? []).join('\n'),
    min_context: String(p.min_context ?? 8192),
    requires_tools: Boolean(p.requires_tools),
    task_tags: (p.task_tags ?? []).join(', '),
  }
}

function ProfilesTab({ ctx }) {
  const { data, error, loading, reload } = useRest(ctx, '/routing-profiles')
  const providersRest = useRest(ctx, '/providers')
  const [selectedId, setSelectedId] = useState(null)
  const [draft, setDraft] = useState(null)
  const [formErrors, setFormErrors] = useState([])
  const [saving, setSaving] = useState(false)
  const [deleteArmed, setDeleteArmed] = useState(false)
  const [notice, setNotice] = useState(null)
  const [previewState, setPreviewState] = useState({ state: 'idle', profileId: null, data: null, message: null })

  if (loading && !data) {
    return jsx(LoadingRow, { label: 'Reading routing profiles…' })
  }
  if (error) {
    return jsx(ErrorBox, { error, onRetry: reload })
  }

  const profiles = Array.isArray(data?.profiles) ? data.profiles : []
  const active = data?.active ?? null
  const effectiveId = selectedId ?? (profiles[0]?.id ?? null)
  const selected = profiles.find((p) => p.id === effectiveId) ?? null

  const inventoryRows = providersRest.data?.connection_inventory?.connections ?? []
  const inventoryById = Object.fromEntries(inventoryRows.map((c) => [c.provider_id, c]))

  const inputClass =
    'h-8 w-full rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-elevated) px-2 text-xs text-foreground outline-none focus-visible:border-ring'
  const areaClass =
    'min-h-16 w-full rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-elevated) p-2 font-mono text-[0.7rem] leading-snug text-foreground outline-none focus-visible:border-ring'

  const startNew = () => {
    setDraft(emptyDraft())
    setFormErrors([])
    setNotice(null)
    setDeleteArmed(false)
    setPreviewState({ state: 'idle', profileId: null, data: null, message: null })
  }
  const startEdit = (p) => {
    setDraft(draftFromProfile(p))
    setFormErrors([])
    setNotice(null)
    setDeleteArmed(false)
    setPreviewState({ state: 'idle', profileId: p.id, data: null, message: null })
  }
  const cancelEdit = () => {
    setDraft(null)
    setFormErrors([])
  }
  const patchDraft = (key) => (value) => {
    const v = value?.target ? value.target.value : value
    setDraft((prev) => (prev ? { ...prev, [key]: v } : prev))
  }
  const toggleProvider = (id) => () => {
    setDraft((prev) => {
      if (!prev) return prev
      const has = prev.providers.includes(id)
      return { ...prev, providers: has ? prev.providers.filter((p) => p !== id) : [...prev.providers, id] }
    })
  }

  const save = () => {
    if (!draft) return
    const errs = validateProfileDraft(draft)
    if (errs.length) {
      setFormErrors(errs)
      return
    }
    setSaving(true)
    setFormErrors([])
    const body = profileFromDraft(draft.id, draft)
    const isNew = !draft.id
    ctx.rest(isNew ? '/routing-profiles' : `/routing-profiles/${draft.id}`, {
      method: isNew ? 'POST' : 'PUT',
      body,
    }).then(
      (resp) => {
        setSaving(false)
        setDraft(null)
        setFormErrors([])
        setNotice(isNew ? 'Routing profile created.' : 'Routing profile saved.')
        setSelectedId(resp?.profile?.id ?? draft.id)
        reload()
      },
      (saveError) => {
        setSaving(false)
        const detail = parseBodyOf(saveError)?.detail
        const fields = detail?.fields && typeof detail.fields === 'object' ? Object.values(detail.fields) : null
        setFormErrors(fields?.length ? fields : [errorText(saveError) ?? 'The profile was not saved.'])
      },
    )
  }

  const duplicate = (p) => {
    setNotice(null)
    ctx.rest(`/routing-profiles/${p.id}/duplicate`, { method: 'POST', body: {} }).then(
      (resp) => {
        setNotice('Profile duplicated.')
        setSelectedId(resp?.profile?.id ?? null)
        reload()
      },
      (err) => setNotice(errorText(err) ?? 'The profile could not be duplicated.'),
    )
  }

  const activate = (p) => {
    setNotice(null)
    ctx.rest(`/routing-profiles/${p.id}/activate`, { method: 'POST' }).then(
      () => {
        setNotice('Default set for AutoRouter sessions created from now on. Existing AutoRouter sessions keep their resolved model. Your global default Hermes model is unchanged.')
        reload()
      },
      (err) => setNotice(errorText(err) ?? 'The profile could not be activated.'),
    )
  }
  const deactivate = () => {
    setNotice(null)
    ctx.rest('/routing-profiles/deactivate', { method: 'POST' }).then(
      () => {
        setNotice('No default routing profile is set. AutoRouter sessions route through your plugin defaults.')
        reload()
      },
      (err) => setNotice(errorText(err) ?? 'The profile could not be deactivated.'),
    )
  }

  const remove = (p) => {
    if (!deleteArmed) {
      setDeleteArmed(true)
      return
    }
    setSaving(true)
    ctx.rest(`/routing-profiles/${p.id}`, { method: 'DELETE' }).then(
      () => {
        setSaving(false)
        setDeleteArmed(false)
        setNotice(active === p.id ? 'Profile deleted and deactivated.' : 'Profile deleted.')
        setSelectedId(null)
        reload()
      },
      (err) => {
        setSaving(false)
        setDeleteArmed(false)
        setNotice(errorText(err) ?? 'The profile could not be deleted.')
      },
    )
  }

  const runPreview = (p) => {
    setPreviewState({ state: 'loading', profileId: p.id, data: null, message: null })
    ctx.rest(`/routing-profiles/${p.id}/preview`, { method: 'POST' }).then(
      (resp) => setPreviewState({ state: 'ok', profileId: p.id, data: resp, message: null }),
      (err) => setPreviewState({ state: 'error', profileId: p.id, data: null, message: errorText(err) ?? 'Preview failed.' }),
    )
  }

  const chip = (label, tone) => jsx(Badge, { variant: tone ?? 'muted', children: label })

  const providerHint = (id) => {
    const row = inventoryById[id]
    if (!row) return null
    if (row.family !== 'llm_adapter' && row.family !== 'llm_host') {
      return jsx('span', { className: 'text-[0.6rem] text-(--ui-text-tertiary)', children: 'host unrecognized — not authorizable' })
    }
    if (row.family === 'llm_host') {
      const hostHint = row.authorized ? 'enabled (host catalog)' : 'host recognized, not enabled'
      if (row.authorized && row.presence === 'configured') return jsx('span', { className: 'text-[0.6rem] text-emerald-600 dark:text-emerald-400', children: 'enabled · configured' })
      if (row.authorized) return jsx('span', { className: 'text-[0.6rem] text-amber-600 dark:text-amber-400', children: 'enabled · presence unknown' })
      if (row.presence === 'configured') return jsx('span', { className: 'text-[0.6rem] text-amber-600 dark:text-amber-400', children: 'configured in Hermes, not enabled' })
      return jsx('span', { className: 'text-[0.6rem] text-(--ui-text-tertiary)', children: hostHint })
    }
    if (row.authorized && row.presence === 'configured') return jsx('span', { className: 'text-[0.6rem] text-emerald-600 dark:text-emerald-400', children: 'enabled · configured' })
    if (row.authorized) return jsx('span', { className: 'text-[0.6rem] text-amber-600 dark:text-amber-400', children: 'enabled · presence unknown' })
    if (row.presence === 'configured') return jsx('span', { className: 'text-[0.6rem] text-amber-600 dark:text-amber-400', children: 'configured in Hermes, not enabled' })
    return jsx('span', { className: 'text-[0.6rem] text-(--ui-text-tertiary)', children: row.presence === 'unknown' ? 'presence unknown' : 'not configured' })
  }

  const renderForm = () =>
    jsxs('div', { className: 'flex flex-col gap-3', children: [
      jsxs('div', { className: 'flex items-center justify-between gap-2', children: [
        jsx('h3', { className: 'text-[0.8rem] font-semibold', children: draft.id ? 'Edit profile' : 'New routing profile' }),
        jsx('span', { className: 'text-[0.62rem] text-(--ui-text-tertiary)', children: 'verified-free only · refuse on no match · never falls back' }),
      ] }),
      jsxs('label', { className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)', children: [
        'Name',
        jsx(Input, { value: draft.name, maxLength: 80, placeholder: 'e.g. Nightly free builder', onChange: patchDraft('name') }),
      ] }),
      jsxs('label', { className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)', children: [
        'Description (optional)',
        jsx(Input, { value: draft.description, maxLength: 500, placeholder: 'What is this profile for?', onChange: patchDraft('description') }),
      ] }),
      jsxs('label', { className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)', children: [
        'Ranking policy',
        jsx('select', { className: inputClass, value: draft.ranking_policy, onChange: patchDraft('ranking_policy'), children:
          Object.entries(PROFILE_POLICY_LABELS).map(([value, label]) => jsx('option', { key: value, value, children: label })) }),
        jsx('span', { className: 'font-normal text-(--ui-text-tertiary)', children: 'Ranking preference among verified-free models. Free-only is mandatory; paid fallback does not exist.' }),
      ] }),
      jsx('fieldset', { className: 'flex flex-col gap-1', children: [
        jsx('legend', { className: 'text-[0.7rem] font-medium text-(--ui-text-secondary)', children: 'Providers (narrow the selection; AutoRouter must have enabled them)' }),
        jsxs('div', { className: 'grid grid-cols-1 gap-1 sm:grid-cols-2', children:
          PROFILE_ADAPTERS.map((id) => jsxs('label', {
            key: id,
            className: 'flex cursor-pointer items-center gap-2 rounded-md border border-(--ui-stroke-tertiary) px-2 py-1.5 text-[0.72rem] hover:bg-(--ui-bg-elevated)',
            children: [
              jsx('input', { type: 'checkbox', checked: draft.providers.includes(id), onChange: toggleProvider(id) }),
              jsx('span', { className: 'font-mono', children: id }),
              providerHint(id),
            ],
          })) }),
        jsx('span', { className: 'text-[0.62rem] text-(--ui-text-tertiary)', children: 'Selection only ever uses providers enabled for AutoRouter; enabling happens in the Providers tab.' }),
      ] }),
      jsxs('div', { className: 'grid grid-cols-1 gap-3 sm:grid-cols-2', children: [
        jsxs('label', { className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)', children: [
          'Minimum context (tokens)',
          jsx(Input, { type: 'number', min: 2048, max: 2000000, inputMode: 'numeric', value: draft.min_context, onChange: patchDraft('min_context') }),
        ] }),
        jsx(ToggleRow, {
          label: 'Require tool calling',
          description: 'Exclude models without verified tool support.',
          checked: draft.requires_tools,
          onChange: (on) => setDraft((prev) => (prev ? { ...prev, requires_tools: Boolean(on) } : prev)),
        }),
      ] }),
      jsxs('label', { className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)', children: [
        'Model include (optional)',
        jsx(Textarea, { className: areaClass, value: draft.model_include, placeholder: 'openrouter/some-free-model\nnvidia/another-free-model', onChange: patchDraft('model_include') }),
        jsx('span', { className: 'font-normal text-(--ui-text-tertiary)', children: 'One provider/model per line. Empty = every eligible model from the enabled providers.' }),
      ] }),
      jsxs('label', { className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)', children: [
        'Model exclude',
        jsx(Textarea, { className: areaClass, value: draft.model_exclude, placeholder: 'openrouter/model-to-avoid', onChange: patchDraft('model_exclude') }),
      ] }),
      jsxs('label', { className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)', children: [
        'Task tags (optional, comma-separated)',
        jsx(Input, { value: draft.task_tags, placeholder: 'nightly, batch', onChange: patchDraft('task_tags') }),
      ] }),
      formErrors.length > 0
        ? jsx('div', { role: 'alert', className: 'rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-[0.7rem] text-destructive',
            children: formErrors.map((message, i) => jsx('div', { key: i, children: `• ${message}` })) })
        : null,
      jsxs('div', { className: 'flex items-center justify-end gap-2', children: [
        jsx(Button, { variant: 'ghost', size: 'sm', onClick: cancelEdit, children: 'Cancel' }),
        jsx(Button, { variant: 'primary', size: 'sm', disabled: saving, onClick: save, children: saving ? 'Saving…' : (draft.id ? 'Save changes' : 'Create profile') }),
      ] }),
    ] })

  const noMatchText = (code) => ({
    profile_no_authorized_providers: "None of this profile's providers is enabled for AutoRouter. Enable one in the Providers tab.",
    no_eligible_model: 'No verified-free model matches this profile with current evidence and health.',
    no_catalog_candidates: 'The catalog is empty or unreadable. Refresh it from the Models tab.',
    catalog_unreadable: 'The catalog could not be read for the include list; refusing rather than guessing.',
    selection_policy_invalid: 'The selection contract was rejected; no route was chosen.',
  }[code] ?? 'No eligible model — refusal before any network request.')

  const renderPreview = (p) => {
    if (previewState.profileId !== p.id || previewState.state === 'idle') {
      return jsx(Button, { variant: 'ghost', size: 'sm', onClick: () => runPreview(p), children: 'Preview eligible models' })
    }
    if (previewState.state === 'loading') {
      return jsx('span', { className: 'text-[0.7rem] text-(--ui-text-tertiary)', children: 'Evaluating catalog…' })
    }
    if (previewState.state === 'error') {
      return jsxs('div', { children: [
        jsx('p', { className: 'text-[0.7rem] text-amber-600 dark:text-amber-400', children: previewState.message }),
        jsx(Button, { variant: 'ghost', size: 'sm', onClick: () => runPreview(p), children: 'Retry preview' }),
      ] })
    }
    const d = previewState.data ?? {}
    const chosen = d.chosen
    return jsxs('div', { className: 'flex flex-col gap-1.5 rounded-md border border-(--ui-stroke-tertiary) p-2', children: [
      jsxs('div', { className: 'flex items-center justify-between gap-2', children: [
        jsx('span', { className: 'text-[0.68rem] font-medium text-(--ui-text-tertiary)', children: `Preview · ${fmtNum(d.eligible_count)} eligible of ${fmtNum(d.total_considered)} considered` }),
        jsx(Button, { variant: 'ghost', size: 'sm', onClick: () => runPreview(p), children: 'Re-run' }),
      ] }),
      chosen
        ? jsxs('p', { className: 'text-[0.75rem]', children: [
            'Would route to ',
            jsx('code', { className: 'font-mono', children: `${chosen.provider}/${chosen.model}` }),
            ' (verified-free, evidence fresh)',
          ] })
        : jsx('p', { className: 'text-[0.72rem] text-amber-600 dark:text-amber-400', children: noMatchText(d.no_match) }),
      Array.isArray(d.excluded) && d.excluded.length > 0
        ? jsxs('div', { className: 'text-[0.65rem] text-(--ui-text-tertiary)', children: [
            'Excluded: ',
            d.excluded.slice(0, 4).map((row, i) => jsx('div', { key: i, className: 'font-mono', children: `${row.provider}/${row.model} — ${row.reason_codes.join(', ')}` })),
            d.excluded_total > 4 ? jsx('div', { children: `…and ${fmtNum(d.excluded_total - 4)} more` }) : null,
          ] })
        : null,
    ] })
  }

  const renderDetail = (p) =>
    jsxs('div', { className: 'flex flex-col gap-3', children: [
      jsxs('div', { className: 'flex flex-wrap items-center justify-between gap-2', children: [
        jsxs('div', { children: [
          jsxs('div', { className: 'flex items-center gap-2', children: [
            jsx('h3', { className: 'text-[0.85rem] font-semibold', children: p.name }),
            active === p.id ? jsx(Badge, { variant: 'success', children: 'active' }) : null,
          ] }),
          p.description ? jsx('p', { className: 'mt-0.5 text-[0.72rem] text-(--ui-text-secondary)', children: p.description }) : null,
        ] }),
        jsxs('div', { className: 'flex flex-wrap items-center gap-1.5', children: [
          active === p.id
            ? jsx(Button, { variant: 'ghost', size: 'sm', onClick: deactivate, children: 'Clear default' })
            : jsx(Button, { variant: 'primary', size: 'sm', onClick: () => activate(p), children: 'Set as AutoRouter default' }),
          jsx(Button, { variant: 'ghost', size: 'sm', onClick: () => startEdit(p), children: 'Edit' }),
          jsx(Button, { variant: 'ghost', size: 'sm', onClick: () => duplicate(p), children: 'Duplicate' }),
          jsx(Button, { variant: 'ghost', size: 'sm', onClick: () => remove(p), children: deleteArmed ? 'Click again to delete' : 'Delete' }),
        ] }),
      ] }),
      jsx('dl', { className: 'grid grid-cols-2 gap-x-4 gap-y-2 @xl:grid-cols-4', children: [
        factRow('Ranking policy', String(p.ranking_policy)),
        factRow('Providers', (p.providers ?? []).length ? (p.providers ?? []).join(', ') : 'none — falls back to plugin defaults, refusing if none eligible'),
        factRow('Min context', fmtNum(p.min_context)),
        factRow('Tools', p.requires_tools ? 'required' : 'not required'),
        factRow('Include', (p.model_include ?? []).length ? `${(p.model_include ?? []).length} model(s)` : 'all eligible'),
        factRow('Exclude', (p.model_exclude ?? []).length ? `${(p.model_exclude ?? []).length} model(s)` : '—'),
        factRow('Task tags', (p.task_tags ?? []).length ? (p.task_tags ?? []).join(', ') : '—'),
        factRow('Updated', fmtAbs(p.updated_at)),
      ] }),
      jsx('div', { className: 'rounded-md border border-(--ui-stroke-tertiary) px-3 py-2 text-[0.65rem] leading-snug text-(--ui-text-tertiary)', children:
        'Narrows your AutoRouter routes only: applies to sessions created after you set it as default, and can only tighten eligibility (providers, context, tools, requirements) — never relax it. Verified-free only; no paid fallback; a failed hard requirement refuses before any network call. Account-specific allowance stays UNKNOWN (issue #41). Sessions already running keep their resolved model.' }),
      renderPreview(p),
    ] })

  return jsxs('div', { className: 'flex flex-col gap-3', children: [
    jsx('div', {
      role: 'status',
      className: 'rounded-md border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-[0.7rem] leading-snug text-amber-700 dark:text-amber-300',
      children: 'Routing profiles narrow the route for AutoRouter (autorouter/auto-free) sessions. “Set as default” applies to sessions created afterwards; sessions already running keep their resolved model. This is not per-session pinning, and it never changes your global Hermes default model. Automatic routing is experimental and this installation has it disabled (enable_chat_router: false).',
    }),
    notice
      ? jsx('div', { role: 'status', className: 'rounded-md border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-[0.7rem] text-emerald-700 dark:text-emerald-300', children: notice })
      : null,
    jsxs('div', { className: 'grid grid-cols-1 gap-3 @2xl:grid-cols-[minmax(15rem,20rem)_1fr]', children: [
      jsx(Panel, {
        title: `Saved profiles (${fmtNum(profiles.length)})`,
        action: jsx(Button, { variant: 'ghost', size: 'sm', onClick: startNew, children: 'New profile' }),
        children:
          profiles.length === 0
            ? jsx(EmptyState, { title: 'No routing profiles yet', description: 'Create one to pin ranking, providers, context and tool requirements.', className: 'min-h-24' })
            : jsxs('div', { className: 'flex flex-col gap-1', children:
                profiles.map((p) => jsxs('button', {
                  key: p.id,
                  type: 'button',
                  onClick: () => { setSelectedId(p.id); cancelEdit(); setDeleteArmed(false); setNotice(null); setPreviewState({ state: 'idle', profileId: p.id, data: null, message: null }) },
                  className: cn('flex flex-col gap-1 rounded-md border px-2 py-1.5 text-left transition-colors',
                    effectiveId === p.id ? 'border-ring bg-(--ui-bg-elevated)' : 'border-transparent hover:bg-(--ui-bg-elevated)'),
                  children: [
                    jsxs('div', { className: 'flex w-full items-center justify-between gap-2', children: [
                      jsx('span', { className: 'truncate text-[0.75rem] font-medium', children: p.name }),
                      active === p.id ? jsx(Badge, { variant: 'success', children: 'active' }) : null,
                    ] }),
                    jsxs('div', { className: 'flex flex-wrap items-center gap-1', children: [
                      chip(String(p.ranking_policy), 'muted'),
                      chip(`${(p.providers ?? []).length} provider(s)`, 'muted'),
                      chip(`ctx ${fmtNum(p.min_context)}`, 'muted'),
                      p.requires_tools ? chip('tools', 'muted') : null,
                    ] }),
                  ],
                })) }),
      }),
      jsx(Panel, {
        title: draft ? (draft.id ? 'Edit profile' : 'New profile') : (selected ? 'Profile detail' : 'Profile detail'),
        children: draft ? renderForm() : selected ? renderDetail(selected)
          : jsx(EmptyState, { title: 'Select or create a profile', description: 'Saved profiles appear here with their exact selection behavior.', className: 'min-h-40' }),
      }),
    ] }),
  ] })
}

/* ---------------------------------------------------------------- *
 *  TAB — Analytics
 * ---------------------------------------------------------------- */

const ANALYTICS_RANGES = [
  { id: '24h', label: '24h' },
  { id: '7d', label: '7d' },
  { id: '30d', label: '30d' },
  { id: '90d', label: '90d' },
  { id: 'all', label: 'All' },
]

function AnalyticsTab({ ctx }) {
  const [range, setRange] = useState('7d')
  const [offset, setOffset] = useState(0)
  const LIMIT = 20

  useEffect(() => {
    setOffset(0)
  }, [range])

  const path = `/analytics?range=${encodeURIComponent(range)}&view=summary&limit=${LIMIT}&offset=${offset}&sort=newest`
  const { data, error, loading, reload } = useRest(ctx, path)

  const recent = Array.isArray(data?.recent_requests) ? data.recent_requests : []
  const recentTotal = Number(data?.recent_total ?? 0)
  const byProvider = Array.isArray(data?.by_provider) ? data.by_provider.slice(0, 8) : []
  const byModel = Array.isArray(data?.by_model) ? data.by_model.slice(0, 8) : []
  const summary = data?.summary ?? null
  const totalPages = Math.max(1, Math.ceil(recentTotal / LIMIT))
  const page = Math.floor(offset / LIMIT) + 1

  return jsxs('div', {
    className: 'flex flex-col gap-3',
    children: [
      jsxs('div', {
        className: 'flex flex-wrap items-center justify-between gap-2',
        children: [
          jsx(SegmentedControl, {
            options: ANALYTICS_RANGES,
            value: range,
            onChange: setRange,
            sizing: 'content',
          }),
          jsx('span', {
            className: 'text-[0.68rem] text-(--ui-text-tertiary)',
            children: 'Recorded Hermes API-hook telemetry; routing decisions are counted in Overview.',
          }),
        ],
      }),

      loading && !data
        ? jsx(LoadingRow, { label: 'Reading telemetry…' })
        : error
          ? jsx(ErrorBox, { error, onRetry: reload })
          : data?.available === false
            ? jsx(ErrorState, {
                title: 'Analytics is unavailable',
                description: data?.reason ?? 'The telemetry store could not be read.',
                className: 'py-6',
              })
            : jsxs(Fragment, {
                children: [
                  jsxs('div', {
                    className: 'grid grid-cols-2 gap-2 @xl:grid-cols-4',
                    children: [
                      jsx(StatCard, {
                        label: 'Requests',
                        value: summary ? fmtNum(summary.total_requests) : '—',
                        hint: summary ? `${fmtNum(summary.success)} ok · ${fmtNum(summary.error)} error · ${fmtNum(summary.canceled)} canceled · ${fmtNum(summary.pending)} pending` : 'no telemetry in range',
                      }),
                      jsx(StatCard, {
                        label: 'Success rate',
                        value: summary?.success_rate != null ? `${summary.success_rate}%` : '—',
                        hint: 'share of decided requests (success + error)',
                        tone: summary?.success_rate != null && summary.success_rate >= 80 ? 'ok' : summary?.success_rate != null ? 'warn' : undefined,
                      }),
                      jsx(StatCard, {
                        label: 'Latency p50 / p95',
                        value: summary?.latency ? `${fmtMs(summary.latency.p50_ms)} / ${fmtMs(summary.latency.p95_ms)}` : '—',
                        hint: summary?.latency ? `avg ${fmtMs(summary.latency.avg_ms)} · ${fmtNum(summary.latency.samples)} samples` : 'not observed',
                      }),
                      jsx(StatCard, {
                        label: 'Tokens in / out',
                        value: summary ? `${fmtNum(summary.input_tokens)} / ${fmtNum(summary.output_tokens)}` : '—',
                        hint: summary?.tokens_per_second != null ? `${fmtNum(summary.tokens_per_second)} tok/s` : 'throughput not observed',
                      }),
                    ],
                  }),

                  jsxs('div', {
                    className: 'grid min-w-0 grid-cols-1 gap-3 @3xl:grid-cols-2',
                    children: [
                      jsx(Panel, {
                        title: 'By provider',
                        children:
                          byProvider.length === 0
                            ? jsx(EmptyState, { title: 'No requests in range', className: 'min-h-20' })
                            : jsx(DataTable, {
                                caption: 'requests by provider',
                                columns: ['Provider', 'Req', 'Ok', 'Err', 'Rate'],
                                rows: byProvider.map((row) =>
                                  jsxs('tr', {
                                    key: String(row.provider),
                                    className: 'border-b border-(--ui-stroke-tertiary) last:border-0',
                                    children: [
                                      jsx('td', { className: cn(tableCell, 'font-mono'), children: row.provider }),
                                      jsx('td', { className: cn(tableCell, 'tabular-nums'), children: fmtNum(row.requests) }),
                                      jsx('td', { className: cn(tableCell, 'tabular-nums'), children: fmtNum(row.success) }),
                                      jsx('td', { className: cn(tableCell, 'tabular-nums'), children: fmtNum(row.error) }),
                                      jsx('td', { className: cn(tableCell, 'tabular-nums'), children: row.success_rate != null ? `${row.success_rate}%` : '—' }),
                                    ],
                                  }),
                                ),
                              }),
                      }),
                      jsx(Panel, {
                        title: 'By model',
                        children:
                          byModel.length === 0
                            ? jsx(EmptyState, { title: 'No requests in range', className: 'min-h-20' })
                            : jsx(DataTable, {
                                caption: 'requests by model',
                                columns: ['Model', 'Req', 'Rate', 'p50'],
                                rows: byModel.map((row) =>
                                  jsxs('tr', {
                                    key: `${row.provider}/${row.model}`,
                                    className: 'border-b border-(--ui-stroke-tertiary) last:border-0',
                                    children: [
                                      jsxs('td', {
                                        className: cn(tableCell, 'font-mono'),
                                        children: [
                                          jsx('div', { className: 'text-[0.65rem] text-(--ui-text-tertiary)', children: row.provider }),
                                          jsx('div', { className: 'max-w-[16rem] truncate', title: row.model, children: row.model }),
                                        ],
                                      }),
                                      jsx('td', { className: cn(tableCell, 'tabular-nums'), children: fmtNum(row.requests) }),
                                      jsx('td', { className: cn(tableCell, 'tabular-nums'), children: row.success_rate != null ? `${row.success_rate}%` : '—' }),
                                      jsx('td', { className: cn(tableCell, 'whitespace-nowrap tabular-nums'), children: fmtMs(row.latency?.p50_ms) }),
                                    ],
                                  }),
                                ),
                              }),
                      }),
                    ],
                  }),

                  jsx(Panel, {
                    title: `Recent requests (${fmtNum(recentTotal)})`,
                    children:
                      recent.length === 0
                        ? jsx(EmptyState, {
                            title: 'No requests recorded',
                            description: 'Requests appear here once the plugin observes Hermes API traffic.',
                            className: 'min-h-20',
                          })
                        : jsxs(Fragment, {
                            children: [
                              jsx(DataTable, {
                                caption: 'recent requests',
                                columns: ['When', 'Provider / Model', 'Status', 'Latency', 'Tokens (in→out)'],
                                rows: recent.map((row) =>
                                  jsxs('tr', {
                                    key: row.id ?? `${row.started_at}-${row.model}`,
                                    className: 'border-b border-(--ui-stroke-tertiary) last:border-0',
                                    children: [
                                      jsx('td', {
                                        className: cn(tableCell, 'whitespace-nowrap text-(--ui-text-tertiary)'),
                                        title: fmtAbs(row.started_at),
                                        children: fmtRel(row.started_at),
                                      }),
                                      jsxs('td', {
                                        className: cn(tableCell, 'font-mono'),
                                        children: [
                                          jsx('div', { children: row.provider }),
                                          jsx('div', { className: 'max-w-[18rem] truncate text-[0.66rem] text-(--ui-text-tertiary)', title: row.model, children: row.model }),
                                        ],
                                      }),
                                      jsx('td', {
                                        className: tableCell,
                                        children: jsx(Badge, {
                                          variant: row.status === 'success' ? 'success' : row.status === 'error' ? 'destructive' : 'muted',
                                          children: String(row.status ?? 'pending'),
                                        }),
                                      }),
                                      jsx('td', { className: cn(tableCell, 'whitespace-nowrap tabular-nums'), children: fmtMs(row.latency_ms) }),
                                      jsx('td', {
                                        className: cn(tableCell, 'whitespace-nowrap tabular-nums'),
                                        children: `${fmtNum(row.input_tokens)} → ${fmtNum(row.output_tokens)}`,
                                      }),
                                    ],
                                  }),
                                ),
                              }),
                              totalPages > 1
                                ? jsxs('div', {
                                    className: 'mt-2 flex items-center justify-between text-[0.7rem] text-(--ui-text-tertiary)',
                                    children: [
                                      jsx('span', { children: `Page ${page} of ${fmtNum(totalPages)}` }),
                                      jsxs('div', {
                                        className: 'flex items-center gap-1',
                                        children: [
                                          jsx(Button, {
                                            variant: 'ghost',
                                            size: 'icon-xs',
                                            disabled: offset <= 0,
                                            onClick: () => setOffset((o) => Math.max(0, o - LIMIT)),
                                            'aria-label': 'Previous requests page',
                                            children: jsx(Codicon, { name: 'chevron-left', size: '0.9rem' }),
                                          }),
                                          jsx(Button, {
                                            variant: 'ghost',
                                            size: 'icon-xs',
                                            disabled: page >= totalPages,
                                            onClick: () => setOffset((o) => o + LIMIT),
                                            'aria-label': 'Next requests page',
                                            children: jsx(Codicon, { name: 'chevron-right', size: '0.9rem' }),
                                          }),
                                        ],
                                      }),
                                    ],
                                  })
                                : null,
                            ],
                          }),
                  }),
                ],
              }),
    ],
  })
}

/* ---------------------------------------------------------------- *
 *  TAB — Settings
 * ---------------------------------------------------------------- */

const PROVIDER_RE = /^[a-z0-9][a-z0-9_-]{0,63}$/
const MODEL_RE = /^[a-z0-9][a-z0-9_-]{0,63}\/[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}$/

function splitLines(text) {
  return String(text ?? '')
    .split(/[\n,]/)
    .map((s) => s.trim())
    .filter(Boolean)
}

function splitComma(text) {
  return String(text ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
}

function validateDraft(draft) {
  const errors = []
  const intValue = (name, value, min, max) => {
    const n = Number(value)
    if (!Number.isInteger(n)) {
      errors.push(`${name} must be an integer`)
      return null
    }
    if (n < min || n > max) {
      errors.push(`${name} must be between ${min} and ${max}`)
      return null
    }
    return n
  }

  const cooldown = intValue('cooldown_seconds', draft.cooldown_seconds, 1, 86400)
  const minContext = intValue('min_context', draft.min_context, 2048, 2000000)

  const providers = splitComma(draft.providersText)
  if (providers.length > 16) {
    errors.push('providers: at most 16 entries')
  } else {
    for (const p of providers) {
      if (!PROVIDER_RE.test(p)) {
        errors.push(`providers: invalid id '${p}'`)
      }
    }
  }

  const include = splitLines(draft.model_include_text)
  const exclude = splitLines(draft.model_exclude_text)
  for (const [name, list] of [['model_include', include], ['model_exclude', exclude]]) {
    if (list.length > 64) {
      errors.push(`${name}: at most 64 entries`)
    }
    for (const entry of list) {
      if (!MODEL_RE.test(entry)) {
        errors.push(`${name}: invalid key '${entry}' (expected 'provider/model')`)
      }
    }
  }

  const clean = {}
  if (cooldown != null) {
    clean.cooldown_seconds = cooldown
  }
  if (minContext != null) {
    clean.min_context = minContext
  }
  clean.policy = draft.policy
  clean.requires_tools = Boolean(draft.requires_tools)
  clean.enable_chat_router = Boolean(draft.enable_chat_router)
  clean.providers = providers
  clean.model_include = include
  clean.model_exclude = exclude
  return { clean, errors }
}

function draftFromValues(values) {
  const v = values ?? {}
  return {
    policy: typeof v.policy === 'string' ? v.policy : 'auto',
    cooldown_seconds: String(v.cooldown_seconds ?? 60),
    min_context: String(v.min_context ?? 8192),
    requires_tools: Boolean(v.requires_tools),
    enable_chat_router: Boolean(v.enable_chat_router),
    providersText: Array.isArray(v.providers) ? v.providers.join(', ') : '',
    model_include_text: Array.isArray(v.model_include) ? v.model_include.join('\n') : '',
    model_exclude_text: Array.isArray(v.model_exclude) ? v.model_exclude.join('\n') : '',
  }
}

function dirtyKeys(draft, saved) {
  const keys = []
  const { clean, errors } = validateDraft(draft)
  if (errors.length === 0) {
    for (const key of Object.keys(clean)) {
      const before = JSON.stringify(saved?.[key] ?? null)
      const after = JSON.stringify(clean[key])
      if (before !== after) {
        keys.push(key)
      }
    }
  }
  return keys
}

function SettingsTab({ ctx }) {
  const { data, error, loading, reload } = useRest(ctx, '/settings')
  const [draft, setDraft] = useState(null)
  const [savedValues, setSavedValues] = useState(null)
  const [saving, setSaving] = useState(false)
  const [saveState, setSaveState] = useState(null) // { kind: 'ok'|'error', title, lines? }

  // Adopt server values into the form exactly once per fresh payload.
  const loadedFor = useRef(null)
  useEffect(() => {
    if (data && loadedFor.current !== data.generated_at) {
      loadedFor.current = data.generated_at
      setSavedValues(data.values ?? {})
      setDraft(draftFromValues(data.values))
      setSaveState(null)
    }
  }, [data])

  if (loading && !data) {
    return jsx(LoadingRow, { label: 'Reading settings…' })
  }
  if (error) {
    return jsx(ErrorBox, { error, onRetry: reload })
  }
  if (!draft) {
    return jsx(LoadingRow, { label: 'Reading settings…' })
  }

  const editable = data?.editable === true
  const editBlockReason = data?.edit_block_reason ?? null
  const policyOptions = Array.isArray(data?.schema?.policy?.options)
    ? data.schema.policy.options
    : ['auto', 'coding', 'fastest', 'reliable']

  const { clean, errors: localErrors } = validateDraft(draft)
  const changed = dirtyKeys(draft, savedValues)
  const canSave = editable && !saving && localErrors.length === 0 && changed.length > 0

  const patch = (key) => (eventOrValue) => {
    const value =
      eventOrValue && typeof eventOrValue === 'object' && 'target' in eventOrValue
        ? eventOrValue.target.value
        : eventOrValue
    setDraft((d) => (d ? { ...d, [key]: value } : d))
    setSaveState(null)
  }

  const reset = () => {
    setDraft(draftFromValues(savedValues))
    setSaveState(null)
  }

  const save = () => {
    if (!canSave) {
      return
    }
    setSaving(true)
    setSaveState(null)
    const updates = {}
    for (const key of changed) {
      updates[key] = clean[key]
    }
    ctx.rest('/settings', { method: 'PUT', body: { updates } }).then(
      (fresh) => {
        setSaving(false)
        loadedFor.current = fresh?.generated_at ?? null
        setSavedValues(fresh?.values ?? {})
        setDraft(draftFromValues(fresh?.values))
        setSaveState({
          kind: 'ok',
          title: 'Settings saved.',
          lines: ['Applied one key at a time through Hermes\u2019 plugin-settings API; they take effect on the next plugin load. Selection-path values apply from the next routing decision.'],
        })
      },
      (saveError) => {
        setSaving(false)
        const partial = parseBodyOf(saveError)?.detail
        if (partial && Array.isArray(partial.saved)) {
          const failedText =
            partial.failed && typeof partial.failed === 'object'
              ? Object.entries(partial.failed).map(([k, v]) => `${k} (${v})`).join(', ')
              : partial.failed
            ? String(partial.failed)
            : null
          setSaveState({
            kind: 'error',
            title: 'Partially saved.',
            lines: [
              partial.message ?? 'Some keys were saved; the rest were not.',
              `Saved: ${partial.saved.join(', ') || 'none'}`,
              failedText ? `Failed: ${failedText}` : null,
              Array.isArray(partial.remaining) ? `Not attempted: ${partial.remaining.join(', ') || 'none'}` : null,
            ].filter(Boolean),
          })
          // Re-read to show the true persisted state.
          reload()
          return
        }
        setSaveState({ kind: 'error', title: 'Settings were not saved.', lines: [errorText(saveError)] })
      },
    )
  }

  const inputClass =
    'h-8 w-full rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-elevated) px-2 text-xs text-foreground outline-none focus-visible:border-ring disabled:cursor-not-allowed disabled:opacity-50'
  const areaClass =
    'min-h-16 w-full rounded-md border border-(--ui-stroke-secondary) bg-(--ui-bg-elevated) p-2 font-mono text-[0.7rem] leading-snug text-foreground outline-none focus-visible:border-ring disabled:cursor-not-allowed disabled:opacity-50'

  return jsxs('div', {
    className: 'flex flex-col gap-3',
    children: [
      !editable
        ? jsxs('div', {
            role: 'status',
            className: 'flex items-start gap-2 rounded-md border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-[0.72rem] leading-snug text-amber-700 dark:text-amber-300',
            children: [
              jsx(Codicon, { name: 'lock', size: '0.85rem', className: 'mt-0.5 shrink-0' }),
              jsx('span', { children: editBlockReason ?? 'Settings are read-only in this process.' }),
            ],
          })
        : null,

      // Selection policy card.
      jsx(Panel, {
        title: 'Selection policy',
        children: jsxs('div', {
          className: 'flex flex-col gap-3',
          children: [
            jsxs('label', {
              className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)',
              children: [
                'Policy',
                jsxs('select', {
                  className: inputClass,
                  value: draft.policy,
                  disabled: !editable,
                  onChange: patch('policy'),
                  children: policyOptions.map((option) =>
                    jsx('option', { key: option, value: option, children: option }),
                  ),
                }),
                jsx('span', {
                  className: 'font-normal text-(--ui-text-tertiary)',
                  children: 'Ranking preference among verified-free models. Free-only is mandatory; paid fallback does not exist.',
                }),
              ],
            }),
            jsxs('div', {
              className: 'grid grid-cols-1 gap-3 sm:grid-cols-2',
              children: [
                jsxs('label', {
                  className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)',
                  children: [
                    'Minimum context (tokens)',
                    jsx(Input, {
                      type: 'number',
                      min: 2048,
                      max: 2000000,
                      value: draft.min_context,
                      disabled: !editable,
                      onChange: patch('min_context'),
                      inputMode: 'numeric',
                    }),
                  ],
                }),
                jsxs('label', {
                  className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)',
                  children: [
                    'Cooldown after retryable failure (seconds)',
                    jsx(Input, {
                      type: 'number',
                      min: 1,
                      max: 86400,
                      value: draft.cooldown_seconds,
                      disabled: !editable,
                      onChange: patch('cooldown_seconds'),
                      inputMode: 'numeric',
                    }),
                  ],
                }),
              ],
            }),
            jsx(ToggleRow, {
              label: 'Require tool-calling support',
              description: 'Only select models with verified tool-call capability for selection.',
              checked: draft.requires_tools,
              disabled: !editable,
              onChange: (on) => patch('requires_tools')(Boolean(on)),
            }),
          ],
        }),
      }),

      // Routing & access card.
      jsx(Panel, {
        title: 'Routing & access',
        children: jsxs('div', {
          className: 'flex flex-col gap-3',
          children: [
            jsx(ToggleRow, {
              label: 'Route virtual model through Hermes',
              description:
                "enable_chat_router — resolves the virtual model 'autorouter/auto-free' at session create / model switch. Independent of the tools' enabled gate.",
              checked: draft.enable_chat_router,
              disabled: !editable,
              onChange: (on) => patch('enable_chat_router')(Boolean(on)),
            }),
            jsx(ToggleRow, {
              label: 'Free-only eligibility',
              description: 'Mandatory in V1 — verified free tier only. This lock cannot be turned off here.',
              checked: true,
              disabled: true,
              onChange: () => {},
            }),
            jsxs('label', {
              className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)',
              children: [
                'Providers (comma-separated discovery allowlist)',
                jsx(Input, {
                  value: draft.providersText,
                  disabled: !editable,
                  onChange: patch('providersText'),
                  placeholder: 'nvidia, openrouter',
                  spellCheck: false,
                }),
              ],
            }),
            jsxs('label', {
              className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)',
              children: [
                'Model allowlist (model_include) — one key per line, empty = no extra restriction',
                jsx(Textarea, {
                  value: draft.model_include_text,
                  disabled: !editable,
                  onChange: patch('model_include_text'),
                  placeholder: 'openrouter/vendor/model',
                  className: areaClass,
                  rows: 3,
                }),
              ],
            }),
            jsxs('label', {
              className: 'flex flex-col gap-1 text-[0.7rem] font-medium text-(--ui-text-secondary)',
              children: [
                'Model blocklist (model_exclude) — never selected',
                jsx(Textarea, {
                  value: draft.model_exclude_text,
                  disabled: !editable,
                  onChange: patch('model_exclude_text'),
                  placeholder: 'openrouter/vendor/model',
                  className: areaClass,
                  rows: 3,
                }),
              ],
            }),
          ],
        }),
      }),

      // Client-side validation echo (server re-validates on save).
      localErrors.length > 0
        ? jsxs('div', {
            role: 'alert',
            className: 'flex flex-col gap-1 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-[0.72rem] text-destructive',
            children: localErrors.map((message, i) => jsx('div', { key: i, children: `• ${message}` })),
          })
        : null,

      // Save row.
      jsxs('div', {
        className: 'flex flex-wrap items-center gap-2',
        children: [
          jsx(Button, {
            onClick: save,
            disabled: !canSave,
            loading: saving,
            children: changed.length > 1 ? `Save ${changed.length} changes` : 'Save changes',
          }),
          jsx(Button, {
            variant: 'ghost',
            size: 'sm',
            onClick: reset,
            disabled: saving || changed.length === 0,
            children: 'Reset',
          }),
          jsx('span', {
            className: 'text-[0.68rem] text-(--ui-text-tertiary)',
            children: changed.length === 0 ? 'No changes' : `Changed: ${changed.join(', ')}`,
          }),
        ],
      }),

      // Save outcome.
      saveState
        ? jsxs('div', {
            role: saveState.kind === 'error' ? 'alert' : 'status',
            className: cn(
              'flex items-start gap-2 rounded-md border px-3 py-2 text-[0.72rem] leading-snug',
              saveState.kind === 'error'
                ? 'border-destructive/40 bg-destructive/10 text-destructive'
                : 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
            ),
            children: [
              jsx(Codicon, {
                name: saveState.kind === 'error' ? 'error' : 'check',
                size: '0.85rem',
                className: 'mt-0.5 shrink-0',
              }),
              jsxs('span', {
                children: [
                  jsx('strong', { children: saveState.title }),
                  Array.isArray(saveState.lines) && saveState.lines.length > 0
                    ? jsx('ul', {
                        className: 'mt-1 list-disc pl-4',
                        children: saveState.lines.map((line, i) => jsx('li', { key: i, children: line })),
                      })
                    : null,
                ],
              }),
            ],
          })
        : null,

      // Notes from the backend (write semantics) + read-only key explanations.
      Array.isArray(data?.notes) && data.notes.length > 0
        ? jsx(Panel, {
            title: 'How settings are applied',
            children: jsx('ul', {
              className: 'list-disc space-y-1 pl-4 text-[0.7rem] leading-snug text-(--ui-text-secondary)',
              children: data.notes.map((note, i) => jsx('li', { key: i, children: note })),
            }),
          })
        : null,
    ],
  })
}

/* ---------------------------------------------------------------- *
 *  Page shell
 * ---------------------------------------------------------------- */

function AutorouterPage({ ctx }) {
  const [tab, setTab] = useState('overview')

  const body =
    tab === 'overview'
      ? jsx(OverviewTab, { ctx })
      : tab === 'providers'
        ? jsx(ProvidersTab, { ctx })
        : tab === 'models'
          ? jsx(ModelsTab, { ctx })
          : tab === 'profiles'
            ? jsx(ProfilesTab, { ctx })
            : tab === 'analytics'
              ? jsx(AnalyticsTab, { ctx })
              : jsx(SettingsTab, { ctx })

  return jsxs('div', {
    className: 'relative flex h-full min-w-0 flex-col overflow-hidden bg-(--ui-surface-background)',
    children: [
      // Header — sits below the floating titlebar chrome like every app page.
      jsxs('header', {
        className: 'flex shrink-0 items-center gap-2.5 px-4 pb-1.5 pt-[calc(var(--titlebar-height)+0.75rem)]',
        children: [
          jsx('span', {
            className: 'inline-flex size-7 items-center justify-center rounded-md bg-amber-500/15 text-amber-600 dark:text-amber-300',
            'aria-hidden': true,
            children: jsx(Codicon, { name: 'zap', size: '1.1rem' }),
          }),
          jsxs('div', {
            className: 'min-w-0 leading-tight',
            children: [
              jsx('h1', {
                className: 'text-[0.95rem] font-semibold text-foreground',
                children: 'AutoRouter',
              }),
              jsx('p', {
                className: 'text-[0.65rem] text-(--ui-text-tertiary)',
                children: `Route-free model selection · management console · v${VERSION}`,
              }),
            ],
          }),
        ],
      }),

      // Tab bar — SDK (radix) Tabs: roving-tabindex arrow-key navigation,
      // Home/End, proper tab/tabpanel semantics.
      jsx('div', {
        className: 'shrink-0 px-4 pb-2',
        children: jsx(Tabs, {
          value: tab,
          onValueChange: (value) => setTab(String(value)),
          children: jsx(TabsList, {
            className: 'h-8',
            'aria-label': 'AutoRouter sections',
            children: TABS.map((entry) =>
              jsx(TabsTrigger, {
                key: entry.id,
                value: entry.id,
                className: 'h-6 px-2.5 text-[0.72rem]',
                children: entry.label,
              }),
            ),
          }),
        }),
      }),

      // Content.
      jsx('div', {
        className: 'min-h-0 flex-1 overflow-y-auto px-4 pb-6 pt-1',
        children: jsxs('div', {
          className: 'mx-auto flex w-full max-w-6xl flex-col gap-3 @container',
          children: [body],
        }),
      }),
    ],
  })
}

/* ---------------------------------------------------------------- *
 *  Registration — sidebar entry, full page, palette command
 * ---------------------------------------------------------------- */

export default {
  id: 'autorouter',
  name: 'AutoRouter',
  description: 'AutoRouter management console — overview, providers, models, analytics and settings.',
  register(ctx) {
    ctx.registerMany([
      {
        id: 'page',
        area: ROUTES_AREA,
        title: 'AutoRouter',
        data: { path: PAGE_PATH },
        render: () => jsx(AutorouterPage, { ctx }),
      },
      {
        id: 'nav',
        area: SIDEBAR_NAV_AREA,
        order: 60,
        data: { codicon: 'zap', label: 'AutoRouter', path: PAGE_PATH },
      },
      {
        id: 'open',
        area: PALETTE_AREA,
        data: {
          id: 'autorouter.open',
          label: 'AutoRouter: Open management console',
          keywords: ['autorouter', 'router', 'models', 'free-only', 'providers'],
          run: () => host.navigate(PAGE_PATH),
        },
      },
    ])
  },
}
