"""Frozen-clock quota collection gates; no provider calls or credentials."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from types import SimpleNamespace
import threading

import pytest
from autorouter.autorouter_core.evidence import free_access as fa, scope_quota as sq
from autorouter.autorouter_core.integration import runtime
from autorouter.autorouter_core.storage import state


@pytest.fixture
def setup(tmp_path, monkeypatch):
    clock = [1000.0]
    monkeypatch.setattr(sq.time, 'time', lambda: clock[0])
    store = state.StateStore(tmp_path)
    calls = []
    def fetch(**kwargs):
        calls.append(kwargs)
        return dict(status='ok', provider_id='openrouter',
            credential_scope_id=kwargs['credential_scope_id'], quota_source='official_key_limits',
            observed_at=clock[0], expires_at=clock[0]+fa.TTL, limit=50, remaining=38, used=12)
    ctx = SimpleNamespace(get_config=lambda *args: True, quota_fetch=fetch)
    data = {'store': store, 'ctx': ctx}
    monkeypatch.setattr(runtime, '_STATE', data)
    def pre(scope='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', provider='openrouter', **extra):
        runtime.on_pre_api_request(provider=provider, model='test:free',
            credential_scope={'provider_id': provider, 'credential_scope_id': scope,
                              'identity_status': 'known'}, **extra)
    return SimpleNamespace(clock=clock, store=store, calls=calls, ctx=ctx, data=data, pre=pre)


def test_twenty_simultaneous_callbacks_and_persisted_cooldown(setup):
    e = setup
    barrier = threading.Barrier(20)
    entered = threading.Event()
    release = threading.Event()
    original = e.ctx.quota_fetch
    def blocked(**kwargs):
        entered.set()
        assert release.wait(5)
        return original(**kwargs)
    e.ctx.quota_fetch = blocked
    def call(i):
        barrier.wait(5)
        e.pre(api_request_id=f'request-{i}', retry_count=i)
    with ThreadPoolExecutor(max_workers=20) as pool:
        futures = [pool.submit(call, i) for i in range(20)]
        assert entered.wait(5)
        # The other callbacks must finish while the only fetch is still active.
        completed = 0
        for future in as_completed(futures, timeout=5):
            future.result()
            completed += 1
            if completed == 19:
                break
        assert e.calls == []
        release.set()
        for future in futures:
            future.result(timeout=5)
    assert len(e.calls) == 1
    assert all(e.store.get_request(e.store.find_request_by_api_id(f'request-{i}'))['key_scope']
               for i in range(20))
    original_evidence = fa.read_snapshot(e.store, 'openrouter', 'openrouter:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')['quota_evidence']
    e.ctx.quota_fetch = original
    # A newly opened store shares the same persisted lease.
    e.data['store'] = state.StateStore(e.store.db_path.parent)
    for now in (1000, 1001, 1059, 1060, 1119.999):
        e.clock[0] = now
        e.pre(api_request_id=f'repeat-{now}')
    assert len(e.calls) == 1
    assert fa.read_snapshot(e.store, 'openrouter', 'openrouter:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')['quota_evidence'] == original_evidence
    e.clock[0] = 1120
    assert fa.evaluate(fa.read_snapshot(e.store, 'openrouter', 'openrouter:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
        'openrouter', None, 'openrouter:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', e.clock[0])['state'] == 'unknown'
    e.pre(api_request_id='after-cooldown')
    assert len(e.calls) == 2


def test_distinct_scopes_keep_binding_and_allowance_isolated(setup):
    e = setup
    e.pre('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', api_request_id='a', retry_count=0)
    e.pre('bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', api_request_id='a', retry_count=1)
    assert [call['credential_scope_id'] for call in e.calls] == ['aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb']
    assert all(call['provider_id']=='openrouter' and call['quota_source']=='official_key_limits' for call in e.calls)
    for scope in ('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'):
        assert fa.read_snapshot(e.store, 'openrouter', 'openrouter:'+scope)['state']=='healthy'
    assert fa.read_snapshot(e.store, 'openrouter', 'openrouter:cccccccccccccccccccccccccccccccc')['state']=='unknown'


@pytest.mark.parametrize('kind', ['nvidia','unknown','malformed','disabled','missing_host'])
def test_ineligible_callbacks_do_not_fetch(setup, kind):
    e = setup
    payload = dict(provider='openrouter', credential_scope=dict(provider_id='openrouter',
        credential_scope_id='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', identity_status='known'))
    if kind=='nvidia':
        payload['provider']='nvidia'
        payload['credential_scope']['provider_id']='nvidia'
    elif kind=='unknown': payload['credential_scope']['identity_status']='unknown'
    elif kind=='malformed': payload['credential_scope']='aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
    elif kind=='disabled': e.ctx.get_config=lambda *args: False
    else: del e.ctx.quota_fetch
    sq.observe(e.data, payload)
    assert e.calls==[]


@pytest.mark.parametrize('outcome', ['unavailable','unknown','rate_limited','unauthorized','malformed','timeout','error'])
def test_failure_keeps_persisted_cooldown_and_inference_continues(setup, outcome):
    e = setup
    def failure(**kwargs):
        e.calls.append(kwargs)
        if outcome=='timeout': raise TimeoutError('synthetic timeout')
        if outcome=='error': raise RuntimeError('synthetic failure')
        return None if outcome=='malformed' else {'status': outcome}
    e.ctx.quota_fetch=failure
    for i in range(20):
        e.pre(api_request_id=f'failed-{i}')
    assert len(e.calls)==1
    assert all(e.store.find_request_by_api_id(f'failed-{i}') is not None for i in range(20))
    cached=fa.read_snapshot(e.store, 'openrouter', 'openrouter:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
    assert cached['state']=='unknown' and not cached['quota_evidence']
    e.clock[0]+=fa.TTL
    e.pre(api_request_id='retry-after-cooldown')
    assert len(e.calls)==2


def test_failed_refresh_preserves_original_evidence_and_expiry(setup):
    e = setup
    e.pre(api_request_id='initial')
    original = fa.read_snapshot(e.store, 'openrouter', 'openrouter:'+'a'*32)['quota_evidence']
    e.clock[0] += fa.TTL
    e.ctx.quota_fetch = lambda **kwargs: {'status': 'unavailable'}
    e.pre(api_request_id='failed-refresh')
    cached = fa.read_snapshot(e.store, 'openrouter', 'openrouter:'+'a'*32)
    assert cached['state']=='unavailable'
    assert cached['quota_evidence']==original
    assert cached['next_refresh_at']==e.clock[0]+fa.TTL
    assert fa.evaluate(cached, 'openrouter', None, 'openrouter:'+'a'*32,
                       e.clock[0])['state']=='unavailable'
