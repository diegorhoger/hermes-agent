import tempfile
from pathlib import Path

from autorouter.autorouter_core.storage import state as st
from autorouter.autorouter_core.routing import router as rt_mod


def _make_store(tmp_path, models):
    store = st.StateStore(tmp_path / "state")
    for p, m, ctx in models:
        seed_verified_model(store, p, m, context_length=ctx, capabilities={"tools": True}, cost_tier="free")
    return store


def test_select_picks_available(tmp_path):
    store = _make_store(tmp_path, [("nvidia", "m1", 16000), ("openrouter", "m2", 32000)])
    state = {"policy": "auto", "free_only": True, "paid_authorized": False,
             "providers": ["nvidia", "openrouter"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select(requires_tools=True, min_context=8192)
    assert chosen is not None
    assert chosen["model"] in ("m1", "m2")


def test_select_excludes_retired_and_cooldown(tmp_path):
    store = _make_store(tmp_path, [("nvidia", "m1", 16000), ("openrouter", "m2", 32000)])
    store.record_outcome("nvidia", "m1", False, status_code=410, error_type="model_not_found")
    state = {"policy": "auto", "free_only": True, "paid_authorized": False,
             "providers": ["nvidia", "openrouter"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select(requires_tools=True, min_context=8192)
    assert chosen is not None
    assert chosen["model"] == "m2"


def test_select_all_unavailable_returns_none(tmp_path):
    store = _make_store(tmp_path, [("nvidia", "m1", 16000)])
    store.record_outcome("nvidia", "m1", False, status_code=410, error_type="model_not_found")
    state = {"policy": "auto", "free_only": True, "paid_authorized": False,
             "providers": ["nvidia"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select(requires_tools=True, min_context=8192)
    assert chosen is None


def test_429_cooldown_respected(tmp_path):
    store = _make_store(tmp_path, [("nvidia", "m1", 16000), ("openrouter", "m2", 32000)])
    store.record_outcome("nvidia", "m1", False, status_code=429)
    state = {"policy": "auto", "free_only": True, "paid_authorized": False,
             "providers": ["nvidia", "openrouter"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select(requires_tools=True, min_context=8192)
    assert chosen is not None
    assert chosen["model"] == "m2"


def test_paid_only_excluded_under_free_policy(tmp_path):
    store = st.StateStore(tmp_path / "state")
    seed_verified_model(store, "openrouter", "paid-model", context_length=16000, capabilities={"tools": True}, cost_tier="paid")
    seed_verified_model(store, "nvidia", "free-model", context_length=16000, capabilities={"tools": True}, cost_tier="free")
    state = {"policy": "auto", "free_only": True, "paid_authorized": False,
             "providers": ["nvidia", "openrouter"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select(requires_tools=True, min_context=8192)
    assert chosen is not None
    assert chosen["model"] == "free-model"


def test_tool_incompatible_excluded(tmp_path):
    store = st.StateStore(tmp_path / "state")
    seed_verified_model(store, "nvidia", "text-only", context_length=16000, capabilities={"tools": False}, cost_tier="free")
    seed_verified_model(store, "nvidia", "tool-model", context_length=16000, capabilities={"tools": True}, cost_tier="free")
    state = {"policy": "auto", "free_only": True, "paid_authorized": False,
             "providers": ["nvidia"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select(requires_tools=True, min_context=8192)
    assert chosen is not None
    assert chosen["model"] == "tool-model"


def test_refresh_updates_catalog(tmp_path, monkeypatch):
    store = st.StateStore(tmp_path / "state")
    state = {"policy": "auto", "free_only": True, "paid_authorized": False,
             "providers": ["nvidia"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    # mock discovery
    import autorouter.autorouter_core.discovery.discovery as dc
    monkeypatch.setattr(dc, "discover_provider", lambda p, store=None: [
        {"provider": p, "model": "new-model", "context_length": 8192, "capabilities": {"tools": True}, "cost_tier": "free"}
    ])
    res = router.refresh()
    assert res["ok"] is True
    rows = store.get_catalog("nvidia")
    assert any(r["model"] == "new-model" for r in rows)


# ── select_free_model: fail-closed free-only selection ──────────────────────

def test_select_free_model_picks_free(tmp_path):
    store = st.StateStore(tmp_path / "state")
    seed_verified_model(store, "nvidia", "free-model", context_length=16000, capabilities={"tools": True}, cost_tier="free")
    seed_verified_model(store, "openrouter", "paid-model", context_length=16000, capabilities={"tools": True}, cost_tier="paid")
    state = {"policy": "auto", "free_only": True, "paid_authorized": True,
             "providers": ["nvidia", "openrouter"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select_free_model(requires_tools=True, min_context=8192)
    assert chosen is not None
    assert chosen["model"] == "free-model"
    assert chosen["cost_tier"] == "free"


def test_select_free_model_excludes_paid_even_authorized(tmp_path):
    store = st.StateStore(tmp_path / "state")
    seed_verified_model(store, "openrouter", "paid-model", context_length=16000, capabilities={"tools": True}, cost_tier="paid")
    state = {"policy": "auto", "free_only": False, "paid_authorized": True,
             "providers": ["openrouter"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select_free_model(requires_tools=True, min_context=8192)
    assert chosen is None


def test_select_free_model_excludes_unknown_cost(tmp_path):
    store = st.StateStore(tmp_path / "state")
    seed_verified_model(store, "nvidia", "unknown-cost", context_length=16000, capabilities={"tools": True}, cost_tier="unknown")
    seed_verified_model(store, "nvidia", "free-model", context_length=16000, capabilities={"tools": True}, cost_tier="free")
    state = {"policy": "auto", "free_only": True, "paid_authorized": False,
             "providers": ["nvidia"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select_free_model(requires_tools=True, min_context=8192)
    assert chosen is not None
    assert chosen["model"] == "free-model"


def test_select_free_model_excludes_missing_cost(tmp_path):
    store = st.StateStore(tmp_path / "state")
    seed_verified_model(store, "nvidia", "missing-cost", context_length=16000, capabilities={"tools": True})
    seed_verified_model(store, "nvidia", "free-model", context_length=16000, capabilities={"tools": True}, cost_tier="free")
    state = {"policy": "auto", "free_only": True, "paid_authorized": False,
             "providers": ["nvidia"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select_free_model(requires_tools=True, min_context=8192)
    assert chosen is not None
    assert chosen["model"] == "free-model"


def test_select_free_model_none_when_no_free_available(tmp_path):
    store = st.StateStore(tmp_path / "state")
    seed_verified_model(store, "openrouter", "paid-model", context_length=16000, capabilities={"tools": True}, cost_tier="paid")
    seed_verified_model(store, "openrouter", "unknown-cost", context_length=16000, capabilities={"tools": True}, cost_tier="unknown")
    state = {"policy": "auto", "free_only": False, "paid_authorized": True,
             "providers": ["openrouter"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select_free_model(requires_tools=True, min_context=8192)
    assert chosen is None


def test_select_free_model_excludes_retired(tmp_path):
    store = st.StateStore(tmp_path / "state")
    seed_verified_model(store, "nvidia", "free-model", context_length=16000, capabilities={"tools": True}, cost_tier="free")
    store.record_outcome("nvidia", "free-model", False, status_code=410, error_type="model_not_found")
    state = {"policy": "auto", "free_only": True, "paid_authorized": False,
             "providers": ["nvidia"], "store": store, "cooldown_seconds": 60}
    router = rt_mod.Router(state)
    chosen = router.select_free_model(requires_tools=True, min_context=8192)
    assert chosen is None

from tests.verified_fixture import seed_verified_model
