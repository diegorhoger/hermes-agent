"""CSS/JS compatibility contract for pinned Hermes web tokens, not desktop APIs."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def test_palette_is_host_owned_and_scoped():
    css = (ROOT / 'dashboard/dist/style.css').read_text()
    assert not re.search(r'#[0-9a-fA-F]{3,8}\b|\brgba?\(|gradient\(|box-shadow\s*:', css)
    assert '--ar-text: var(--midground, currentColor)' in css
    assert '--ar-bg: var(--background-base, Canvas)' in css
    for token in ('--color-border', '--color-ring', '--color-muted-foreground', '--color-input',
                  '--theme-font-sans', '--theme-font-mono', '--theme-radius', '--theme-spacing-mul'):
        assert token in css
    for selectors in re.findall(r'([^{}]+)\{', re.sub(r'/\*.*?\*/', '', css, flags=re.S)):
        if selectors.strip().startswith('@'):
            continue
        assert all(selector.strip().startswith('.ar-') for selector in re.split(r',(?![^()]*\))', selectors)), selectors
    assert 'prefers-reduced-motion: reduce' in css
    assert 'summary, [tabindex]):focus-visible' in css


def test_plugin_does_not_own_theme_state_or_fixed_chart_palette():
    js = (ROOT / 'dashboard/dist/index.js').read_text()
    assert 'localStorage' not in js and 'data-theme' not in js
    assert not re.search(r'background:\s*"#', js)
    assert 'var(--series-output-token' in js and 'var(--series-input-token' in js
    assert 'class: "ar-logo"' not in js
    assert '__HERMES_PLUGINS__.register' in js
