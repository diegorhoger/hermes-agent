import json
import tempfile
from pathlib import Path

import pytest

from autorouter.autorouter_core.storage import state as st
from autorouter.autorouter_core.routing import router as rt
from autorouter.autorouter_core.routing import integration as integ
from autorouter.autorouter_core.configuration import capabilities as cap


def _setup_store(tmp_path, models):
    store = st.StateStore(tmp_path / "state")
    for m in models:
        store.upsert_catalog(m["provider"], m["model"], context_length=m.get("context_length"),
                            capabilities=m.get("capabilities"), cost_tier=m.get("cost_tier"))
        mc = cap.ModelCapabilities(
            provider=m["provider"], model=m["model"],
            context_window=m.get("context_length"),
            tools=cap.VerificationState.SUPPORTED if (m.get("capabilities") or {}).get("tools") else cap.VerificationState.UNKNOWN,
            cost_tier=m.get("cost_tier", "unknown"),
            metadata_source="provider",
            retrieved_at=1.0, expires_at=9999999999.0,
        )
        store.upsert_capability(m["provider"], m["model"], json.dumps(mc.to_dict()),
                                metadata_source="provider", retrieved_at=1.0, expires_at=9999999999.0)
    return store


def test_e2e_new_model_selected(tmp_path):
    store = _setup_store(tmp_path, [
        {"provider": "openrouter", "model": "brand-new-model-7b", "context_length": 32768,
         "capabilities": {"tools": True}, "cost_tier": "free"},
    ])
    r = rt.Router({"policy": "auto", "free_only": True, "paid_authorized": False,
                   "providers": ["openrouter"], "store": store})
    # inject store
    r.state["store"] = store
    chosen = r.select(requires_tools=True, min_context=8192)
    assert chosen is not None
    assert chosen["provider"] == "openrouter"
    assert chosen["model"] == "brand-new-model-7b"


def test_e2e_insufficient_context_excluded(tmp_path):
    store = _setup_store(tmp_path, [
        {"provider": "openrouter", "model": "small-ctx", "context_length": 4096,
         "capabilities": {"tools": True}, "cost_tier": "free"},
    ])
    r = rt.Router({"policy": "auto", "free_only": True, "paid_authorized": False,
                   "providers": ["openrouter"], "store": store})
    r.state["store"] = store
    assert r.select(requires_tools=True, min_context=8192) is None


def test_e2e_unknown_tools_excluded(tmp_path):
    store = _setup_store(tmp_path, [
        {"provider": "openrouter", "model": "unknown-tools", "context_length": 32768,
         "capabilities": {"tools": "unknown"}, "cost_tier": "free"},
    ])
    # override capability tools to unknown
    mc = cap.ModelCapabilities(provider="openrouter", model="unknown-tools", context_window=32768,
                                tools=cap.VerificationState.UNKNOWN, cost_tier="free",
                                metadata_source="provider", retrieved_at=1.0, expires_at=9999999999.0)
    store.upsert_capability("openrouter", "unknown-tools", json.dumps(mc.to_dict()),
                            metadata_source="provider", retrieved_at=1.0, expires_at=9999999999.0)
    r = rt.Router({"policy": "auto", "free_only": True, "paid_authorized": False,
                   "providers": ["openrouter"], "store": store})
    r.state["store"] = store
    assert r.select(requires_tools=True, min_context=8192) is None


def test_e2e_paid_excluded_free_only(tmp_path):
    store = _setup_store(tmp_path, [
        {"provider": "openrouter", "model": "paid-model", "context_length": 32768,
         "capabilities": {"tools": True}, "cost_tier": "paid"},
    ])
    r = rt.Router({"policy": "auto", "free_only": True, "paid_authorized": False,
                   "providers": ["openrouter"], "store": store})
    r.state["store"] = store
    assert r.select(requires_tools=True, min_context=8192) is None


def test_e2e_integration_receives_selected(tmp_path, monkeypatch):
    store = _setup_store(tmp_path, [
        {"provider": "openrouter", "model": "brand-new-model-7b", "context_length": 32768,
         "capabilities": {"tools": True}, "cost_tier": "free"},
    ])
    # patch runtime router
    import autorouter.autorouter_core.integration.runtime as rtmod
    r = rt.Router({"policy": "auto", "free_only": True, "paid_authorized": False,
                   "providers": ["openrouter"], "store": store})
    r.state["store"] = store
    rtmod._STATE["router"] = r
    rtmod._STATE["store"] = store
    chain = integ.build_fallback_chain(requires_tools=True, min_context=8192, limit=3)
    assert chain and chain[0]["model"] == "brand-new-model-7b"


def test_e2e_sqlite_reconnect_preserves(tmp_path):
    store = _setup_store(tmp_path, [
        {"provider": "openrouter", "model": "persisted", "context_length": 32768,
         "capabilities": {"tools": True}, "cost_tier": "free"},
    ])
    # reconnect
    store2 = st.StateStore(tmp_path / "state")
    row = store2.get_capability("openrouter", "persisted")
    assert row is not None


def test_e2e_conflicting_metadata_fails_closed(tmp_path):
    # provider says tools supported, cached says unsupported -> unknown
    store = st.StateStore(tmp_path / "state")
    store.upsert_catalog("openrouter", "conflict", context_length=32768,
                        capabilities={"tools": True}, cost_tier="free")
    store.upsert_catalog("openrouter", "conflict", context_length=32768,
                        capabilities={"tools": False}, cost_tier="free")
    # resolve manually
    caps = cap.resolve_capabilities({"tools": True, "source": "provider"},
                                    {"tools": False, "source": "cached"}, None)
    assert caps.tools == cap.VerificationState.UNKNOWN
