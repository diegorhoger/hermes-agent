"""Five-adapter lifecycle acceptance; synthetic transport is not live entitlement."""
import json
from types import SimpleNamespace
import pytest
from autorouter.autorouter_core.discovery import adapters, discovery, metadata
from autorouter.autorouter_core.providers import provider_intelligence
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.storage import state


@pytest.mark.parametrize('payload', [None, [], {}, {'data':None}, {'data':[None]},
    {'data':[{'id':'duplicate'},{'id':'duplicate'}]}, {'data':[{'id':'sk-privateprivate'}]}])
def test_openrouter_rejects_incomplete_or_malformed_catalog(payload):
    with pytest.raises(adapters.DiscoveryError, match='malformed_catalog'):
        metadata.normalize_openrouter(payload, 100)


def test_openrouter_uses_bounded_redirect_refusing_public_transport(monkeypatch):
    calls=[]
    def read(url, headers):
        calls.append((url,headers))
        return {'data':[{'id':'arbitrary:free','context_length':32000,
                         'supported_parameters':['tools'], 'pricing':{'prompt':'0','completion':'0'}}]}
    monkeypatch.setattr(adapters,'_read_json',read)
    row=metadata.fetch_metadata('openrouter')['arbitrary:free']
    assert calls==[(metadata.OPENROUTER,{'Accept':'application/json'})]
    assert row['cost_tier']=='free' and row['discovery_status']=='discovered'
    assert row['metadata_source']==metadata.OPENROUTER
    assert row['expires_at']==row['retrieved_at']+metadata.TTL


@pytest.mark.parametrize('provider',['nvidia','openrouter'])
def test_complete_native_empty_catalog_revokes_absent_models(provider,tmp_path,monkeypatch):
    import providers
    monkeypatch.setattr(providers,'get_provider_profile',lambda _:SimpleNamespace(
        env_vars=(),fallback_models=('fallback',),fetch_models=lambda **_:[]))
    monkeypatch.setattr(metadata,'fetch_metadata',lambda _: {})
    store=state.StateStore(tmp_path)
    cap=dict(provider=provider,model='removed',cost_tier='free',tools='supported',context_window=32000,
        metadata_source='controlled-test-fixture',retrieved_at=100,expires_at=99999999999)
    store.persist_discovered_model(dict(provider=provider,model='removed',metadata=cap))
    rows=discovery.discover_all([provider],store)[provider]
    assert [row['model'] for row in rows]==['removed']
    saved=json.loads(store.get_capability(provider,'removed')['capability_json'])
    assert saved['available'] is False and saved['discovery_status']=='removed'
    assert metadata.verified_fields(saved,provider,'removed',saved['retrieved_at']+1)[0]['cost_tier']=='unknown'
    assert router.Router(dict(store=store,providers=[provider])).preview()['chosen'] is None


def test_native_fallback_is_candidate_not_fresh_discovery_or_eligible(tmp_path,monkeypatch):
    import providers
    monkeypatch.setattr(providers,'get_provider_profile',lambda _:SimpleNamespace(
        env_vars=(),fallback_models=('fallback',),fetch_models=lambda **_:None))
    monkeypatch.setattr(metadata,'fetch_metadata',lambda _: {})
    store=state.StateStore(tmp_path)
    old=dict(provider='nvidia',model='fallback',cost_tier='free',tools='supported',context_window=32000,
        metadata_source='controlled-test-fixture',retrieved_at=100,expires_at=99999999999)
    store.persist_discovered_model(dict(provider='nvidia',model='fallback',metadata=old))
    discovery.discover_all(['nvidia'],store)
    cap=json.loads(store.get_capability('nvidia','fallback')['capability_json'])
    assert cap['discovery_status']=='candidate'
    assert cap['field_evidence']['cost_tier']['retrieved_at']==100
    assert metadata.verified_fields(cap,'nvidia','fallback',101)[0]['cost_tier']=='unknown'
    assert router.Router(dict(store=store,providers=['nvidia'])).preview()['chosen'] is None


@pytest.mark.parametrize('models',[{'model':'value'},['duplicate','duplicate'],[None],['sk-privateprivate']])
def test_native_malformed_catalog_does_not_replace_evidence(models,tmp_path,monkeypatch):
    import providers
    monkeypatch.setattr(providers,'get_provider_profile',lambda _:SimpleNamespace(
        env_vars=(),fetch_models=lambda **_:models))
    monkeypatch.setattr(metadata,'fetch_metadata',lambda _:pytest.fail('malformed IDs must stop first'))
    store=state.StateStore(tmp_path)
    assert discovery.discover_all(['nvidia'],store)['nvidia']==[]
    assert store.get_catalog()==[]


def test_stages_never_promote_registry_candidates_or_entitlement():
    models=[dict(provider='openrouter',model='m',eligible=True,discovery_status='discovered'),
            dict(provider='nvidia',model='old',eligible=False,discovery_status='removed')]
    data=provider_intelligence.registry_details(['openrouter','nvidia'],models)
    stages={row['provider_id']:row for row in data['discovery_states']}
    assert len(stages)==6 and data['candidate_count']==249
    assert stages['openrouter']['discovery_capable'] and stages['openrouter']['configured']
    assert stages['openrouter']['discovered_model_count']==stages['openrouter']['eligible_model_count']==1
    assert stages['nvidia']['catalog_model_count']==1 and stages['nvidia']['discovered_model_count']==0
    assert not stages['groq']['configured'] and stages['groq']['discovered_model_count']==0
    assert all(row['operationally_usable']=='unknown' for row in stages.values())
    assert all(row['verification']=='unverified_source_claim' for row in data['candidates'])


def test_discovery_stage_expires_without_renewing_catalog_age():
    cap=adapters.normalize('groq', {'data':[{'id':'m'}]},100)['m']
    fresh=provider_intelligence.model_details(cap,101,str)
    stale=provider_intelligence.model_details(cap,100+adapters.TTL,str)
    assert fresh['discovery_status']=='discovered' and stale['discovery_status']=='unknown'
    assert fresh['discovery_evidence']==stale['discovery_evidence']
    assert stale['discovery_evidence']['retrieved_at']==100


@pytest.mark.parametrize('provider',['nvidia','openrouter'])
def test_native_reappearance_clears_catalog_tombstone(provider,tmp_path,monkeypatch):
    import providers
    models=[]
    monkeypatch.setattr(providers,'get_provider_profile',lambda _:SimpleNamespace(
        env_vars=(),fetch_models=lambda **_:list(models)))
    monkeypatch.setattr(metadata,'fetch_metadata',lambda _: {})
    store=state.StateStore(tmp_path)
    old=dict(provider=provider,model='reappeared',cost_tier='unknown',metadata_source='controlled-test-fixture',
        retrieved_at=100,expires_at=200)
    store.persist_discovered_model(dict(provider=provider,model='reappeared',metadata=old))
    discovery.discover_all([provider],store)
    assert json.loads(store.get_capability(provider,'reappeared')['capability_json'])['available'] is False
    models.append('reappeared')
    discovery.discover_all([provider],store)
    cap=json.loads(store.get_capability(provider,'reappeared')['capability_json'])
    assert cap['available'] is True and cap['discovery_status']=='discovered'
    assert metadata.verified_fields(cap,provider,'reappeared',cap['discovery_evidence']['retrieved_at']+1)[0]['cost_tier']=='unknown'
