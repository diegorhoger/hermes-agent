from autorouter.autorouter_core.integration import runtime as rt
from autorouter.autorouter_core.routing import integration as ig


def test_build_fallback_chain_empty_without_router():
    chain = ig.build_fallback_chain()
    assert isinstance(chain, list)


def test_apply_to_agent_refuses_private_mutation(monkeypatch):
    class FakeAgent:
        pass
    # configure runtime with a router using tmp store
    import tempfile
    from pathlib import Path
    from autorouter.autorouter_core.storage import state as st
    store = st.StateStore(Path(tempfile.mkdtemp()) / "state")
    seed_verified_model(store, "nvidia", "m1", context_length=16000, capabilities={"tools": True}, cost_tier="free")
    seed_verified_model(store, "openrouter", "m2", context_length=32000, capabilities={"tools": True}, cost_tier="free")
    rt.configure(policy="auto", free_only=True, paid_authorized=False, providers=["nvidia", "openrouter"],
                 cooldown_seconds=60, state_dir=Path(tempfile.mkdtemp()) / "state2")
    rt.get_state()["store"] = store
    # rebuild router
    from autorouter.autorouter_core.routing import router as rmod
    rt.get_state()["router"] = rmod.Router(rt.get_state())

    agent = FakeAgent()
    ok = ig.apply_to_agent(agent)
    assert ok is False
    assert not hasattr(agent, "_fallback_chain")

from tests.verified_fixture import seed_verified_model
