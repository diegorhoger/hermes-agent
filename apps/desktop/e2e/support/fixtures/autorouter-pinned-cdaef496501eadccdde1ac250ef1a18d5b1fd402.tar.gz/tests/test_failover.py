from autorouter.autorouter_core.routing import failover as fv


def test_classify_429():
    res = fv.classify({"status_code": 429, "provider": "nvidia", "model": "m1"})
    assert res is not None
    assert res["should_fallback"] is True
    assert res["retryable"] is True


def test_classify_410():
    res = fv.classify({"status_code": 410, "provider": "nvidia", "model": "m1"})
    assert res is not None
    assert res["should_fallback"] is True


def test_classify_401():
    res = fv.classify({"status_code": 401, "provider": "nvidia", "model": "m1"})
    assert res is not None
    assert res["should_fallback"] is True


def test_classify_503():
    res = fv.classify({"status_code": 503, "provider": "nvidia", "model": "m1"})
    assert res is not None
    assert res["should_fallback"] is True


def test_classify_unknown_returns_none():
    res = fv.classify({"status_code": 200, "provider": "nvidia", "model": "m1"})
    assert res is None


def test_retry_after_respected(monkeypatch, tmp_path):
    import tempfile
    from pathlib import Path
    from autorouter.autorouter_core.storage import state as st
    from autorouter.autorouter_core.integration import runtime as rt
    store = st.StateStore(tmp_path / "state")
    rt.configure(policy="auto", free_only=True, paid_authorized=False,
                 providers=["nvidia"], cooldown_seconds=60, state_dir=tmp_path / "state")
    # inject store
    rt.get_state()["store"] = store
    res = fv.classify({"status_code": 429, "provider": "nvidia", "model": "m1", "retry_after": 120})
    assert res is not None
    h = store.get_health("nvidia", "m1")
    assert h["cooldown_until"] > 0
