"""HTTP-layer and unit tests for the model on/off preference endpoints and
the preference annotations on the /models payload (issue #108).

Run with:
    uv run --with fastapi --with httpx python -m pytest tests/test_model_toggles_api.py
"""

from __future__ import annotations

import copy
import importlib.util
import json
import sys
from pathlib import Path

import pytest

fastapi = pytest.importorskip("fastapi")
httpx = pytest.importorskip("httpx")

from fastapi import FastAPI
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
PLUGIN_API = ROOT / "dashboard" / "plugin_api.py"


def _load_plugin_api():
    name = "_test_autorouter_toggles_api"
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, PLUGIN_API)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def _load_state_reader():
    _load_plugin_api()
    return sys.modules["_autorouter_dashboard_state_reader"]


@pytest.fixture()
def workspace(monkeypatch, tmp_path):
    """Mutable plugin-values + seeded catalog on a tmp store."""
    state_dir = tmp_path / "state"
    values = {
        "enabled": True,
        "policy": "auto",
        "free_only": True,
        "providers": ["nvidia", "openrouter"],
        "cooldown_seconds": 60,
        "min_context": 8192,
        "requires_tools": True,
        "state_dir": str(state_dir),
        "paid_authorized": False,
        "model_include": [],
        "model_exclude": [],
    }
    sr = _load_state_reader()

    state = {"values": values}
    monkeypatch.setattr(sr, "read_plugin_config", lambda: {
        "values": state["values"], "available": True, "reason": None, "managed": False,
    })
    # Fake the persistence boundary — never the live config.
    saved: list[tuple[str, list]] = []
    def fake_save(plugin_id, segments, value):
        assert plugin_id == "autorouter"
        saved.append((".".join(segments), value))
        state["values"][".".join(segments)] = copy.deepcopy(value)

    import hermes_cli.plugins_state as psr
    monkeypatch.setattr(psr, "save_plugin_setting", fake_save)

    state_mod = sr._load_submodule("state")
    store = state_mod.StateStore(state_dir)
    now = 1.0
    expiry = 9999999999.0

    def seed(rows):
        for p, m, ctx, tools, tier in rows:
            store.upsert_catalog(p, m, context_length=ctx, capabilities={"tools": tools}, cost_tier=tier)
            store.upsert_capability(
                p, m,
                json.dumps({
                    "provider": p, "model": m,
                    "field_evidence": {
                        "context_window": {"metadata_source": "provider", "retrieved_at": now, "expires_at": expiry},
                        "tools": {"metadata_source": "provider", "retrieved_at": now, "expires_at": expiry},
                        "cost_tier": {"metadata_source": "provider", "retrieved_at": now, "expires_at": expiry},
                    },
                    "context_window": ctx, "tools": tools, "cost_tier": tier, "source": "provider",
                }),
                metadata_source="provider", retrieved_at=now, expires_at=expiry)

    rows = []
    providers = ["nvidia", "openrouter", "groq", "gemini", "mistral", "nous"]
    for i in range(20):
        for j, p in enumerate(providers):
            tier = "free" if (i + j) % 3 else "paid"
            tools = "supported" if (i + j) % 4 != 3 else "unknown"
            rows.append((p, f"model-{i:02d}", 131072, tools, tier))
    seed(rows)
    # One big eligible free row so selection-related annotations have signal.
    seed([("nvidia", "nvidia-free", 131072, "supported", "free")])
    state["seed_rows"] = len(rows)
    state["saved"] = saved
    return state


@pytest.fixture()
def client(workspace):
    plugin_api = _load_plugin_api()
    app = FastAPI()
    app.include_router(plugin_api.router, prefix="/api/plugins/autorouter")
    with TestClient(app) as c:
        yield c


def _pref(client):
    return client.get("/api/plugins/autorouter/models/preference")


def _toggle(client, toggles, base=None):
    base = base if base is not None else _pref(client).json()["preference_hash"]
    return client.post("/api/plugins/autorouter/models/preference",
                       json={"toggles": toggles, "base": base})


def test_preference_read_back_shape_and_counts(client, workspace):
    r = _pref(client)
    assert r.status_code == 200
    body = r.json()
    assert body["available"] is True
    assert body["catalog_size"] == workspace["seed_rows"] + 1
    assert body["allowlist_mode"] is False
    assert body["enabled_count"] == body["catalog_size"]
    assert body["disabled_count"] == 0
    assert "preference_hash" in body and len(body["preference_hash"]) == 64
    assert body["model_include"] == [] and body["model_exclude"] == []


def test_models_rows_carry_preference_and_eligibility(client, workspace):
    r = client.get("/api/plugins/autorouter/models?page=1&page_size=200")
    assert r.status_code == 200
    body = r.json()
    assert body["preference"]["allowlist_mode"] is False
    for row in body["models"]:
        assert row["user_preference"] == "on"
    paid = [row for row in body["models"] if row["cost_tier"] == "paid"]
    assert paid, "fixture must contain paid rows"
    for row in paid:
        assert row["eligible"] is False


def test_models_preference_filter_off(client, workspace):
    base = _pref(client).json()["preference_hash"]
    toggles = [{"provider": "groq", "model": "model-00", "enabled": False},
               {"provider": "gemini", "model": "model-00", "enabled": False}]
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": toggles, "base": base})
    assert r.status_code == 200
    off = client.get("/api/plugins/autorouter/models?preference=off&page_size=200")
    assert off.status_code == 200
    pairs = {(m["provider"], m["model"]) for m in off.json()["models"]}
    assert ("groq", "model-00") in pairs
    assert ("gemini", "model-00") in pairs
    on = client.get("/api/plugins/autorouter/models?preference=on&page_size=200")
    assert ("groq", "model-00") not in {(m["provider"], m["model"]) for m in on.json()["models"]}


def test_toggle_off_enable_roundtrip_unrestricted(client, workspace):
    base = _pref(client).json()["preference_hash"]
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [{"provider": "groq", "model": "model-00", "enabled": False}],
                          "base": base})
    assert r.status_code == 200
    body = r.json()
    assert body["applied"]["changed"] is True
    assert "groq/model-00" in body["model_exclude"]
    base2 = body["preference_hash"]
    row = next(m for m in client.get("/api/plugins/autorouter/models?page_size=200&preference=off").json()["models"]
               if (m["provider"], m["model"]) == ("groq", "model-00"))
    assert row["user_preference"] == "off"
    assert row["preference_note"] == "disabled by you"

    r2 = client.post("/api/plugins/autorouter/models/preference",
                     json={"toggles": [{"provider": "groq", "model": "model-00", "enabled": True}],
                           "base": base2})
    assert r2.status_code == 200
    body2 = r2.json()
    assert "groq/model-00" not in body2["model_exclude"]
    row2 = next(m for m in client.get("/api/plugins/autorouter/models?page_size=200").json()["models"]
                if (m["provider"], m["model"]) == ("groq", "model-00"))
    assert row2["user_preference"] == "on"


def test_toggle_on_never_makes_paid_model_eligible(client, workspace):
    r = client.get("/api/plugins/autorouter/models?page_size=200").json()
    paid = next(m for m in r["models"] if m["cost_tier"] == "paid")
    assert paid["eligible"] is False
    key = _pref(client).json()["preference_hash"]
    r2 = client.post("/api/plugins/autorouter/models/preference",
                     json={"toggles": [{"provider": paid["provider"], "model": paid["model"], "enabled": True}],
                           "base": key})
    assert r2.status_code == 200
    after = client.get("/api/plugins/autorouter/models?provider=" + paid["provider"] + "&query=" + paid["model"]).json()
    row = next(m for m in after["models"] if (m["provider"], m["model"]) == (paid["provider"], paid["model"]))
    assert row["eligible"] is False
    assert "cost_not_verified_free" in (row.get("reason_codes") or [])


def test_stale_base_is_409_and_never_clobbers_concurrent_writer(client, workspace):
    base = _pref(client).json()["preference_hash"]
    first = client.post("/api/plugins/autorouter/models/preference",
                        json={"toggles": [{"provider": "groq", "model": "model-00", "enabled": False}],
                              "base": base})
    assert first.status_code == 200
    # A second writer still holding the original base must be refused.
    second = client.post("/api/plugins/autorouter/models/preference",
                         json={"toggles": [{"provider": "gemini", "model": "model-00", "enabled": False}],
                               "base": base})
    assert second.status_code == 409
    detail = second.json()["detail"]
    assert detail["stale"] is True
    assert "groq/model-00" in detail["model_exclude"]
    # Rebasing on the current state succeeds and preserves both edits.
    rebased = _pref(client).json()["preference_hash"]
    third = client.post("/api/plugins/autorouter/models/preference",
                        json={"toggles": [{"provider": "gemini", "model": "model-00", "enabled": False}],
                              "base": rebased})
    assert third.status_code == 200
    assert set(third.json()["model_exclude"]) >= {"groq/model-00", "gemini/model-00"}


def test_partial_toggle_batch_applies_atomically_on_invalid_member(client, workspace):
    base = _pref(client).json()["preference_hash"]
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [{"provider": "groq", "model": "model-00", "enabled": False},
                                      {"provider": "BAD PROVIDER!", "model": "x y", "enabled": False}],
                          "base": base})
    assert r.status_code == 400
    assert "groq/model-00" not in _pref(client).json()["model_exclude"]


def test_max_model_keys_enforced_and_nothing_written(client, workspace):
    # Pre-fill the exclude list to the cap, then one more toggle must fail with 400.
    workspace["values"]["model_exclude"] = [f"seedprov/prefilled-{i:03d}" for i in range(512)]
    base = _pref(client).json()["preference_hash"]
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [{"provider": "groq", "model": "model-00", "enabled": False}],
                          "base": base})
    assert r.status_code == 400
    assert _pref(client).json()["model_exclude"] == [f"seedprov/prefilled-{i:03d}" for i in range(512)]


def test_allowlist_last_off_yields_none_never_unrestricted(client, workspace):
    _toggle(client, [{"provider": "groq", "model": "model-00", "enabled": True}])
    body = _pref(client).json()
    assert body["allowlist_mode"] is False
    _toggle(client, [{"provider": "groq", "model": "model-01", "enabled": False}])
    body = _pref(client).json()
    assert body["model_exclude"] == ["groq/model-01"]
    # Seed allowlist mode with one allowed model through the fold path.
    _sr = _load_state_reader()
    _sr.write_settings({"model_include": ["groq/model-02"]})
    body = _pref(client).json()
    assert body["allowlist_mode"] is True
    assert body["mode"] == "allowlist"
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [{"provider": "groq", "model": "model-02", "enabled": False}],
                          "base": body["preference_hash"]})
    assert r.status_code == 200
    body = r.json()
    assert body["mode"] == "none"
    assert body["model_include"] == []
    # Critically: unrestricted was NOT restored.
    assert body["allowlist_mode"] is False
    assert body["enabled_count"] == 0
    rows = client.get("/api/plugins/autorouter/models?page_size=200").json()
    assert all(m["user_preference"] == "off" for m in rows["models"])
    # Re-enabling the previously disabled model restores allowlist with just it.
    r2 = client.post("/api/plugins/autorouter/models/preference",
                     json={"toggles": [{"provider": "groq", "model": "model-02", "enabled": True}],
                           "base": body["preference_hash"]})
    assert r2.status_code == 200
    assert r2.json()["mode"] == "allowlist"
    assert r2.json()["model_include"] == ["groq/model-02"]


def test_reset_unrestricted_is_explicit_and_clears_lists(client, workspace):
    _sr = _load_state_reader()
    _sr.write_settings({"model_include": ["groq/model-02"]})
    body = _pref(client).json()
    client.post("/api/plugins/autorouter/models/preference",
                json={"toggles": [{"provider": "groq", "model": "model-02", "enabled": False}],
                      "base": body["preference_hash"]})
    body = _pref(client).json()
    assert body["mode"] == "none"
    # A stale base is still a 409 for reset — it is not an implicit escape hatch.
    stale = client.post("/api/plugins/autorouter/models/preference",
                        json={"reset": "unrestricted", "base": "deadbeef"})
    assert stale.status_code == 409
    assert _pref(client).json()["mode"] == "none"
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"reset": "unrestricted", "base": body["preference_hash"]})
    assert r.status_code == 200
    assert r.json()["mode"] == "unrestricted"
    assert r.json()["model_include"] == [] and r.json()["model_exclude"] == []
    # Reset cannot be combined with toggles.
    r2 = client.post("/api/plugins/autorouter/models/preference",
                     json={"reset": "unrestricted",
                           "toggles": [{"provider": "groq", "model": "model-00", "enabled": True}],
                           "base": _pref(client).json()["preference_hash"]})
    assert r2.status_code == 400
    # Unsupported reset value is rejected.
    r3 = client.post("/api/plugins/autorouter/models/preference",
                     json={"reset": "everything", "base": _pref(client).json()["preference_hash"]})
    assert r3.status_code == 400


def test_batch_last_wins_for_same_pair(client, workspace):
    base = _pref(client).json()["preference_hash"]
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [{"provider": "groq", "model": "model-00", "enabled": False},
                                      {"provider": "groq", "model": "model-00", "enabled": True}],
                          "base": base})
    assert r.status_code == 200
    assert "groq/model-00" not in r.json()["model_exclude"]


def test_empty_toggle_batch_rejected(client, workspace):
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [], "base": _pref(client).json()["preference_hash"]})
    assert r.status_code == 400


def test_no_credential_material_in_preference_payload(client, workspace):
    body = _pref(client).json()
    dumped = json.dumps(body)
    for needle in ("api_key", "sk-", "token", "Bearer "):
        assert needle not in dumped


def test_toggle_migrates_legacy_lists_and_preserves_them_verbatim(client, workspace):
    workspace["values"]["model_include"] = ["nvidia/nvidia-free", "legacy-cruft"] if False else ["nvidia/nvidia-free"]
    workspace["values"]["model_exclude"] = ["openrouter/legacy-excluded"]
    base = _pref(client).json()["preference_hash"]
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [{"provider": "openrouter", "model": "model-00", "enabled": True}],
                          "base": base})
    assert r.status_code == 200
    # Legacy keys are preserved verbatim on disk; the blob is authoritative.
    assert workspace["values"]["model_include"] == ["nvidia/nvidia-free"]
    assert workspace["values"]["model_exclude"] == ["openrouter/legacy-excluded"]
    assert workspace["values"]["model_preference"]["mode"] == "allowlist"
    assert workspace["values"]["model_preference"]["include"] == ["nvidia/nvidia-free", "openrouter/model-00"]


def test_unrecognized_legacy_entry_refuses_toggle_and_stays_unchanged(client, workspace):
    workspace["values"]["model_include"] = ["nvidia/nvidia-free"]
    workspace["values"]["model_exclude"] = ["not a valid key!!"]
    before = _pref(client).json()["preference_hash"]
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [{"provider": "nvidia", "model": "model-00", "enabled": True}],
                          "base": before})
    assert r.status_code == 400
    assert "unrecognized" in json.dumps(r.json())
    assert workspace["values"]["model_exclude"] == ["not a valid key!!"]
    assert "model_preference" not in workspace["values"]


def test_raw_settings_edit_of_include_folds_and_preserves_exclusions(client, workspace):
    _sr = _load_state_reader()
    _sr.write_settings({"model_exclude": ["groq/model-00"]})   # seed some state
    result = _sr.write_settings({"model_include": ["groq/model-01", "groq/model-02"]})
    values = workspace["values"]
    assert values["model_preference"]["mode"] == "allowlist"
    assert values["model_preference"]["include"] == ["groq/model-01", "groq/model-02"]
    # The exclude side persisted earlier is retained, not dropped.
    assert values["model_preference"]["exclude"] == ["groq/model-00"]


def test_restart_persistence(client, workspace):
    base = _pref(client).json()["preference_hash"]
    client.post("/api/plugins/autorouter/models/preference",
                json={"toggles": [{"provider": "nvidia", "model": "model-00", "enabled": False}],
                      "base": base})
    # Fresh reader sees persisted values
    body = _pref(client).json()
    assert "nvidia/model-00" in body["model_exclude"]
    assert body["preference_hash"] != base


def test_preference_write_failure_writes_nothing_and_reports_accurately(client, workspace, monkeypatch):
    import hermes_cli.plugins_state as psr

    calls = []

    def record_save(plugin_id, segments, value):
        calls.append(".".join(segments))
        if "model_preference" in segments:
            raise RuntimeError("simulated store failure")
        workspace["values"][".".join(segments)] = copy.deepcopy(value)

    monkeypatch.setattr(psr, "save_plugin_setting", record_save)
    base = _pref(client).json()["preference_hash"]
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [{"provider": "groq", "model": "model-03", "enabled": False}],
                          "base": base})
    assert r.status_code == 503
    detail = r.json()["detail"]
    assert detail["partial"] is False
    assert detail["saved"] == []
    assert "model_preference" in detail["failed"]
    # The single-key blob is all-or-nothing: the previous state is intact.
    assert "model_preference" not in workspace["values"]
    assert workspace["values"]["model_exclude"] == []


def test_profile_exclude_shows_profile_reason(client, workspace):
    rps_mod = _load_state_reader()._load_submodule("profiles")
    state_mod = _load_state_reader()._load_submodule("state")
    profiles = state_mod.RoutingProfileStore(workspace["values"]["state_dir"])
    prof = profiles.create({"name": "Nvidia Only", "ranking_policy": "auto",
                            "providers": ["nvidia"], "min_context": 8192,
                            "requires_tools": True, "model_exclude": ["nvidia/model-00"]})
    profiles.set_active(prof["id"])
    body = _pref(client).json()
    assert body["profile"] == "Nvidia Only"
    rows = client.get("/api/plugins/autorouter/models?page_size=200").json()["models"]
    row = next(m for m in rows if (m["provider"], m["model"]) == ("nvidia", "model-00"))
    assert row["blocked_by_profile"] == "Nvidia Only"
    assert row["preference_note"] == "disabled by routing profile 'Nvidia Only'"


def test_global_exclude_still_applies_when_profile_allows(client, workspace):
    state_mod = _load_state_reader()._load_submodule("state")
    profiles = state_mod.RoutingProfileStore(workspace["values"]["state_dir"])
    prof = profiles.create({"name": "Broad", "ranking_policy": "auto",
                            "providers": ["nvidia", "openrouter"], "min_context": 8192,
                            "requires_tools": True})
    profiles.set_active(prof["id"])
    base = _pref(client).json()["preference_hash"]
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [{"provider": "openrouter", "model": "model-00", "enabled": False}],
                          "base": base})
    assert r.status_code == 200
    rows = client.get("/api/plugins/autorouter/models?page_size=200&query=model-00").json()["models"]
    row = next(m for m in rows if (m["provider"], m["model"]) == ("openrouter", "model-00"))
    assert row["user_preference"] == "off"
    assert row["blocked_by_profile"] is None


def test_accross_key_toggle_persists_as_one_atomic_key(client, workspace):
    saved = workspace["saved"]
    base = _pref(client).json()["preference_hash"]
    r = client.post("/api/plugins/autorouter/models/preference",
                    json={"toggles": [{"provider": "groq", "model": "model-00", "enabled": False},
                                      {"provider": "gemini", "model": "model-00", "enabled": False}],
                          "base": base})
    assert r.status_code == 200
    keys = [key for key, _ in saved]
    # Exactly one persistence call, carrying both lists plus mode as one value.
    assert keys == ["model_preference"]
    blob = workspace["values"]["model_preference"]
    assert blob["mode"] == "unrestricted"
    assert blob["exclude"] == ["gemini/model-00", "groq/model-00"]
    assert blob["include"] == []


def test_bulk_disable_page_then_zero_enabled(client, workspace):
    base = _pref(client).json()["preference_hash"]
    rows = client.get("/api/plugins/autorouter/models?page_size=200").json()["models"]
    for row in rows:
        r = client.post("/api/plugins/autorouter/models/preference",
                        json={"toggles": [{"provider": row["provider"], "model": row["model"],
                                           "enabled": False}],
                              "base": _pref(client).json()["preference_hash"]})
        assert r.status_code == 200
    body = _pref(client).json()
    assert body["disabled_count"] == body["catalog_size"]
    assert body["enabled_count"] == 0
