"""Routing profiles (issue #100): contract, CRUD, migration, preview, isolation."""
import copy
import json
import sqlite3
import threading
import time

import pytest

from autorouter.autorouter_core.providers import registry as _registry


@pytest.fixture(autouse=True)
def _pin_offline_host_registry(monkeypatch):
    """Routing profiles fail closed on a host that recognizes nothing."""
    monkeypatch.setenv("AUTOROUTER_REGISTRY_OFFLINE", "1")


from autorouter.autorouter_core.routing import profiles as profiles_mod
from autorouter.autorouter_core.routing.preview import preview_profile
from autorouter.autorouter_core.storage.state import SCHEMA_VERSION, StateStore, RoutingProfileStore
from .verified_fixture import seed_verified_model


# --------------------------------------------------------------------------
# Contract validation
# --------------------------------------------------------------------------

def test_defaults_and_roundtrip():
    p = profiles_mod.validate_profile({"name": "Dispatch"})
    assert p["ranking_policy"] == "auto" and p["providers"] == []
    assert p["min_context"] == 8192 and p["verified_free_only"] is True
    assert p["fallback_policy"] == "refuse" and p["health"]["respect_failures"] is True


def test_unknown_keys_rejected():
    with pytest.raises(profiles_mod.ProfileError) as exc:
        profiles_mod.validate_profile({"name": "x", "bogus": 1})
    assert exc.value.code == "profile_invalid"


@pytest.mark.parametrize("name", ["", "  ", "x" * 81, "bad\nname"])
def test_name_validation(name):
    with pytest.raises(profiles_mod.ProfileError):
        profiles_mod.validate_profile({"name": name})


def test_ranking_policy_membership():
    with pytest.raises(profiles_mod.ProfileError) as exc:
        profiles_mod.validate_profile({"name": "x", "ranking_policy": "smartestx"})
    assert "ranking_policy" in exc.value.fields
    assert profiles_mod.validate_profile({"name": "x", "ranking_policy": "coding"})["ranking_policy"] == "coding"


def test_providers_unsupported_rejected():
    with pytest.raises(profiles_mod.ProfileError) as exc:
        profiles_mod.validate_profile({"name": "x", "providers": ["zai"]})
    assert exc.value.fields["providers"].startswith("unsupported provider")


def test_model_include_requires_provider_model_and_charset():
    with pytest.raises(profiles_mod.ProfileError) as exc:
        profiles_mod.validate_profile({"name": "x", "model_include": ["not-a-ref"]})
    assert "model_include" in exc.value.fields
    with pytest.raises(profiles_mod.ProfileError):
        profiles_mod.validate_profile({"name": "x", "model_include": ["zai/model"]})
    with pytest.raises(profiles_mod.ProfileError):
        profiles_mod.validate_profile({"name": "x", "model_exclude": ["nvidia/sk-abc123abc123abc123abc123"]})


def test_min_context_bounds_and_bool_rejected():
    with pytest.raises(profiles_mod.ProfileError):
        profiles_mod.validate_profile({"name": "x", "min_context": 1})
    with pytest.raises(profiles_mod.ProfileError):
        profiles_mod.validate_profile({"name": "x", "min_context": True})
    assert profiles_mod.validate_profile({"name": "x", "min_context": 2048})["min_context"] == 2048


def test_health_hard_gates_cannot_be_disabled():
    with pytest.raises(profiles_mod.ProfileError) as exc:
        profiles_mod.validate_profile({"name": "x", "health": {"respect_cooldowns": False}})
    assert "health.respect_cooldowns" in exc.value.fields
    with pytest.raises(profiles_mod.ProfileError):
        profiles_mod.validate_profile({"name": "x", "health": {"bogus": True}})


def test_fallback_policy_refuse_only_and_free_only_mandatory():
    with pytest.raises(profiles_mod.ProfileError):
        profiles_mod.validate_profile({"name": "x", "fallback_policy": "automatic"})
    with pytest.raises(profiles_mod.ProfileError):
        profiles_mod.validate_profile({"name": "x", "verified_free_only": False})


# --------------------------------------------------------------------------
# CRUD
# --------------------------------------------------------------------------

def test_crud_lifecycle(tmp_path):
    store = RoutingProfileStore(tmp_path)
    created = store.create({"name": "Alpha", "ranking_policy": "coding",
                            "providers": ["nvidia"], "min_context": 16000, "requires_tools": True})
    assert created["id"].startswith("rp_")
    assert created["requires_tools"] is True and created["providers"] == ["nvidia"]

    listed = store.list()
    assert [p["id"] for p in listed] == [created["id"]]

    updated = store.update(created["id"], {"name": "Alpha 2", "min_context": 32000})
    assert updated["name"] == "Alpha 2" and updated["min_context"] == 32000
    assert updated["created_at"] == created["created_at"] and updated["updated_at"] > created["updated_at"]

    dup = store.duplicate(created["id"])
    assert dup["id"] != created["id"] and dup["name"].startswith("Alpha 2 copy")
    assert dup["ranking_policy"] == updated["ranking_policy"]

    outcome = store.delete(created["id"])
    assert outcome == {"deleted": True, "deactivated": False}
    assert store.get(created["id"]) is None


def test_name_uniqueness_case_insensitive(tmp_path):
    store = RoutingProfileStore(tmp_path)
    store.create({"name": "Alpha"})
    with pytest.raises(profiles_mod.ProfileError) as exc:
        store.create({"name": "alpha"})
    assert exc.value.code == "profile_name_conflict"
    with pytest.raises(profiles_mod.ProfileError) as exc:
        other = store.create({"name": "Beta"})
        store.update(other["id"], {"name": "ALPHA"})
    assert exc.value.code == "profile_name_conflict"


def test_delete_clears_active_profile(tmp_path):
    store = RoutingProfileStore(tmp_path)
    created = store.create({"name": "Active"})
    store.set_active(created["id"])
    assert store.active_id() == created["id"]
    outcome = store.delete(created["id"])
    assert outcome["deactivated"] is True
    assert store.active_id() is None


def test_activate_unknown_profile_fails(tmp_path):
    store = RoutingProfileStore(tmp_path)
    with pytest.raises(profiles_mod.ProfileError) as exc:
        store.set_active("rp_missing")
    assert exc.value.code == "profile_not_found"


def test_duplicate_generates_unique_names(tmp_path):
    store = RoutingProfileStore(tmp_path)
    created = store.create({"name": "Copy"})
    first = store.duplicate(created["id"])
    second = store.duplicate(created["id"])
    assert first["name"] != second["name"]


def test_concurrent_creates_get_distinct_ids(tmp_path):
    store = RoutingProfileStore(tmp_path)
    results: list[str] = []
    lock = threading.Lock()

    def worker(i):
        p = store.create({"name": f"Concurrent {i}"})
        with lock:
            results.append(p["id"])

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(results) == 8
    assert len(set(results)) == 8
    assert len(store.list()) == 8


def test_restart_persistence(tmp_path):
    store = RoutingProfileStore(tmp_path)
    created = store.create({"name": "Persist", "ranking_policy": "reliable"})
    store.set_active(created["id"])
    reopened = RoutingProfileStore(tmp_path)
    assert reopened.get(created["id"])["name"] == "Persist"
    assert reopened.active_id() == created["id"]


# --------------------------------------------------------------------------
# Migration v5 -> v6
# --------------------------------------------------------------------------

def _preseed_v5_database(db_path):
    conn = sqlite3.connect(db_path)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS catalog(provider TEXT NOT NULL, model TEXT NOT NULL,
            context_length INTEGER, capabilities TEXT, cost_tier TEXT, updated_at REAL NOT NULL,
            PRIMARY KEY(provider, model));
        CREATE TABLE IF NOT EXISTS decisions(id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL NOT NULL, policy TEXT, provider TEXT, model TEXT, reason TEXT, candidates INTEGER);
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        INSERT INTO meta(key, value) VALUES('schema_version', '5');
        INSERT INTO catalog(provider, model, context_length, capabilities, cost_tier, updated_at)
            VALUES('nvidia', 'retained-model', 16000, '{}', 'free', 42);
        INSERT INTO decisions(ts, policy, provider, model, reason, candidates)
            VALUES(1, 'auto', 'nvidia', 'retained-model', 'selected', 3);
    """)
    conn.close()


def test_migration_from_v5_preserves_data_and_creates_table(tmp_path):
    db_path = tmp_path / "autorouter.db"
    _preseed_v5_database(db_path)
    store = StateStore(tmp_path)
    conn = sqlite3.connect(db_path)
    version = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]
    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    catalog = conn.execute("SELECT COUNT(*) FROM catalog").fetchone()[0]
    decisions = conn.execute("SELECT COUNT(*) FROM decisions").fetchone()[0]
    conn.close()
    assert version == str(SCHEMA_VERSION) == "6"
    assert "routing_profiles" in tables
    assert catalog == 1 and decisions == 1


def test_migration_is_idempotent(tmp_path):
    store = StateStore(tmp_path)
    first = store._connect()
    first.close()
    again = StateStore(tmp_path)
    conn = again._connect()
    version = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]
    conn.close()
    assert version == "6"


# --------------------------------------------------------------------------
# Preview
# --------------------------------------------------------------------------

def test_preview_selects_free_verified_model(tmp_path):
    store = StateStore(tmp_path)
    seed_verified_model(store, 'nvidia', 'free-a', 16000, {'tools': True}, 'free')
    seed_verified_model(store, 'nvidia', 'paid-b', 16000, {'tools': True}, 'paid')
    profile = profiles_mod.validate_profile({"name": "P", "providers": ["nvidia"]})
    result = preview_profile(store.db_path, profile, authorized_providers=["nvidia"], now=time.time())
    assert result["chosen"]["model"] == "free-a"
    assert result["eligible_count"] == 1


def test_preview_respects_provider_allowlist(tmp_path):
    store = StateStore(tmp_path)
    seed_verified_model(store, 'nvidia', 'free-a', 16000, {'tools': True}, 'free')
    seed_verified_model(store, 'openrouter', 'free-b', 16000, {'tools': True}, 'free')
    profile = profiles_mod.validate_profile({"name": "P", "providers": ["openrouter"]})
    result = preview_profile(store.db_path, profile, authorized_providers=["nvidia", "openrouter"], now=time.time())
    assert result["chosen"]["provider"] == "openrouter"
    profile_nvidia = profiles_mod.validate_profile({"name": "P2", "providers": ["nvidia"]})
    result = preview_profile(store.db_path, profile_nvidia, authorized_providers=["openrouter"], now=time.time())
    assert result["eligible_count"] == 0
    assert result["chosen"] is None
    assert result["no_match"] in ("no_eligible_model", "profile_no_authorized_providers")


def test_preview_include_and_exclude(tmp_path):
    store = StateStore(tmp_path)
    seed_verified_model(store, 'nvidia', 'alpha', 16000, {'tools': True}, 'free')
    seed_verified_model(store, 'nvidia', 'beta', 16000, {'tools': True}, 'free')
    profile = profiles_mod.validate_profile({"name": "P", "providers": ["nvidia"],
                                             "model_include": ["nvidia/beta"]})
    result = preview_profile(store.db_path, profile, authorized_providers=["nvidia"], now=time.time())
    assert result["chosen"]["model"] == "beta"
    profile2 = profiles_mod.validate_profile({"name": "P2", "providers": ["nvidia"],
                                              "model_exclude": ["nvidia/beta"]})
    result = preview_profile(store.db_path, profile2, authorized_providers=["nvidia"], now=time.time())
    assert result["chosen"]["model"] == "alpha"


def test_preview_requires_tools(tmp_path):
    store = StateStore(tmp_path)
    seed_verified_model(store, 'nvidia', 'tools-model', 16000, {'tools': True}, 'free')
    seed_verified_model(store, 'nvidia', 'bare-model', 16000, {'tools': False}, 'free')
    profile = profiles_mod.validate_profile({"name": "P", "providers": ["nvidia"], "requires_tools": True})
    result = preview_profile(store.db_path, profile, authorized_providers=["nvidia"], now=time.time())
    assert result["chosen"]["model"] == "tools-model"
    assert any(row["model"] == "bare-model" for row in result["excluded"])


def test_preview_no_eligible_when_catalog_empty(tmp_path):
    store = StateStore(tmp_path)
    profile = profiles_mod.validate_profile({"name": "P", "providers": ["nvidia"]})
    result = preview_profile(store.db_path, profile, authorized_providers=["nvidia"], now=time.time())
    assert result["chosen"] is None
    assert result["eligible_count"] == 0
    assert result["excluded"] == []


def test_preview_never_writes(tmp_path, monkeypatch):
    store = StateStore(tmp_path)
    seed_verified_model(store, 'nvidia', 'free-a', 16000, {'tools': True}, 'free')
    before = (tmp_path / "autorouter.db").read_bytes()
    profile = profiles_mod.validate_profile({"name": "P", "providers": ["nvidia"]})
    result = preview_profile(store.db_path, profile, authorized_providers=["nvidia"], now=time.time())
    after = (tmp_path / "autorouter.db").read_bytes()
    assert before == after
    assert result["chosen"] is not None


# --------------------------------------------------------------------------
# Narrow-only merge with global settings
# --------------------------------------------------------------------------

def _merge(name, global_settings, profile_overrides, providers=None):
    prof = profiles_mod.validate_profile({"name": name, **profile_overrides})
    merged, err = profiles_mod.merge_global_and_profile(
        global_settings, prof, authorized_providers=(providers or ["nvidia", "openrouter"]))
    return merged, err


def test_merge_profile_narrows_never_relaxes(tmp_path):
    store = RoutingProfileStore(tmp_path)
    global_settings = {"policy": "auto", "min_context": 8192, "requires_tools": False,
                       "cooldown_seconds": 60,
                       "model_include_pairs": [], "model_exclude_pairs": []}
    merged, err = _merge("narrow", global_settings,
                         {"ranking_policy": "reliable", "min_context": 32768,
                          "requires_tools": True, "providers": ["openrouter"]})
    assert err is None
    assert merged["min_context"] == 32768          # max(8192, 32768)
    assert merged["requires_tools"] is True        # profile is stricter
    assert merged["policy"] == "reliable"          # ordering preference allowed
    assert merged["providers"] == ["openrouter"]   # intersection


def test_merge_cannot_relax_global_tools_or_context():
    global_settings = {"policy": "auto", "min_context": 200000, "requires_tools": True,
                       "cooldown_seconds": 60,
                       "model_include_pairs": [], "model_exclude_pairs": []}
    merged, err = _merge("relaxy", global_settings,
                         {"ranking_policy": "fastest", "min_context": 8192,
                          "requires_tools": False, "providers": ["nvidia"]})
    assert err is None
    assert merged["min_context"] == 200000         # global wins
    assert merged["requires_tools"] is True        # global wins


def test_merge_exclude_is_union():
    global_settings = {"policy": "auto", "min_context": 8192, "requires_tools": False,
                       "model_include_pairs": [],
                       "model_exclude_pairs": [("nvidia", "excluded-by-global")]}
    merged, err = _merge("ex", global_settings,
                         {"providers": ["nvidia"],
                          "model_exclude": ["nvidia/excluded-by-profile"]})
    assert err is None
    pair = set(merged["model_exclude_pairs"])
    assert ("nvidia", "excluded-by-global") in pair
    assert ("nvidia", "excluded-by-profile") in pair


def test_merge_include_intersects_when_both_sides_set():
    global_settings = {"policy": "auto", "min_context": 8192, "requires_tools": False,
                       "cooldown_seconds": 60,
                       "model_include_pairs": [("nvidia", "a-model"), ("nvidia", "b-model")],
                       "model_exclude_pairs": []}
    merged, err = _merge("inc", global_settings,
                         {"providers": ["nvidia"],
                          "model_include": ["nvidia/b-model", "nvidia/c-model"]})
    assert err is None
    assert merged["model_include_pairs"] == [("nvidia", "b-model")]


def test_merge_include_from_profile_only_when_global_unset():
    global_settings = {"policy": "auto", "min_context": 8192, "requires_tools": False,
                       "cooldown_seconds": 60,
                       "model_include_pairs": [], "model_exclude_pairs": []}
    merged, err = _merge("inc2", global_settings,
                         {"providers": ["nvidia"],
                          "model_include": ["nvidia/only-one"]})
    assert err is None
    assert merged["model_include_pairs"] == [("nvidia", "only-one")]


def test_merge_include_from_global_only_when_profile_unset():
    global_settings = {"policy": "auto", "min_context": 8192, "requires_tools": False,
                       "cooldown_seconds": 60,
                       "model_include_pairs": [("nvidia", "kept")],
                       "model_exclude_pairs": []}
    merged, err = _merge("inc3", global_settings,
                         {"providers": ["nvidia"]})
    assert err is None
    assert merged["model_include_pairs"] == [("nvidia", "kept")]


def test_merge_fails_closed_on_empty_provider_intersection():
    global_settings = {"policy": "auto", "min_context": 8192, "requires_tools": False,
                       "cooldown_seconds": 60,
                       "model_include_pairs": [], "model_exclude_pairs": []}
    merged, err = _merge("no-overlap", global_settings,
                         {"providers": ["openrouter"]},
                         providers=["nvidia"])
    assert err == "active profile authorizes no provider that is enabled for AutoRouter"
    assert merged == {}


def test_merge_always_preserves_free_only_and_no_fallback():
    """'refuse' fallback is the only fallback; verified-free is mandatory."""
    for ranking in profiles_mod.RANKING_POLICIES:
        global_settings = {"policy": "auto", "min_context": 8192, "requires_tools": False,
                           "cooldown_seconds": 60,
                           "model_include_pairs": [], "model_exclude_pairs": []}
        merged, err = _merge(f"p-{ranking}", global_settings,
                             {"ranking_policy": ranking, "providers": ["nvidia"]})
        assert err is None and merged["policy"] == ranking


# --------------------------------------------------------------------------
# Stored-profile revalidation
# --------------------------------------------------------------------------

def test_validate_stored_profile_accepts_roundtrip(tmp_path):
    store = RoutingProfileStore(tmp_path)
    created = store.create({"name": "stored", "ranking_policy": "coding"})
    row = store.get(created["id"])
    assert row is not None
    clean = profiles_mod.validate_stored_profile(row)
    assert clean["id"] == created["id"] and clean["ranking_policy"] == "coding"


def test_validate_stored_profile_rejects_corrupt_rows():
    good = profiles_mod.validate_stored_profile(
        dict(id="rp_x", name="x", ranking_policy="auto", providers=["nvidia"],
             model_include=[], model_exclude=[], min_context=8192,
             requires_tools=False, health={"respect_failures": True, "respect_cooldowns": True, "require_observed": False},
             task_tags=[], fallback_policy="refuse", created_at=1.0, updated_at=2.0))
    assert good["name"] == "x"
    with pytest.raises(profiles_mod.ProfileError):
        profiles_mod.validate_stored_profile({"id": "rp_x"})  # missing everything


def test_active_default_is_fail_closed_when_row_deleted_or_corrupt(tmp_path):
    store = RoutingProfileStore(tmp_path)
    prof = store.create({"name": "Backdoor", "providers": ["nvidia"]})
    store.set_active(prof["id"])
    # Corrupt the stored row (simulating manual surgery / bad restore).
    with store.store._connect() as db:
        db.execute("UPDATE routing_profiles SET ranking_policy = 'YOLO' WHERE id = ?", (prof["id"],))
    loaded, err = store.store and None or store, None
    from autorouter.autorouter_core.storage.state import active_routing_profile
    profile, error = active_routing_profile(store.store)
    assert profile is None and "corrupt" in error


# --------------------------------------------------------------------------
# Public scope annotation
# --------------------------------------------------------------------------

def test_public_active_annotates_global_default_scope():
    out = profiles_mod.public_active({
        "id": "rp_abcd1234", "name": "Nightly", "ranking_policy": "coding",
        "providers": ["nvidia"], "min_context": 32768, "requires_tools": True,
    })
    assert out["scope"] == "global_default"
    assert "global Hermes default model" in out["scope_note"]


def test_public_active_empty():
    assert profiles_mod.public_active(None) is None
