import os
from unittest.mock import patch, MagicMock

from autorouter.autorouter_core.discovery import discovery as dc
from autorouter.autorouter_core.storage import state as st


class _Profile:
    env_vars = ("NVIDIA_API_KEY",)
    fallback_models = ("nvidia/llama-3.1-nemotron-70b-instruct",)
    supports_vision = False
    base_url = "https://integrate.api.nvidia.com/v1"

    def fetch_models(self, api_key=None, base_url=None, timeout=8.0):
        if api_key == "test-key":
            return ["nvidia/model-a", "nvidia/model-b"]
        return None


def test_discover_provider_success(monkeypatch, tmp_path):
    monkeypatch.setenv("NVIDIA_API_KEY", "test-key")
    import providers
    monkeypatch.setattr(providers, "get_provider_profile", lambda name: _Profile())
    res = dc.discover_provider("nvidia")
    assert len(res) == 2
    assert res[0]["model"] == "nvidia/model-a"


def test_discover_provider_failure_uses_fallback(monkeypatch):
    monkeypatch.delenv("NVIDIA_API_KEY", raising=False)
    import providers
    monkeypatch.setattr(providers, "get_provider_profile", lambda name: _Profile())
    res = dc.discover_provider("nvidia")
    # fetch_models returns None without key -> fallback_models used
    assert len(res) == 1
    assert res[0]["model"] == "nvidia/llama-3.1-nemotron-70b-instruct"


def test_discover_all_persists_and_lkg(tmp_path, monkeypatch):
    monkeypatch.setenv("NVIDIA_API_KEY", "test-key")
    import providers
    monkeypatch.setattr(providers, "get_provider_profile", lambda name: _Profile())
    store = st.StateStore(tmp_path / "state")
    out = dc.discover_all(["nvidia"], store=store)
    assert "nvidia" in out
    assert len(out["nvidia"]) == 2
    rows = store.get_catalog("nvidia")
    assert len(rows) == 2
    lkg = store.get_lkg()
    assert lkg is not None


def test_discover_all_failure_preserves_lkg(tmp_path, monkeypatch):
    # first populate lkg
    monkeypatch.setenv("NVIDIA_API_KEY", "test-key")
    import providers
    monkeypatch.setattr(providers, "get_provider_profile", lambda name: _Profile())
    store = st.StateStore(tmp_path / "state")
    dc.discover_all(["nvidia"], store=store)

    # now make discovery fail
    class _FailProfile(_Profile):
        def fetch_models(self, api_key=None, base_url=None, timeout=8.0):
            raise RuntimeError("boom")
    monkeypatch.setattr(providers, "get_provider_profile", lambda name: _FailProfile())
    monkeypatch.delenv("NVIDIA_API_KEY", raising=False)
    # discover_all should not crash; lkg remains
    try:
        dc.discover_all(["nvidia"], store=store)
    except Exception:
        pass
    lkg = store.get_lkg()
    assert lkg is not None
