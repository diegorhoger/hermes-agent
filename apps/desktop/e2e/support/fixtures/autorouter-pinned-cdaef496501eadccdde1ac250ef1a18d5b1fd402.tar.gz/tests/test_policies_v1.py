"""Shared launch policy fixture and real selection/tool/dashboard contract parity."""
import json
from pathlib import Path

import pytest
from autorouter.autorouter_core.configuration import policies
from autorouter.autorouter_core.integration import tools
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.storage import state
from tests.test_dashboard_state_reader import sr
from tests.test_dashboard_api import _load_plugin_api

NOW = 150.0
FIXTURE = Path(__file__).with_name('fixtures') / 'policies-v1.json'


def seeded(tmp_path):
    store = state.StateStore(tmp_path)
    fixture = json.loads(FIXTURE.read_text())['decision_fixture']
    for row in fixture['models']:
        model, cost, expires, supported = (row[k] for k in ('id', 'cost_tier', 'expires_at', 'tools'))
        store.upsert_catalog('nvidia', model, 16000, {'tools': supported}, cost)
        proof = dict(provider='nvidia', model=model, context_window=16000,
            tools='supported' if supported else 'unsupported', cost_tier=cost,
            metadata_source='controlled-test-fixture', retrieved_at=100, expires_at=expires)
        store.upsert_capability('nvidia', model, json.dumps(proof), retrieved_at=100, expires_at=expires)
    return store


def test_portable_policy_contract_fixture_is_current_and_versioned():
    fixture = json.loads(FIXTURE.read_text())
    assert fixture['contract'] == policies.contract()
    assert fixture['contract']['schema_version'] == 1
    assert fixture['contract']['cost_mode'] == 'verified-free-only'
    assert fixture['website_mapping'] == {'Free-first': 'auto', 'General': 'auto',
        'Coding': 'coding', 'Fast response': 'fastest', 'Reliability-first': 'reliable'}


@pytest.mark.parametrize('policy', ['auto', 'coding', 'fastest', 'reliable', 'general',
    'free-first', 'fast-response', 'reliability-first', 'smartest', 'priority'])
def test_same_fixture_has_identical_engine_tool_api_dashboard_decision(tmp_path, monkeypatch, policy):
    monkeypatch.setattr(router.time, 'time', lambda: NOW)
    store = seeded(tmp_path)
    values = dict(state_dir=str(tmp_path), providers=['nvidia'], policy=policy,
                  free_only=False, paid_authorized=True)
    r = router.Router(dict(values, store=store))
    config = dict(available=True, managed=False, values=values)
    monkeypatch.setattr(sr, 'read_plugin_config', lambda: config)
    monkeypatch.setattr(tools._rt(), 'get_router', lambda: r)
    expected = r.preview(now=NOW, requires_tools=False)
    actual = tools._select_handler({'requires_tools': False})
    assert actual['decision'] == expected
    assert actual['model'] == expected['chosen']['model'] == json.loads(FIXTURE.read_text())['decision_fixture']['expected_model']
    assert sr.assemble_models(now=NOW)['preview'] == expected
    assert expected['policy_metadata'] == policies.resolve(policy)
    assert expected['cost_mode']=='verified-free-only'
    reasons = {row['model']: row['reason_codes'] for row in expected['considered']}
    assert all('cost_not_verified_free' in reasons[m] for m in ['paid', 'unknown', 'stale:free'])
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    api = _load_plugin_api()
    monkeypatch.setattr(api._sr, 'read_plugin_config', lambda: config)
    app = FastAPI()
    app.include_router(api.router, prefix='/api/plugins/autorouter')
    with TestClient(app) as client:
        response = client.get('/api/plugins/autorouter/models')
        settings = client.get('/api/plugins/autorouter/settings')
    assert response.status_code == settings.status_code == 200
    assert response.json()['preview'] == expected
    assert settings.json()['policy_contract'] == policies.contract()
    assert settings.json()['values']['free_only'] is True


@pytest.mark.parametrize('policy', ['auto', 'coding', 'fastest', 'reliable'])
def test_tool_context_and_strict_constraints_compose_with_every_policy(tmp_path, monkeypatch, policy):
    monkeypatch.setattr(router.time, 'time', lambda: NOW)
    r = router.Router(dict(store=seeded(tmp_path), policy=policy, providers=['nvidia']))
    preview = r.preview(requires_tools=True, min_context=8192, now=NOW)
    no_tools = next(row for row in preview['considered'] if row['model']=='no-tools')
    assert no_tools['reason_codes']==['tools_unverified_or_unsupported']
    assert r.preview(min_context=20000, now=NOW)['chosen'] is None
    assert r.preview(strict_no_charge=True, now=NOW)['chosen'] is None
    assert r.select(min_context=20000) is None


@pytest.mark.parametrize('value', [None, {}, 1, '', 'paid', 'unknown-policy'])
def test_unknown_policy_has_no_selection_no_discovery_and_no_implicit_fallback(tmp_path, monkeypatch, value):
    def forbidden(*args, **kwargs):
        pytest.fail('invalid policy initiated discovery')
    import autorouter.autorouter_core.discovery.discovery as discovery
    monkeypatch.setattr(discovery, 'discover_all', forbidden)
    r = router.Router(dict(store=state.StateStore(tmp_path), policy=value))
    assert r.select() is None
    result = r.preview(now=NOW)
    assert result['chosen'] is None and result['no_match']=='policy_invalid'
    monkeypatch.setattr(tools._rt(), 'get_router', lambda: r)
    assert tools._select_handler({'policy': value}) == {'ok': False, 'error': 'invalid policy or constraints'}


def test_settings_cannot_disable_verified_free_only_and_accepts_policy_aliases():
    assert sr.validate_settings_updates({'free_only': False})[1]
    assert sr.validate_settings_updates({'free_only': True}) == ({'free_only': True}, [])
    assert sr.validate_settings_updates({'policy': 'reliability-first'}) == ({'policy': 'reliability-first'}, [])
