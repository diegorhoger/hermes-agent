"""Offline supported presence contract; never invokes host credential resolvers."""
import json
import os
from types import SimpleNamespace

import pytest
from autorouter.autorouter_core.providers import connections as contract
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.storage import state
from tests.test_dashboard_api import _load_plugin_api, state_dir, client


@pytest.fixture(autouse=True)
def _hermetic_host(monkeypatch):
    """Keep unit tests independent of the live Hermes installation:
    host seams are stubbed to deterministic local fakes, and the
    host-derived registry is pinned to the static six only."""
    from autorouter.autorouter_core.providers import registry as registry_mod
    monkeypatch.setattr(contract, '_host_env_present', lambda name: bool(os.environ.get(name)))
    monkeypatch.setattr(contract, '_host_explicit', lambda provider: False)
    monkeypatch.setattr(contract, '_host_pool_snapshot', lambda: {})
    monkeypatch.setattr(contract, '_host_suppressed', lambda provider: [])
    monkeypatch.setattr(contract, '_host_registered', lambda provider: True)
    monkeypatch.setattr(registry_mod, '_OVERRIDE', [])


@pytest.fixture
def configured():
    return {'available': True, 'managed': False, 'values': {'providers': ['nvidia','openrouter']}}


def test_supported_read_only_presence(configured, monkeypatch):
    import providers
    monkeypatch.setattr(providers, 'get_provider_profile', lambda p: SimpleNamespace(env_vars=(contract.PROVIDERS[p][1],)))
    secret = 'SENTINEL-credential-without-a-recognizable-prefix'
    monkeypatch.setenv('NVIDIA_API_KEY', secret)
    monkeypatch.delenv('OPENROUTER_API_KEY', raising=False)
    result = contract.inventory(configured)
    first, second = result['connections'][:2]
    assert first['presence'] == 'configured'
    assert second['presence'] == 'not_observed'
    assert first['masked_credential'] == '••••••••'
    assert not first['verified'] and first['last_tested_at'] is None
    assert secret not in json.dumps(result)
    assert first['id'] == 'hermes-env:nvidia'
    assert all(not first['operations'][op]['supported'] for op in contract.OPERATIONS)


def test_multiple_sources_duplicates_and_accounts_not_invented(configured, monkeypatch):
    import providers
    monkeypatch.setattr(providers, 'get_provider_profile', lambda p: SimpleNamespace(env_vars=(contract.PROVIDERS[p][1], 'OTHER_KEY')))
    for key in ('NVIDIA_API_KEY','OPENROUTER_API_KEY','OTHER_KEY'): monkeypatch.setenv(key,'same-test-secret')
    configured['values']['providers'].append('nvidia')
    result = contract.inventory(configured)
    assert len(result['connections']) == 6
    assert all(row['credential_count'] is None and row['account_count'] is None for row in result['connections'])
    assert all(row['account_scope'] == 'not_observable' for row in result['connections'])


@pytest.mark.parametrize('kind', ['missing','keyless','permission','failure'])
def test_host_api_matrix(configured, monkeypatch, caplog, kind):
    import providers
    def profile(_):
        if kind == 'permission': raise PermissionError('SECRET_UNECHOED')
        if kind == 'failure': raise RuntimeError('SECRET_UNECHOED')
        return None if kind == 'missing' else SimpleNamespace(env_vars=())
    monkeypatch.setattr(providers,'get_provider_profile',profile)
    result = contract.inventory(configured)
    assert all(row['presence'] == 'unknown' and not row['verified'] for row in result['connections'])
    assert 'SECRET_UNECHOED' not in json.dumps(result) + caplog.text


def test_unavailable_configuration_does_not_probe_credentials(configured):
    configured['available'] = False
    result = contract.inventory(configured, presence_reader=lambda p: pytest.fail('unauthorized probe'))
    assert not result['configuration_available']
    assert all(not row['authorized'] for row in result['connections'])


def test_region_and_model_scope_and_auth_failure_are_not_credential_verification(configured):
    result = contract.inventory(configured, {'nvidia':{'auth_failed':True,'model_count':3}}, 'available', lambda p:(True,None))
    row = result['connections'][0]
    assert row['health'] == 'provider_auth_failure_observed'
    assert row['verified'] is False
    assert row['model_scope'] is None and row['region_scope'] == 'unknown'
    assert row['discovered_model_count'] == 3


@pytest.mark.parametrize('provider,status', [('bad/id',400), ('UPPER',400), ('x'*100,400), ('pollinations',404), ('g4f-nvidia',404)])
def test_provider_validation(provider,status):
    with pytest.raises(contract.ConnectionError) as error: contract.validate_provider(provider)
    assert error.value.status == status
    assert provider not in error.value.message


def test_untrusted_diagnostics_discarded(configured):
    result = contract.inventory(configured, {'nvidia':{'model_count':'SECRET'}}, presence_reader=lambda p: (None,'SECRET'))
    assert 'SECRET' not in json.dumps(result)


@pytest.mark.parametrize('operation', contract.OPERATIONS)
def test_no_host_writer_never_reports_success(client, operation, state_dir, caplog):
    secret = 'SENTINEL_SECRET_NEVER_PERSISTED'
    response = client.post(f'/api/plugins/autorouter/connections/nvidia/actions/{operation}', json={
        'key':secret, 'account': {'label': secret, 'region': '../bad'}, 'keys':[secret,secret]})
    assert response.status_code == 501
    assert response.json()['detail']['code'] == 'host_capability_unavailable'
    assert secret not in response.text + caplog.text
    assert not state_dir.exists()


def test_http_inventory_and_compatibility(client, monkeypatch):
    import providers
    monkeypatch.setattr(providers,'get_provider_profile',lambda p:SimpleNamespace(env_vars=(contract.PROVIDERS[p][1],)))
    monkeypatch.setenv('NVIDIA_API_KEY','SENTINEL-RAW')
    response = client.get('/api/plugins/autorouter/connections')
    assert response.status_code == 200
    assert response.json()['mode'] == 'read_only'
    assert 'SENTINEL-RAW' not in response.text
    assert client.get('/api/plugins/autorouter/connections/nvidia').json()['presence'] == 'configured'
    assert client.get('/api/plugins/autorouter/models').status_code == 200
    assert client.get('/api/plugins/autorouter/providers').status_code == 200
    assert client.get('/api/plugins/autorouter/connections/nvidia/reveal').status_code == 404


def test_managed_and_operator_permission_denials(client, monkeypatch):
    api = _load_plugin_api()
    cfg = {'available':True,'managed':True,'values':{'providers':['nvidia']}}
    monkeypatch.setattr(api._sr,'read_plugin_config',lambda:cfg)
    path='/api/plugins/autorouter/connections/nvidia/actions/replace'
    assert client.post(path,json={'key':'SENTINEL'}).status_code == 403
    cfg['managed']=False
    cfg['values']['providers']=[]
    assert client.post(path).json()['detail']['code'] == 'provider_not_authorized'
    cfg['available']=False
    assert client.post(path).status_code == 503


@pytest.mark.parametrize('body', ['not-json', '{"key":"RAW_SECRET","account":null}', '{"keys":["RAW_SECRET","RAW_SECRET"]}'])
def test_malformed_or_duplicate_account_input_is_not_parsed(client, body):
    result=client.post('/api/plugins/autorouter/connections/nvidia/actions/add', content=body, headers={'content-type':'application/json'})
    assert result.status_code == 501
    assert 'RAW_SECRET' not in result.text


@pytest.mark.parametrize('condition',['missing','corrupt','partial'])
def test_state_failure_preserves_safe_inventory(client,state_dir,condition):
    if condition != 'missing':
        state_dir.mkdir()
        (state_dir/'autorouter.db').write_bytes(b'not a database' if condition=='corrupt' else b'')
    response=client.get('/api/plugins/autorouter/connections')
    assert response.status_code == 200
    assert response.json()['local_state'] == 'unavailable'
    assert all(row['discovered_model_count'] is None for row in response.json()['connections'])


def test_sqlite_remains_secret_free_and_selection_unchanged(client,state_dir,monkeypatch):
    store=state.StateStore(state_dir)
    store.upsert_catalog('nvidia','old',32768,{'tools':True},'free')
    store.upsert_health('nvidia','old',auth_failed=1,last_error='SHOULD_NOT_BE_COPIED')
    before=(state_dir/'autorouter.db').read_bytes()
    monkeypatch.setenv('NVIDIA_API_KEY','SENTINEL_SECRET')
    result=client.get('/api/plugins/autorouter/connections')
    assert 'SENTINEL_SECRET' not in result.text
    assert 'SHOULD_NOT_BE_COPIED' not in result.text
    assert (state_dir/'autorouter.db').read_bytes() == before
    assert router.Router({'store':store}).select_free_model() is None


def test_outer_host_auth_and_consent_gate_applies(monkeypatch):
    from fastapi import FastAPI, Depends, HTTPException
    from fastapi.testclient import TestClient
    api=_load_plugin_api()
    policy={'status':401}
    def host_gate(): raise HTTPException(policy['status'], 'Host access denied')
    app=FastAPI()
    app.include_router(api.router, prefix='/api/plugins/autorouter', dependencies=[Depends(host_gate)])
    monkeypatch.setattr(api._sr,'assemble_connections',lambda:pytest.fail('gate bypass'))
    with TestClient(app) as client:
        assert client.get('/api/plugins/autorouter/connections').status_code == 401
        policy['status']=403
        assert client.get('/api/plugins/autorouter/connections').status_code == 403


def test_last_observed_presence_is_not_reused_after_access_failure(configured):
    known = contract.inventory(configured, presence_reader=lambda p:(True,None))['connections'][0]
    unknown = contract.inventory(configured, presence_reader=lambda p:(None,'permission_denied'))['connections'][0]
    assert known['id'] == unknown['id']
    assert unknown['presence'] == 'unknown' and unknown['masked_credential'] is None
    assert not unknown['verified'] and unknown['reason'] == 'permission_denied'


def test_official_provider_guidance_has_no_lifecycle_or_secret_fields(configured):
    out = contract.inventory(configured, presence_reader=lambda p: (True, None))
    assert len(out['connections']) == 6
    for connection in out['connections']:
        guidance = connection['guidance']
        assert guidance['source_type'] == 'official_provider_documentation'
        assert guidance['key_issuance_url'].startswith('https://')
        assert guidance['source_url'].startswith('https://')
        expected_slot = contract.PROVIDERS[connection['provider_id']][1]
        if connection['provider_id'] == 'nous':
            expected_slot = 'Nous Portal OAuth (managed by Hermes)'
        assert guidance['environment_slot'] == expected_slot
        assert not connection['verified'] and connection['account_count'] is None
        assert not any(connection['operations'][operation]['supported'] for operation in contract.OPERATIONS)


def test_provider_page_embeds_same_readonly_contract_on_corrupt_state(client, state_dir, monkeypatch):
    monkeypatch.setenv('NVIDIA_API_KEY', 'PRIVATE_PRESENCE_SENTINEL')
    state_dir.mkdir(exist_ok=True)
    (state_dir / 'autorouter.db').write_bytes(b'corrupt database')
    response = client.get('/api/plugins/autorouter/providers')
    assert response.status_code == 200
    inventory = response.json()['connection_inventory']
    assert inventory['mode'] == 'read_only' and len(inventory['connections']) >= 6
    assert set(contract.PROVIDERS) <= {row['provider_id'] for row in inventory['connections']}
    assert inventory['local_state'] == 'unavailable'
    assert 'PRIVATE_PRESENCE_SENTINEL' not in response.text


def test_env_presence_uses_dotenv_gate_not_raw_environ(monkeypatch):
    """Presence flows through the host's dotenv-aware reader; the value never
    leaves the host-side call chain unreduced."""
    import os
    monkeypatch.delenv('NVIDIA_API_KEY', raising=False)
    import hermes_cli.config as hc_config
    import hermes_cli.auth as hc_auth
    monkeypatch.setattr(hc_config, 'get_env_value_prefer_dotenv',
                        lambda name: 'SENTINEL-NOT-A-REAL-KEY' if name == 'NVIDIA_API_KEY' else None)
    monkeypatch.setattr(hc_auth, 'has_usable_secret',
                        lambda value, **kwargs: isinstance(value, str) and value.startswith('SENTINEL'))
    assert contract._read_env_present('NVIDIA_API_KEY') is True
    monkeypatch.setattr(hc_config, 'get_env_value_prefer_dotenv', lambda name: 'definitely-not-usable')
    monkeypatch.setattr(hc_auth, 'has_usable_secret', lambda value, **kwargs: False)
    assert contract._read_env_present('NVIDIA_API_KEY') is False
    monkeypatch.setattr(hc_config, 'get_env_value_prefer_dotenv', lambda name: 1 / 0)
    monkeypatch.setattr(hc_auth, 'has_usable_secret', lambda value, **kwargs: (_ for _ in ()).throw(RuntimeError()))
    # host unreadable -> presence is False (nothing affirmed); never an exception crossing the boundary
    assert contract._read_env_present('NVIDIA_API_KEY') is False


def test_pool_snapshot_discards_entry_payloads(monkeypatch):
    """Credential-pool rows are enumerated for existence only; arbitrary
    source/auth_type strings from the store are never carried out."""
    import hermes_cli.auth as hc_auth
    hostile = [
        {'source': 'env:SENTINEL-AUTOROUTER-POOL-ROW-CANARY', 'auth_type': 'api_key', 'label': 'x'},
        {'source': 'device_code', 'auth_type': 'oauth'},
        {'source': 12345, 'auth_type': None},
        'not-a-dict',
        {'source': 'gh_cli' * 200, 'auth_type': 'bearer'},
    ]
    monkeypatch.setattr(hc_auth, 'read_credential_pool', lambda provider=None: {'nvidia': list(hostile)})
    snap = contract._read_pool_snapshot()
    blob = json.dumps(snap)
    assert 'SENTINEL' not in blob and 'gh_cli' not in blob
    assert snap == {'nvidia': {'entries': 5, 'oauth': True}}
    # Arbitrary keys are rejected by the provider-id validator.
    monkeypatch.setattr(hc_auth, 'read_credential_pool',
                        lambda provider=None: {'pwn/x': [{'source': 'env'}], 'good-1': [{'source': 'env'}]})
    assert contract._read_pool_snapshot() == {'good-1': {'entries': 1, 'oauth': False}}


def test_suppressed_sources_allowlisted(monkeypatch):
    import hermes_cli.auth as hc_auth
    monkeypatch.setattr(hc_auth, 'suppressed_credential_sources', lambda provider: {'env:SENTINEL-SUPPRESS', 'manual', 42, 'device_code'})
    result = contract._read_suppressed_sources('xiaomi')
    assert result == ['device_code', 'env', 'manual', 'unknown']
    monkeypatch.setattr(hc_auth, 'suppressed_credential_sources', lambda provider: 'SENTINEL-NOT-A-SET')
    assert contract._read_suppressed_sources('xiaomi') is None


def _walk_strings(node, out):
    if isinstance(node, dict):
        for key, value in node.items():
            out.append(str(key))
            _walk_strings(value, out)
    elif isinstance(node, (list, tuple)):
        for item in node:
            _walk_strings(item, out)
    elif isinstance(node, str):
        out.append(node)


def test_inventory_emits_no_unbounded_strings(configured, monkeypatch):
    monkeypatch.setattr(contract, '_host_pool_snapshot', _pool_snapshot)
    monkeypatch.setattr(contract, '_host_explicit', lambda p: True)
    monkeypatch.setattr(contract, '_host_env_present', lambda name: True)
    monkeypatch.setattr(contract, '_host_suppressed', lambda p: ['env:SENTINEL-SUPPRESSED'])
    configured['values']['providers'] = ['nvidia']
    result = contract.inventory(configured)
    strings = []
    _walk_strings(result, strings)
    assert strings, 'inventory must emit strings'
    for item in strings:
        assert len(item) <= 200, item
    blob = ' '.join(strings)
    assert 'SENTINEL' not in blob


def _pool_snapshot():
    return {
        'nvidia': {'entries': 1, 'oauth': False},
        'openrouter': {'entries': 1, 'oauth': False},
        'zai': {'entries': 1, 'oauth': False},
        'copilot': {'entries': 2, 'oauth': False},
        'nous': {'entries': 1, 'oauth': True},
        'anthropic': {'entries': 1, 'oauth': False},
        'xiaomi': {'entries': 1, 'oauth': False},
    }


def test_hermes_pool_observed_providers_appear_with_honest_families(configured, monkeypatch):
    monkeypatch.setattr(contract, '_host_pool_snapshot', _pool_snapshot)
    monkeypatch.setattr(contract, '_host_explicit', lambda p: p in ('nvidia', 'openrouter', 'nous', 'zai', 'copilot'))
    monkeypatch.setattr(contract, '_host_env_present', lambda name: name in ('NVIDIA_API_KEY', 'OPENROUTER_API_KEY'))
    result = contract.inventory(configured)
    rows = {row['provider_id']: row for row in result['connections']}
    # All six adapter-backed providers are present.
    assert set(contract.PROVIDERS) <= set(rows)
    # Hermes-configured but unsupported providers are inventoried, not hidden.
    assert rows['zai']['family'] == 'llm_unsupported'
    assert rows['zai']['presence'] == 'configured'
    assert rows['zai']['discovery'] == 'unsupported'
    assert rows['zai']['usable_for_routing'] == 'unsupported'
    assert rows['zai']['authorized'] is False
    assert rows['zai']['guidance']['auth_prerequisite'].startswith('AutoRouter has no discovery')
    assert rows['copilot']['family'] == 'llm_unsupported'
    assert rows['copilot']['credential_source'] == 'hermes_credential_pool'
    # Anthropic: configured in pool but stale (env var absent, not explicit) — not reported configured.
    assert rows['anthropic']['presence'] == 'not_observed'
    # No secret material or account identity anywhere in the payload.
    blob = json.dumps(result)
    assert 'SENTINEL' not in blob and 'diegorhoger' not in blob


def test_configured_but_unauthorized_adapter_is_not_mislabeled_missing(configured, monkeypatch):
    configured['values']['providers'] = ['nvidia']  # openrouter present but not authorized
    monkeypatch.setattr(contract, '_host_env_present', lambda name: name == 'OPENROUTER_API_KEY')
    result = contract.inventory(configured)
    rows = {row['provider_id']: row for row in result['connections']}
    assert rows['openrouter']['presence'] == 'configured'
    assert rows['openrouter']['authorized'] is False
    assert rows['openrouter']['usable_for_routing'] == 'not_authorized'
    assert rows['openrouter']['enabled'] is None
    assert rows['nvidia']['authorized'] is True


def test_unsupported_providers_can_never_enter_the_authorization_list():
    with pytest.raises(contract.ConnectionError):
        contract.validate_provider('zai')
    assert contract.valid_provider_list(['nvidia', 'zai']) is False
    assert contract.valid_provider_list(['zai']) is False
    assert contract.valid_provider_list(['nvidia', 'openrouter']) is True


def test_presence_never_implies_allowlist_expansion(configured, monkeypatch):
    monkeypatch.setattr(contract, '_host_pool_snapshot', _pool_snapshot)
    monkeypatch.setattr(contract, '_host_explicit', lambda p: True)
    monkeypatch.setattr(contract, '_host_env_present', lambda name: True)
    configured['values']['providers'] = ['nvidia', 'openrouter']
    result = contract.inventory(configured)
    assert [row['provider_id'] for row in result['connections'] if row['authorized']] == ['nvidia', 'openrouter']


def test_account_allowance_and_inference_auth_are_never_verified(configured, monkeypatch):
    monkeypatch.setattr(contract, '_host_pool_snapshot', _pool_snapshot)
    monkeypatch.setattr(contract, '_host_explicit', lambda p: True)
    monkeypatch.setattr(contract, '_host_env_present', lambda name: True)
    configured['values']['providers'] = ['nvidia', 'openrouter']
    result = contract.inventory(configured)
    for row in result['connections']:
        assert row['verification'] == 'unverified'
        assert row['account_allowance'] == 'unknown'
        assert row['inference_authenticated'] == 'unknown'
    assert result['account_allowance'] == 'unknown'
    assert result['inference_authentication'] == 'unverified'


def test_suppressed_sources_marked_not_configured(configured, monkeypatch):
    monkeypatch.setattr(contract, '_host_pool_snapshot', _pool_snapshot)
    monkeypatch.setattr(contract, '_host_explicit', lambda p: p == 'xiaomi')
    monkeypatch.setattr(contract, '_host_suppressed', lambda p: ['env'] if p == 'xiaomi' else [])
    result = contract.inventory(configured)
    rows = {row['provider_id']: row for row in result['connections']}
    assert rows['xiaomi']['presence'] == 'not_observed'
    assert rows['xiaomi']['credential_source'] == 'suppressed'


def test_inventory_is_secret_free_for_every_row(configured, monkeypatch):
    monkeypatch.setattr(contract, '_host_pool_snapshot', _pool_snapshot)
    monkeypatch.setattr(contract, '_host_explicit', lambda p: True)
    monkeypatch.setattr(contract, '_host_env_present', lambda name: True)
    monkeypatch.setattr(contract, '_host_suppressed', lambda p: ['env'])
    result = contract.inventory(configured)

    forbidden_keys = {'access_token', 'refresh_token', 'secret_fingerprint', 'agent_key',
                      'expires_at', 'api_key', 'secret', 'password', 'authorization'}

    def walk(node):
        if isinstance(node, dict):
            for key, value in node.items():
                assert str(key).lower() not in forbidden_keys, (key, node)
                walk(value)
        elif isinstance(node, (list, tuple)):
            for item in node:
                walk(item)
        elif isinstance(node, str):
            assert 'SENTINEL' not in node
            assert 'sk-' not in node
    walk(result)
    blob = json.dumps(result)
    for forbidden in ('access_token', 'refresh_token', 'secret_fingerprint', 'agent_key'):
        assert forbidden not in blob
