"""Pure reproducibility and adversarial archive checks without git subprocesses."""

import importlib.util
from pathlib import Path
import io
import json
import zipfile
import pytest

spec = importlib.util.spec_from_file_location(
    "package_builder", Path(__file__).resolve().parents[1] / "tools/build_package.py"
)
pkg = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pkg)


def files():
    result = {name: b"fixture" for name in pkg.REQUIRED}
    result["LICENSE"] = b"MIT License"
    result["plugin.yaml"] = b"name: autorouter\nversion: 0.2.0\n"
    return result


def encode(payload=None):
    return pkg.encode(files() if payload is None else payload, "a" * 40, "b" * 40)


def test_repeatable_manifest_and_exact_member_inventory():
    one = encode()
    assert one == encode(dict(reversed(list(files().items()))))
    manifest = pkg.verify(one)
    assert manifest["source_sha"] == "a" * 40
    assert len(manifest["files"]) == len(files())
    assert manifest["license"] == "MIT"


@pytest.mark.parametrize(
    "name",
    [
        ".env",
        "dashboard/.env.local",
        "../secret.py",
        "/absolute.py",
        "state/db.py",
        "tests/example.py",
    ],
)
def test_nonpayload_paths_cannot_be_packaged(name):
    data = files()
    data[name] = b"PRIVATE"
    with pytest.raises(ValueError):
        encode(data)


@pytest.mark.parametrize(
    "value",
    [b"-----BEGIN PRIVATE KEY-----", b"ghp_" + b"x" * 32, b"nvapi-" + b"x" * 32],
)
def test_secret_patterns_reject_without_echoing_value(value):
    data = files()
    data["README.md"] = value
    with pytest.raises(ValueError, match="values redacted") as err:
        encode(data)
    assert value.decode() not in str(err.value)


@pytest.mark.parametrize(
    "mutation", ["tamper", "extra", "duplicate", "symlink", "traversal"]
)
def test_mutated_archives_are_rejected_before_extraction(mutation):
    original = zipfile.ZipFile(io.BytesIO(encode()))
    result = io.BytesIO()
    with zipfile.ZipFile(result, "w") as output:
        for info in original.infolist():
            data = original.read(info.filename)
            if info.filename.endswith("README.md"):
                if mutation == "tamper":
                    data = b"changed"
                if mutation == "symlink":
                    info.external_attr = 0o120777 << 16
            output.writestr(info, data)
        if mutation in ("extra", "duplicate", "traversal"):
            name = {
                "extra": "autorouter/extra.py",
                "duplicate": "autorouter/README.md",
                "traversal": "autorouter/../outside.py",
            }[mutation]
            info = zipfile.ZipInfo(name)
            info.external_attr = 0o100644 << 16
            output.writestr(info, b"bad")
    with pytest.raises(ValueError):
        pkg.verify(result.getvalue())


def test_user_docs_are_packaged_and_internal_records_are_not():
    data = files()
    data["docs/installation.md"] = b"install"
    assert len(pkg.verify(encode(data))["files"]) == len(data)
    for internal in (
        "docs/internal/product/claims-v1.json",
        "docs/internal/adr/index.json",
        "docs/internal/adr/0001-native-intelligence-and-replaceable-execution.md",
        "docs/internal/provider-intelligence/hermes-credential-scope-contract.md",
        "controlled_mock_server.py",
        "mock_server.py",
    ):
        blocked = dict(files())
        blocked[internal] = b"internal"
        with pytest.raises(ValueError):
            encode(blocked)


@pytest.mark.parametrize("field", ["source_sha", "tree_sha"])
def test_expected_identity_rejects_different_but_well_formed_commit_metadata(field):
    with pytest.raises(ValueError, match="expected source/tree"):
        pkg.verify(encode(), **{field: "c" * 40})


@pytest.mark.parametrize(
    "mutation",
    [
        "absolute",
        "mode",
        "missing_runtime",
        "missing_license",
        "wrong_identity",
        "invalid_version",
        "manifest_hash",
        "source_format",
        "tree_format",
        "oversized",
        "entry_count",
        "noncanonical",
    ],
)
def test_additional_archive_security_gates(mutation):
    original = zipfile.ZipFile(io.BytesIO(encode()))
    if mutation == "oversized":
        with pytest.raises(ValueError):
            pkg.verify(b"x" * (pkg.MAX_BYTES * 2 + 1))
        return
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w") as archive:
        for info in original.infolist():
            payload = original.read(info.filename)
            if (
                mutation == "missing_runtime"
                and info.filename == "autorouter/__init__.py"
            ):
                continue
            if mutation == "missing_license" and info.filename == "autorouter/LICENSE":
                continue
            if info.filename == "autorouter/README.md":
                if mutation == "absolute":
                    info.filename = "/autorouter/README.md"
                if mutation == "mode":
                    info.external_attr = 0o100755 << 16
                if mutation == "noncanonical":
                    info.date_time = (2001, 1, 1, 0, 0, 0)
            if info.filename == "autorouter/plugin.yaml":
                if mutation == "wrong_identity":
                    payload = b"name: another\nversion: 0.2.0\n"
                if mutation == "invalid_version":
                    payload = b"name: autorouter\nversion: invalid\n"
            if info.filename == "autorouter/PACKAGE-MANIFEST.json":
                manifest = json.loads(payload)
                if mutation == "manifest_hash":
                    manifest["files"][0]["sha256"] = "0" * 64
                if mutation == "source_format":
                    manifest["source_sha"] = "invalid"
                if mutation == "tree_format":
                    manifest["tree_sha"] = "invalid"
                payload = json.dumps(manifest).encode()
            archive.writestr(info, payload)
        if mutation == "entry_count":
            for n in range(2001):
                archive.writestr("autorouter/extra" + str(n) + ".py", b"")
    with pytest.raises((ValueError, KeyError)):
        pkg.verify(out.getvalue())
