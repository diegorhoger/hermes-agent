"""Virtual-model deactivation guard tests: no host, no network, no real config.

The guard is warning-only by design: it detects a dangling virtual pin,
logs critically, persists a durable unresolved-pin marker for the dashboard,
and never rewrites the profile configuration. Historical ``decisions`` /
``requests`` rows are usage history, not authoritative configuration
snapshots, and are never used to pick a substitute route.

Each test runs against a disposable HERMES_HOME.
"""
import json
import sqlite3
import time
from pathlib import Path

import yaml

import pytest

from autorouter.autorouter_core.storage import state as _state_mod
from autorouter.autorouter_core.integration import virtual_pin_guard as gpg

NOW = 1794575637.0
VIRTUAL = 'autorouter/auto-free'


def _scratch_home(tmp_path):
    home = tmp_path / 'home'
    home.mkdir()
    return home


def _seed_store(home, decisions=(), requests=()):
    """Seed the plugin store. ``requests`` entries are (ts, provider, model, status)."""
    store_dir = home / 'plugin-data' / 'autorouter'
    store_dir.mkdir(parents=True, exist_ok=True)
    db_path = store_dir / 'autorouter.db'
    conn = sqlite3.connect(str(db_path))
    try:
        conn.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        conn.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('schema_version','5')")
        conn.execute("""CREATE TABLE IF NOT EXISTS decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, policy TEXT,
            provider TEXT, model TEXT, reason TEXT, candidates INTEGER)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT, model TEXT, status TEXT NOT NULL DEFAULT 'pending',
            created_at REAL NOT NULL DEFAULT 0)""")
        for ts, provider, model in decisions:
            conn.execute("INSERT INTO decisions(ts, policy, provider, model, reason, candidates) VALUES (?,?,?,?,?,?)",
                         (ts, 'auto', provider, model, 'selected', 3))
        for req in requests:
            ts, provider, model = req[0], req[1], req[2]
            status = req[3] if len(req) > 3 else 'success'
            conn.execute("INSERT INTO requests(provider, model, status, created_at) VALUES (?,?,?,?)",
                         (provider, model, status, ts))
        conn.commit()
    finally:
        conn.close()
    return store_dir


def _read(path):
    return yaml.safe_load(path.read_text(encoding='utf-8'))


def _write_config(home, model_block=None, extra=None):
    body = {'model': model_block} if model_block is not None else {}
    if extra:
        body.update(extra)
    (home / 'config.yaml').write_text(json.dumps(body), encoding='utf-8')


def _config_bytes(home):
    return (home / 'config.yaml').read_bytes()


@pytest.fixture
def hermes_home(tmp_path, monkeypatch):
    home = _scratch_home(tmp_path)
    monkeypatch.setenv('HERMES_HOME', str(home))
    return home


def test_disabled_adapter_without_pin_is_clear(hermes_home):
    _write_config(hermes_home, {'default': 'free-chat', 'provider': 'mock-local', 'base_url': 'http://127.0.0.1:1/v1'})
    report = gpg.guard(None, cfg=None, env={})
    assert report['state'] == 'clear'
    saved = _read(hermes_home / 'config.yaml')
    assert saved['model']['default'] == 'free-chat'
    assert saved['model']['provider'] == 'mock-local'


def test_virtual_pin_with_no_history_reports_loudly_and_preserves_config(hermes_home):
    _write_config(hermes_home, {'default': VIRTUAL, 'provider': 'autorouter', 'base_url': 'http://127.0.0.1:9/v1'})
    before = _config_bytes(hermes_home)
    report = gpg.guard(None, env={})
    assert report['state'] == 'unresolved_pin'
    assert report['restored'] is None
    assert report['restore_error'].startswith('not attempted')
    assert _config_bytes(hermes_home) == before  # configuration untouched
    assert 'unresolved' in report['detail'].lower()
    assert '/model' in report['detail']


def test_virtual_pin_with_stale_historical_requests_is_not_restored(hermes_home):
    _seed_store(hermes_home, requests=[(NOW - 500, 'openrouter', 'some/free-model:free')])
    _write_config(hermes_home, {'default': VIRTUAL, 'provider': 'autorouter',
                                'base_url': 'http://127.0.0.1:9/v1'})
    before = _config_bytes(hermes_home)
    report = gpg.guard(hermes_home / 'plugin-data' / 'autorouter', env={})
    assert report['state'] == 'unresolved_pin'
    assert report['restored'] is None
    saved = _read(hermes_home / 'config.yaml')
    assert saved['model']['default'] == VIRTUAL          # no substitution from history
    assert saved['model']['base_url'] == 'http://127.0.0.1:9/v1'
    assert _config_bytes(hermes_home) == before


def test_historical_route_with_different_provider_and_endpoint_is_not_restored(hermes_home):
    # History points at openrouter/some-model; the pinned config carries a
    # different endpoint. The guard must not merge history into the config.
    _seed_store(hermes_home, decisions=[(NOW - 1000, 'openrouter', 'historical/model:free')])
    _write_config(hermes_home, {'default': VIRTUAL, 'provider': 'autorouter',
                                'base_url': 'http://127.0.0.1:9/v1', 'api_mode': 'chat_completions'})
    before = _config_bytes(hermes_home)
    report = gpg.guard(hermes_home / 'plugin-data' / 'autorouter', env={})
    assert report['state'] == 'unresolved_pin'
    saved = _read(hermes_home / 'config.yaml')
    assert saved['model']['default'] == VIRTUAL
    assert saved['model']['provider'] == 'autorouter'
    assert saved['model']['base_url'] == 'http://127.0.0.1:9/v1'
    assert saved['model']['api_mode'] == 'chat_completions'
    assert _config_bytes(hermes_home) == before


def test_failed_request_in_history_is_not_restored(hermes_home):
    _seed_store(hermes_home, requests=[(NOW - 100, 'openrouter', 'failed/model:free', 'failed')])
    _write_config(hermes_home, {'default': VIRTUAL})
    before = _config_bytes(hermes_home)
    report = gpg.guard(hermes_home / 'plugin-data' / 'autorouter', env={})
    assert report['state'] == 'unresolved_pin'
    assert _config_bytes(hermes_home) == before


def test_ambiguous_history_is_not_restored(hermes_home):
    _seed_store(hermes_home, decisions=[(NOW - 100, 'mock-local', 'free-chat'),
                                        (NOW - 100, 'openrouter', 'other/free-model:free')])
    _write_config(hermes_home, {'default': VIRTUAL, 'provider': 'autorouter'})
    before = _config_bytes(hermes_home)
    report = gpg.guard(hermes_home / 'plugin-data' / 'autorouter', env={})
    assert report['state'] == 'unresolved_pin'
    assert _config_bytes(hermes_home) == before


def test_missing_plugin_interposition_reports_without_adapter(hermes_home):
    # Plugin routing entirely absent: the guard needs nothing from the adapter.
    _seed_store(hermes_home, decisions=[(NOW - 100, 'mock-local', 'free-chat')])
    _write_config(hermes_home, {'default': VIRTUAL})
    before = _config_bytes(hermes_home)
    report = gpg.guard(hermes_home / 'plugin-data' / 'autorouter', env={},
                       _routing_check=lambda: False)
    assert report['state'] == 'unresolved_pin'
    assert _config_bytes(hermes_home) == before


def test_failed_adapter_load_reports_without_adapter(hermes_home):
    # enable_chat_router true but the adapter never interposed (loader exception).
    _write_config(hermes_home, {'default': VIRTUAL})
    before = _config_bytes(hermes_home)
    report = gpg.guard(None, env={}, _routing_check=lambda: False)
    assert report['state'] == 'unresolved_pin'
    assert _config_bytes(hermes_home) == before


def test_gateway_restart_repeats_warning_and_preserves_config(hermes_home):
    _seed_store(hermes_home, requests=[(NOW - 10, 'mock-local', 'free-chat')])
    _write_config(hermes_home, {'default': VIRTUAL, 'provider': 'autorouter', 'base_url': 'http://127.0.0.1:9/v1'})
    before = _config_bytes(hermes_home)
    for _ in range(2):  # two gateway restarts
        report = gpg.guard(hermes_home / 'plugin-data' / 'autorouter', env={})
        assert report['state'] == 'unresolved_pin'
        assert _config_bytes(hermes_home) == before
    marker = gpg.read_marker(hermes_home / 'plugin-data' / 'autorouter')
    assert marker is not None and marker['state'] == 'unresolved_pin'


def test_disabled_routing_flag_is_not_rewritten(hermes_home, monkeypatch):
    # Routing flag off means no adapter interposition; hermes_cli.model_switch
    # may be loaded in this process, so pin the check explicitly to "disabled".
    _write_config(hermes_home, {'default': VIRTUAL})
    before = _config_bytes(hermes_home)
    report = gpg.guard(None, env={}, _routing_check=lambda: False)
    assert report['state'] == 'unresolved_pin'
    assert _config_bytes(hermes_home) == before


def test_routing_active_is_noop(hermes_home):
    _write_config(hermes_home, {'default': VIRTUAL})
    report = gpg.guard(None, cfg=None, env={}, _routing_check=lambda: True)
    assert report['state'] == 'routing_active'
    saved = _read(hermes_home / 'config.yaml')
    assert saved['model']['default'] == VIRTUAL


def test_managed_configuration_is_never_rewritten(hermes_home, monkeypatch):
    import hermes_cli.config as _cfg
    monkeypatch.setattr(_cfg, 'save_config',
                        lambda *a, **kw: (_ for _ in ()).throw(PermissionError('managed install')))
    monkeypatch.setattr(_cfg, 'read_user_config_raw',
                        lambda *a, **kw: (_ for _ in ()).throw(AssertionError('writer must not be consulted')))
    _write_config(hermes_home, {'default': VIRTUAL, 'provider': 'autorouter'})
    before = _config_bytes(hermes_home)
    report = gpg.guard(None, env={})
    assert report['state'] == 'unresolved_pin'
    assert _config_bytes(hermes_home) == before


def test_config_writer_failure_leaves_config_untouched(hermes_home, monkeypatch):
    import hermes_cli.config as _cfg
    monkeypatch.setattr(_cfg, 'save_config',
                        lambda *a, **kw: (_ for _ in ()).throw(RuntimeError('disk full')))
    _write_config(hermes_home, {'default': VIRTUAL, 'provider': 'autorouter'})
    before = _config_bytes(hermes_home)
    report = gpg.guard(None, env={})
    assert report['state'] == 'unresolved_pin'
    assert report['restored'] is None
    assert _config_bytes(hermes_home) == before


def test_guard_performs_no_network_activity(hermes_home, monkeypatch):
    import socket
    def _no_network(*args, **kwargs):
        raise AssertionError('guard attempted network activity')
    monkeypatch.setattr(socket.socket, 'connect', _no_network)
    monkeypatch.setattr(socket, 'create_connection', _no_network)
    _seed_store(hermes_home, decisions=[(NOW - 100, 'mock-local', 'free-chat')])
    _write_config(hermes_home, {'default': VIRTUAL})
    before = _config_bytes(hermes_home)
    report = gpg.guard(hermes_home / 'plugin-data' / 'autorouter', env={})
    assert report['state'] == 'unresolved_pin'
    assert _config_bytes(hermes_home) == before


def test_marker_and_report_disclose_no_secrets(hermes_home):
    _write_config(hermes_home, {'default': VIRTUAL, 'provider': 'autorouter',
                                'base_url': 'http://127.0.0.1:9/v1', 'api_mode': 'chat_completions',
                                'api_key': 'sk-test-secret-123'},
                   extra={'plugins': {'entries': {'autorouter': {'settings': {'token': 'tok-secret-456'}}}}})
    store = _seed_store(hermes_home, requests=[(NOW - 100, 'openrouter', 'x/y', 'success')])
    report = gpg.guard(store, env={})
    marker_raw = (store / 'autorouter.db').read_bytes()
    for needle in ('sk-test-secret-123', 'tok-secret-456', '127.0.0.1:9', 'chat_completions', 'api_key', 'base_url'):
        assert needle not in json.dumps(report), needle
        assert needle.encode() not in marker_raw, needle


def test_arbitrary_config_structure_is_preserved_verbatim(hermes_home):
    extra = {'plugins': {'entries': {'autorouter': {'settings': {'enabled': False}}}},
             'telemetry': {'enabled': True}, 'theme': 'dark'}
    _write_config(hermes_home, {'default': VIRTUAL, 'provider': 'autorouter', 'base_url': 'http://x:9/v1'},
                   extra=extra)
    before = _config_bytes(hermes_home)
    gpg.guard(None, env={})
    gpg.guard(hermes_home / 'plugin-data' / 'autorouter', env={})  # state dir may not exist; still fine
    assert _config_bytes(hermes_home) == before


def test_env_pin_is_reported_and_config_untouched(hermes_home):
    _write_config(hermes_home, {'default': 'free-chat', 'provider': 'mock-local'})
    report = gpg.guard(None, cfg=_read(hermes_home / 'config.yaml'),
                       env={'HERMES_INFERENCE_MODEL': VIRTUAL})
    assert report['state'] == 'unresolved_pin'
    assert report['pins'] == [{'source': 'env.HERMES_INFERENCE_MODEL', 'detail': VIRTUAL}]
    saved = _read(hermes_home / 'config.yaml')
    assert saved['model']['default'] == 'free-chat'


def test_flat_string_model_pin_is_detected(hermes_home):
    _seed_store(hermes_home, decisions=[(NOW - 100, 'mock-local', 'free-chat')])
    _write_config(hermes_home, VIRTUAL)  # flat-string model pin, legacy shape
    before = _config_bytes(hermes_home)
    report = gpg.guard(hermes_home / 'plugin-data' / 'autorouter', env={})
    assert report['state'] == 'unresolved_pin'
    assert _config_bytes(hermes_home) == before


def test_unrelated_model_section_is_left_alone(hermes_home):
    _write_config(hermes_home, {'default': 'some/real-model', 'provider': 'openrouter'})
    report = gpg.guard(None, env={})
    assert report['state'] == 'clear'
    assert _read(hermes_home / 'config.yaml')['model']['default'] == 'some/real-model'


def test_marker_is_readable_by_dashboard_and_superseded_on_fix(hermes_home):
    _write_config(hermes_home, {'default': VIRTUAL})
    store = _seed_store(hermes_home)
    gpg.guard(store, env={})
    marker = gpg.read_marker(store)
    assert marker is not None and marker['state'] == 'unresolved_pin'
    # The user fixes the pin; the next guard run supersedes the stale marker.
    _write_config(hermes_home, {'default': 'free-chat', 'provider': 'mock-local'})
    gpg.guard(store, env={})
    marker = gpg.read_marker(store)
    assert marker is not None and marker['state'] == 'clear'


def test_guard_never_raises_on_corrupt_config(hermes_home):
    (hermes_home / 'config.yaml').write_text('{not yaml at all: [', encoding='utf-8')
    report = gpg.guard(None, env={})
    # Malformed config is treated as unknown -> no findings -> clear, untouched.
    assert report['state'] in ('clear', 'unresolved_pin', 'guard_error')


def test_assume_disabled_overrides_in_process_interposition(hermes_home):
    # Deactivation-save semantics: the adapter is still interposed in the
    # current process, but the verdict must reflect the next host load.
    _write_config(hermes_home, {'default': VIRTUAL, 'provider': 'autorouter'})
    report = gpg.guard(None, env={}, _routing_check=lambda: True, assume_disabled=True)
    assert report['state'] == 'unresolved_pin'


def test_unreadable_config_never_clears_stale_unresolved_marker(hermes_home, monkeypatch):
    store = _seed_store(hermes_home)
    _write_config(hermes_home, {'default': VIRTUAL})
    report = gpg.guard(store, env={})
    assert report['state'] == 'unresolved_pin'
    import hermes_cli.config as _cfg
    monkeypatch.setattr(_cfg, 'load_config_readonly',
                        lambda *a, **kw: (_ for _ in ()).throw(RuntimeError('unreadable')))
    report = gpg.guard(store, env={})
    assert report['state'] == 'guard_error'
    marker = gpg.read_marker(store)
    assert marker is not None and marker['state'] == 'unresolved_pin'


def test_unreadable_config_still_reports_env_pin(hermes_home, monkeypatch):
    import hermes_cli.config as _cfg
    monkeypatch.setattr(_cfg, 'load_config_readonly',
                        lambda *a, **kw: (_ for _ in ()).throw(RuntimeError('unreadable')))
    report = gpg.guard(None, env={'HERMES_INFERENCE_MODEL': VIRTUAL})
    assert report['state'] == 'unresolved_pin'
    assert report['pins'] == [{'source': 'env.HERMES_INFERENCE_MODEL', 'detail': VIRTUAL}]


def test_healthy_verdicts_do_not_materialize_a_store(hermes_home, tmp_path):
    store = tmp_path / 'nonexistent-store'
    _write_config(hermes_home, {'default': 'free-chat', 'provider': 'mock-local'})
    report = gpg.guard(store, cfg=_read(hermes_home / 'config.yaml'), env={})
    assert report['state'] == 'clear'
    assert not store.exists() and not (store / 'autorouter.db').exists()
    report = gpg.guard(store, cfg=_read(hermes_home / 'config.yaml'), env={},
                       _routing_check=lambda: True)
    assert report['state'] == 'routing_active'
    assert not (store / 'autorouter.db').exists()


def test_unresolved_pin_may_create_minimal_store(hermes_home, tmp_path):
    store = tmp_path / 'fresh-store'
    _write_config(hermes_home, {'default': VIRTUAL})
    report = gpg.guard(store, env={})
    assert report['state'] == 'unresolved_pin'
    assert (store / 'autorouter.db').is_file()
    assert gpg.read_marker(store)['state'] == 'unresolved_pin'


def test_healthy_verdict_supersedes_marker_in_existing_store(hermes_home, tmp_path):
    store = _seed_store(hermes_home)
    _write_config(hermes_home, {'default': VIRTUAL})
    gpg.guard(store, env={})
    assert gpg.read_marker(store)['state'] == 'unresolved_pin'
    _write_config(hermes_home, {'default': 'free-chat', 'provider': 'mock-local'})
    gpg.guard(store, env={})
    assert gpg.read_marker(store)['state'] == 'clear'
