"""Scope isolation, deterministic circuit transitions, atomicity and redaction."""
from concurrent.futures import ThreadPoolExecutor
import json
import sqlite3

import pytest
from autorouter.autorouter_core.storage.state import StateStore, SCHEMA_VERSION
from autorouter.autorouter_core.health.health import decision, parse_retry_after, scope_id, classify_failure
from autorouter.autorouter_core.routing.router import Router
from .verified_fixture import seed_verified_model


def test_scopes_and_layers(tmp_path):
    store = StateStore(tmp_path)
    store.record_outcome('p', 'x', False, key_scope='account-A', status_code=401, now=100)
    assert not decision(store, 'p', 'y', 'account-A', now=101)['available']
    assert decision(store, 'p', 'x', 'account-B', now=101)['available']
    store.record_outcome('p', 'x', False, status_code=401, now=100)
    assert decision(store, 'p', 'x', 'account-B', now=101)['available']
    assert decision(store, 'p', 'x', now=101)['scope'] == 'scope_unknown'
    store.record_outcome('p', 'x', False, status_code=410, error_type="model_not_found", now=100)
    assert not decision(store, 'p', 'x', 'account-B', now=101)['available']
    assert decision(store, 'p', 'y', 'account-B', now=101)['available']


def test_provider_threshold_half_open_recovery(tmp_path):
    store = StateStore(tmp_path)
    for n in range(3):
        store.record_outcome('p', 'x', False, status_code=503, now=100+n)
        assert decision(store, 'p', 'y', 'B', now=103)['available'] == (n < 2)
    assert decision(store, 'p', 'y', 'B', now=133)['circuit'] == 'half_open'
    store.record_outcome('p', 'y', False, status_code=503, now=134)
    assert decision(store, 'p', 'x', now=135)['circuit'] == 'open'
    store.record_outcome('p', 'y', True, key_scope='B', now=136)
    assert decision(store, 'p', 'x', now=137)['circuit'] == 'closed'


def test_rate_limit_scope_and_reason(tmp_path):
    store = StateStore(tmp_path)
    store.record_outcome('p', 'x', False, key_scope='A', status_code=429,
                         trusted_reason='quota_exhausted', retry_after='120', now=100)
    assert decision(store, 'p', 'x', 'A', now=219)['reason'] == 'quota_exhausted'
    assert decision(store, 'p', 'x', 'A', now=220)['circuit'] == 'half_open'
    assert decision(store, 'p', 'x', 'B', now=101)['available']
    assert decision(store, 'p', 'y', 'A', now=101)['available']
    assert classify_failure(404)[1] == 'unknown_error'
    assert classify_failure(410)[1] == 'unknown_error'
    assert classify_failure(410,'model_gone')[1] == 'model_retired'
    assert classify_failure(404, 'model_not_found')[1] == 'model_retired'
    assert classify_failure(429, trusted_reason='concurrency_limited')[1] == 'concurrency_limited'
    assert classify_failure(429, trusted_reason='raw-provider-secret')[1] == 'rate_limit'


@pytest.mark.parametrize('raw,expected', [('NaN',None), ('Infinity',None), ('-1',None), ('junk',None),
    (True,None), ('0',0), ('12',12), ('999999999',86400), ('Thu, 01 Jan 1970 00:02:00 GMT',20)])
def test_retry_after(raw, expected):
    assert parse_retry_after(raw, now=100) == expected


def test_atomic_and_secret_safe(tmp_path):
    store = StateStore(tmp_path)
    secret='UNSAFE_PRIVATE_CREDENTIAL_SENTINEL'
    with ThreadPoolExecutor(max_workers=8) as executor:
        list(executor.map(lambda _: store.record_outcome('p', 'x', True, key_scope=secret), range(30)))
    assert store.get_health('p', 'x', secret)['successes'] == 30
    store.record_outcome('p', 'x', False, key_scope=secret, status_code=401,
                         error_type=secret, error_message=secret)
    with store._connect() as conn:
        for table in ('health','health_circuits'):
            assert secret not in json.dumps([dict(r) for r in conn.execute('SELECT * FROM '+table)])
    assert scope_id(scope_id(secret)) == scope_id(secret)


def test_selection_uses_explicit_scope_and_preview_agrees(tmp_path):
    store=StateStore(tmp_path)
    seed_verified_model(store,'nvidia','x',16000,{'tools':True},'free')
    store.record_outcome('nvidia','x',False,key_scope='A',status_code=401)
    for scope,expected in [('A',False),('B',True),('',True)]:
        router=Router({'store':store,'credential_scopes':{'nvidia':scope}})
        assert bool(router.select()) == expected
        preview=router.preview()
        assert bool(preview['chosen']) == expected
        assert preview['considered'][0]['scope_state'] == ('known' if scope else 'scope_unknown')


def test_schema_v2_upgrade_and_rollback(tmp_path,monkeypatch):
    store=StateStore(tmp_path)
    with store._connect() as conn:
        conn.execute('DROP TABLE health_circuits')
        conn.execute("UPDATE meta SET value='2' WHERE key='schema_version'")
    original=StateStore._init_telemetry_schema
    def fail(self,conn):
        original(self,conn)
        raise RuntimeError('injected migration failure')
    monkeypatch.setattr(StateStore,'_init_telemetry_schema',fail)
    with pytest.raises(RuntimeError): StateStore(tmp_path)
    with sqlite3.connect(store.db_path) as conn:
        assert conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]=='2'
        assert conn.execute("SELECT name FROM sqlite_master WHERE name='health_circuits'").fetchone() is None
    monkeypatch.setattr(StateStore,'_init_telemetry_schema',original)
    StateStore(tmp_path)
    assert SCHEMA_VERSION==6


def test_legacy_scope_migration_and_diagnostic_compatibility(tmp_path):
    store=StateStore(tmp_path)
    with store._connect() as conn:
        conn.execute("INSERT INTO health(provider,model,key_scope,successes,auth_failed) VALUES('p','x','old-account',7,1)")
    from autorouter.autorouter_core.storage.snapshot import ReadOnlyStateStore
    assert ReadOnlyStateStore(store.db_path).get_health('p','x','old-account')['successes']==7
    upgraded=StateStore(tmp_path)
    assert upgraded.get_health('p','x','old-account')['successes']==7
    with upgraded._connect() as conn:
        assert conn.execute("SELECT key_scope FROM health WHERE provider='p'").fetchone()[0]==scope_id('old-account')
    assert not decision(upgraded,'p','x','old-account')['available']


def test_explicit_cooldown_respected_without_extra_outcome(tmp_path):
    store=StateStore(tmp_path)
    store.set_cooldown('p','x',120,key_scope='A')
    assert not decision(store,'p','x','A')['available']
    assert decision(store,'p','x','B')['available']
    assert store.get_health('p','x','A')['failures']==0


def test_explicit_observer_scope_groups_telemetry_without_secret(tmp_path):
    from autorouter.autorouter_core.integration import runtime
    from autorouter.autorouter_core.telemetry import telemetry
    runtime.configure(state_dir=tmp_path)
    raw='explicit-opaque-account-reference'
    runtime.on_pre_api_request(api_request_id='one',provider='p',model='x',credential_scope=raw)
    runtime.on_post_api_request(api_request_id='one',provider='p',model='x',credential_scope=raw,status_code=200)
    store=runtime.get_store()
    assert store.get_health('p','x',raw)['successes']==1
    with store._connect() as conn:
        row=dict(conn.execute('SELECT * FROM requests').fetchone())
    assert row['key_scope']==telemetry.redact_key_scope(raw)
    assert raw not in json.dumps(row)


@pytest.mark.parametrize('legacy,reason', [({'retired':1},'model_retired'),
    ({'auth_failed':1},'auth'), ({'cooldown_until':500},'rate_limit')])
@pytest.mark.parametrize('status,error_type', [(503,None),(None,'TimeoutError')])
def test_unrelated_failure_never_clears_legacy_denial(tmp_path, legacy, reason, status, error_type):
    store=StateStore(tmp_path)
    store.upsert_health('p','x',**legacy)
    assert not decision(store,'p','x',now=100)['available']
    store.record_outcome('p','x',False,status_code=status,error_type=error_type,now=100)
    result=decision(store,'p','x',now=101)
    assert not result['available']
    assert result['reason']==reason


def test_success_recovers_legacy_auth_but_not_model_retirement(tmp_path):
    store=StateStore(tmp_path)
    store.upsert_health('p','x',key_scope='A',auth_failed=1)
    store.record_outcome('p','x',True,key_scope='A',now=100)
    assert decision(store,'p','x','A',now=101)['available']
    store.upsert_health('p','y',retired=1)
    store.record_outcome('p','y',True,now=100)
    assert not decision(store,'p','y',now=101)['available']


def test_v3_migration_rolls_back_scope_conversion_and_circuits(tmp_path,monkeypatch):
    store=StateStore(tmp_path)
    with store._connect() as conn:
        conn.execute('DROP TABLE health_circuits')
        conn.execute("UPDATE meta SET value='2' WHERE key='schema_version'")
        conn.execute("INSERT INTO health(provider,model,key_scope,retired) VALUES('p','x','legacy-reference',1)")
    original=StateStore._preserve_legacy_denials
    def fail(conn,rows,now):
        original(conn,rows,now)
        raise RuntimeError('after scoped migration')
    monkeypatch.setattr(StateStore,'_preserve_legacy_denials',staticmethod(fail))
    with pytest.raises(RuntimeError): StateStore(tmp_path)
    with sqlite3.connect(store.db_path) as conn:
        assert conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]=='2'
        assert conn.execute("SELECT key_scope FROM health WHERE provider='p'").fetchone()[0]=='legacy-reference'
        assert conn.execute("SELECT name FROM sqlite_master WHERE name='health_circuits'").fetchone() is None


def test_upgrade_drops_arbitrary_legacy_error_bodies(tmp_path):
    store=StateStore(tmp_path)
    store.upsert_health('p','x',last_error='PRIVATE_LEGACY_ERROR_SENTINEL')
    upgraded=StateStore(tmp_path)
    assert upgraded.get_health('p','x')['last_error']=='legacy_error'
