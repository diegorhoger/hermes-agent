"""The sanctioned profile data root preserves legacy SQLite and explicit overrides."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sqlite3

import pytest
from autorouter.autorouter_core.storage import state_dir


@pytest.fixture
def paths(tmp_path, monkeypatch):
    monkeypatch.setenv('HERMES_HOME', str(tmp_path/'profile'))
    source = tmp_path/'profile/plugins/autorouter/state/autorouter.db'
    source.parent.mkdir(parents=True)
    return tmp_path/'profile/plugins/autorouter', source, tmp_path/'profile/plugin-data/autorouter/autorouter.db'


def seed(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as db:
        db.execute('CREATE TABLE sample (value TEXT)')
        db.execute('INSERT INTO sample VALUES (?)', (value,))


def rows(path):
    with sqlite3.connect(path) as db:
        return db.execute('SELECT value FROM sample').fetchall()


def test_explicit_override_is_preserved_without_migration(paths, tmp_path):
    root, source, target = paths
    seed(source, 'legacy')
    explicit = tmp_path/'custom'
    assert state_dir.initialize_state_dir(str(explicit), root) == explicit
    assert not explicit.exists() and not target.exists()
    assert rows(source) == [('legacy',)]


def test_default_profile_root_without_legacy(paths):
    root, _, target = paths
    assert state_dir.initialize_state_dir('', root) == target.parent
    assert not target.exists()


def test_legacy_database_preserved_and_migration_idempotent(paths):
    root, source, target = paths
    seed(source, 'legacy')
    before = source.read_bytes()
    state_dir.initialize_state_dir('', root)
    assert rows(target) == [('legacy',)]
    assert source.read_bytes() == before
    state_dir.initialize_state_dir('', root)
    assert rows(target) == [('legacy',)]
    assert not list(target.parent.glob('.autorouter-migrate-*'))


def test_committed_wal_rows_are_included(paths):
    root, source, target = paths
    with sqlite3.connect(source) as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA wal_autocheckpoint=0')
        db.execute('CREATE TABLE sample (value TEXT)')
        db.execute("INSERT INTO sample VALUES ('wal-only')")
        db.commit()
        assert Path(str(source)+'-wal').stat().st_size > 0
        state_dir.initialize_state_dir('', root)
        assert rows(target) == [('wal-only',)]
        assert db.execute('SELECT value FROM sample').fetchall() == [('wal-only',)]


def test_existing_destination_never_overwritten(paths):
    root, source, target = paths
    seed(source, 'legacy'); seed(target, 'newer')
    state_dir.initialize_state_dir('', root)
    assert rows(target) == [('newer',)] and rows(source) == [('legacy',)]


@pytest.mark.parametrize('which', ['source', 'target'])
def test_corrupt_database_fails_without_replacing_data(paths, which):
    root, source, target = paths
    broken = source if which == 'source' else target
    broken.parent.mkdir(parents=True, exist_ok=True)
    broken.write_bytes(b'not a SQLite database')
    with pytest.raises(sqlite3.DatabaseError):
        state_dir.initialize_state_dir('', root)
    assert broken.read_bytes() == b'not a SQLite database'
    if which == 'source':
        assert not target.exists()


def test_concurrent_migration_never_overwrites_a_published_database(paths):
    root, source, target = paths
    seed(source, 'legacy')
    with ThreadPoolExecutor(4) as pool:
        results = list(pool.map(lambda _: state_dir.initialize_state_dir('', root), range(8)))
    assert all(p == target.parent for p in results)
    assert rows(target) == [('legacy',)] and rows(source) == [('legacy',)]
    assert not list(target.parent.glob('.autorouter-migrate-*'))


def test_failed_publication_preserves_source_and_cleans_staging(paths, monkeypatch):
    root, source, target = paths
    seed(source, 'legacy')
    def fail(*args):
        raise OSError('synthetic disk failure')
    monkeypatch.setattr(state_dir.os, 'link', fail)
    with pytest.raises(OSError):
        state_dir.initialize_state_dir('', root)
    assert rows(source) == [('legacy',)] and not target.exists()
    assert not list(target.parent.glob('.autorouter-migrate-*'))


def test_profiles_get_separate_data_roots(paths, tmp_path, monkeypatch):
    root, source, first = paths
    seed(source, 'legacy')
    state_dir.initialize_state_dir('', root)
    monkeypatch.setenv('HERMES_HOME', str(tmp_path/'second-profile'))
    second = state_dir.initialize_state_dir('', root)/'autorouter.db'
    assert second != first and not second.exists()
    assert rows(source) == [('legacy',)] and rows(first) == [('legacy',)]


def test_shared_install_symlink_cannot_import_another_profiles_data(paths, tmp_path, monkeypatch):
    root, source, first = paths
    seed(source, 'private-first-profile')
    second_home = tmp_path/'second-profile'
    linked = second_home/'plugins/autorouter'
    linked.parent.mkdir(parents=True)
    linked.symlink_to(root, target_is_directory=True)
    monkeypatch.setenv('HERMES_HOME', str(second_home))
    second = state_dir.initialize_state_dir('', linked)/'autorouter.db'
    assert not second.exists() and not first.exists()
    assert rows(source) == [('private-first-profile',)]


@pytest.mark.parametrize('linked_part', ['state-directory', 'database', 'wal', 'shm'])
def test_nested_legacy_links_cannot_import_foreign_profile(paths, tmp_path, linked_part):
    root, source, target = paths
    foreign = tmp_path/'foreign-profile/private/autorouter.db'
    seed(foreign, 'private-foreign-record')
    if linked_part == 'state-directory':
        source.parent.rmdir()
        source.parent.symlink_to(foreign.parent, target_is_directory=True)
    elif linked_part == 'database':
        source.symlink_to(foreign)
    else:
        seed(source, 'owned-record')
        sidecar = Path(str(source) + '-' + linked_part)
        sidecar.symlink_to(foreign)
    state_dir.initialize_state_dir('', root)
    assert not target.exists()
    assert rows(foreign) == [('private-foreign-record',)]


def test_dashboard_lookup_never_publishes_or_freezes_legacy_database(paths, monkeypatch):
    from tests.test_dashboard_state_reader import sr
    root, source, target = paths
    seed(source, 'before-dashboard')
    original_loader = sr._load_submodule
    monkeypatch.setattr(sr, '_load_submodule', lambda name: state_dir if name == 'state_dir' else original_loader(name))
    monkeypatch.setattr(sr, '_PLUGIN_ROOT', root)
    before = source.read_bytes()
    assert sr._db_path({'state_dir':''}) == source
    assert source.read_bytes() == before
    assert not target.parent.exists()
    with sqlite3.connect(source) as db:
        db.execute("INSERT INTO sample VALUES ('after-dashboard')")
    assert sr._db_path({'state_dir':''}) == source
    assert rows(source) == [('before-dashboard',), ('after-dashboard',)]
    assert not target.exists()
    state_dir.initialize_state_dir('', root)
    assert rows(target) == rows(source)
    assert sr._db_path({'state_dir':''}) == target


def test_readonly_path_without_database_creates_no_profile_directories(paths):
    root, _, target = paths
    assert state_dir.resolve_state_dir('', root) == target.parent
    assert not target.parent.exists()


def test_disabled_registration_does_not_initialize_or_migrate_storage(paths, monkeypatch):
    import autorouter as plugin
    root, source, target = paths
    seed(source, 'legacy')
    monkeypatch.setattr(plugin, '_plugin_root', lambda:root)
    class Context:
        def get_config(self,key,default=None): return False if key=='enabled' else default
    plugin.register(Context())
    assert not target.parent.exists()
    assert state_dir.resolve_state_dir('', root) == source.parent
