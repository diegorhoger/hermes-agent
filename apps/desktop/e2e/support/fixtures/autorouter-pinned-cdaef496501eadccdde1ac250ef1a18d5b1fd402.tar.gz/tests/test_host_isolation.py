"""Exercise actual socket/process/file APIs against the host-test sandbox."""
import json
import os
from pathlib import Path
import subprocess
import sys


def test_host_acceptance_sandbox_denies_external_effects(tmp_path):
    private = tmp_path / "private-hermes"
    private.mkdir()
    (private / "sentinel").write_text("MUST_NOT_BE_READ")
    home = tmp_path / "home"
    home.mkdir()
    output = tmp_path / "result.json"
    worker = Path(__file__).parent / "integration" / "host_worker.py"
    result = subprocess.run([sys.executable, str(worker), str(output), "guards"],
        env={"HOME": str(home), "PATH": os.environ.get("PATH", ""),
             "AUTOROUTER_FORBIDDEN_HERMES_HOME": str(private)},
        cwd=tmp_path, capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stderr
    assert "MUST_NOT_BE_READ" not in result.stdout + result.stderr + output.read_text()
    blocked = set(json.loads(output.read_text())["blocked"])
    assert {"private_file", "private_directory", "child_process", "dns", "bind", "connect", "sendto"} <= blocked
    import socket
    if hasattr(socket.socket, "sendmsg"):
        assert "sendmsg" in blocked
