"""PR56 link regressions: local-only, no remote repository access."""
import importlib.util
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('adr_link_checker',ROOT/'tools/check_adrs.py')
checker=importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)


class ADRLinkRegressionTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        shutil.copytree(ROOT/'docs/internal/adr',self.root/'docs/internal/adr')
        shutil.copyfile(ROOT/'docs/internal/glossary.md',self.root/'docs/internal/glossary.md')

    def append(self,text):
        path=self.root/'docs/internal/adr/backlog.md'
        path.write_text(path.read_text()+'\n'+text+'\n')

    def test_current_register_is_clean(self):
        self.assertEqual(checker.check(self.root),[])

    def test_reported_nested_links_are_rejected(self):
        for label,number,repository in [('Epic',37,'diegorhoger/autorouter'),
                ('PR',36,'diegorhoger/autorouter'),('PR',52,'diegorhoger/autorouter'),
                ('PR',53,'diegorhoger/autorouter'),('Hermes PR',150317,'NousResearch/hermes-agent')]:
            with self.subTest(label=label,number=number):
                path=self.root/'docs/internal/adr/backlog.md'
                before=path.read_text()
                self.append(f'[{label} [#{number}](https://github.com/diegorhoger/autorouter/issues/{number})](https://github.com/{repository}/pull/{number})')
                self.assertIn('backlog.md: nested Markdown link',checker.check(self.root))
                path.write_text(before)

    def test_ordinary_single_links_are_allowed(self):
        self.append('[Epic #37](https://github.com/diegorhoger/autorouter/issues/37) '
                    '[Hermes PR #150317](https://github.com/NousResearch/hermes-agent/pull/150317)')
        self.assertEqual(checker.check(self.root),[])

    def test_missing_local_target_is_still_rejected(self):
        self.append('[Missing](not-present.md)')
        self.assertIn('backlog.md: missing/unsafe local link',checker.check(self.root))


if __name__=='__main__':
    unittest.main()
