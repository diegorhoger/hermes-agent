"""Scoped descriptive evidence is an additional fail-closed gate."""
import copy
import json
import pytest
from autorouter.autorouter_core.discovery import metadata as md
from autorouter.autorouter_core.evidence import evidence as ev
from autorouter.autorouter_core.storage import state


def proof(**changes):
    record = dict(provider='p', model='m', scope='model', classification='VERIFIED_ZERO_PRICE_MODEL',
                  source_url='https://provider.example/models', source_type='provider_api', issuer='p',
                  source_of_truth=True, observed_at=100, expires_at=200, currency='USD',
                  prices={'prompt': '0', 'completion': '0'})
    record.update(changes)
    return record


def test_zero_price_and_scope():
    assert ev.access_allowed([proof()], 'p', 'm', 150)
    assert not ev.access_allowed([proof(scope='provider', model=None)], 'p', 'm', 150)
    for classification in ev.CLASSIFICATIONS - ev.FREE:
        assert not ev.access_allowed([proof(classification=classification)], 'p', 'm', 150)
    assert not ev.access_allowed([proof(), proof(classification='PAID_ONLY')], 'p', 'm', 150)


@pytest.mark.parametrize('changes', [
    {'prices': None}, {'prices': {'prompt': '0'}}, {'prices': {'prompt': '0', 'completion': 'NaN'}},
    {'prices': {'prompt': '0', 'completion': '-1'}}, {'prices': {'prompt': '0', 'completion': '0', 'image': '1'}},
    {'currency': 'EUR'}, {'expires_at': 150}, {'observed_at': 151}, {'source_of_truth': False},
    {'source_url': 'https://user:secret@provider.example'}, {'source_url': 'unknown'},
    {'classification': 'DEPRECATED'}, {'credits_exhausted': True}, {'account_scope': 'account-A'},
    {'regions': ['eu']}, {'scope': 'account'}, {'model': 'other'}, {'provider': 'other'},
])
def test_invalid_stale_restricted_or_paid_denied(changes):
    assert not ev.access_allowed([proof(**changes)], 'p', 'm', 150)


def test_account_region_isolation():
    records = [proof(account_scope='account-A', regions=['eu'])]
    assert ev.access_allowed(records, 'p', 'm', 150, account_scope='account-A', region='eu')
    assert not ev.access_allowed(records, 'p', 'm', 150, account_scope='account-B', region='eu')
    assert not ev.access_allowed(records, 'p', 'm', 150, account_scope='account-A', region='us')


def test_partial_refresh_keeps_original_access_provenance():
    old = md.normalize_openrouter({'data': [dict(id='m', pricing={'prompt': '0', 'completion': '0'},
                                               context_length=8192, supported_parameters=['tools'])]}, 100)['m']
    original = copy.deepcopy(old['access_evidence'])
    partial = md.normalize_openrouter({'data': [dict(id='m', context_length=16384)]}, 150)['m']
    merged = md.merge_metadata(partial, old, 151)
    assert merged['access_evidence'] == original
    assert md.verified_fields(merged, 'openrouter', 'm', 151)[0]['cost_tier'] == 'free'
    assert md.verified_fields(merged, 'openrouter', 'm', 100000)[0]['cost_tier'] == 'unknown'
    refreshed = md.normalize_openrouter({'data': [dict(id='m', pricing={'prompt': '0.01', 'completion': '0'})]}, 160)['m']
    assert md.verified_fields(md.merge_metadata(refreshed, merged, 161), 'openrouter', 'm', 161)[0]['cost_tier'] != 'free'


def test_evidence_stored_in_legacy_capability_json(tmp_path):
    store = state.StateStore(tmp_path / 'legacy.db')
    cap = md.normalize_openrouter({'data': [dict(id='m', pricing={'prompt': '0', 'completion': '0'},
                                               context_length=8192, supported_parameters=['tools'])]}, 100)['m']
    store.upsert_capability('openrouter', 'm', json.dumps(cap))
    loaded = json.loads(store.get_capability('openrouter', 'm')['capability_json'])
    assert loaded['access_evidence'] == cap['access_evidence']
    assert md.verified_fields(loaded, 'openrouter', 'm', 150)[0]['cost_tier'] == 'free'
    loaded['access_evidence'][0]['classification'] = 'TRIAL'
    assert md.verified_fields(loaded, 'openrouter', 'm', 150)[0]['cost_tier'] == 'unknown'


def test_missing_evidence_and_unknown_policies():
    assert not ev.access_allowed([], 'p', 'm', 150)
    normalized = ev.normalize_evidence(proof(raw_key='secret'))
    assert 'raw_key' not in normalized
    for name in ('payment_required', 'kyc_required', 'logging_policy', 'training_policy'):
        assert normalized[name] is None


def test_typed_resolver_preserves_evidence_and_denies_trial():
    from autorouter.autorouter_core.configuration.capabilities import ModelCapabilities, resolve_capabilities
    raw = dict(provider='p', model='m', cost_tier='free', retrieved_at=100, expires_at=200,
               access_evidence=[proof()])
    assert ModelCapabilities.from_dict(raw).to_dict()['access_evidence'] == raw['access_evidence']
    assert resolve_capabilities(raw, None, None, now=150).cost_tier == 'free'
    raw['access_evidence'][0]['classification'] = 'TRIAL'
    assert resolve_capabilities(raw, None, None, now=150).cost_tier == 'unknown'
    assert not ev.access_allowed([proof(classification=[])], 'p', 'm', 150)


@pytest.mark.parametrize('restriction', [
    dict(scope='provider', model=None, classification='DEPRECATED'),
    dict(scope='account', account_scope='account-A', classification='TRIAL'),
    dict(scope='account', account_scope='account-A', credits_exhausted=True),
])
def test_public_price_refresh_preserves_independent_restrictions(restriction):
    old = md.normalize_openrouter({'data': [dict(id='m', pricing={'prompt': '0', 'completion': '0'},
                                               context_length=8192, supported_parameters=['tools'])]}, 100)['m']
    denial = proof(provider='openrouter', source_url='https://provider.example/account', **restriction)
    old['access_evidence'].append(denial)
    fresh = md.normalize_openrouter({'data': [dict(id='m', pricing={'prompt': '0', 'completion': '0'})]}, 150)['m']
    merged = md.merge_metadata(fresh, old, 151)
    assert denial in merged['access_evidence']
    assert len(merged['access_evidence']) == 2  # refreshed model proof replaces only its own record
    assert merged['access_evidence'][0]['observed_at'] == 100
    assert not ev.access_allowed(merged['access_evidence'], 'openrouter', 'm', 151, account_scope='account-A')
    assert md.verified_fields(merged, 'openrouter', 'm', 151)[0]['cost_tier'] == 'unknown'
    # Another public refresh cannot renew the independent account/provider source.
    assert md.merge_metadata(fresh, merged, 201)['access_evidence'][0]['expires_at'] == 200


def test_explicit_null_evidence_round_trip_stays_denied():
    from autorouter.autorouter_core.configuration.capabilities import ModelCapabilities
    raw = dict(provider='p', model='m', cost_tier='free', context_window=8192,
               tools='supported', metadata_source='fixture', retrieved_at=100, expires_at=200)
    assert 'access_evidence' not in ModelCapabilities.from_dict(raw).to_dict()
    raw['access_evidence'] = None
    roundtrip = ModelCapabilities.from_dict(raw).to_dict()
    assert roundtrip['access_evidence'] == []
    assert md.verified_fields(raw, 'p', 'm', 150)[0]['cost_tier'] == 'unknown'
    assert md.verified_fields(roundtrip, 'p', 'm', 150)[0]['cost_tier'] == 'unknown'
