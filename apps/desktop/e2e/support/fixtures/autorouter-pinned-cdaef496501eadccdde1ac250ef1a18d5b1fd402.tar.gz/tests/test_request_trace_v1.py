"""Trace evidence and observer isolation, without a fabricated apply receipt."""

import json
import pytest
from autorouter.autorouter_core.integration import runtime
from autorouter.autorouter_core.storage import state
from autorouter.autorouter_core.telemetry import request_trace as trace
from tests.test_dashboard_state_reader import sr


@pytest.fixture
def observed(tmp_path, monkeypatch):
    store = state.StateStore(tmp_path)
    monkeypatch.setattr(runtime, "get_store", lambda: store)
    monkeypatch.setattr(runtime, "get_router", lambda: None)
    return store


def event(**extra):
    return dict(
        api_request_id="host-id",
        session_id="private-session",
        task_id="private-task",
        turn_id="private-turn",
        provider="nvidia",
        model="m",
        retry_count=0,
        **extra,
    )


def project(store, identity="host-id"):
    rid = store.find_request_by_api_id(identity)
    return trace.build(store.get_request(rid), store.get_request_attempts(rid))


@pytest.mark.parametrize(
    "field,value",
    [
        ("session_id", "other"),
        ("session_id", None),
        ("task_id", "other"),
        ("turn_id", "other"),
    ],
)
def test_mismatched_callback_cannot_mutate_original_lifecycle(observed, field, value):
    runtime.on_pre_api_request(**event())
    before = observed.db_path.read_bytes()
    wrong = event()
    wrong[field] = value
    runtime.on_post_api_request(**wrong, usage={"input_tokens": 99})
    assert observed.db_path.read_bytes() == before
    assert project(observed)["completion"]["state"] == "pending_or_unknown"
    runtime.on_post_api_request(**event(), usage={"input_tokens": 0})
    out = project(observed)
    assert out["completion"]["outcome"] == "success"
    assert out["metrics"]["input_tokens"] == {"state": "observed", "value": 0}
    assert out["metrics"]["output_tokens"] == {"state": "unavailable", "value": None}


def test_repeated_attempt_is_immutable_and_terminal_count_is_single(observed):
    runtime.on_pre_api_request(**event())
    runtime.on_api_request_error(
        **event(), status_code=429, retryable=True, max_retries=2
    )
    rid = observed.find_request_by_api_id("host-id")
    first = observed.get_request_attempts(rid)
    changed = event()
    changed["model"] = "different"
    runtime.on_api_request_error(
        **changed, status_code=503, retryable=True, max_retries=2
    )
    assert observed.get_request_attempts(rid) == first
    final = event()
    final["retry_count"] = 1
    runtime.on_post_api_request(**final, usage={"output_tokens": 0})
    before = observed.db_path.read_bytes()
    runtime.on_post_api_request(**final, usage={"output_tokens": 100})
    assert observed.db_path.read_bytes() == before
    out = project(observed)
    assert out["attempts"]["observed_count"] == 2
    assert out["metrics"]["output_tokens"]["value"] == 0
    assert out["end_to_end_correlation"] == "unavailable"
    with observed._connect() as conn:
        assert (
            conn.execute("SELECT SUM(total_requests) FROM request_hourly").fetchone()[0]
            == 1
        )


def test_changed_account_permanently_loses_specific_attribution(observed):
    runtime.on_pre_api_request(**event(credential_scope="A"))
    runtime.on_api_request_error(
        **event(credential_scope="B"), status_code=429, retryable=True, max_retries=2
    )
    final = event(credential_scope="A")
    final["retry_count"] = 1
    runtime.on_post_api_request(**final)
    out = project(observed)
    assert out["request"]["account_scope"] == "unknown"
    assert not out["request"]["active_account_authority"]


@pytest.mark.parametrize("status", ["success", "error", "canceled"])
def test_completion_before_pre_does_not_reopen_or_invent_decision(observed, status):
    terminal = event()
    terminal["retry_count"] = 2
    if status == "error":
        runtime.on_api_request_error(**terminal, status_code=500, retryable=False)
    else:
        runtime.on_post_api_request(**terminal, status=status)
    before = observed.db_path.read_bytes()
    runtime.on_pre_api_request(**event())
    runtime.on_api_request_error(**event(), status_code=401, retryable=False)
    assert observed.db_path.read_bytes() == before
    out = project(observed)
    assert out["completion"]["outcome"] == status
    assert out["attempts"]["completeness"] == "partial_or_unavailable"
    assert out["decision"]["state"] == out["apply"]["state"] == "unavailable"


def test_trace_does_not_serialize_identity_content_or_infer_target(observed):
    runtime.on_pre_api_request(**event())
    changed = event()
    changed["model"] = "other-model"
    runtime.on_post_api_request(
        **changed,
        response_model="served-alias",
        request="SECRET-PROMPT",
        response="SECRET-RESPONSE",
    )
    out = project(observed)
    assert out["attempts"]["target_consistency"] == "different_observed_target"
    text = json.dumps(out)
    assert not any(
        s in text
        for s in (
            "private-session",
            "private-task",
            "private-turn",
            "host-id",
            "SECRET",
            "served-alias",
        )
    )
    assert not out["execution_authority"]


@pytest.mark.parametrize(
    "value", [None, True, -1, float("inf"), float("nan"), "SECRET"]
)
def test_bad_metrics_stay_unavailable(value):
    out = trace.build(
        {"status": "pending", "input_tokens": value, "latency_ms": value}, []
    )
    assert all(m["state"] == "unavailable" for m in out["metrics"].values())
    assert out["request"]["identity"] == "unavailable"


def test_readonly_detail_projects_bounded_trace_and_retains_unknown(
    tmp_path, monkeypatch
):
    store = state.StateStore(tmp_path)
    rid = store.begin_request(api_request_id="local-test", provider="nvidia", model="m")
    for n in range(103):
        store.record_attempt(rid, n, provider="nvidia", model="m")
    store.finish_request(rid, output_tokens=0)
    before = store.db_path.read_bytes()
    detail = sr._assemble_request_detail(store.db_path, rid, 100)
    assert len(detail["attempts"]) == 100
    assert detail["trace"]["attempts"]["truncated"] is True
    assert detail["trace"]["metrics"]["input_tokens"]["value"] is None
    assert detail["trace"]["metrics"]["output_tokens"]["value"] == 0
    assert store.db_path.read_bytes() == before


@pytest.mark.parametrize("model", ["org/" + "a" * 160, "org/" + "a" * 170])
def test_dashboard_target_comparison_uses_raw_bounded_rows_before_scrub(
    tmp_path, model
):
    store = state.StateStore(tmp_path)
    rid = store.begin_request(
        api_request_id="long-target", provider="nvidia", model=model
    )
    store.record_attempt(rid, 0, provider="nvidia", model=model)
    store.finish_request(rid)
    before = store.db_path.read_bytes()
    direct = trace.build(store.get_request(rid), store.get_request_attempts(rid))
    display = sr._assemble_request_detail(store.db_path, rid, 100)
    assert display["trace"] == direct
    assert direct["attempts"]["target_consistency"] == "matching_observed_target"
    assert len(display["attempts"][0]["model"]) <= 161
    assert store.db_path.read_bytes() == before


@pytest.mark.parametrize("with_pre", [False, True])
@pytest.mark.parametrize("error_hook", [False, True])
def test_cancellation_is_terminal_without_health_or_quota_accounting(
    observed, monkeypatch, with_pre, error_hook
):
    from types import SimpleNamespace
    from autorouter.autorouter_core.evidence import free_access

    health = []
    invalidations = []
    monkeypatch.setattr(
        runtime,
        "get_router",
        lambda: SimpleNamespace(record_outcome=lambda **kw: health.append(kw)),
    )
    monkeypatch.setattr(
        free_access, "invalidate_cached", lambda *a, **kw: invalidations.append((a, kw))
    )
    if with_pre:
        runtime.on_pre_api_request(**event())
    callback = (
        runtime.on_api_request_error if error_hook else runtime.on_post_api_request
    )
    callback(**event(), status="canceled", retryable=True, max_retries=2)
    assert project(observed)["completion"]["outcome"] == "canceled"
    assert not health and not invalidations
    with observed._connect() as db:
        row = db.execute(
            "SELECT success_count,error_count,canceled_count FROM request_hourly"
        ).fetchone()
        assert tuple(row) == (0, 0, 1)
