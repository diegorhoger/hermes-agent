"""Nous Portal read-only catalog fixtures: no network, no real credentials."""
import json
import time
from types import SimpleNamespace
from urllib.error import HTTPError, URLError
import pytest
from autorouter.autorouter_core.discovery import adapters as ad, discovery, nous_catalog
from autorouter.autorouter_core.storage import state

import time as _time
NOW = int(_time.time())


def _pool(entries):
    return entries


def _entry(**overrides):
    base = dict(access_token='fixture-access-token', agent_key='fixture-agent-key',
                refresh_token='fixture-refresh-token', inference_base_url='https://inference-api.nousresearch.com/v1',
                agent_key_expires_at='2099-01-01T00:00:00+00:00', expires_at='2099-01-01T00:00:00+00:00')
    base.update(overrides)
    return base


def test_credential_missing_yields_no_models(monkeypatch):
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p: [])
    with pytest.raises(ad.DiscoveryError, match='credential_missing'):
        nous_catalog.fetch_catalog(now=NOW)


def test_expired_credential_yields_no_models(monkeypatch):
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool',
                        lambda p: [_entry(agent_key_expires_at='2001-01-01T00:00:00+00:00',
                                          expires_at='2001-01-01T00:00:00+00:00')])
    with pytest.raises(ad.DiscoveryError, match='credential_missing'):
        nous_catalog.fetch_catalog(now=NOW)


def test_unparseable_expiry_is_rejected(monkeypatch):
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool',
                        lambda p: [_entry(agent_key_expires_at='not-a-date', expires_at='not-a-date')])
    with pytest.raises(ad.DiscoveryError, match='credential_missing'):
        nous_catalog.fetch_catalog(now=NOW)


def test_auth_store_error_is_classified_without_secret(monkeypatch):
    def boom(provider):
        raise RuntimeError('secret-material-leak-test')
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', boom)
    with pytest.raises(ad.DiscoveryError, match='credential_unavailable') as error:
        nous_catalog.fetch_catalog(now=NOW)
    assert 'secret-material-leak-test' not in str(error.value)


def test_bearer_is_never_placed_in_url_and_no_redirect_forward(monkeypatch):
    calls = []
    def fetch(url, headers):
        calls.append((url, headers)); return {'data': [{'id': 'vendor/model', 'context_length': 131072}]}
    monkeypatch.setattr(nous_catalog, '_read_json', fetch)
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p: [_entry()])
    rows = nous_catalog.fetch_catalog(now=NOW)
    assert 'fixture-agent-key' not in calls[0][0]
    assert calls[0][1]['Authorization'] == 'Bearer fixture-agent-key'
    assert calls[0][0] == 'https://inference-api.nousresearch.com/v1/models'
    assert rows['vendor/model']['context_window'] == 131072


def test_token_rejected_when_malformed(monkeypatch):
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool',
                        lambda p: [_entry(agent_key='has space\nand newline', access_token='has space\nand newline')])
    with pytest.raises(ad.DiscoveryError, match='credential_missing'):
        nous_catalog.fetch_catalog(now=NOW)


def test_zero_priced_rows_are_price_metadata_never_entitlement_guarantee(monkeypatch):
    payload = {'data': [
        {'id': 'vendor/free-model', 'context_length': 8192,
         'supported_parameters': ['tools', 'reasoning'],
         'pricing': {'prompt': '0', 'completion': '0', 'image': '0'}},
        {'id': 'vendor/paid-model', 'context_length': 32768,
         'supported_parameters': ['tools'],
         'pricing': {'prompt': '0.0000015', 'completion': '0.0000075'}},
        {'id': 'vendor/unknown-cost-model', 'context_length': 4096,
         'supported_parameters': []},
    ]}
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p: [_entry()])
    monkeypatch.setattr(nous_catalog, '_read_json', lambda url, headers: payload)
    rows = nous_catalog.fetch_catalog(now=NOW)
    assert rows['vendor/free-model']['cost_tier'] == 'free'
    assert rows['vendor/paid-model']['cost_tier'] == 'paid'
    assert rows['vendor/unknown-cost-model']['cost_tier'] == 'unknown'
    caps = rows['vendor/free-model']
    assert caps['access_evidence'][0]['classification'] == 'VERIFIED_ZERO_PRICE_MODEL'
    assert caps['access_evidence'][0]['prices'] == {'prompt': '0', 'completion': '0', 'image': '0'}
    # A zero-price label is published price metadata, never a billing guarantee:
    assert caps['pricing_status'] == 'free'
    assert all('no-charge' not in json.dumps(row).lower() and 'guarantee' not in json.dumps(row).lower()
               for row in rows.values())


def test_tools_field_mirrors_openrouter_evidence_vocabulary(monkeypatch):
    payload = {'data': [
        {'id': 'vendor/a', 'context_length': 8192, 'supported_parameters': ['tools']},
        {'id': 'vendor/b', 'context_length': 8192, 'supported_parameters': ['reasoning']},
        {'id': 'vendor/c', 'context_length': 8192},
    ]}
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p: [_entry()])
    monkeypatch.setattr(nous_catalog, '_read_json', lambda *a: payload)
    rows = nous_catalog.fetch_catalog(now=NOW)
    assert rows['vendor/a']['tools'] == 'supported'
    assert rows['vendor/b']['tools'] == 'unsupported'
    assert rows['vendor/c']['tools'] == 'unknown'


def test_malformed_catalog_is_rejected_without_secret(monkeypatch):
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p: [_entry()])
    for payload in [{}, {'data': None}, {'data': [None]},
                    {'data': [{'id': 'same'}, {'id': 'same'}]},
                    {'data': [{'id': 'sk-secretsecretsecret'}]}]:
        monkeypatch.setattr(nous_catalog, '_read_json', lambda *a: payload)
        with pytest.raises(ad.DiscoveryError) as error:
            nous_catalog.fetch_catalog(now=NOW)
        assert 'sk-secretsecretsecret' not in str(error.value)


@pytest.mark.parametrize('code,category', [(401, 'authentication'), (403, 'authentication'),
                                           (429, 'rate_limited'), (500, 'provider_unavailable'), (302, 'http_error')])
def test_transport_status_redaction(code, category, monkeypatch):
    def fail(*args, **kwargs):
        raise HTTPError('https://secret.invalid?api_key=secret', code, 'Bearer sensitive-secret', {}, None)
    monkeypatch.setattr(ad, 'build_opener', lambda *a: SimpleNamespace(open=fail))
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p: [_entry()])
    with pytest.raises(ad.DiscoveryError) as error:
        nous_catalog.fetch_catalog(now=NOW)
    assert str(error.value) == category


def test_transport_error_is_classified(monkeypatch):
    def fail(*args, **kwargs): raise URLError('secret')
    monkeypatch.setattr(ad, 'build_opener', lambda *a: SimpleNamespace(open=fail))
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p: [_entry()])
    with pytest.raises(ad.DiscoveryError, match='transport_error'):
        nous_catalog.fetch_catalog(now=NOW)


def test_discovery_wires_nous_without_network(monkeypatch):
    table = {'a-model': dict(provider='nous', model='a-model', context_window=16384,
                             tools='supported', cost_tier='free', discovery_status='discovered',
                             metadata_source=nous_catalog.NOUS_MODELS_URL,
                             retrieved_at=NOW, expires_at=NOW + 86400,
                             discovery_evidence=dict(metadata_source=nous_catalog.NOUS_MODELS_URL,
                                                     retrieved_at=NOW, expires_at=NOW + 86400),
                             supplied_fields=['context_window', 'tools', 'cost_tier'])}
    monkeypatch.setattr(discovery, 'nous_catalog', SimpleNamespace(
        fetch_catalog=lambda: table, NOUS_MODELS_URL=nous_catalog.NOUS_MODELS_URL,
        DiscoveryError=ad.DiscoveryError))
    rows = discovery.discover_provider('nous')
    assert [r['model'] for r in rows] == ['a-model']
    assert rows[0]['cost_tier'] == 'free' and rows[0]['context_length'] == 16384


def test_discovery_nous_failure_preserves_existing_catalog(monkeypatch):
    def fail():
        raise ad.DiscoveryError('authentication')
    monkeypatch.setattr(discovery, 'nous_catalog', SimpleNamespace(
        fetch_catalog=fail, NOUS_MODELS_URL=nous_catalog.NOUS_MODELS_URL,
        DiscoveryError=ad.DiscoveryError))
    assert discovery.discover_provider('nous') == []


def test_connections_identify_nous_oauth_presence(monkeypatch):
    from autorouter.autorouter_core.providers import connections
    cfg = {'available': True, 'values': {'providers': ['nous']}}
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p: [_entry()])
    rows = {r['provider_id']: r for r in connections.inventory(cfg)['connections']}
    nous = rows['nous']
    assert nous['presence'] == 'configured'
    assert nous['verification'] == 'unverified'
    assert nous['authentication_requirement'] == 'oauth_portal'
    assert nous['credential_source_scope'] == 'hermes_oauth_store'
    assert nous['masked_credential'] == '••••••••'
    assert 'fixture-agent-key' not in json.dumps(nous)
    assert nous['id'] == 'hermes-oauth:nous'


def test_connections_nous_missing_oauth_state(monkeypatch):
    from autorouter.autorouter_core.providers import connections
    cfg = {'available': True, 'values': {'providers': ['nous']}}
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p: [])
    rows = {r['provider_id']: r for r in connections.inventory(cfg)['connections']}
    assert rows['nous']['presence'] == 'not_observed'
    assert rows['nous']['masked_credential'] is None


def test_connections_nous_presence_error_is_unknown_not_false(monkeypatch):
    from autorouter.autorouter_core.providers import connections
    cfg = {'available': True, 'values': {'providers': ['nous']}}
    def boom(p):
        raise RuntimeError('host-secret')
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', boom)
    rows = {r['provider_id']: r for r in connections.inventory(cfg)['connections']}
    assert rows['nous']['presence'] == 'unknown'
    assert rows['nous']['reason'] == 'host_presence_unavailable'
    assert 'host-secret' not in json.dumps(rows['nous'])


def test_connections_environment_slot_never_used_for_nous(monkeypatch):
    from autorouter.autorouter_core.providers import connections
    assert connections.PROVIDERS['nous'][1] is None
    assert connections._nous_oauth_presence.__doc__ is not None


def test_provider_intelligence_counts_nous_adapter():
    from autorouter.autorouter_core.providers import provider_intelligence as pi
    result = pi.registry_details([], [])
    assert 'nous' in result['discovery_adapters']
    assert result['discovery_adapter_count'] == 6


def test_empty_catalog_data_list_is_valid_not_malformed():
    assert nous_catalog.normalize({'data': []}, NOW) == {}


def test_all_invalid_rows_are_malformed():
    with pytest.raises(ad.DiscoveryError, match='malformed_catalog'):
        nous_catalog.normalize({'data': [{'id': '~alias-only'}, {'id': '~other'}]}, NOW)


HOSTILE_BASE_URLS = [
    'https://evil.com/v1',
    'https://inference-api.nousresearch.com.evil.com/v1',
    'https://evil.com?x=@inference-api.nousresearch.com/v1',
    'https://inference-api.nousresearch.com@evil.com/v1',
    'https://user:pass@inference-api.nousresearch.com/v1',
    'https://user@inference-api.nousresearch.com/v1',
    'https://inference-api.nousresearch.com:8080/v1',
    'https://inference-api.nousresearch.com:443/v1',
    'https://inference-api.nousresearch.com/v1?api_key=leak',
    'https://inference-api.nousresearch.com/v1#fragment',
    'https://inference-api.nousresearch.com/v1/models',
    'https://inference-api.nousresearch.com/v1/../admin',
    'https://inference-api.nousresearch.com/',
    'https://inference-api.nousresearch.com',
    'http://inference-api.nousresearch.com/v1',
    'ftp://inference-api.nousresearch.com/v1',
    'https://inference-api.nousresearch.cοm/v1',
    'https://inference_api.nousresearch.com/v1',
    'https://inference-api.nousresearch.com/v1%2e%2e/admin',
    '//inference-api.nousresearch.com/v1',
    'https://inference-api.nousresearch.com/v1 ',
]


@pytest.mark.parametrize('hostile', HOSTILE_BASE_URLS)
def test_hostile_base_url_is_rejected_without_http(hostile, monkeypatch):
    calls = []
    monkeypatch.setattr(nous_catalog, '_read_json',
                        lambda *a, **k: calls.append((a, k)) or {'data': []})
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool',
                        lambda p: [_entry(inference_base_url=hostile)])
    with pytest.raises(ad.DiscoveryError, match='unexpected_base_url'):
        nous_catalog.fetch_catalog(now=NOW)
    assert calls == []


@pytest.mark.parametrize('malformed', [123, 1.5, True, ['https://inference-api.nousresearch.com/v1'],
                                       {'url': 'https://inference-api.nousresearch.com/v1'},
                                       b'https://inference-api.nousresearch.com/v1',
                                       '   ', 'https://inference-api.nousresearch.com/v1\x00evil'])
def test_malformed_base_url_state_is_rejected_without_http(malformed, monkeypatch):
    calls = []
    monkeypatch.setattr(nous_catalog, '_read_json',
                        lambda *a, **k: calls.append((a, k)) or {'data': []})
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool',
                        lambda p: [_entry(inference_base_url=malformed)])
    with pytest.raises(ad.DiscoveryError, match='unexpected_base_url'):
        nous_catalog.fetch_catalog(now=NOW)
    assert calls == []


def test_canonical_base_url_with_trailing_slash_is_accepted(monkeypatch):
    calls = []
    monkeypatch.setattr(nous_catalog, '_read_json',
                        lambda url, headers: calls.append((url, headers)) or {'data': []})
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool',
                        lambda p: [_entry(inference_base_url='https://inference-api.nousresearch.com/v1/')])
    assert nous_catalog.fetch_catalog(now=NOW) == {}
    assert calls[0][0] == 'https://inference-api.nousresearch.com/v1/models'


def test_absent_base_url_uses_fixed_endpoint(monkeypatch):
    calls = []
    monkeypatch.setattr(nous_catalog, '_read_json',
                        lambda url, headers: calls.append((url, headers)) or {'data': []})
    entry = _entry()
    del entry['inference_base_url']
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p: [entry])
    assert nous_catalog.fetch_catalog(now=NOW) == {}
    assert calls[0][0] == 'https://inference-api.nousresearch.com/v1/models'


def test_bearer_never_reaches_url_even_for_canonical_state(monkeypatch):
    calls = []
    monkeypatch.setattr(nous_catalog, '_read_json',
                        lambda url, headers: calls.append((url, headers)) or {'data': []})
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool',
                        lambda p: [_entry(inference_base_url='https://inference-api.nousresearch.com/v1')])
    nous_catalog.fetch_catalog(now=NOW)
    url, headers = calls[0]
    assert 'fixture-agent-key' not in url
    assert 'fixture-access-token' not in url
    assert headers['Authorization'] == 'Bearer fixture-agent-key'


def test_malformed_auth_state_types_are_rejected(monkeypatch):
    calls = []
    monkeypatch.setattr(nous_catalog, '_read_json',
                        lambda *a, **k: calls.append((a, k)) or {'data': []})
    for entries in [None, 'not-a-list', 42, {}, ['not-a-dict'], [123], [None]]:
        monkeypatch.setattr('hermes_cli.auth.read_credential_pool', lambda p, e=entries: e)
        with pytest.raises(ad.DiscoveryError):
            nous_catalog.fetch_catalog(now=NOW)
    assert calls == []


def test_rejection_does_not_log_bearer(monkeypatch, caplog):
    monkeypatch.setattr(nous_catalog, '_read_json',
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError('HTTP must not occur')))
    monkeypatch.setattr('hermes_cli.auth.read_credential_pool',
                        lambda p: [_entry(inference_base_url='https://evil.example/v1')])
    with caplog.at_level('DEBUG'):
        with pytest.raises(ad.DiscoveryError, match='unexpected_base_url'):
            nous_catalog.fetch_catalog(now=NOW)
    assert 'fixture-agent-key' not in caplog.text
    assert 'fixture-access-token' not in caplog.text
