"""Quota fixtures are source claims unless explicitly marked test observations."""
import json
import pytest
from autorouter.autorouter_core.configuration import capabilities
from autorouter.autorouter_core.discovery import metadata
from autorouter.autorouter_core.evidence import quota as q
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.storage import state

NOW = 1000


def credit(**changes):
    return dict(provider='p', model=None, account_scope='opaque-test-account', dimension='credits',
        remaining='1', currency='USD', window='one_time', source='provider_api',
        source_url='https://provider.example/account', source_type='provider_api', issuer='p',
        source_of_truth=True, observed_at=900, expires_at=1100, spendable=True, **changes)


def pricing(**changes):
    out = dict(provider='p', model='m', scope='model', currency='USD',
        prices={'prompt': '0.000001', 'completion': '0.000003'},
        source_url='https://provider.example/models', source_type='provider_api', issuer='p',
        source_of_truth=True, observed_at=900, expires_at=1100)
    out.update(changes)
    return out


def test_projection_decimal_floor_and_formula():
    out = q.estimate_credit_tokens(credit(), pricing(), input_share='0.75', workload_source='operator selected 75% input', now=NOW)
    assert out['tokens'] == 666666
    assert out['state'] == 'estimated'
    assert out['recurring'] is False
    assert out['spendable_credit'] == '1'
    assert out['input_price_per_token'] == '0.000001'
    assert 'floor' in out['formula']
    assert q.estimate_credit_tokens(dict(credit(), remaining='0'), pricing(), input_share=1, workload_source='all input', now=NOW)['tokens'] == 0


@pytest.mark.parametrize('mutate', [
    lambda c,p: c.update(remaining=None), lambda c,p: c.update(spendable=False),
    lambda c,p: c.update(currency='EUR'), lambda c,p: c.update(expires_at=999),
    lambda c,p: c.update(grant_expires_at=999), lambda c,p: c.update(reset_at=999),
    lambda c,p: c.update(source='advertised'), lambda c,p: c.update(account_scope=None),
    lambda c,p: p.update(model=None), lambda c,p: p.update(scope='provider'),
    lambda c,p: p.update(expires_at=999), lambda c,p: p.update(prices={'prompt':'0','completion':'0'}),
    lambda c,p: p.update(prices={'prompt':'1'}), lambda c,p: p.update(prices={'prompt':'1','completion':'2','request':'1'}),
    lambda c,p: p.update(prices={'prompt':'NaN','completion':'2'}),
    lambda c,p: p.update(account_scope='another-account'), lambda c,p: c.update(model='other'),
])
def test_missing_or_conflicting_inputs_are_unknown(mutate):
    c,p = credit(),pricing()
    mutate(c,p)
    assert q.estimate_credit_tokens(c,p,input_share='.5',workload_source='test mix',now=NOW)['tokens'] is None


@pytest.mark.parametrize('share,source', [(None,'test'), ('NaN','test'), ('-1','test'), ('1.1','test'), ('.5','')])
def test_invalid_workload_is_unknown(share, source):
    assert q.estimate_credit_tokens(credit(),pricing(),input_share=share,workload_source=source,now=NOW)['state'] == 'unknown'


@pytest.mark.parametrize('provider,dimension,limit,window,extra', [
    ('groq','aggregate_tokens','200000','day',{'model':'chat-model'}),
    ('internlm','input_tokens','1000000','month',{}),
    ('internlm','output_tokens','3000000','month',{}),
    ('openrouter','requests','20','minute',{}),
    ('openrouter','requests','200','day',{}),
    ('cohere','requests','1000','month',{}),
    ('deepseek','aggregate_tokens','5000000','one_time',{'signup_required':True}),
    ('longcat','aggregate_tokens','10000000','one_time',{'kyc_required':True}),
    ('scaleway','aggregate_tokens','1000000','one_time',{'signup_required':True}),
    ('freemodel.dev','credits','300','one_time',{'currency':'USD'}),
    ('agentrouter','credits','200','one_time',{'currency':'USD'}),
])
def test_source_claims_never_become_observed_allowance(provider,dimension,limit,window,extra):
    # These are regression fixtures from the issue, not live provider guarantees.
    row = q.normalize_quota(dict(provider=provider,dimension=dimension,limit=limit,window=window,
        source='advertised',source_of_truth=False,**extra))
    assert row['limit'] == limit
    assert row['remaining'] is None
    assert q.quota_status(row,NOW) == 'unknown'
    assert row['window'] == window  # No multiplying daily caps into monthly guarantees.


def test_expiry_reset_and_shared_caps():
    c = dict(credit(), shared_scope='same-account-pool', reset_at=1050, timezone='UTC')
    assert q.quota_status(c,NOW) == 'available'
    assert q.quota_status(c,1060) == 'unknown'
    assert q.normalize_quota(c)['shared_scope'] == 'same-account-pool'
    assert q.normalize_quota(dict(c,window='one_time',rollover=True))['rollover'] is False
    assert q.normalize_quota(dict(c,timezone='Not/AZone'))['timezone'] is None
    assert q.quota_status(dict(c,grant_expires_at=950),NOW) == 'expired'


def test_partial_refresh_retains_other_dimensions_and_original_timestamps():
    old = dict(credit(), dimension='input_tokens', remaining='10')
    new = dict(old, observed_at=1000, expires_at=1200, remaining='8')
    output = dict(old, dimension='output_tokens', remaining='20')
    result = metadata.merge_metadata({'quota_evidence':[new]}, {'quota_evidence':[old,output]},NOW)
    assert result['quota_evidence'] == [output,new]
    assert result['quota_evidence'][0]['observed_at'] == 900


def test_existing_json_storage_and_typed_resolver_preserve_quota(tmp_path):
    store = state.StateStore(tmp_path)
    rec = credit()
    caps = capabilities.ModelCapabilities(provider='p',model='m',quota_evidence=[rec])
    encoded = json.dumps(caps.to_dict())
    store.upsert_capability('p','m',encoded)
    restored = capabilities.ModelCapabilities.from_dict(json.loads(store.get_capability('p','m')['capability_json']))
    assert restored.quota_evidence == [rec]
    resolved = capabilities.resolve_capabilities(dict(provider='p',model='m',expires_at=1100,quota_evidence=[rec]),None,None,now=NOW)
    assert resolved.quota_evidence[0]['observed_at'] == 900
    # Credit balances do not authorize a free model.
    store.upsert_catalog('p','m',8192,{},'unknown')
    assert router.Router({'store':store}).select() is None


@pytest.mark.parametrize('bad', [True, 'NaN', 'Infinity', '-1', '1e1000000', [], {}])
def test_malformed_amounts_never_become_zero_or_infinite(bad):
    assert q.decimal_value(bad) is None
    assert q.normalize_quota(dict(credit(),remaining=bad))['remaining'] is None


def test_projection_rounding_remains_exact_beyond_decimal_context_precision():
    c = dict(credit(), remaining="999999999999999999999999999999")
    p = pricing(prices={"prompt":"0.000000000000000000000000000003", "completion":"0.000000000000000000000000000003"})
    out = q.estimate_credit_tokens(c,p,input_share=".5",workload_source="equal mix",now=NOW)
    assert out["tokens"] == 999999999999999999999999999999 * 10**30 // 3


@pytest.mark.parametrize('changes', [
    {'limit':'0.5','remaining':'1'}, {'limit':'invalid'}, {'currency':True}, {'currency':'dollars'},
    {'grant_expires_at':'950'}, {'reset_at':'950'}, {'reset_at':float('nan')},
    {'grant_expires_at':True}, {'reset_at':0},
    {'state':'exhausted','remaining':'1'}, {'state':'healthy','remaining':'0'},
    {'state':'unavailable'}, {'state':'unknown'}, {'state':'invalid'},
    {'dimension':'unknown'}, {'dimension':[]}, {'window':'unknown'},
    {'account_scope':{}}, {'account_scope':''}, {'provider':[]},
    {'model':42}, {'shared_scope':[]},
])
def test_conflicting_malformed_optional_fields_never_authorize_projection(changes):
    c = dict(credit(), **changes)
    assert q.quota_status(c,NOW) == 'unknown'
    assert q.estimate_credit_tokens(c,pricing(),input_share='.5',workload_source='test mix',now=NOW)['tokens'] is None


def test_normalization_does_not_erase_malformed_limit_denial():
    record = q.normalize_quota(dict(credit(), limit='bad'))
    assert record['state'] == 'unknown'
    assert q.quota_status(record,NOW) == 'unknown'


@pytest.mark.parametrize('field', ['grant_expires_at','reset_at'])
def test_projection_validity_ends_at_earliest_grant_reset_or_price_expiry(field):
    c = dict(credit(), **{field:1050})
    out = q.estimate_credit_tokens(c,pricing(),input_share='.5',workload_source='test mix',now=NOW)
    assert out['expires_at'] == 1050
    assert out['pricing_observed_at'] == 900
    assert out['pricing_source_url'] == pricing()['source_url']
    assert out['credit_source_url'] == c['source_url']
    assert q.estimate_credit_tokens(c,pricing(),input_share='.5',workload_source='test mix',now=1050)['state'] == 'unknown'
