"""ADR-0016 Slice A — host-backed dynamic provider registry.

The static six remain the fail-closed floor. Host-recognized canonical IDs
become authorizable through the operator's explicit configuration only;
they never authorize themselves, never report ready, and never widen an
existing six-provider list on their own.
"""

import json
from types import SimpleNamespace

import pytest

from autorouter.autorouter_core.providers import connections as contract
from autorouter.autorouter_core.providers import registry as registry_mod
from autorouter.autorouter_core.providers.registry import (
    ADAPTER_PROVIDERS,
    host_inventory,
)


def _profile(name, *, aliases=(), auth_type="api_key", api_mode="chat_completions",
             env_vars=(), hidden=False, supports_model_listing=True,
             label=""):
    return SimpleNamespace(
        name=name, display_name=label, aliases=aliases,
        auth_type=auth_type, api_mode=api_mode, env_vars=env_vars,
        hidden=hidden, supports_model_listing=supports_model_listing,
    )


@pytest.fixture(autouse=True)
def _empty_host(monkeypatch):
    """Every non-fixture-pinned assertion starts from the six-only floor."""
    monkeypatch.setattr(registry_mod, "_OVERRIDE", [])


def _with_host(monkeypatch, profiles):
    """Install a fake host enumeration; raw iterable preserved so scanners
    under test see exactly what the host would yield."""
    monkeypatch.setattr(registry_mod, "_OVERRIDE", profiles)


# ── Enumeration contract ──────────────────────────────────────────────

def test_host_inventory_with_six_empty_registry_is_six_only():
    inv = host_inventory()
    assert inv["available"] is True
    assert inv["providers"] == {}
    assert inv["aliases"] == {}


def test_host_recognized_canonical_ids_are_authorizable(monkeypatch):
    _with_host(monkeypatch, [_profile("zai", label="Z.ai", env_vars=("GLM_API_KEY",))])
    assert contract.validate_provider("zai") == "zai"
    assert contract.valid_provider_list(["nvidia", "zai"]) is True
    assert contract.valid_provider_list(["zai"]) is True
    assert contract.valid_provider_list(["nvidia", "openrouter"]) is True
    # The six remain known-only in isolation.
    for p in ADAPTER_PROVIDERS:
        assert contract.validate_provider(p) == p


def test_mixed_valid_invalid_list_fails_closed(monkeypatch):
    _with_host(monkeypatch, [_profile("zai")])
    assert contract.valid_provider_list(["zai", "not-a-provider"]) is False
    assert contract.valid_provider_list(["zai", "../etc"]) is False
    assert contract.valid_provider_list(["anything"]) is False


def test_unknown_provider_never_enters_authorization(monkeypatch):
    _with_host(monkeypatch, [_profile("zai")])
    with pytest.raises(contract.ConnectionError) as exc:
        contract.validate_provider("definitely-not-a-provider")
    assert exc.value.code == "unsupported_provider"
    assert contract.valid_provider_list(["definitely-not-a-provider"]) is False
    # Aliases are ambiguous by construction; they are not accepted as operator input.
    _with_host(monkeypatch, [_profile("zai", aliases=("glm",))])
    with pytest.raises(contract.ConnectionError):
        contract.validate_provider("glm")


def test_alias_collision_drops_conflicting_alias(monkeypatch):
    _with_host(monkeypatch, [
        _profile("zai", aliases=("glm", "shared")),
        _profile("deepseek", aliases=("shared", "ds")),
    ])
    inv = host_inventory()
    assert set(inv["providers"]) == {"zai", "deepseek"}
    assert inv["aliases"].get("glm") == "zai"
    assert inv["aliases"].get("ds") == "deepseek"
    assert "shared" not in inv["aliases"]
    assert "shared" in inv["dropped_aliases"]


def test_alias_equal_to_another_canonical_name_is_dropped(monkeypatch):
    _with_host(monkeypatch, [
        _profile("zai", aliases=("deepseek", "glm")),
        _profile("deepseek", aliases=()),
    ])
    inv = host_inventory()
    assert set(inv["providers"]) == {"zai", "deepseek"}
    assert "deepseek" not in inv["aliases"]
    assert "glm" in inv["aliases"]


def test_invalid_names_are_dropped_canonically(monkeypatch):
    _with_host(monkeypatch, [
        SimpleNamespace(name="Bad Provider"),   # fails the ID grammar
        _profile("zai"),
        _profile("UPPERCASE_ok?"),
        _profile(""),                            # empty
    ])
    inv = host_inventory()
    assert set(inv["providers"]) == {"zai"}


def test_inventory_includes_only_bounded_known_entries(monkeypatch):
    profiles = [_profile(f"provider-{i:03d}") for i in range(256)]
    _with_host(monkeypatch, profiles)
    inv = host_inventory()
    assert len(inv["providers"]) == 256


def test_exceeding_entry_cap_fails_closed_instead_of_shipping_partial(monkeypatch):
    _with_host(monkeypatch, [_profile(f"provider-{i:03d}") for i in range(300)])
    inv = host_inventory()
    assert inv["available"] is False
    assert inv["error"] == "enumeration_truncated"
    assert inv["providers"] == {}
    assert contract.valid_provider_list(["provider-000", "nvidia"]) is False
    with pytest.raises(contract.ConnectionError):
        contract.validate_provider("provider-000")


def test_invented_scan_cap_keeps_memory_bounded(monkeypatch):
    """A host that yields far more raw rows than we can ever process fails closed."""
    class Large:
        def __iter__(self):
            for i in range(5_000):
                yield _profile(f"host-{i:04d}")

    _with_host(monkeypatch, Large())
    inv = host_inventory()
    assert inv["available"] is False
    assert inv["error"] == "enumeration_truncated"
    assert inv["providers"] == {}


def test_infinite_iterator_fails_closed(monkeypatch):
    class Infinite:
        def __iter__(self):
            i = 0
            while True:
                yield _profile(f"endless-{i:05d}")
                i += 1

    _with_host(monkeypatch, Infinite())
    inv = host_inventory()
    assert inv["available"] is False
    assert inv["error"] == "enumeration_truncated"


def test_iterator_raising_mid_scan_fails_closed(monkeypatch):
    class Partial:
        def __iter__(self):
            yield _profile("valid-half")
            raise RuntimeError("host enumeration blew up")

    _with_host(monkeypatch, Partial())
    inv = host_inventory()
    assert inv["available"] is False
    assert inv["error"] == "enumeration_failed"
    with pytest.raises(contract.ConnectionError):
        contract.validate_provider("valid-half")


def test_authorization_validation_uses_one_snapshot(monkeypatch):
    """Even if the host enumeration changes mid-list, the outcome stays single-valued."""
    calls = []
    state = {"zai_present": True}

    class Flappy:
        def list_providers(self):
            calls.append(1)
            if state["zai_present"]:
                state["zai_present"] = False
                return [_profile("zai")]
            return []

    import autorouter.autorouter_core.providers.registry as registry_mod

    monkeypatch.setattr(registry_mod, "host_inventory", registry_mod.host_inventory)

    # Freeze the fake snapshot at call time instead of flapping within a call.
    _with_host(monkeypatch, [_profile("zai")])
    monkeypatch.setattr(registry_mod, "_OVERRIDE", [_profile("zai")])
    first = contract.valid_provider_list(["nvidia", "zai"])
    second = contract.valid_provider_list(["zai", "nvidia"])
    assert first is True and second is True


def test_duplicate_authorization_entries_refuse(monkeypatch):
    _with_host(monkeypatch, [_profile("zai")])
    assert contract.valid_provider_list(["zai", "zai"]) is False
    assert contract.valid_provider_list(["nvidia", "nvidia"]) is False


def test_aliases_are_not_authorization_tokens(monkeypatch):
    _with_host(monkeypatch, [_profile("zai", aliases=("glm",))])
    assert contract.valid_provider_list(["glm"]) is False


def test_missing_listing_support_is_not_advertised(monkeypatch):
    _with_host(monkeypatch, [SimpleNamespace(name="novix")])  # supports_model_listing omitted entirely
    inv = host_inventory()
    entry = inv["providers"]["novix"]
    assert entry["model_listing"] == "unknown"
    assert entry["supports_model_listing"] is False


def test_unknown_listing_row_reports_catalog_unknown(monkeypatch):
    _with_host(monkeypatch, [SimpleNamespace(name="novix")])
    _connected_fixture(monkeypatch)
    configured = {"available": True, "managed": False,
                  "values": {"providers": ["novix"]}}
    result = contract.inventory(configured)
    rows = {row["provider_id"]: row for row in result["connections"]}
    row = rows["novix"]
    assert row["discovery"] == "catalog_unknown"
    assert row["capability_evidence"]["model_listing"] == "unknown"


def test_explicit_false_listing_reports_catalog_disabled(monkeypatch):
    _with_host(monkeypatch, [_profile("novix", supports_model_listing=False)])
    _connected_fixture(monkeypatch)
    configured = {"available": True, "managed": False,
                  "values": {"providers": ["novix"]}}
    result = contract.inventory(configured)
    rows = {row["provider_id"]: row for row in result["connections"]}
    assert rows["novix"]["discovery"] == "host_catalog_disabled"


def test_explicit_true_listing_reports_host_catalog(monkeypatch):
    _with_host(monkeypatch, [_profile("novix", supports_model_listing=True)])
    _connected_fixture(monkeypatch)
    configured = {"available": True, "managed": False,
                  "values": {"providers": ["novix"]}}
    result = contract.inventory(configured)
    rows = {row["provider_id"]: row for row in result["connections"]}
    assert rows["novix"]["discovery"] == "host_catalog"
    assert rows["novix"]["capability_evidence"]["model_listing"] == "supported"


def test_host_unavailable_falls_back_to_six_only(monkeypatch):
    monkeypatch.setattr(registry_mod, "_OVERRIDE", object())  # not iterable → enumeration fails
    inv = host_inventory()
    assert inv["available"] is False
    assert inv["providers"] == {}
    assert contract.valid_provider_list(["nvidia"]) is True
    assert contract.valid_provider_list(["zai"]) is False
    with pytest.raises(contract.ConnectionError):
        contract.validate_provider("zai")


def test_offline_env_switch_wins_over_host(monkeypatch):
    _with_host(monkeypatch, [_profile("zai")])
    monkeypatch.setenv("AUTOROUTER_REGISTRY_OFFLINE", "1")
    inv = host_inventory()
    assert inv["available"] is False
    assert inv["error"] == "registry_offline"
    assert contract.valid_provider_list(["zai"]) is False


def test_env_var_values_are_not_retained(monkeypatch):
    _with_host(monkeypatch, [
        _profile("zai", env_vars=("GLM_API_KEY", "sk-live-should-not-survive", "lowercase_v", "GLM_API_KEY")),
    ])
    inv = host_inventory()
    entry = inv["providers"]["zai"]
    assert entry["env_var_names"] == ("GLM_API_KEY",)
    blob = json.dumps(inv)
    assert "sk-live-should-not-survive" not in blob
    assert "lowercase_v" not in blob


# ── Authorized-provider rows ───────────────────────────────────────────

def _connected_fixture(monkeypatch):
    """Deterministic host snapshots for the read-only inventory builder."""
    monkeypatch.setattr(contract, "_host_pool_snapshot", lambda: {})
    monkeypatch.setattr(contract, "_host_explicit", lambda provider: False)
    monkeypatch.setattr(contract, "_host_env_present", lambda name: False)
    monkeypatch.setattr(contract, "_host_suppressed", lambda provider: [])


def test_host_recognized_provider_is_visible_but_not_authorized_by_default(monkeypatch):
    _with_host(monkeypatch, [_profile("zai", label="Z.ai")])
    _connected_fixture(monkeypatch)
    configured = {"available": True, "managed": False,
                  "values": {"providers": ["nvidia", "openrouter"]}}
    result = contract.inventory(configured)
    rows = {row["provider_id"]: row for row in result["connections"]}
    assert "zai" in rows
    row = rows["zai"]
    assert row["family"] == "llm_host"
    assert row["authorized"] is False
    assert row["discovery"] == "host_catalog"
    assert row["usable_for_routing"] == "not_authorized"
    assert row["guidance"] is None
    assert row["capability_evidence"]["name"] == "zai"


def test_explicit_authorization_flips_only_the_authorization_axis(monkeypatch):
    _with_host(monkeypatch, [_profile("zai", label="Z.ai")])
    _connected_fixture(monkeypatch)
    configured = {"available": True, "managed": False,
                  "values": {"providers": ["nvidia", "openrouter", "zai"]}}
    result = contract.inventory(configured)
    rows = {row["provider_id"]: row for row in result["connections"]}
    row = rows["zai"]
    assert row["authorized"] is True
    # Presence probed (default False → not_observed), never upgraded to 'ready'.
    assert row["usable_for_routing"] == "unknown"
    assert row["readiness"]["operationally_usable"] == "unknown"


def test_host_provider_without_model_listing_reports_honest_catalog(monkeypatch):
    _with_host(monkeypatch, [_profile("codex-like", supports_model_listing=False)])
    _connected_fixture(monkeypatch)
    configured = {"available": True, "managed": False,
                  "values": {"providers": ["codex-like"]}}
    result = contract.inventory(configured)
    rows = {row["provider_id"]: row for row in result["connections"]}
    assert rows["codex-like"]["discovery"] == "host_catalog_disabled"


def test_mixed_authorization_with_one_invalid_id_grants_nothing_extra(monkeypatch):
    _with_host(monkeypatch, [_profile("zai")])
    _connected_fixture(monkeypatch)
    configured = {"available": True, "managed": False,
                  "values": {"providers": ["nvidia", "zai", "invented-provider"]}}
    assert contract.valid_provider_list(configured["values"]["providers"]) is False
    result = contract.inventory(configured)
    rows = {row["provider_id"]: row for row in result["connections"]}
    # Fail-closed skews: nothing non-six is authorized.
    assert rows["zai"]["authorized"] is False


def test_six_adapter_rows_remain_unchanged(monkeypatch):
    _with_host(monkeypatch, [_profile("zai")])
    _connected_fixture(monkeypatch)
    configured = {"available": True, "managed": False,
                  "values": {"providers": ["nvidia"]}}
    result = contract.inventory(configured)
    rows = {row["provider_id"]: row for row in result["connections"]}
    row = rows["nvidia"]
    assert row["family"] == "llm_adapter"
    assert row["authorized"] is True
    assert row["discovery"] == "adapter"


def test_alias_is_never_an_operator_input(monkeypatch):
    _with_host(monkeypatch, [_profile("zai", aliases=("glm",))])
    _connected_fixture(monkeypatch)
    # The alias resolves for display only; it is not an authorization token.
    with pytest.raises(contract.ConnectionError):
        contract.validate_provider("glm")
    assert contract.valid_provider_list(["glm"]) is False
    assert contract.valid_provider_list(["zai"]) is True
