"""Hermes structured scope compatibility; no credentials, network or host internals."""
import json
import pytest
from autorouter.autorouter_core.evidence import free_access
from autorouter.autorouter_core.health import health
from autorouter.autorouter_core.integration import runtime
from autorouter.autorouter_core.storage import state
from autorouter.autorouter_core.telemetry import telemetry
from autorouter.autorouter_core.evidence.credential_scope import observed_scope

A='a'*32
B='b'*32

def meta(identity=A,provider='openrouter',status='known'):
    return dict(provider_id=provider,credential_scope_id=identity,identity_status=status)

@pytest.fixture
def configured(tmp_path,monkeypatch):
    # Do not retain a context/settings singleton from a previous test.
    monkeypatch.setattr(runtime,'_STATE',dict(ctx=None,providers=['openrouter'],policy='auto',free_only=True))
    runtime.configure(state_dir=tmp_path)
    return runtime.get_store()


def test_known_scope_is_provider_bound_and_explicit_legacy_strings_still_work():
    assert observed_scope('openrouter',meta())=='openrouter:'+A
    assert observed_scope('nvidia',meta(provider='nvidia'))=='nvidia:'+A
    assert observed_scope('openrouter',meta())!=observed_scope('nvidia',meta(provider='nvidia'))
    assert observed_scope('openrouter','legacy-connection-a')=='legacy-connection-a'


@pytest.mark.parametrize('value',[None,{},[],True,7,'unknown','default','none','scope_unknown',
    meta(None,status='unknown'),meta(None,status='unavailable'),meta(status='unknown'),
    meta(provider='nvidia'),meta('short'),meta('A'*32),dict(meta(),access_token='PRIVATE_SENTINEL')])
def test_missing_malformed_mismatched_scope_is_unknown(configured,value):
    kwargs=dict(provider='openrouter',model='m',api_request_id='unknown-case',credential_scope=value)
    runtime.on_pre_api_request(**kwargs)
    runtime.on_post_api_request(**kwargs)
    assert observed_scope('openrouter',value)==''
    row=configured.get_request(configured.find_request_by_api_id('unknown-case'))
    assert row['key_scope']=='' and row['status']=='success'
    with configured._connect() as conn:
        assert conn.execute("SELECT COUNT(*) FROM health WHERE key_scope!=''").fetchone()[0]==0


def test_non_string_telemetry_values_are_not_stringified():
    class PrivateValue:
        def __str__(self):raise AssertionError('must not stringify an unknown identity')
    for value in [meta(),{'credential_scope_id':None},[],False,3,PrivateValue()]:
        assert telemetry.redact_key_scope(value)==''


@pytest.mark.parametrize('code',[401,429])
def test_real_observers_isolate_health_and_quota_cache(configured,monkeypatch,code):
    now=1000
    scopes=[observed_scope('openrouter',meta(i)) for i in [A,B]]
    for scope in scopes:
        canonical=free_access.canonical_scope(scope)
        records=free_access.normalize_openrouter_quota({'data':{'free_model_daily_requests':{
            'limit':50,'remaining':30,'used':20}}},canonical,now)
        free_access._save(configured,free_access.FreeAccessSnapshot('openrouter',canonical,
            quota_evidence=records,state='healthy').to_dict())
    before=[free_access.read_snapshot(configured,'openrouter',s) for s in scopes]
    import autorouter.autorouter_core.discovery.discovery as discovery
    monkeypatch.setattr(discovery,'_resolve_api_key',lambda *a:pytest.fail('observer read credentials'))
    kwargs=dict(provider='openrouter',model='m',api_request_id='failure',credential_scope=meta())
    runtime.on_pre_api_request(**kwargs)
    runtime.on_api_request_error(**kwargs,status_code=code,retry_count=0,max_retries=0,retryable=False)
    assert configured.get_health('openrouter','m',scopes[0])['failures']==1
    assert configured.get_health('openrouter','m',scopes[1])['failures']==0
    assert health.decision(configured,'openrouter','m',scopes[1])['available']
    after=free_access.read_snapshot(configured,'openrouter',scopes[0])
    assert after['state']=='unavailable' and after['quota_evidence']==before[0]['quota_evidence']
    assert free_access.read_snapshot(configured,'openrouter',scopes[1])==before[1]
    assert not runtime.get_state().get('credential_scopes')
    assert free_access.evaluate(before[1],'openrouter','m',scopes[1],now+free_access.TTL+1)['state']=='unknown'
    assert not free_access.evaluate(before[1],'openrouter','m',scopes[1],now,strict_no_charge=True)['allowed']


def test_same_request_retry_tracks_scoped_attempts_but_loses_request_scope(configured):
    common=dict(provider='openrouter',model='m',api_request_id='retry')
    runtime.on_pre_api_request(**common,credential_scope=meta())
    runtime.on_api_request_error(**common,credential_scope=meta(),status_code=429,retry_count=0,max_retries=2,retryable=True)
    runtime.on_pre_api_request(**common,credential_scope=meta(B),retry_count=1)
    runtime.on_post_api_request(**common,credential_scope=meta(B))
    row=configured.get_request(configured.find_request_by_api_id('retry'))
    assert row['status']=='success' and row['key_scope']==''
    assert len(configured.get_request_attempts(row['id']))==2
    assert configured.get_health('openrouter','m',observed_scope('openrouter',meta()))['failures']==1
    assert configured.get_health('openrouter','m',observed_scope('openrouter',meta(B)))['successes']==1


def test_known_quota_exhaustion_does_not_change_another_scope(configured):
    scopes=[observed_scope('openrouter',meta(i)) for i in [A,B]]
    canonical=free_access.canonical_scope(scopes[0])
    records=free_access.normalize_openrouter_quota({'data':{'free_model_daily_requests':{
        'limit':50,'remaining':0,'used':50}}},canonical,1000)
    snapshot=free_access.FreeAccessSnapshot('openrouter',canonical,quota_evidence=records,state='exhausted').to_dict()
    free_access._save(configured,snapshot)
    assert not free_access.evaluate(snapshot,'openrouter','m',scopes[0],1000)['allowed']
    assert free_access.evaluate(snapshot,'openrouter','m',scopes[1],1000)['state']=='unknown'
    assert free_access.evaluate(snapshot,'openrouter','m',None,1000)['state']=='unknown'
    assert free_access.evaluate(snapshot,'openrouter','m',scopes[0],1201)['state']=='unknown'


def test_duplicate_attempt_cannot_reassign_scope(configured):
    first=observed_scope('openrouter',meta())
    second=observed_scope('openrouter',meta(B))
    request=configured.begin_request(api_request_id='duplicate',provider='openrouter',model='m')
    assert configured.record_attempt(request,0,provider='openrouter',model='m',key_scope=first)
    assert not configured.record_attempt(request,0,provider='openrouter',model='m',key_scope=second)
    assert configured.get_request_attempts(request)[0]['key_scope']==telemetry.redact_key_scope(first)


def test_v3_migration_is_atomic_and_legacy_diagnostics_remain_read_only(configured,monkeypatch):
    from tests.test_dashboard_state_reader import sr
    request=configured.begin_request(api_request_id='legacy',provider='openrouter',model='m')
    configured.record_attempt(request,0,provider='openrouter',model='m')
    with configured._connect() as conn:
        conn.execute('ALTER TABLE request_attempts DROP COLUMN key_scope')
        conn.execute("UPDATE meta SET value='3' WHERE key='schema_version'")
    monkeypatch.setattr(sr,'read_plugin_config',lambda:dict(available=True,managed=False,
        values={'state_dir':str(configured.state_dir)}))
    before=configured.db_path.read_bytes()
    detail=sr.assemble_analytics(view='request',request_id=request)
    assert detail['available'] and detail['attempts'][0]['key_scope']==''
    assert configured.db_path.read_bytes()==before
    original=state.StateStore._init_telemetry_schema
    def fail(self,conn):
        original(self,conn)
        raise RuntimeError('injected migration failure')
    with monkeypatch.context() as patch:
        patch.setattr(state.StateStore,'_init_telemetry_schema',fail)
        with pytest.raises(RuntimeError):state.StateStore(configured.state_dir)
    with configured._connect() as conn:
        assert 'key_scope' not in {r[1] for r in conn.execute('PRAGMA table_info(request_attempts)')}
        assert conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]=='3'
    migrated=state.StateStore(configured.state_dir)
    assert migrated.get_request_attempts(request)[0]['key_scope']==''
    assert migrated.get_request(request)['api_request_id']==configured.get_request(request)['api_request_id']
    with migrated._connect() as conn:
        assert conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]==str(state.SCHEMA_VERSION)


def test_attempt_api_exposes_only_hashes_and_preserves_retry_attribution(configured,monkeypatch):
    from tests.test_dashboard_state_reader import sr
    common=dict(provider='openrouter',model='m',api_request_id='detail')
    runtime.on_pre_api_request(**common,credential_scope=meta())
    runtime.on_api_request_error(**common,credential_scope=meta(),status_code=429,retry_count=0,max_retries=2,retryable=True)
    runtime.on_pre_api_request(**common,credential_scope=meta(B),retry_count=1)
    runtime.on_post_api_request(**common,credential_scope=meta(B))
    request=configured.find_request_by_api_id('detail')
    monkeypatch.setattr(sr,'read_plugin_config',lambda:dict(available=True,managed=False,
        values={'state_dir':str(configured.state_dir)}))
    before=configured.db_path.read_bytes()
    detail=sr.assemble_analytics(view='request',request_id=request)
    expected=[telemetry.redact_key_scope(observed_scope('openrouter',meta(i))) for i in [A,B]]
    assert [a['key_scope'] for a in detail['attempts']]==expected
    assert detail['request']['key_scope']==''
    assert configured.db_path.read_bytes()==before
    # Treat even a manually corrupted scope cell as untrusted on the API boundary.
    with configured._connect() as conn:
        conn.execute("UPDATE request_attempts SET key_scope='PRIVATE_SENTINEL'")
    detail=sr.assemble_analytics(view='request',request_id=request)
    assert all(a['key_scope']=='' for a in detail['attempts'])
    assert 'PRIVATE_SENTINEL' not in json.dumps(detail)
