"""Consolidated issue #41 acceptance matrix rows not covered elsewhere.

Scope of this module: repository-local, synthetic, credential-free. Every
producer fact is injected through the same seams the host contract exposes
(`scope_quota.observe` with a synthetic `ctx.quota_fetch`, or
`runtime.on_api_request_error` with explicit status codes). No network, no
credentials, no host binaries.

These rows complement `tests/test_operational_access_acceptance.py`,
`tests/test_quota_policies_v1.py`, `tests/test_scope_quota_refresh.py` and
`tests/test_structured_credential_scope.py`; they do not duplicate them.

What is NOT established here (external gates, see issue #41):
- Real authorized host acceptance on a released Hermes that ships the
  `llm.credential_scope` / `llm.quota_observation` producers
  (NousResearch/hermes-agent PR #156606, unmerged at the time of writing).
- Any no-charge billing guarantee. Nothing observed here can establish one.
"""
from types import SimpleNamespace

import pytest

from autorouter.autorouter_core.evidence import free_access, scope_quota
from autorouter.autorouter_core.integration import runtime
from autorouter.autorouter_core.storage import state

NOW = 1794000000.0
A = 'a' * 32
B = 'b' * 32
CANONICAL_A = free_access.canonical_scope('openrouter:' + A)
CANONICAL_B = free_access.canonical_scope('openrouter:' + B)


@pytest.fixture
def matrix(tmp_path, monkeypatch):
    clock = [NOW]
    monkeypatch.setattr(scope_quota.time, 'time', lambda: clock[0])
    store = state.StateStore(tmp_path)
    return SimpleNamespace(store=store, clock=clock)


def observation(scope, remaining):
    return dict(status='ok', provider_id='openrouter', credential_scope_id=scope,
                quota_source='official_key_limits', limit=50, remaining=remaining,
                used=50 - remaining, observed_at=NOW, expires_at=NOW + 120)


def seed_healthy(store, scope, remaining=38):
    assert scope_quota.ingest(store, 'openrouter', 'openrouter:' + scope,
                              observation(scope, remaining))


def test_rotation_never_inherits_predecessors_allowance(matrix, monkeypatch):
    """Issue #41: credential scope rotated.

    A rotated-out credential's allowance must never attach to the entry that
    replaces it: the new scope starts UNKNOWN and needs its own producer fact.
    """
    seed_healthy(matrix.store, A, 38)
    scope_b = 'openrouter:' + B
    snap_b = free_access.read_snapshot(matrix.store, 'openrouter', scope_b)
    assert snap_b['state'] == 'unknown' and snap_b['quota_evidence'] == []
    # The old scope's evidence is untouched by the rotation itself.
    snap_a = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + A)
    assert snap_a['state'] == 'healthy'
    # Strict policies refuse without the new scope's own evidence; only the
    # explicitly-lax policies tolerate unknown, and never as an allowance fact.
    out = free_access.evaluate_policy(snap_b, 'openrouter', 'example:free',
                                      scope_b, NOW,
                                      quota_policy='require_fresh_account_allowance')
    assert not out['allowed'] and not out['allowance']['complete']
    assert not out['preference_available']


def test_rotation_evicted_scope_producer_unavailable_preserves_original(matrix, monkeypatch):
    """Issue #41: credential scope rotated -> producer reports unavailable.

    Per the host contract, a quota_fetch for a rotated-out scope returns
    {"status": "unavailable"}. The consumer must invalidate availability
    without fabricating exhaustion and without touching the predecessor
    account's stored facts.
    """
    seed_healthy(matrix.store, A, 38)
    seed_healthy(matrix.store, B, 19)
    # Capture both original facts BEFORE the attempted refresh. Reading twice
    # afterward would prove nothing about whether invalidation lost evidence.
    before = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + A)
    sibling_before = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + B)
    calls = []
    ctx = SimpleNamespace(
        get_config=lambda *args: True,
        quota_fetch=lambda **kwargs: (calls.append(kwargs),
                                      {'status': 'unavailable', 'reason': 'rotated_scope'})[1],
    )
    monkeypatch.setattr(runtime, '_STATE', {'store': matrix.store, 'ctx': ctx})
    matrix.clock[0] = NOW + 61  # advance past the MIN_REFRESH lease from the seed ingest
    runtime.on_pre_api_request(
        provider='openrouter', model='example:free', api_request_id='rotated-1',
        credential_scope={'provider_id': 'openrouter', 'credential_scope_id': A,
                          'identity_status': 'known'},
    )
    # The authorized callback must address exactly the scope it observed.
    assert [call['credential_scope_id'] for call in calls] == [A]
    after = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + A)
    assert after['state'] == 'unavailable'
    assert after['error_category'] == 'metadata_unavailable'
    assert after['state'] != 'exhausted'
    # Original observed rows are retained verbatim, including provenance and
    # original timestamp; the unrelated account's full snapshot is untouched.
    assert before['state'] == 'healthy'
    assert before['quota_evidence']
    assert after['quota_evidence'] == before['quota_evidence']
    sibling_after = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + B)
    assert sibling_after == sibling_before


def test_rotation_new_scope_fetches_its_own_evidence_only(matrix, monkeypatch):
    seed_healthy(matrix.store, A, 38)
    calls = []
    ctx = SimpleNamespace(
        get_config=lambda *args: True,
        quota_fetch=lambda **kwargs: (calls.append(kwargs), observation(
            kwargs['credential_scope_id'], 7))[1],
    )
    monkeypatch.setattr(runtime, '_STATE', {'store': matrix.store, 'ctx': ctx})
    runtime.on_pre_api_request(
        provider='openrouter', model='example:free', api_request_id='rotated-2',
        credential_scope={'provider_id': 'openrouter', 'credential_scope_id': B,
                          'identity_status': 'known'},
    )
    assert [call['credential_scope_id'] for call in calls] == [B]
    snap_b = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + B)
    assert snap_b['state'] == 'healthy'
    # The predecessor scope's cache row is never rewritten by the new account.
    snap_a = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + A)
    assert snap_a['state'] == 'healthy'
    assert snap_a['quota_evidence'][0]['remaining'] == '38'


def test_403_through_runtime_error_hook_invalidates_only_its_scope(matrix, monkeypatch):
    """Issue #41: account disconnected or revoked (403 via the production entry point)."""
    seed_healthy(matrix.store, A, 38)
    seed_healthy(matrix.store, B, 38)
    monkeypatch.setattr(runtime, '_STATE', dict(
        ctx=None, providers=['openrouter'], policy='auto', free_only=True, store=matrix.store))
    runtime.on_api_request_error(
        provider='openrouter', model='example:free', api_request_id='revoked-1',
        credential_scope={'provider_id': 'openrouter', 'credential_scope_id': A,
                          'identity_status': 'known'},
        status_code=403, retry_count=0, max_retries=0, retryable=False,
    )
    snap_a = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + A)
    snap_b = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + B)
    assert snap_a['state'] == 'unavailable'
    assert snap_a['error_category'] == 'auth_unavailable'
    assert snap_a['state'] != 'exhausted'
    assert snap_b['state'] == 'healthy'
    strict = free_access.evaluate_policy(snap_a, 'openrouter', 'example:free',
                                         'openrouter:' + A, NOW,
                                         quota_policy='require_fresh_account_allowance')
    assert not strict['allowed']
    lax = free_access.evaluate_policy(snap_a, 'openrouter', 'example:free',
                                      'openrouter:' + A, NOW,
                                      quota_policy='avoid_verified_exhaustion')
    # 403 is not exhaustion evidence: the lax policy still permits selection.
    assert lax['allowed']


def test_429_through_runtime_error_hook_is_rate_limited_not_exhausted(matrix, monkeypatch):
    """Issue #41: 429 without fabricated exhaustion, via the production entry point."""
    seed_healthy(matrix.store, A, 38)
    monkeypatch.setattr(runtime, '_STATE', dict(
        ctx=None, providers=['openrouter'], policy='auto', free_only=True, store=matrix.store))
    runtime.on_api_request_error(
        provider='openrouter', model='example:free', api_request_id='limited-1',
        credential_scope={'provider_id': 'openrouter', 'credential_scope_id': A,
                          'identity_status': 'known'},
        status_code=429, retry_count=0, max_retries=0, retryable=False,
    )
    snap_a = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + A)
    assert snap_a['state'] == 'unavailable'
    assert snap_a['error_category'] == 'rate_limited'
    assert snap_a['state'] != 'exhausted'
    lax = free_access.evaluate_policy(snap_a, 'openrouter', 'example:free',
                                      'openrouter:' + A, NOW,
                                      quota_policy='avoid_verified_exhaustion')
    assert lax['allowed']
    strict = free_access.evaluate_policy(snap_a, 'openrouter', 'example:free',
                                         'openrouter:' + A, NOW,
                                         quota_policy='require_fresh_account_allowance')
    assert not strict['allowed']


def test_no_charge_guarantee_refuses_even_with_healthy_evidence(matrix):
    """Issue #41: no-charge guarantee must refuse without an enforceable boundary."""
    seed_healthy(matrix.store, A, 38)
    snap = free_access.read_snapshot(matrix.store, 'openrouter', 'openrouter:' + A)
    out = free_access.evaluate_policy(snap, 'openrouter', 'example:free',
                                      'openrouter:' + A, NOW,
                                      quota_policy='require_no_charge_guarantee')
    assert not out['allowed']
    assert out['allowance']['quota_windows'][0]['remaining'] == '38'
    assert not out['hard_stop_guaranteed']
