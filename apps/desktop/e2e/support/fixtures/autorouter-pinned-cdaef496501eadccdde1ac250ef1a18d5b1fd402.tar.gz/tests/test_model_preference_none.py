"""Regression tests for the model-preference repairs (dispatch #111).

Covers the two critical defects independently reported on PR #110:

1. Disabling the last allowlisted model must never widen selection. The
   canonical selector understands an explicit ``none`` preference mode and
   refuses to route — fail closed, zero outbound requests, no matter what
   arrives later (fresh catalog models included).
2. Preference persistence is a single ``model_preference`` key written
   all-or-nothing, guarded by a cross-process lock; the routing engine reads
   it, and eligibility stays independent of the preference.

These tests drive the real resolution path with a seeded store and a patched
Hermes config, exactly like tests/test_native_routing_contract.py.
"""

from __future__ import annotations

import json
import os

import pytest

os.environ.setdefault("HERMES_DISABLE_LAZY_INSTALLS", "1")

from autorouter.autorouter_core.integration import native_routing  # noqa: E402
from autorouter.autorouter_core.storage import state as state_mod  # noqa: E402

_HERMES_IMPORTABLE = False
try:
    import hermes_cli.config  # noqa: F401

    _HERMES_IMPORTABLE = True
except Exception:
    _HERMES_IMPORTABLE = False

requires_hermes = pytest.mark.skipif(not _HERMES_IMPORTABLE, reason="Hermes v0.23.1 not importable")


def _seed_catalog(store, rows):
    now = 1.0
    expiry = 9999999999.0
    for p, m, ctx, caps, tier in rows:
        store.upsert_catalog(p, m, context_length=ctx, capabilities=caps, cost_tier=tier)
        store.upsert_capability(
            p, m,
            json.dumps({
                "provider": p, "model": m,
                "field_evidence": {
                    "context_window": {"metadata_source": "provider",
                                       "retrieved_at": now, "expires_at": expiry},
                    "tools": {"metadata_source": "provider",
                              "retrieved_at": now, "expires_at": expiry},
                    "cost_tier": {"metadata_source": "provider",
                                  "retrieved_at": now, "expires_at": expiry},
                },
                "context_window": ctx, "tools": caps["tools"],
                "cost_tier": tier, "source": "provider",
            }),
            metadata_source="provider", retrieved_at=now, expires_at=expiry)


@pytest.fixture
def store_dir(tmp_path):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "nvidia-free", 131072, {"tools": "supported"}, "free"),
        ("openrouter", "qwen/qwen3-coder:free", 262144, {"tools": "supported"}, "free"),
        ("nvidia", "paid-x", 131072, {"tools": "supported"}, "paid"),
        ("nvidia", "unknown-cost", 131072, {"tools": "supported"}, "unknown"),
    ])
    return tmp_path / "store"


def _settings(**overrides):
    base = {
        "enabled": True,
        "enable_chat_router": False,
        "enable_native_routing": True,
        "policy": "auto",
        "min_context": 8192,
        "cooldown_seconds": 60,
        "requires_tools": True,
        "free_only": True,
        "providers": ["nvidia", "openrouter"],
        "model_include": [],
        "model_exclude": [],
    }
    base.update(overrides)
    return base


def _patch_hermes_config(monkeypatch, **settings):
    import hermes_cli.config as _hcfg

    merged = _settings(**settings)
    monkeypatch.setattr(_hcfg, "load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": merged}}}})
    return merged


def _blob(mode, include=(), exclude=()):
    return {"version": 1, "mode": mode,
            "include": sorted(include), "exclude": sorted(exclude)}


def _route(metadata_id, store_dir):
    return native_routing.resolve_consumer_route(
        metadata={"session_id": metadata_id},
        store_dir=store_dir,
        providers=["nvidia", "openrouter"],
    )


@requires_hermes
def test_none_mode_refuses_even_with_eligible_free_models(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, model_preference=_blob("none"))
    out = _route("session-none-1", store_dir)
    assert out["status"] == "refuse"
    assert "no model is enabled" in out["reason"]


@requires_hermes
def test_none_mode_zero_outbound_requests(monkeypatch, store_dir):
    import socket

    def _boom(*args, **kwargs):
        raise AssertionError("network access is forbidden on the none-mode refusal path")

    monkeypatch.setattr(socket, "socket", _boom)
    monkeypatch.setattr(socket, "create_connection", _boom)
    _patch_hermes_config(monkeypatch, model_preference=_blob("none"))
    out = _route("session-none-2", store_dir)
    assert out["status"] == "refuse"


@requires_hermes
def test_none_mode_newly_discovered_model_still_refuses(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, model_preference=_blob("none"))
    # A model appears in the catalog *after* everything was toggled off.
    store = state_mod.StateStore(store_dir)
    _seed_catalog(store, [("openrouter", "brand-new:free", 262144, {"tools": "supported"}, "free")])
    out = _route("session-none-3", store_dir)
    assert out["status"] == "refuse"
    assert "no model is enabled" in out["reason"]


@requires_hermes
def test_none_mode_re_enable_single_model_allows_only_it(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, model_preference=_blob("allowlist", ["nvidia/nvidia-free"]))
    out = _route("session-none-4", store_dir)
    assert out["status"] != "refuse"
    assert out["provider"] == "nvidia" and out["model"] == "nvidia-free"


@requires_hermes
def test_allowlist_excludes_paid_and_unknown_cost(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch,
                         model_preference=_blob("allowlist", ["nvidia/paid-x", "nvidia/unknown-cost"]))
    out = _route("session-none-5", store_dir)
    assert out["status"] == "refuse"


@requires_hermes
def test_invalid_model_preference_fails_closed(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, model_preference={"version": 1, "mode": "allowlist", "include": []})
    out = _route("session-none-6", store_dir)
    assert out["status"] == "refuse"
    assert "no model is enabled" in out["reason"]


@requires_hermes
def test_corrupt_model_preference_fails_closed(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, model_preference={"mode": "banana"})
    out = _route("session-none-7", store_dir)
    assert out["status"] == "refuse"


@requires_hermes
def test_legacy_empty_include_remains_unrestricted(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch)  # no model_preference key at all
    out = _route("session-legacy-1", store_dir)
    assert out["status"] != "refuse"


@requires_hermes
def test_legacy_include_implies_allowlist(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, model_include=["nvidia/nvidia-free"])
    out = _route("session-legacy-2", store_dir)
    assert out["status"] != "refuse"
    assert (out["provider"], out["model"]) == ("nvidia", "nvidia-free")


@requires_hermes
def test_unrestricted_reset_blob_routes_again(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch, model_preference=_blob("unrestricted"))
    out = _route("session-none-8", store_dir)
    assert out["status"] != "refuse"


@requires_hermes
def test_profile_cannot_widen_global_none(monkeypatch, store_dir):
    store = state_mod.StateStore(store_dir)
    profiles = state_mod.RoutingProfileStore(store_dir)
    prof = profiles.create({"name": "Widen attempt", "ranking_policy": "auto",
                            "providers": ["nvidia", "openrouter"], "min_context": 8192,
                            "requires_tools": True,
                            "model_include": ["nvidia/nvidia-free", "openrouter/qwen/qwen3-coder:free"]})
    profiles.set_active(prof["id"])
    _patch_hermes_config(monkeypatch, model_preference=_blob("none"))
    out = _route("session-none-9", store_dir)
    assert out["status"] == "refuse"


@requires_hermes
def test_profile_include_empty_intersection_refuses_not_widens(monkeypatch, store_dir):
    store = state_mod.StateStore(store_dir)
    profiles = state_mod.RoutingProfileStore(store_dir)
    prof = profiles.create({"name": "Disjoint", "ranking_policy": "auto",
                            "providers": ["openrouter"], "min_context": 8192,
                            "requires_tools": True,
                            "model_include": ["openrouter/qwen/qwen3-coder:free"]})
    profiles.set_active(prof["id"])
    _patch_hermes_config(monkeypatch, model_preference=_blob("allowlist", ["nvidia/nvidia-free"]))
    out = _route("session-none-10", store_dir)
    assert out["status"] == "refuse"


@requires_hermes
def test_profile_include_intersection_narrows(monkeypatch, store_dir):
    store = state_mod.StateStore(store_dir)
    profiles = state_mod.RoutingProfileStore(store_dir)
    prof = profiles.create({"name": "Narrow", "ranking_policy": "auto",
                            "providers": ["openrouter"], "min_context": 8192,
                            "requires_tools": True,
                            "model_include": ["openrouter/qwen/qwen3-coder:free"]})
    profiles.set_active(prof["id"])
    _patch_hermes_config(monkeypatch,
                         model_preference=_blob("allowlist",
                                                ["nvidia/nvidia-free", "openrouter/qwen/qwen3-coder:free"]))
    out = _route("session-none-11", store_dir)
    assert (out["provider"], out["model"]) == ("openrouter", "qwen/qwen3-coder:free")


@requires_hermes
def test_profile_exclusion_union_still_narrows_in_unrestricted(monkeypatch, store_dir):
    store = state_mod.StateStore(store_dir)
    profiles = state_mod.RoutingProfileStore(store_dir)
    prof = profiles.create({"name": "Exclude one", "ranking_policy": "auto",
                            "providers": ["nvidia"], "min_context": 8192,
                            "requires_tools": True,
                            "model_exclude": ["nvidia/nvidia-free"]})
    profiles.set_active(prof["id"])
    _patch_hermes_config(monkeypatch, model_preference=_blob("unrestricted"))
    out = _route("session-none-12", store_dir)
    assert out["status"] == "refuse"  # the only eligible free nvidia model is excluded


@requires_hermes
def test_empty_catalog_refuses_and_makes_no_network_call(monkeypatch, tmp_path):
    empty = tmp_path / "empty-store"
    state_mod.StateStore(empty)  # schema exists, catalog empty
    import socket

    def _boom(*args, **kwargs):
        raise AssertionError("network access is forbidden on the refusal path")

    monkeypatch.setattr(socket, "socket", _boom)
    monkeypatch.setattr(socket, "create_connection", _boom)
    _patch_hermes_config(monkeypatch, model_preference=_blob("none"))
    out = _route("session-empty-1", empty)
    assert out["status"] == "refuse"


@requires_hermes
def test_allowlist_does_not_authorize_unauthorized_provider(monkeypatch, store_dir):
    # The preference lists a model offered by a provider AutoRouter is NOT
    # authorized to use. A preference is never an authorization grant.
    store = state_mod.StateStore(store_dir)
    _seed_catalog(store, [("zai", "some-free-model", 131072, {"tools": "supported"}, "free")])
    _patch_hermes_config(monkeypatch,
                         providers=["nvidia", "openrouter"],
                         model_preference=_blob("allowlist", ["zai/some-free-model"]))
    out = _route("session-auth-1", store_dir)
    assert out["status"] == "refuse"


@requires_hermes
def test_allowlist_cannot_widen_free_only_or_paid_gate(monkeypatch, store_dir):
    _patch_hermes_config(monkeypatch,
                         model_preference=_blob("allowlist",
                                                ["nvidia/paid-x", "nvidia/unknown-cost", "nvidia/nvidia-free"]))
    out = _route("session-free-1", store_dir)
    assert out["status"] != "refuse"
    assert (out["provider"], out["model"]) == ("nvidia", "nvidia-free")
