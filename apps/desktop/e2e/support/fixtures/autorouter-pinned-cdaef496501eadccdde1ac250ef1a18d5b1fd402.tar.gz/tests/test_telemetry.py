"""Deterministic tests for the analytics telemetry layer.

Covers:
* typed contracts in ``autorouter.telemetry`` (validation, immutability)
* pure calculations (percentiles, success rate, tokens/sec, hour bucketing)
* Hermes-hook field mappers (only fields Hermes actually delivers)
* the bounded ingestion contract for host callbacks Hermes does NOT provide
* the schema-v2 store methods (requests / attempts / hourly / counters)

No network, no sleeps, fixed timestamps: fully deterministic.
"""

from __future__ import annotations

import hashlib
import sqlite3
from pathlib import Path

import pytest

from autorouter.autorouter_core.storage import state as st
from autorouter.autorouter_core.telemetry import telemetry as tl


# ---------------------------------------------------------------------------
# Range handling
# ---------------------------------------------------------------------------


def test_normalize_range_accepts_supported_values():
    for value in ("24h", "7d", "30d", "90d", "all"):
        assert tl.normalize_range(value) == value


def test_normalize_range_falls_back_to_7d():
    assert tl.normalize_range("1h") == "7d"
    assert tl.normalize_range(None) == "7d"
    assert tl.normalize_range(5) == "7d"


def test_since_timestamp_cutoffs():
    now = 1_000_000.0
    assert tl.since_timestamp("24h", now) == now - 86_400
    assert tl.since_timestamp("90d", now) == now - 90 * 86_400
    assert tl.since_timestamp("all", now) is None


# ---------------------------------------------------------------------------
# Typed contracts
# ---------------------------------------------------------------------------


def test_token_usage_rejects_negative_or_non_int():
    assert tl.TokenUsage(1, 2).output_tokens == 2
    with pytest.raises(ValueError):
        tl.TokenUsage(-1, 0)
    with pytest.raises(ValueError):
        tl.TokenUsage(True, 0)  # bool is not an int here
    with pytest.raises(ValueError):
        tl.TokenUsage(1.5, 0)


def test_inference_request_status_and_timing_validation():
    req = tl.InferenceRequest(provider="p", model="m", status="success", latency_ms=10.0)
    assert req.status == "success"
    with pytest.raises(ValueError):
        tl.InferenceRequest(status="boom")
    with pytest.raises(ValueError):
        tl.InferenceRequest(latency_ms=-1)
    with pytest.raises(ValueError):
        tl.InferenceRequest(ttft_ms=-0.1)


def test_inference_request_is_frozen():
    req = tl.InferenceRequest()
    with pytest.raises(AttributeError):
        req.status = "success"  # type: ignore[misc]


def test_execution_attempt_ordinal_validation():
    tl.ExecutionAttempt(request_ref="r", ordinal=0)
    with pytest.raises(ValueError):
        tl.ExecutionAttempt(request_ref="r", ordinal=-1)
    with pytest.raises(ValueError):
        tl.ExecutionAttempt(request_ref="r", ordinal=1.5)


def test_bounded_event_dataclasses_are_construction_only():
    tl.CacheEvent(provider="p", hit=True, latency_ms=1.0)
    tl.SearchEvent(provider="p", query_length=10, results_count=0)
    tl.CredentialScopeEvent(provider="p", key_scope_hash="k_x", auth_ok=True)
    # frozen
    with pytest.raises(AttributeError):
        tl.CacheEvent().hit = False  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Error classification
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("status", "expected"),
    [
        (429, "Rate Limited (429)"),
        (401, "Auth Error (401)"),
        (403, "Forbidden (403)"),
        (404, "Not Found (404)"),
        (410, "Not Found (404)"),
        (500, "Server Error (500)"),
        (502, "Server Error (500)"),
        (503, "Unavailable (503)"),
        (504, "Unavailable (503)"),
        (418, "Other"),
        (599, "Server Error (500)"),
    ],
)
def test_classify_error_by_status(status, expected):
    assert tl.classify_error(status_code=status) == expected


def test_classify_error_by_text_fallback():
    assert tl.classify_error(error_type="rate_limit_error") == "Rate Limited (429)"
    assert tl.classify_error(message="Invalid API key provided") == "Auth Error (401)"
    assert tl.classify_error(message="connection reset by peer") == "Timeout/Connection"
    assert tl.classify_error(message="no such model") == "Not Found (404)"
    assert tl.classify_error(message="something odd") == "Other"
    assert tl.classify_error() == "Other"


def test_classify_error_ignores_bool_status():
    # A bool status is not an HTTP status: must fall through to text/Other.
    assert tl.classify_error(status_code=True) == "Other"


# ---------------------------------------------------------------------------
# Pure calculations
# ---------------------------------------------------------------------------


def test_percentile_nearest_rank():
    assert tl.percentile([], 0.5) is None
    assert tl.percentile([5], 0.95) == 5
    values = [10, 20, 30, 40]
    assert tl.percentile(values, 0.5) == 20
    assert tl.percentile(values, 0.95) == 40
    with pytest.raises(ValueError):
        tl.percentile(values, 1.5)


def test_latency_percentiles_skips_nulls_and_handles_empty():
    assert tl.latency_percentiles([]) == (None, None)
    p50, p95 = tl.latency_percentiles([30, None, 10, 20, 40])
    assert (p50, p95) == (20, 40)


def test_success_rate_excludes_undecided():
    assert tl.success_rate(0, 0) is None
    assert tl.success_rate(3, 1) == 75.0
    assert tl.success_rate(1, 0) == 100.0
    assert tl.success_rate(0, 2) == 0.0


def test_tokens_per_second():
    assert tl.tokens_per_second(100, 4000) == 25.0
    assert tl.tokens_per_second(0, 4000) is None
    assert tl.tokens_per_second(100, 0) is None


def test_hour_key_is_utc_hour_bucket():
    # 1_700_000_000 == 2023-11-14 22:13:20 UTC
    assert tl.hour_key(1_700_000_000.0) == "2023-11-14 22:00:00"


def test_avg_ignores_none_and_empty():
    assert tl.avg([]) is None
    assert tl.avg([None, 2.0, 4.0]) == 3.0


# ---------------------------------------------------------------------------
# Hermes-hook mappers
# ---------------------------------------------------------------------------


def test_extract_usage_from_usage_dict():
    kwargs = {"usage": {"input_tokens": 12, "output_tokens": 34}}
    usage = tl.extract_usage(kwargs)
    assert (usage.input_tokens, usage.output_tokens) == (12, 34)


def test_extract_usage_aliases_and_float_integers():
    usage = tl.extract_usage({"usage": {"prompt_tokens": 5, "completion_tokens": 6.0}})
    assert (usage.input_tokens, usage.output_tokens) == (5, 6)


def test_extract_usage_flat_fallback_and_missing():
    usage = tl.extract_usage({"prompt_tokens": 7, "output_tokens": 8})
    assert (usage.input_tokens, usage.output_tokens) == (7, 8)
    empty = tl.extract_usage({})
    assert (empty.input_tokens, empty.output_tokens) == (None, None)
    # bools are never tokens
    weird = tl.extract_usage({"usage": {"input_tokens": True}})
    assert weird.input_tokens is None


def test_extract_usage_non_dict_is_empty():
    assert tl.extract_usage(None) == tl.TokenUsage()  # type: ignore[arg-type]


def test_latency_ms_from_kwargs_variants():
    assert tl.latency_ms_from_kwargs({"api_duration": 1.5}) == 1500.0
    assert tl.latency_ms_from_kwargs({"latency_ms": 250}) == 250.0
    assert tl.latency_ms_from_kwargs({"started_at": 1.0, "ended_at": 1.25}) == 250.0
    assert tl.latency_ms_from_kwargs({}) is None
    assert tl.latency_ms_from_kwargs({"api_duration": -1}) is None
    assert tl.latency_ms_from_kwargs({"started_at": 2.0, "ended_at": 1.0}) is None


def test_ttft_ms_from_kwargs_variants():
    assert tl.ttft_ms_from_kwargs({"started_at": 10.0, "first_chunk_at": 10.4}) == 400.0
    assert tl.ttft_ms_from_kwargs({"ttft_ms": 120}) == 120.0
    assert tl.ttft_ms_from_kwargs({}) is None
    assert tl.ttft_ms_from_kwargs({"first_chunk_at": 1.0, "started_at": 2.0}) is None


def test_status_from_kwargs():
    assert tl.status_from_kwargs({"status_code": 200}) == "success"
    assert tl.status_from_kwargs({"status_code": 502}) == "error"
    assert tl.status_from_kwargs({"error": {"message": "x"}}) == "error"
    assert tl.status_from_kwargs({"status": "ok"}) == "success"
    assert tl.status_from_kwargs({"status": "canceled"}) == "canceled"
    assert tl.status_from_kwargs({}, default="success") == "success"
    assert tl.status_from_kwargs({"status_code": True}, default="success") == "success"


def test_error_parts_variants():
    assert tl.error_parts({"error": {"type": "t1", "message": "m1"}}) == ("t1", "m1")
    assert tl.error_parts({"error": "boom"}) == (None, "boom")
    assert tl.error_parts({"error_type": "t2", "error_message": "m2"}) == ("t2", "m2")
    assert tl.error_parts({}) == (None, None)
    assert tl.error_parts(None) == (None, None)  # type: ignore[arg-type]


def test_agent_id_hashing_is_stable_and_never_raw():
    expected = hashlib.sha256(b"sess-123").hexdigest()[:12]
    assert tl.agent_id_from_kwargs({"session_id": "sess-123"}) == expected
    assert tl.agent_id_from_kwargs({"session_id": "sess-123"}) == tl.agent_id_from_kwargs(
        {"session_id": " sess-123 "}
    )
    assert tl.agent_id_from_kwargs({"session_id": "other"}) != expected
    assert tl.agent_id_from_kwargs({"session_id": ""}) is None
    assert tl.agent_id_from_kwargs({}) is None


def test_redact_key_scope_hashing():
    hashed = tl.redact_key_scope("sk-live-abc")
    assert hashed.startswith("k_") and len(hashed) == 14
    assert hashed == tl.redact_key_scope("sk-live-abc")
    assert tl.redact_key_scope(None) == ""
    assert tl.redact_key_scope("") == ""
    for unknown in ("unknown", "default", "none"):
        assert tl.redact_key_scope(unknown) == ""


# ---------------------------------------------------------------------------
# Bounded ingestion contract (host callbacks Hermes does NOT provide)
# ---------------------------------------------------------------------------


def test_ingest_bounded_event_cache():
    event = tl.ingest_bounded_event(
        "cache_event", {"provider": "p", "model": "m", "hit": True, "latency_ms": 2.5}
    )
    assert event == {
        "kind": "cache_event",
        "provider": "p",
        "model": "m",
        "hit": True,
        "latency_ms": 2.5,
    }
    with pytest.raises(ValueError):
        tl.ingest_bounded_event("cache_event", {"latency_ms": 1.0})  # missing hit
    with pytest.raises(ValueError):
        tl.ingest_bounded_event("cache_event", {"hit": True, "latency_ms": -1})


def test_ingest_bounded_event_search():
    event = tl.ingest_bounded_event(
        "search_event", {"provider": "p", "query_length": 9, "latency_ms": 12, "results_count": 3}
    )
    assert event["kind"] == "search_event"
    assert event["results_count"] == 3
    with pytest.raises(ValueError):
        tl.ingest_bounded_event("search_event", {"results_count": -1})


def test_ingest_bounded_event_credential_scope():
    event = tl.ingest_bounded_event(
        "credential_scope_event", {"provider": "p", "key_scope": "team-a", "auth_ok": True}
    )
    assert event["key_scope_hash"] == tl.redact_key_scope("team-a")
    assert "team-a" not in str(event)
    with pytest.raises(ValueError):
        tl.ingest_bounded_event("credential_scope_event", {"key_scope": 5})
    with pytest.raises(ValueError):
        tl.ingest_bounded_event("credential_scope_event", {"key_scope": "x", "auth_ok": "yes"})


def test_ingest_bounded_event_token_adjustment():
    event = tl.ingest_bounded_event(
        "token_adjustment", {"api_request_id": "r1", "input_tokens": 4, "output_tokens": None}
    )
    assert event["input_tokens"] == 4 and event["output_tokens"] is None
    with pytest.raises(ValueError):
        tl.ingest_bounded_event("token_adjustment", {"input_tokens": -4})


def test_ingest_bounded_event_rejects_unknown_kind_and_payloads():
    with pytest.raises(ValueError):
        tl.ingest_bounded_event("client_ip_event", {})
    with pytest.raises(ValueError):
        tl.ingest_bounded_event("cache_event", "not-a-dict")


def test_host_observation_matrix_documents_missing_callbacks():
    matrix = tl.host_observation_matrix()
    assert set(matrix) == {"supported", "unsupported"}
    unsupported = {row["measurement"] for row in matrix["unsupported"]}
    assert "prompt-cache hits" in unsupported
    assert "search backend observations" in unsupported
    assert "client IP / User-Agent" in unsupported
    for row in matrix["unsupported"]:
        assert row["missing_callback"]


# ---------------------------------------------------------------------------
# Schema-v2 store: requests / attempts / hourly / counters
# ---------------------------------------------------------------------------


@pytest.fixture()
def store(tmp_path: Path) -> st.StateStore:
    return st.StateStore(tmp_path / "state")


def _table_names(db_path: Path) -> set[str]:
    conn = sqlite3.connect(str(db_path))
    try:
        rows = conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        return {row[0] for row in rows}
    finally:
        conn.close()


def test_schema_v2_creates_telemetry_tables(store: st.StateStore):
    names = _table_names(store.db_path)
    for table in st.TELEMETRY_TABLES:
        assert table in names
    conn = sqlite3.connect(str(store.db_path))
    try:
        version = conn.execute(
            "SELECT value FROM meta WHERE key='schema_version'"
        ).fetchone()[0]
    finally:
        conn.close()
    assert version == str(st.SCHEMA_VERSION)


def test_integrity_check_ok(store: st.StateStore):
    report = store.integrity_check()
    assert report["integrity_check"] == "ok"
    assert report["foreign_key_violations"] == 0


def test_request_lifecycle_success(store: st.StateStore):
    request_id = store.begin_request(
        api_request_id="req-1", provider="p", model="m", session_hash="abc123"
    )
    assert isinstance(request_id, int)
    # Idempotent on the same api_request_id.
    assert store.begin_request(api_request_id="req-1", provider="p", model="m") == request_id

    store.record_attempt(request_id, 0, provider="p", model="m")
    store.finish_request(
        request_id,
        status="success",
        response_model="m2",
        input_tokens=100,
        output_tokens=50,
        latency_ms=1500.0,
        ttft_ms=300.0,
        ended_at=1_700_000_000.0,
    )

    row = store.get_request(request_id)
    assert row is not None
    assert row["status"] == "success"
    assert row["response_model"] == "m2"
    assert row["input_tokens"] == 100
    assert row["output_tokens"] == 50
    assert row["latency_ms"] == 1500.0
    assert row["ttft_ms"] == 300.0

    attempts = store.get_request_attempts(request_id)
    assert len(attempts) == 1
    assert attempts[0]["ordinal"] == 0
    assert attempts[0]["provider"] == "p"


def test_finish_request_is_single_counted(store: st.StateStore):
    request_id = store.begin_request(api_request_id="req-dup", provider="p", model="m")
    store.finish_request(
        request_id, status="success", input_tokens=100, output_tokens=50,
        latency_ms=1000.0, ended_at=1_700_000_000.0,
    )
    # A duplicate terminal write (e.g. post + error pair) must not double-count.
    store.finish_request(
        request_id, status="error", input_tokens=999, output_tokens=999,
        latency_ms=2000.0, ended_at=1_700_000_000.5,
    )

    row = store.get_request(request_id)
    assert row["status"] == "success"  # first terminal result is immutable
    assert row["input_tokens"] == 100
    assert row["output_tokens"] == 50
    assert row["input_tokens"] == 100  # terminal tokens are immutable

    conn = sqlite3.connect(str(store.db_path))
    try:
        hourly = conn.execute("SELECT * FROM request_hourly").fetchall()
        total = conn.execute(
            "SELECT value FROM lifetime_counters WHERE key='total_requests'"
        ).fetchone()[0]
        tokens = conn.execute(
            "SELECT value FROM lifetime_counters WHERE key='total_input_tokens'"
        ).fetchone()[0]
    finally:
        conn.close()
    assert len(hourly) == 1
    assert hourly[0][1] == 1  # total_requests counted once
    assert hourly[0][2] == 1 and hourly[0][3] == 0  # one success, zero errors
    assert hourly[0][5] == 100  # tokens counted once (first terminal write)
    assert total == 1
    assert tokens == 100


def test_finish_request_hour_bucket_and_counters(store: st.StateStore):
    for i, (status, tokens_in, tokens_out) in enumerate(
        [("success", 10, 5), ("error", None, 7), ("canceled", None, None)]
    ):
        request_id = store.begin_request(api_request_id=f"r{i}")
        store.finish_request(
            request_id, status=status, input_tokens=tokens_in,
            output_tokens=tokens_out, ended_at=1_700_000_000.0,
        )
    conn = sqlite3.connect(str(store.db_path))
    try:
        row = conn.execute(
            "SELECT total_requests, success_count, error_count, canceled_count,"
            " input_tokens, output_tokens FROM request_hourly WHERE hour=?",
            ("2023-11-14 22:00:00",),
        ).fetchone()
        total_out = conn.execute(
            "SELECT value FROM lifetime_counters WHERE key='total_output_tokens'"
        ).fetchone()[0]
    finally:
        conn.close()
    assert row == (3, 1, 1, 1, 10, 12)
    assert total_out == 12


def test_finish_request_unknown_id_is_noop(store: st.StateStore):
    store.finish_request(424242, status="success")  # must not raise
    assert store.get_request(424242) is None


def test_record_attempt_ordering_and_flags(store: st.StateStore):
    request_id = store.begin_request(provider="p", model="m")
    store.record_attempt(request_id, 1, provider="p", status_code=429, retryable=True, reason="rate")
    store.record_attempt(request_id, 0, provider="p", status_code=500, retryable=False)
    attempts = store.get_request_attempts(request_id)
    assert [a["ordinal"] for a in attempts] == [0, 1]
    assert attempts[1]["retryable"] == 1
    assert attempts[0]["retryable"] == 0


def test_record_cache_and_search_events(store: st.StateStore):
    store.record_cache_event(provider="p", model="m", hit=True, latency_ms=1.25)
    store.record_search_event(provider="p", query_length=8, latency_ms=4.5, results_count=2)
    conn = sqlite3.connect(str(store.db_path))
    try:
        cache = conn.execute(
            "SELECT provider, model, hit, latency_ms FROM cache_events"
        ).fetchone()
        search = conn.execute(
            "SELECT provider, query_length, latency_ms, results_count FROM search_events"
        ).fetchone()
    finally:
        conn.close()
    assert cache == ("p", "m", 1, 1.25)
    assert search == ("p", 8, 4.5, 2)


def test_record_credential_scope_hashes_and_upserts(store: st.StateStore):
    store.record_credential_scope(provider="p", key_scope="team-a", auth_ok=True)
    store.record_credential_scope(provider="p", key_scope="team-a", auth_ok=False, reason="401")
    conn = sqlite3.connect(str(store.db_path))
    try:
        rows = conn.execute(
            "SELECT provider, key_scope_hash, last_auth_ok, observation_count FROM credential_scopes"
        ).fetchall()
    finally:
        conn.close()
    assert len(rows) == 1
    provider, scope_hash, auth_ok, count = rows[0]
    assert provider == "p"
    assert scope_hash == tl.redact_key_scope("team-a")
    assert auth_ok == 0  # last observation wins
    assert count == 2
    # The raw label must never be persisted in the database files.
    for db_file in (store.db_path, store.db_path.with_suffix(store.db_path.suffix + "-wal")):
        if db_file.exists():
            assert "team-a" not in db_file.read_bytes().decode("latin-1")


def test_begin_request_hashes_key_scope(store: st.StateStore):
    request_id = store.begin_request(api_request_id="req-scope", key_scope="team-b")
    row = store.get_request(request_id)
    assert row["key_scope"] == tl.redact_key_scope("team-b")
    assert "team-b" not in (row["key_scope"] or "")


def test_reopening_store_is_idempotent(tmp_path: Path):
    first = st.StateStore(tmp_path / "state")
    first.begin_request(api_request_id="keep-me")
    second = st.StateStore(tmp_path / "state")
    conn = sqlite3.connect(str(second.db_path))
    try:
        count = conn.execute("SELECT COUNT(*) FROM requests").fetchone()[0]
    finally:
        conn.close()
    assert count == 1


def test_v1_migration_is_atomic_and_preserves_catalog(tmp_path, monkeypatch):
    db_path = tmp_path / "autorouter.db"
    with sqlite3.connect(db_path) as db:
        db.executescript("""
            CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            INSERT INTO meta VALUES('schema_version', '1');
            CREATE TABLE catalog(provider TEXT, model TEXT, context_length INTEGER,
                capabilities TEXT, cost_tier TEXT, updated_at REAL,
                PRIMARY KEY(provider, model));
            INSERT INTO catalog VALUES('p', 'legacy', 8192, '{}', 'unknown', 123);
        """)
    original = st.StateStore._init_telemetry_schema
    def interrupted(self, conn):
        original(self, conn)
        raise sqlite3.OperationalError("simulated migration interruption")
    monkeypatch.setattr(st.StateStore, "_init_telemetry_schema", interrupted)
    with pytest.raises(sqlite3.OperationalError, match="interruption"):
        st.StateStore(tmp_path)
    with sqlite3.connect(db_path) as db:
        assert db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0] == "1"
        assert db.execute("SELECT model, updated_at FROM catalog").fetchone() == ("legacy", 123)
    assert not set(st.TELEMETRY_TABLES) & _table_names(db_path)
    monkeypatch.setattr(st.StateStore, "_init_telemetry_schema", original)
    migrated = st.StateStore(tmp_path)
    assert migrated.get_catalog()[0]["updated_at"] == 123
    assert set(st.TELEMETRY_TABLES) <= _table_names(db_path)
    with migrated._connect() as db:
        assert db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0] == str(st.SCHEMA_VERSION)
