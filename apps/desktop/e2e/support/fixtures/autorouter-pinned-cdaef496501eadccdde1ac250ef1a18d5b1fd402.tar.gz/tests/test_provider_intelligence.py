"""PIR-5 presentation contracts: registry counts, source ages and safe disclosure."""
import json
import time
from autorouter.autorouter_core.providers import provider_intelligence as pi
from autorouter.autorouter_core.storage import state
from .test_dashboard_state_reader import sr
from .verified_fixture import seed_verified_model


def test_registry_separates_candidates_from_adapters_and_verified_models():
    result = pi.registry_details(['nvidia', 'openrouter'], [])
    assert result['candidate_count'] == len(result['candidates']) == 249
    assert result['configured_provider_count'] == 2
    assert result['discovery_adapter_count'] == 6
    assert result['verified_eligible_model_count'] == 0
    assert result['verified_eligible_provider_count'] == 0
    assert all(c['verification'] == 'unverified_source_claim' for c in result['candidates'])
    assert all('VERIFIED_ZERO_PRICE_MODEL' not in c['access_classes'] for c in result['candidates'])
    assert any(c['access_classes'] == ['UNKNOWN'] for c in result['candidates'])
    assert all(c['jurisdiction'] == 'unknown' for c in result['candidates'])


def test_model_details_preserve_ages_units_and_unknown_policies():
    cap = dict(provider='p', model='m', access_evidence=[dict(provider='p', model='m', scope='model',
        classification='TRIAL', source_url='https://provider.example/models', source_type='provider_api', issuer='p',
        source_of_truth=True, observed_at=100, expires_at=200, account_scope='sk-secretsecretsecret', currency='USD',
        prices={'prompt': '0.1', 'completion': '0.2'})], quota_evidence=[dict(provider='p', model='m',
        account_scope='sk-secretsecretsecret', shared_scope='PRIVATE_SHARED_SCOPE_SENTINEL', dimension='requests', limit='100', remaining='9', window='day',
        source='advertised', source_url='https://provider.example/limits', observed_at=100, expires_at=200, reset_at=180)])
    details = pi.model_details(cap, 150, sr.scrub)
    assert details['access_classes'] == ['TRIAL']
    assert details['access_evidence'][0]['observed_at'] == 100
    assert details['access_evidence'][0]['payment_required'] is None
    q = details['quota_evidence'][0]
    assert (q['dimension'], q['remaining'], q['window'], q['reset_at']) == ('requests', '9', 'day', 180)
    assert q['status'] == 'unknown'  # advertised is not observed allowance
    assert details['token_estimate']['tokens'] is None
    assert 'sk-secretsecretsecret' not in json.dumps(details)
    assert 'PRIVATE_SHARED_SCOPE_SENTINEL' not in json.dumps(details)
    assert pi.model_details(cap, 201, sr.scrub)['access_evidence'][0]['freshness'] == 'stale_or_unverified'
    assert pi.model_details(cap, 201, sr.scrub)['access_classes'] == ['UNKNOWN']


def test_dashboard_uses_actual_preview_denials_and_preserves_readonly_intelligence(tmp_path, monkeypatch):
    store = state.StateStore(tmp_path)
    seed_verified_model(store, 'nvidia', 'configured', 32000, {'tools': True}, 'free')
    seed_verified_model(store, 'openrouter', 'disabled', 32000, {'tools': True}, 'free')
    monkeypatch.setattr(sr, 'read_plugin_config', lambda: dict(available=True, values=dict(
        providers=['nvidia'], state_dir=str(tmp_path), free_only=True), managed=False))
    before = store.db_path.read_bytes()
    models = sr.assemble_models()
    rows = {m['model']: m for m in models['models']}
    assert rows['configured']['eligible']
    assert not rows['disabled']['eligible'] and 'provider_disabled' in rows['disabled']['reason_codes']
    providers = sr.assemble_providers()
    assert providers['intelligence']['candidate_count'] == 249
    assert providers['intelligence']['verified_eligible_model_count'] == 1
    assert rows['configured']['access_classes'] == ['VERIFIED_ZERO_PRICE_MODEL']
    assert store.db_path.read_bytes() == before


def test_malformed_public_evidence_never_exposes_unknown_fields():
    cap = dict(provider='p', model='m', access_evidence=[dict(classification=[],
        source_url='https://user:private@host.invalid', regions=[{'secret': 'private'}, 'eu'], private='PRIVATE_SENTINEL')],
        quota_evidence=[dict(source_url='javascript:alert(1)', private='PRIVATE_SENTINEL')])
    out = pi.model_details(cap, time.time(), sr.scrub)
    assert out['access_evidence'][0]['source_url'] is None
    assert out['access_evidence'][0]['regions'] == ['eu']
    assert out['quota_evidence'][0]['source_url'] is None
    assert 'PRIVATE_SENTINEL' not in json.dumps(out)


def test_cached_operational_quota_reaches_models_and_providers_without_poll(tmp_path, monkeypatch):
    from autorouter.autorouter_core.evidence import free_access
    now = time.time()
    store = state.StateStore(tmp_path)
    seed_verified_model(store, 'openrouter', 'free', 32000, {'tools': True}, 'free')
    scope = free_access.canonical_scope('explicit-account-reference')
    record = dict(provider='openrouter', model=None, account_scope=scope, dimension='requests', window='day',
        source='provider_api', source_type='provider_api', source_url=free_access.ENDPOINT,
        issuer='openrouter', source_of_truth=True, observed_at=now - 10, expires_at=now + 100,
        limit='100', remaining='0', state='exhausted')
    free_access._save(store, free_access.FreeAccessSnapshot('openrouter', scope, [record], state='exhausted').to_dict())
    monkeypatch.setattr(sr, 'read_plugin_config', lambda: dict(available=True, values=dict(
        providers=['openrouter'], state_dir=str(tmp_path), credential_scopes={'openrouter': scope}), managed=False))
    import urllib.request
    monkeypatch.setattr(urllib.request, 'urlopen', lambda *a, **kw: (_ for _ in ()).throw(AssertionError('poll')))
    out = sr.assemble_models(now=now)
    model = out['models'][0]
    assert not model['eligible'] and 'verified_account_quota_exhausted' in model['reason_codes']
    assert model['free_access']['state'] == 'exhausted'
    assert model['free_access']['quota_evidence'][0]['observed_at'] == now - 10
    provider = sr.assemble_providers(now=now)['providers'][0]
    assert provider['free_access_states'] == ['exhausted']
    assert provider['quota_evidence'][0]['source_url'] == free_access.ENDPOINT
    assert not model['free_access']['hard_stop_guaranteed'] and not model['free_access']['verified_no_charge_execution']


def test_dashboard_health_matches_explicit_selected_scope(tmp_path, monkeypatch):
    now = time.time()
    store = state.StateStore(tmp_path)
    seed_verified_model(store, 'openrouter', 'm', 32000, {'tools': True}, 'free')
    store.record_outcome('openrouter', 'm', False, key_scope='connection-a', status_code=401, now=now)
    values = dict(providers=['openrouter'], state_dir=str(tmp_path), credential_scopes={'openrouter': 'connection-a'})
    monkeypatch.setattr(sr, 'read_plugin_config', lambda: dict(available=True, values=values, managed=False))
    row = sr.assemble_models(now=now + 1)['models'][0]
    assert not row['eligible'] and not row['health']['available']
    assert row['health']['auth_failed'] and row['health']['scope_state'] == 'known'
    assert 'auth_failed' in row['reason_codes']
    assert sr.assemble_providers(now=now + 1)['providers'][0]['auth_failed'] == 1
    values['credential_scopes']['openrouter'] = 'connection-b'
    row = sr.assemble_models(now=now + 1)['models'][0]
    assert row['eligible'] and row['health']['available'] and not row['health']['auth_failed']
    assert sr.assemble_providers(now=now + 1)['providers'][0]['auth_failed'] == 0
