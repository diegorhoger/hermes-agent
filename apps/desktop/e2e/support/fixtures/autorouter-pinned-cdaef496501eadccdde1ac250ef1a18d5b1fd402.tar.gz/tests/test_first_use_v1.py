"""First-use guidance reads evidence; activation/refresh/handoff are explicit actions."""

import json
import pytest
from autorouter.autorouter_core.discovery import first_use as fu
from autorouter.autorouter_core.routing import execution_adapter as ea, router
from tests.test_policies_v1 import seeded, NOW
from tests.test_dashboard_state_reader import sr
from tests.test_dashboard_api import _load_plugin_api


def snapshots():
    config = dict(
        available=True,
        managed=False,
        values=dict(enabled=True, providers=["nvidia", "openrouter"]),
    )
    inventory = dict(
        provider_scope="existing_nvidia_openrouter_integrations_only",
        connections=[
            dict(
                provider_id="nvidia",
                presence="configured",
                health="unknown",
                discovered_model_count=1,
                guidance={},
            ),
            dict(
                provider_id="openrouter",
                presence="unknown",
                health="unknown",
                guidance={},
            ),
        ],
    )
    models = dict(
        available=True,
        models=[dict(provider="nvidia", field_freshness={"cost_tier": "fresh"})],
        preview=dict(
            eligible_count=1,
            evidence_report=dict(
                schema_version=1,
                outcome="recommended",
                recommendation=dict(provider="nvidia", model="m"),
            ),
        ),
    )
    return config, inventory, models


def build(config, inventory, models):
    return fu.build(config, inventory, models, now=NOW, capabilities=ea.capabilities())


@pytest.mark.parametrize(
    "case,stage",
    [
        ("ready", "recommendation_ready"),
        ("disabled", "activation_required"),
        ("unreadable", "configuration_unavailable"),
        ("no-provider", "providers_required"),
        ("invalid-provider", "configuration_unavailable"),
        ("missing-catalog", "catalog_refresh_required"),
        ("corrupt", "evidence_unavailable"),
        ("stale", "no_eligible_recommendation"),
        ("no-match", "no_eligible_recommendation"),
    ],
)
def test_first_use_states_do_not_claim_live_auth_or_application(case, stage):
    c, i, m = snapshots()
    if case == "disabled":
        c["values"]["enabled"] = False
    elif case == "unreadable":
        c["available"] = False
    elif case == "no-provider":
        c["values"]["providers"] = []
    elif case == "invalid-provider":
        c["values"]["providers"] = "nvidia"
    elif case == "missing-catalog":
        m = dict(available=True, models=[])
    elif case == "corrupt":
        m = dict(available=False, models=[])
    elif case in ("stale", "no-match"):
        m["preview"]["eligible_count"] = 0
        m["preview"]["evidence_report"].update(outcome="no_match", recommendation=None)
        m["models"][0]["field_freshness"]["cost_tier"] = "stale_or_unverified"
    guide = build(c, i, m)
    assert guide["schema_version"] == 1 and guide["stage"] == stage
    assert guide["ready_for_recommendation"] == (stage == "recommendation_ready")
    assert guide["completion_scope"] == "recommendation evidence only"
    assert not guide["execution_authority"]
    assert not guide["execution_capabilities"]["host_confirmed_apply"]
    assert all(p["authentication"] == "unverified" for p in guide["providers"])


@pytest.mark.parametrize("presence", ["configured", "not_observed", "unknown"])
def test_presence_and_partial_provider_evidence_are_not_authentication(presence):
    c, i, m = snapshots()
    i["connections"][0]["presence"] = presence
    i["connections"][0]["health"] = "provider_auth_failure_observed"
    guide = build(c, i, m)
    assert guide["providers"][0]["presence"] == presence
    assert guide["providers"][0]["authentication"] == "unverified"
    assert guide["providers"][0]["active_credential_binding"] == "unknown"
    assert guide["providers"][0]["observed_auth_failure"]
    assert guide["evidence"]["configured_providers_without_displayed_models"] == [
        "openrouter"
    ]
    assert guide["evidence"]["provider_refresh_outcome"] == "unknown"


def test_future_inventory_contract_accepts_five_ids_without_fabricating_slots():
    c, i, m = snapshots()
    c["values"]["providers"] = list(fu.PROVIDERS)
    guide = build(c, i, m)
    assert len(guide["providers"]) == 5
    assert all(
        p["presence"] == "unknown" and p["authentication"] == "unverified"
        for p in guide["providers"][2:]
    )
    assert not any(p.get("credential_count") for p in guide["providers"])


def test_secret_and_untrusted_setup_fields_are_not_projected():
    c, i, m = snapshots()
    c["values"]["api_key"] = "SECRET"
    i["connections"][0].update(
        masked_credential="SECRET",
        account_id="PRIVATE",
        guidance={"key_issuance_url": "https://evil.test/?token=SECRET"},
    )
    guide = build(c, i, m)
    assert "SECRET" not in json.dumps(guide) and "PRIVATE" not in json.dumps(guide)
    assert guide["providers"][0]["setup_url"] is None


def test_real_readonly_sqlite_api_flow_has_correct_completion(tmp_path, monkeypatch):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    monkeypatch.setattr(router.time, "time", lambda: NOW)
    store = seeded(tmp_path)
    values = dict(
        enabled=True, state_dir=str(tmp_path), providers=["nvidia"], policy="auto"
    )
    config = dict(available=True, managed=False, values=values)
    monkeypatch.setattr(sr, "read_plugin_config", lambda: config)
    inventory = snapshots()[1]
    monkeypatch.setattr(sr, "assemble_connections", lambda now=None: inventory)
    before = store.db_path.read_bytes()
    actual = sr.assemble_first_use(now=NOW)
    assert actual["stage"] == "recommendation_ready" and actual["recommendation"]
    assert actual["evidence"]["eligible_models"] > 0
    api = _load_plugin_api()
    monkeypatch.setattr(api._sr, "read_plugin_config", lambda: config)
    monkeypatch.setattr(api._sr, "assemble_connections", lambda now=None: inventory)
    app = FastAPI()
    app.include_router(api.router, prefix="/api/plugins/autorouter")
    with TestClient(app) as client:
        response = client.get("/api/plugins/autorouter/first-use")
    assert response.status_code == 200 and response.json() == actual
    assert store.db_path.read_bytes() == before


def test_missing_first_use_state_does_not_initialize_or_enable_plugin(
    tmp_path, monkeypatch
):
    values = dict(enabled=False, state_dir=str(tmp_path), providers=[])
    monkeypatch.setattr(
        sr, "read_plugin_config", lambda: dict(available=True, values=values)
    )
    monkeypatch.setattr(
        sr, "assemble_connections", lambda now=None: dict(connections=[])
    )
    guide = sr.assemble_first_use(now=NOW)
    assert guide["stage"] == "activation_required"
    assert not (tmp_path / "autorouter.db").exists()
    assert values["enabled"] is False


def test_managed_setup_never_offers_override_commands():
    c, i, m = snapshots()
    c["managed"] = True
    c["values"]["enabled"] = False
    guide = build(c, i, m)
    assert guide["managed"] and guide["steps"][0]["commands"] == []
    assert "administrator" in guide["steps"][0]["instructions"]


def test_explicit_empty_authorization_does_not_select_cached_defaults(
    tmp_path, monkeypatch
):
    import autorouter as plugin
    from autorouter.autorouter_core.integration import runtime

    monkeypatch.setattr(router.time, "time", lambda: NOW)
    store = seeded(tmp_path)

    class Context:
        def get_config(self, key, default=None):
            return {"enabled": True, "providers": [], "state_dir": str(tmp_path)}.get(
                key, default
            )

        def register_hook(self, *args, **kwargs):
            pass

        def register_tool(self, *args, **kwargs):
            pass

    before = dict(runtime.get_state())
    plugin.register(Context())
    try:
        assert runtime.get_router().state["providers"] == []
        assert runtime.get_router().preview(now=NOW)["chosen"] is None
    finally:
        runtime._STATE.clear()
        runtime._STATE.update(before)


@pytest.mark.parametrize(
    "providers",
    ["nvidia", {}, ["nvidia", 1], ["unsupported"], ["nvidia", "unsupported"]],
)
def test_malformed_provider_authorization_never_becomes_ready(providers):
    c, i, m = snapshots()
    c["values"]["providers"] = providers
    guide = build(c, i, m)
    assert guide["stage"] == "configuration_unavailable"
    assert guide["providers"] == []
    assert not guide["ready_for_recommendation"]


@pytest.mark.parametrize(
    "providers",
    ["nvidia", {}, ["nvidia", 1], ["unsupported"], ["nvidia", "unsupported"]],
)
def test_invalid_provider_inventory_and_settings_grant_no_partial_authorization(
    providers,
):
    from autorouter.autorouter_core.providers import connections

    config = dict(available=True, values=dict(providers=providers))
    result = connections.inventory(
        config,
        presence_reader=lambda p: pytest.fail("credential presence must not be probed"),
    )
    assert not any(row["authorized"] for row in result["connections"])
    clean, errors = sr.validate_settings_updates(dict(providers=providers))
    assert errors and "providers" not in clean


def test_first_use_discloses_runtime_limits_without_stale_project_dependencies():
    c, i, m = snapshots()
    guide = build(c, i, m)
    assert guide["stage"] == "recommendation_ready"
    assert guide["completion_scope"] == "recommendation evidence only"
    limitations = " ".join(guide["limitations"])
    assert "#57" not in limitations and "#59" not in limitations
    assert "awaits" not in limitations
    assert "authentication and live provider entitlement are unverified" in limitations
    assert "recommendation is not applied or executed" in limitations
    assert "no-charge guarantee is unavailable" in limitations
