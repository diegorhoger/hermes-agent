"""Manual-only handoff is never confirmed apply, execution or credential authority."""

import json
from dataclasses import replace
import pytest
from autorouter.autorouter_core.integration import tools
from autorouter.autorouter_core.routing import execution_adapter as ea, router
from tests.test_policies_v1 import seeded, NOW
from tests.test_task_profiles_v1 import policy
from tests.test_dashboard_state_reader import sr
from tests.test_dashboard_api import _load_plugin_api


def setup_adapter(tmp_path, monkeypatch):
    monkeypatch.setattr(router.time, "time", lambda: NOW)
    store = seeded(tmp_path)
    values = dict(
        store=store,
        state_dir=str(tmp_path),
        enabled=True,
        providers=["nvidia"],
        policy="auto",
    )
    r = router.Router(values)
    preview = r.preview(now=NOW)
    selection = dict(
        schema_version=1,
        provider=preview["chosen"]["provider"],
        model=preview["chosen"]["model"],
        generated_at=NOW,
    )
    return ea.ManualHermesAdapter(r), selection, store, values


def test_capability_contract_never_grants_unsupported_authority():
    c = ea.capabilities()
    assert c["schema_version"] == 1 and c["selection_handoff"]
    assert all(
        c[k] is False
        for k in (
            "host_confirmed_apply",
            "host_confirmed_restore",
            "execution",
            "streaming",
            "retries",
            "spending_enforcement",
        )
    )


def test_explicit_confirmation_prepares_only_safe_manual_cli_and_no_writes(
    tmp_path, monkeypatch
):
    adapter, target, store, _ = setup_adapter(tmp_path, monkeypatch)
    before = store.db_path.read_bytes()
    pending = adapter.handoff(target, now=NOW)
    assert pending["state"] == "recommendation" and pending["manual_command"] is None
    receipt = adapter.handoff(target, confirmed=True, now=NOW)
    assert receipt["state"] == "manual_handoff_pending"
    assert receipt["manual_argv"] == [
        "hermes",
        "chat",
        "--provider",
        target["provider"],
        "--model",
        target["model"],
    ]
    assert receipt["manual_command"] == " ".join(receipt["manual_argv"])
    assert receipt["actual_request_target"] == "unobserved"
    assert (
        not receipt["applied"] and not receipt["restored"] and not receipt["executed"]
    )
    assert receipt["context_state"] == "unknown"
    assert store.db_path.read_bytes() == before
    assert (
        adapter.apply(target)["state"]
        == adapter.restore(target)["state"]
        == "unavailable_evidence"
    )
    assert store.db_path.read_bytes() == before


@pytest.mark.parametrize(
    "kind",
    [
        "version",
        "future",
        "expired",
        "paid",
        "unknown",
        "stale-proof",
        "missing",
        "injection",
        "secret",
        "malformed",
        "invalid-confirmation",
        "invalid-clock",
        "invalid-policy",
        "no-match",
    ],
)
def test_invalid_or_unproven_targets_cannot_produce_manual_command(
    tmp_path, monkeypatch, kind
):
    adapter, target, store, values = setup_adapter(tmp_path, monkeypatch)
    options = dict(confirmed=True, now=NOW)
    if kind == "version":
        target["schema_version"] = 2
    elif kind == "future":
        target["generated_at"] = NOW + 1
    elif kind == "expired":
        target["generated_at"] = NOW - 120
    elif kind in ("paid", "unknown"):
        target["model"] = kind
    elif kind == "stale-proof":
        options["now"] = 221
    elif kind == "missing":
        target["model"] = "missing"
    elif kind == "injection":
        target["model"] = "$(touch /tmp/WRONG)"
    elif kind == "secret":
        target["model"] = "sk-SECRET"
    elif kind == "malformed":
        target["prompt"] = "PRIVATE"
    elif kind == "invalid-confirmation":
        options["confirmed"] = "true"
    elif kind == "invalid-clock":
        options["now"] = float("nan")
    elif kind == "invalid-policy":
        options["selection_policy"] = {}
    else:
        options["min_context"] = 1000000000
    result = adapter.handoff(target, **options)
    assert result["state"] in ("validation_failed", "unavailable_evidence")
    assert result["manual_command"] is None and not result["applied"]
    assert "SECRET" not in json.dumps(result) and "PRIVATE" not in json.dumps(result)


@pytest.mark.parametrize(
    "field", ["profile_id", "session_id", "agent_id", "request_id", "schema_version"]
)
def test_concurrent_or_stale_context_never_matches_another_binding(
    tmp_path, monkeypatch, field
):
    adapter, target, _, _ = setup_adapter(tmp_path, monkeypatch)
    context = ea.ExecutionContext("1" * 32, "2" * 32, "3" * 32, "4" * 32)
    wrong = replace(context, **{field: 2 if field == "schema_version" else "5" * 32})
    receipt = adapter.handoff(
        target, context, confirmed=True, current_context=wrong, now=NOW
    )
    assert receipt["state"] == "validation_failed" and receipt["manual_command"] is None
    good = adapter.handoff(
        target, context, confirmed=True, current_context=context, now=NOW
    )
    assert good["context_state"] == "bound" and not good["applied"]
    assert "1" * 32 not in json.dumps(good)


def test_json_context_is_not_a_sanctioned_binding(tmp_path, monkeypatch):
    adapter, target, _, _ = setup_adapter(tmp_path, monkeypatch)
    assert (
        adapter.handoff(target, {}, confirmed=True, current_context={}, now=NOW)[
            "state"
        ]
        == "validation_failed"
    )


def test_tool_api_and_adapter_agree_without_database_writes_from_handoff(
    tmp_path, monkeypatch
):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    adapter, target, store, values = setup_adapter(tmp_path, monkeypatch)
    config = dict(
        available=True,
        managed=False,
        values={k: v for k, v in values.items() if k != "store"},
    )
    monkeypatch.setattr(sr, "read_plugin_config", lambda: config)
    monkeypatch.setattr(tools._rt(), "get_router", lambda: adapter.router)
    value = policy("general")
    value["hard_eligibility"]["authorized_providers"] = ["nvidia"]
    expected = adapter.handoff(target, confirmed=True, selection_policy=value, now=NOW)
    tool = tools._select_handler(
        {"selection_policy": value, "handoff": {"confirmed": True}}
    )
    assert tool["handoff_receipt"] == expected
    api = _load_plugin_api()
    monkeypatch.setattr(api._sr, "read_plugin_config", lambda: config)
    app = FastAPI()
    app.include_router(api.router, prefix="/api/plugins/autorouter")
    before = store.db_path.read_bytes()
    with TestClient(app) as client:
        response = client.post(
            "/api/plugins/autorouter/handoff/manual",
            json=dict(selection=target, confirmed=True, selection_policy=value),
        )
        capabilities = client.get("/api/plugins/autorouter/execution-capabilities")
        denied = client.post(
            "/api/plugins/autorouter/handoff/manual",
            json=dict(
                selection=target, confirmed=True, context={"session_id": "OTHER"}
            ),
        )
    assert response.status_code == 200 and response.json() == expected
    assert capabilities.json() == ea.capabilities()
    assert denied.status_code == 400
    assert store.db_path.read_bytes() == before


def test_disabled_plugin_and_absent_database_cannot_prepare_handoff(
    tmp_path, monkeypatch
):
    monkeypatch.setattr(router.time, "time", lambda: NOW)
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    api = _load_plugin_api()
    values = dict(enabled=False, state_dir=str(tmp_path), providers=["nvidia"])
    monkeypatch.setattr(
        api._sr, "read_plugin_config", lambda: dict(available=True, values=values)
    )
    app = FastAPI()
    app.include_router(api.router, prefix="/api/plugins/autorouter")
    target = dict(schema_version=1, provider="nvidia", model="m", generated_at=NOW)
    with TestClient(app) as client:
        out = client.post(
            "/api/plugins/autorouter/handoff/manual",
            json=dict(selection=target, confirmed=True),
        ).json()
    assert out["state"] == "unavailable_evidence" and out["reason"] == "plugin_disabled"
    values["enabled"] = True
    with TestClient(app) as client:
        unavailable = client.post(
            "/api/plugins/autorouter/handoff/manual",
            json=dict(selection=target, confirmed=True),
        ).json()
    assert unavailable["state"] == "unavailable_evidence"
    assert unavailable["reason"] == "selection_evidence_absent"
    assert not (tmp_path / "autorouter.db").exists()


def test_legacy_helper_does_not_inspect_or_mutate_any_agent():
    from autorouter.autorouter_core.routing.integration import apply_to_agent

    class HostTrap:
        def __getattribute__(self, name):
            raise AssertionError("private host inspection")

        def __setattr__(self, name, value):
            raise AssertionError("private host mutation")

    assert apply_to_agent(HostTrap()) is False


def test_failed_revalidation_does_not_echo_native_exception(tmp_path, monkeypatch):
    adapter, target, _, _ = setup_adapter(tmp_path, monkeypatch)

    def broken(**kwargs):
        raise RuntimeError("sk-SECRET PRIVATE")

    monkeypatch.setattr(adapter.router, "preview", broken)
    receipt = adapter.handoff(target, confirmed=True, now=NOW)
    assert receipt["state"] == "unavailable_evidence"
    assert "SECRET" not in json.dumps(receipt) and "PRIVATE" not in json.dumps(receipt)


def test_manual_cli_cannot_weaken_account_specific_requirements(tmp_path, monkeypatch):
    adapter, target, _, _ = setup_adapter(tmp_path, monkeypatch)
    canonical = adapter.router.preview(now=NOW)
    canonical["selection_policy"] = {
        "connection_restrictions": {"require_authority": True},
        "quota_policy": "avoid_verified_exhaustion",
    }
    monkeypatch.setattr(adapter.router, "preview", lambda **kwargs: canonical)
    receipt = adapter.handoff(target, confirmed=True, now=NOW)
    assert receipt["state"] == "unavailable_evidence"
    assert receipt["reason"] == "manual_cli_cannot_preserve_connection_authority"
    assert receipt["manual_command"] is None


@pytest.mark.parametrize("profile", ["general", "coding", "fast-response"])
def test_real_api_original_profile_request_handoffs_while_public_explanation_is_not_request(
    tmp_path, monkeypatch, profile
):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    adapter, _, _, values = setup_adapter(tmp_path, monkeypatch)
    value = policy(profile)
    value["hard_eligibility"]["authorized_providers"] = ["nvidia"]
    value["hard_eligibility"]["min_context"] = 12000
    preview = adapter.router.preview(selection_policy=value, now=NOW)
    target = dict(
        schema_version=1,
        provider=preview["chosen"]["provider"],
        model=preview["chosen"]["model"],
        generated_at=NOW,
    )
    api = _load_plugin_api()
    monkeypatch.setattr(
        api._sr,
        "read_plugin_config",
        lambda: dict(
            available=True, values={k: v for k, v in values.items() if k != "store"}
        ),
    )
    app = FastAPI()
    app.include_router(api.router, prefix="/api/plugins/autorouter")
    with TestClient(app) as client:
        broken = client.post(
            "/api/plugins/autorouter/handoff/manual",
            json=dict(
                selection=target,
                confirmed=True,
                selection_policy=preview["selection_policy"],
            ),
        ).json()
        fixed = client.post(
            "/api/plugins/autorouter/handoff/manual",
            json=dict(selection=target, confirmed=True, selection_policy=value),
        ).json()
    assert broken["state"] == "validation_failed" and broken["manual_command"] is None
    assert fixed["state"] == "manual_handoff_pending"
    assert (
        fixed["evidence_report"]["selection_requirements"]["hard_eligibility"][
            "min_context"
        ]
        == 12000
    )
    assert not fixed["applied"] and not fixed["executed"]
