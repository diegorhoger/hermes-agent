"""Explicit profiles use synthetic public evidence, never credentials or inference."""

import json
from pathlib import Path
import pytest
from autorouter.autorouter_core.routing import task_profiles as tp
from autorouter.autorouter_core.configuration import selection_policy as sp
from autorouter.autorouter_core.routing import router, scoring
from autorouter.autorouter_core.integration import tools
from tests.test_selection_policy_v1 import request, candidate, run
from tests.test_policies_v1 import seeded, NOW
from tests.test_dashboard_state_reader import sr
from tests.test_dashboard_api import _load_plugin_api

FIXTURE = Path(__file__).with_name("fixtures") / "task-profiles-v1.json"


def policy(profile="general", tools_required=False):
    value = request()
    value["task_requirements"].update(
        label=profile, profile=dict(schema_version=1, id=profile)
    )
    value["preferences"]["policy"] = (
        "fast-response" if profile == "fast-response" else "general"
    )
    if tools_required:
        value["task_requirements"]["required_capabilities"] = {"tools": "required"}
    return value


@pytest.mark.parametrize("profile", ["general", "coding", "fast-response"])
def test_portable_profile_contract(profile):
    fixture = json.loads(FIXTURE.read_text())
    assert fixture["profiles"] == tp.catalog()
    assert fixture["synthetic"] and not fixture["live_entitlement"]
    portable = next(
        v for v in fixture["requests"] if v["task_requirements"]["label"] == profile
    )
    assert run(value=portable) == run(value=policy(profile))
    value = policy(profile)
    normalized = sp.validate(value)
    assert (
        normalized["preferences"]["policy"]
        == tp.resolve(value["task_requirements"]["profile"])["preference"]
    )
    out = run(value=value)
    assert out["chosen"] and out["semantic_quality"] == "unknown"
    assert out["task_profile"]["hard_capabilities"] == {}
    assert out["task_profile"]["min_context"] == 8192
    assert not out["execution_authority"]
    assert out == run(value=value)


@pytest.mark.parametrize(
    "bad",
    [
        None,
        {},
        [],
        True,
        {"id": "general"},
        {"schema_version": 1, "id": "unknown"},
        {"schema_version": 2, "id": "coding"},
        {"schema_version": True, "id": "general"},
        {"schema_version": 1, "id": []},
        {"schema_version": 1, "id": "general", "prompt": "SECRET"},
    ],
)
def test_invalid_explicit_profile_never_defaults(bad):
    value = policy()
    value["task_requirements"]["profile"] = bad
    out = run(value=value)
    assert out["chosen"] is None and out["no_match"] == "selection_policy_invalid"
    assert out["contract_error"].startswith("task_profile_")
    assert "SECRET" not in json.dumps(out)


@pytest.mark.parametrize("profile", ["general", "coding", "fast-response"])
@pytest.mark.parametrize(
    "kind",
    [
        "paid",
        "unknown",
        "stale",
        "tools",
        "context",
        "retired",
        "unhealthy",
        "stale-tools",
        "stale-context",
    ],
)
def test_profiles_preserve_hard_gates(profile, kind):
    value = policy(profile, tools_required=kind in ("tools", "stale-tools"))
    row = candidate()
    if kind in ("paid", "unknown"):
        row["cost_tier"] = kind
    elif kind == "stale":
        row["field_evidence"]["cost_tier"]["expires_at"] = 149
    elif kind == "tools":
        row["capabilities"]["tools"] = False
    elif kind == "context":
        row["context_length"] = 4096
    elif kind == "retired":
        row["retired"] = True
    elif kind == "unhealthy":
        row.update(health_reason="auth_failed", health={"auth_failed": 1})
    elif kind == "stale-tools":
        row["field_evidence"]["tools"]["expires_at"] = 149
    else:
        row["field_evidence"]["context_window"]["expires_at"] = 149
    out = run([row], value=value)
    assert out["chosen"] is None and out["considered"][0]["reason_codes"]
    assert out["no_match"] == "no_eligible_model"


def test_coding_tools_only_when_workload_explicitly_requires_them():
    rows = [candidate("a", capabilities={"tools": False}), candidate("b")]
    assert run(rows, value=policy("coding"))["chosen"]["model"] == "a"
    assert run(rows, value=policy("coding", True))["chosen"]["model"] == "b"
    value = policy("coding", True)
    value["hard_eligibility"]["required_capabilities"] = {"tools": "forbidden"}
    assert run(rows, value=value)["no_match"] == "selection_policy_invalid"
    value = policy("coding")
    value["task_requirements"]["label"] = "general"
    assert run(value=value)["contract_error"] == "task_profile_conflict"


def observations(latency, now=150):
    return scoring.summarize_observations(
        [
            dict(id=i, ended_at=now, status="success", latency_ms=latency)
            for i in range(1, 17)
        ],
        now=now,
    )


def test_fast_profile_uses_confidence_aware_observed_latency_not_model_name():
    rows = [
        candidate("a-fast-name", outcome_observations=observations(1000)),
        candidate("z", outcome_observations=observations(5)),
    ]
    result = run(rows, value=policy("fast-response"))
    assert result["chosen"]["model"] == "z"
    speed = result["chosen"]["score"]["observations"]
    assert (
        speed["source"] == "observed_final_requests" and speed["latency_confidence"] > 0
    )
    assert result["chosen"]["score"]["semantic_quality"] == "unknown"
    assert result == run(list(reversed(rows)), value=policy("fast-response"))
    # General remains balanced; Coding does not fabricate a competence prior.
    assert run(rows, value=policy("general"))["policy"] == "general"
    assert run(rows, value=policy("coding"))["policy"] == "general"


@pytest.mark.parametrize("kind", ["missing", "stale", "future", "wrong-source"])
def test_missing_or_invalid_performance_has_no_speed_claim(kind):
    row = candidate(outcome_observations=observations(1))
    if kind == "missing":
        row.pop("outcome_observations")
    elif kind == "stale":
        row["outcome_observations"]["last_latency_observed_at"] = -604800
    elif kind == "future":
        row["outcome_observations"]["last_latency_observed_at"] = 151
    else:
        row["outcome_observations"]["source"] = "advertised"
    out = run([row], value=policy("fast-response"))
    score = out["chosen"]["score"]
    assert score["observations"]["latency_ewma_ms"] is None
    assert score["observations"]["latency_confidence"] == 0
    assert score["observations"]["latency_samples"] == 0


@pytest.mark.parametrize("profile", ["general", "coding", "fast-response"])
def test_engine_preview_tool_api_parity_and_readonly(tmp_path, monkeypatch, profile):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    monkeypatch.setattr(router.time, "time", lambda: NOW)
    store = seeded(tmp_path)
    values = dict(state_dir=str(tmp_path), providers=["nvidia"], policy="auto")
    r = router.Router(dict(values, store=store))
    config = dict(available=True, managed=False, values=values)
    monkeypatch.setattr(sr, "read_plugin_config", lambda: config)
    monkeypatch.setattr(tools._rt(), "get_router", lambda: r)
    value = policy(profile)
    value["hard_eligibility"]["authorized_providers"] = ["nvidia"]
    before = store.db_path.read_bytes()
    expected = r.preview(selection_policy=value, now=NOW)
    assert sr.assemble_models(now=NOW, selection_policy=value)["preview"] == expected
    assert store.db_path.read_bytes() == before
    api = _load_plugin_api()
    monkeypatch.setattr(api._sr, "read_plugin_config", lambda: config)
    app = FastAPI()
    app.include_router(api.router, prefix="/api/plugins/autorouter")
    with TestClient(app) as client:
        result = client.post(
            "/api/plugins/autorouter/selection/preview",
            json={"selection_policy": value},
        )
        catalog = client.get("/api/plugins/autorouter/task-profiles")
    assert result.status_code == 200 and result.json() == expected
    assert catalog.json()["profiles"] == tp.catalog()
    assert store.db_path.read_bytes() == before
    assert tools._select_handler({"selection_policy": value})["decision"] == expected
    assert r.select(selection_policy=value, return_decision=True) == expected
    assert not r.state.get("connection_contexts") and not r.state.get(
        "quota_policy_evaluator"
    )


def test_catalog_name_and_synthetic_transport_cannot_prove_entitlement():
    row = candidate("coding-free-fast", cost_tier="unknown")
    for profile in tp.catalog():
        assert run([row], value=policy(profile["id"]))["chosen"] is None


def test_profile_preference_conflict_and_builder_validation():
    value = policy("fast-response")
    value["preferences"]["policy"] = "general"
    assert run(value=value)["contract_error"] == "task_profile_preference_conflict"
    for profile in tp.catalog():
        built = tp.request(profile["id"], ["openrouter"])
        assert sp.validate(built) == built
        assert built["task_requirements"]["profile"]["id"] == profile["id"]
    with pytest.raises(sp.PolicyError):
        tp.request("coding", ["openrouter"], requires_tools="true")


def test_recent_outcome_without_latency_does_not_refresh_old_latency():
    rows = [
        dict(id=1, ended_at=1, status="success", latency_ms=1),
        dict(id=2, ended_at=700000, status="success", latency_ms=None),
    ]
    stats = scoring.summarize_observations(rows, now=700000)
    assert stats["last_latency_observed_at"] == 1
    filtered = tp.scoring_candidate(
        candidate(outcome_observations=stats), tp.catalog()[2], 700000
    )
    assert filtered["outcome_observations"]["latency_ewma_ms"] is None
    assert filtered["outcome_observations"]["last_latency_observed_at"] == 1


def test_fast_and_general_rank_differently_for_evidenced_tradeoff():
    reliable = observations(500)
    fast = scoring.summarize_observations(
        [
            dict(
                id=i, ended_at=150, status="success" if i < 9 else "error", latency_ms=5
            )
            for i in range(1, 17)
        ],
        now=150,
    )
    rows = [
        candidate("reliable", outcome_observations=reliable),
        candidate("fast", outcome_observations=fast),
    ]
    assert run(rows, value=policy("general"))["chosen"]["model"] == "reliable"
    assert run(rows, value=policy("fast-response"))["chosen"]["model"] == "fast"


def test_unusable_latency_does_not_discard_independent_reliability():
    observed = observations(1)
    observed["last_latency_observed_at"] = 151
    clean = tp.scoring_candidate(
        candidate(outcome_observations=observed), tp.catalog()[2], 150
    )["outcome_observations"]
    assert clean["reliability"] == observed["reliability"]
    assert clean["confidence"] == observed["confidence"]
    assert clean["latency_confidence"] == 0 and clean["latency_ewma_ms"] is None


@pytest.mark.parametrize("profile", ["general", "coding", "fast-response"])
@pytest.mark.parametrize("mode", sp.QUOTA_MODES)
def test_profiles_preserve_quota_modes_without_host_extension(profile, mode):
    value = policy(profile)
    value["quota_policy"] = mode
    out = run(value=value)
    assert bool(out["chosen"]) == (
        mode in ("prefer_available_allowance", "avoid_verified_exhaustion")
    )
    assert out["considered"][0]["connection_authority"] == "unknown"
    assert out["considered"][0]["quota_policy_evidence"]["state"] == "unknown"
    assert not out["execution_authority"]


@pytest.mark.parametrize("profile", ["general", "coding", "fast-response"])
def test_missing_tools_are_not_verified_for_explicit_workload(profile):
    assert (
        run([candidate(capabilities={})], value=policy(profile, True))["chosen"] is None
    )
