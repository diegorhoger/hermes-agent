import json, subprocess, sys, tempfile, threading, time, pathlib

def test_phase_log_survives_child_termination(tmp_path):
    log = tmp_path / "phases.jsonl"
    code = '''
import json, os, time, sys
p = sys.argv[1]
rec = {"ts": time.monotonic(), "pid": os.getpid(), "tid": 1, "phase": "X", "state": "enter"}
with open(p, "a") as f:
    f.write(json.dumps(rec) + "\\n"); f.flush(); os.fsync(f.fileno())
time.sleep(10)
'''
    proc = subprocess.Popen([sys.executable, "-c", code, str(log)])
    time.sleep(1)
    proc.terminate()
    proc.wait(timeout=5)
    data = log.read_text().strip().splitlines()
    assert len(data) == 1
    r = json.loads(data[0])
    assert r["phase"] == "X" and r["state"] == "enter"

def test_uv_guard_rejects_forbidden_and_allows_safe(tmp_path):
    # Test conceptually by simulating wrapper
    forbidden = [pathlib.Path(tmp_path / "forbidden" / "venv").resolve(),
                 pathlib.Path(tmp_path / "forbidden").resolve(),
                 pathlib.Path(tmp_path / "scratch" / "autorouter-v02").resolve(),
                 pathlib.Path(tmp_path / "plugins").resolve()]
    def guard(dest):
        d = pathlib.Path(dest).resolve()
        for f in forbidden:
            if d == f or f in d.parents:
                return False
        return True
    assert guard(str(tmp_path / "scratchpad" / "safe")) is True
    assert guard(str(forbidden[0])) is False
    assert guard(str(pathlib.Path(tmp_path / "plugins" / "x"))) is False
    assert guard(str(pathlib.Path(tmp_path / "scratch" / "autorouter-v02" / "sub"))) is False

