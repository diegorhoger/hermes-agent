"""Five-adapter readiness and secure host gaps; no secret intake or network."""
import json
from types import SimpleNamespace
import pytest
from autorouter.autorouter_core.providers import connections
from tests.test_dashboard_api import client, state_dir

FIVE=['nvidia','openrouter','groq','gemini','mistral']


def config():
    return {'available':True,'values':{'providers':FIVE + ['nous']}}


def test_five_adapters_with_unknown_auth_and_unavailable_slot_authority(monkeypatch):
    # On six-only floor the inventory is exactly six-plus-nous; the dynamic
    # registry, when enabled, adds host-recognized rows with their own axes.
    monkeypatch.setenv('AUTOROUTER_REGISTRY_OFFLINE', '1')
    observed={p:{'model_count':7,'discovered_model_count':3,'eligible_model_count':1,
        'verified':True,'slots':[{'name':'SECRET_UNTRUSTED','key':'SECRET_UNTRUSTED'}]} for p in FIVE}
    result=connections.inventory(config(),observed,presence_reader=lambda p:(True,None))
    assert [c['provider_id'] for c in result['connections']]==FIVE+['nous']
    for row in result['connections']:
        row_expected = dict(configured=True,presence_observed=True,
            authentication_validated='unknown',models_discovered=None,models_eligible=None,model_count_scope='displayed proof snapshot (maximum 500 rows)',operationally_usable='unknown')
        if row['provider_id'] != 'nous':
            row_expected.update(models_discovered=3, models_eligible=1)
        assert row['readiness']==row_expected
        assert row['connection_slots'] is None and row['account_count'] is None
        assert row['onboarding_url']=='/autorouter?provider='+row['provider_id']
        assert not row['verified'] and row['model_scope'] is None
        assert all(not row['operations'][op]['supported'] for op in connections.OPERATIONS)
    assert 'SECRET_UNTRUSTED' not in json.dumps(result)


@pytest.mark.parametrize('provider',FIVE)
def test_missing_native_profile_never_reads_environment_or_claims_setup(provider,monkeypatch):
    import providers
    monkeypatch.setattr(providers,'get_provider_profile',lambda p:None)
    monkeypatch.setattr(connections.os.environ,'get',lambda *args:pytest.fail('undeclared credential slot read'))
    assert connections.host_presence(provider)==(None,'host_presence_unavailable')


def test_gemini_only_declared_fixed_aliases_count_as_presence(monkeypatch):
    import providers
    monkeypatch.setattr(providers,'get_provider_profile',lambda p:SimpleNamespace(env_vars=('GEMINI_API_KEY','ARBITRARY_SECRET')))
    monkeypatch.setenv('GEMINI_API_KEY','SYNTHETIC_SENTINEL')
    assert connections.host_presence('gemini')==(True,None)
    result=connections.inventory(config())
    assert 'SYNTHETIC_SENTINEL' not in json.dumps(result)


@pytest.mark.parametrize('provider',FIVE)
@pytest.mark.parametrize('operation',connections.OPERATIONS)
def test_no_host_lifecycle_never_succeeds(provider,operation):
    with pytest.raises(connections.ConnectionError) as error:
        connections.unavailable_operation(provider,operation,config())
    assert error.value.status==501


def test_unavailable_model_proofs_do_not_become_zero_eligible(client,state_dir,monkeypatch):
    from autorouter.autorouter_core.storage import state
    from tests.test_dashboard_api import _load_plugin_api
    state.StateStore(state_dir)
    api=_load_plugin_api()
    monkeypatch.setattr(api._sr,'assemble_models',lambda **kwargs:{'available':False})
    response=client.get('/api/plugins/autorouter/connections')
    assert response.status_code==200
    assert all(row['readiness']['models_eligible'] is None for row in response.json()['connections'])
