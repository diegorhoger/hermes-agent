"""Static + behavioral smoke tests for the Hermes Desktop runtime plugin.

These tests do NOT prove the Desktop GUI renders — that requires the real app
(see issue #96 for the live acceptance evidence). They prove the artifact is
loadable by the Desktop runtime door's contract: one ESM default export, the
import allowlist (@hermes/plugin-sdk and react* only), no HTML-injection
sinks, and the exact contributions the Desktop navigation/routing system
consumes (sidebar.nav entry, /autorouter route, palette command).
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
PLUGIN = ROOT / "desktop" / "plugin.js"
HARNESS = ROOT / "tests" / "fixtures" / "desktop_plugin.harness.mjs"

NODE = shutil.which("node")


def test_desktop_plugin_exists():
    assert PLUGIN.is_file(), "desktop/plugin.js is required for Desktop integration (issue #96)"


def test_no_html_injection_sinks_or_eval():
    src = PLUGIN.read_text()
    for sink in (".innerHTML", ".outerHTML", "insertAdjacentHTML", "document.write", "eval(", "new Function"):
        assert sink not in src, f"forbidden sink {sink} in desktop/plugin.js"


def test_imports_stay_within_runtime_allowlist():
    src = PLUGIN.read_text()
    specifiers = re.findall(r"(?:from|import)\s*\(?\s*['\"]([^'\"]+)['\"]", src)
    allowed = {"@hermes/plugin-sdk", "react", "react/jsx-runtime", "react/jsx-dev-runtime"}
    unsupported = sorted({s for s in specifiers if s not in allowed})
    assert not unsupported, f"imports outside the Desktop allowlist: {unsupported}"


def test_no_direct_fetch_or_websocket():
    """All backend traffic must go through ctx.rest / ctx.socket."""
    src = PLUGIN.read_text()
    assert "fetch(" not in src
    assert "WebSocket" not in src
    assert "XMLHttpRequest" not in src


def test_all_five_management_tabs_present():
    src = PLUGIN.read_text()
    for label in ("Overview", "Providers", "Models", "Analytics", "Settings"):
        assert f"'{label}'" in src or f'"{label}"' in src


def test_analytics_surfaces_pending_and_decided_success_rate():
    """Analytics must show the full status breakdown (including pending) and
    label the success rate as decided-outcome (success + error) based."""
    src = PLUGIN.read_text()
    assert "summary.pending)} pending" in src
    assert "share of decided requests (success + error)" in src


@pytest.mark.skipif(NODE is None, reason="node is not available")
def test_plugin_registers_nav_route_and_palette(tmp_path):
    out = tmp_path / "report.json"
    result = subprocess.run(
        [NODE, str(HARNESS), str(PLUGIN), str(out)],
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert result.returncode == 0, f"harness failed: {result.stderr}"
    report = json.loads(out.read_text())

    assert report["load_error"] is None, report["load_error"]
    assert report["unsupported_imports"] == []
    assert report["plugin_id"] == "autorouter"

    by_area = {}
    for contribution in report["contributions"]:
        by_area.setdefault(contribution["area"], []).append(contribution)

    # Route: a full page at /autorouter, renderable by the workspace pane.
    routes = by_area.get("routes", [])
    assert len(routes) == 1
    page = routes[0]
    assert page["data"]["path"] == "/autorouter"
    assert page["has_render"], "route must carry a render function"
    assert page["title"] == "AutoRouter"

    # Sidebar navigation row pointing at the same route.
    nav = by_area.get("sidebar.nav", [])
    assert len(nav) == 1
    assert nav[0]["data"]["codicon"] == "zap"
    assert nav[0]["data"]["label"] == "AutoRouter"
    assert nav[0]["data"]["path"] == page["data"]["path"]

    # Palette command navigates to the page.
    palette = by_area.get("command_palette", [])
    assert len(palette) == 1
    assert palette[0]["data"]["id"] == "autorouter.open"
    assert report["navigate_calls"] == ["/autorouter"]


def test_enable_provider_uses_fresh_settings_read():
    """The provider enable action must not build its write from a stale
    inventory snapshot — it reads /settings fresh and re-verifies after."""
    src = PLUGIN.read_text()
    i_enable = src.index("const enableProvider = (id) =>")
    i_ping = src.index("ctx.rest('/settings').then(", i_enable)
    assert "const current = Array.isArray(fresh?.values?.providers)" in src[i_ping:i_ping + 400]
    # No PUT may be built from the inventory snapshot's authorized list.
    assert "inv.filter((c) => c.authorized)" not in src[i_enable:i_enable + 1500]
    # Post-write verification read exists (concurrent-change detection).
    assert src.count("ctx.rest('/settings')") >= 2


def test_profiles_section_and_api_surface():
    src = PLUGIN.read_text()
    assert "'profiles'" in src, "Profiles tab id missing"
    assert "Profiles" in src
    for endpoint in ("'/routing-profiles'", "/routing-profiles/"):
        assert endpoint in src, f"routing-profiles API call missing: {endpoint}"
    assert "Preview eligible models" in src
    assert "Set as AutoRouter default" in src
    assert "verified-free" in src


def test_desktop_plugin_is_packaged():
    """build_package.py must ship desktop/plugin.js in the installable ZIP."""
    spec = (ROOT / "tools" / "build_package.py").read_text()
    assert '"desktop/plugin.js"' in spec, "build_package.py REQUIRED must include desktop/plugin.js"
