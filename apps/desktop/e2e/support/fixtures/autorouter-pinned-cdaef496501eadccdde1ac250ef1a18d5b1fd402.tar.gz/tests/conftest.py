"""Test bootstrap for AutoRouter plugin.

Registers the repository root as the ``autorouter`` package shell so plugin
submodules (``autorouter.router`` etc.) import exactly as they do under the
Hermes plugin loader. Hermes host modules resolve from a Hermes agent tree
(env ``HERMES_AGENT`` or ``~/.hermes/hermes-agent``); when Hermes is not
available, a minimal ``providers`` test double is installed so the plugin's
discovery/connections code stays testable standalone — the double is
namespaced the same way the plugin consumes it and is replaced by the real
host package whenever one is importable. Hermes-host tests themselves skip
when the host is not importable.
"""

from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path
from types import ModuleType

import pytest

PACKAGE = "autorouter"
_ROOT = Path(__file__).resolve().parents[1]

sys.path[:] = [p for p in sys.path if Path(p or ".").resolve() != _ROOT]


def _hermes_agent_dir() -> Path | None:
    env = os.environ.get("HERMES_AGENT")
    candidates = [Path(env)] if env else []
    candidates.append(Path.home() / ".hermes" / "hermes-agent")
    for candidate in candidates:
        try:
            if candidate.is_dir() and (candidate / "hermes_cli").is_dir():
                return candidate
        except OSError:
            continue
    return None


_HERMES = _hermes_agent_dir()
if _HERMES is not None and str(_HERMES) not in sys.path:
    sys.path.insert(0, str(_HERMES))


def _providers_importable() -> bool:
    try:
        import providers  # noqa: F401

        return True
    except Exception:
        return False


if not _providers_importable():
    _providers_mock = ModuleType("providers")

    def _get_provider_profile(name):
        return None

    _providers_mock.get_provider_profile = _get_provider_profile
    sys.modules["providers"] = _providers_mock


def _load_plugin_package():
    if PACKAGE in sys.modules:
        return sys.modules[PACKAGE]
    spec = importlib.util.spec_from_file_location(
        PACKAGE, _ROOT / "__init__.py", submodule_search_locations=[str(_ROOT)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[PACKAGE] = module
    spec.loader.exec_module(module)
    return module


_load_plugin_package()


class _Collector:
    @pytest.hookimpl(tryfirst=True)
    def pytest_collect_directory(self, path, parent):
        if Path(path).resolve() == _ROOT:
            return pytest.Dir.from_parent(parent, path=path)
        return None


def pytest_configure(config):
    if not config.pluginmanager.has_plugin("autorouter-repo-root"):
        config.pluginmanager.register(_Collector(), "autorouter-repo-root")
