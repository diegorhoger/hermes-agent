import json
import time
import pytest
from autorouter.autorouter_core.discovery import metadata as md, discovery as dc
from autorouter.autorouter_core.routing import router as rt
from autorouter.autorouter_core.storage import state as st


def fixture(now=None):
    return md.normalize_openrouter({'data': [dict(id='arbitrary-model', context_length=32768,
        supported_parameters=['tools'], pricing={'prompt': '0', 'completion': '0'})]}, now)


def test_persistence_and_selection(tmp_path, monkeypatch):
    import providers
    class Profile:
        env_vars = ()
        def fetch_models(self, **kw):
            return ['arbitrary-model']
    monkeypatch.setattr(providers, 'get_provider_profile', lambda name: Profile())
    monkeypatch.setattr(md, 'fetch_metadata', lambda provider: fixture())
    store = st.StateStore(tmp_path)
    dc.discover_all(['openrouter'], store)
    assert len(store.get_catalog()) == 1
    cap = store.get_capability('openrouter', 'arbitrary-model')
    assert 0 < cap['retrieved_at'] <= time.time()
    assert cap['expires_at'] > cap['retrieved_at']
    router = rt.Router(dict(store=store))
    assert router.select(requires_tools=True)
    store.upsert_health('openrouter', 'arbitrary-model', retired=1)
    assert router.select() is None


def test_errors_are_observable(tmp_path, monkeypatch, caplog):
    store = st.StateStore(tmp_path)
    monkeypatch.setattr(dc, 'discover_provider', lambda *a, **k: [dict(provider='p', model='m')])
    monkeypatch.setattr(store, 'persist_discovered_model', lambda *a, **k: (_ for _ in ()).throw(ValueError('SECRET')))
    with pytest.raises(RuntimeError, match='persistence failed'):
        dc.discover_all(['p'], store)
    assert store.get_lkg() is None
    assert 'SECRET' not in caplog.text


@pytest.mark.parametrize('pricing,expected', [(None, 'unknown'), ({}, 'unknown'),
    ({'prompt':'0','completion':'1'}, 'paid'), ({'prompt':'0','completion':'0','request':'1'}, 'paid'),
    ({'prompt':'NaN','completion':'0'}, 'unknown')])
def test_pricing(pricing, expected):
    row = md.normalize_openrouter({'data':[dict(id='premium-free-tools-128k', pricing=pricing)]})
    assert row['premium-free-tools-128k']['cost_tier'] == expected
    assert row['premium-free-tools-128k']['context_window'] is None
    assert row['premium-free-tools-128k']['tools'] == 'unknown'


def test_partial_and_expiration(tmp_path):
    old = fixture(100)['arbitrary-model']
    fresh = dict(old, tools='unsupported', cost_tier='paid', retrieved_at=200, expires_at=300)
    merged = md.merge_metadata(fresh, old, 201)
    assert merged['cost_tier'] == 'paid'
    assert merged['tools'] == 'unsupported'
    partial = md.merge_metadata(dict(provider='openrouter', model='arbitrary-model'), old, 202)
    assert partial['field_evidence']['cost_tier']['retrieved_at'] == 100
    expired = md.merge_metadata({}, partial, 100000)
    assert expired['cost_tier'] == 'unknown'
    assert expired['tools'] == 'unknown'


def test_expired_catalog_free_is_rejected(tmp_path):
    store = st.StateStore(tmp_path)
    store.upsert_catalog('p', 'm', 32768, {'tools':True}, 'free')
    store.upsert_capability('p','m', json.dumps(dict(cost_tier='free', tools='supported')), expires_at=1)
    assert rt.Router(dict(store=store)).select() is None


def test_nvidia_unknown_and_no_network(monkeypatch):
    monkeypatch.setattr(__import__('autorouter.autorouter_core.discovery.adapters', fromlist=['_read_json']), '_read_json', lambda *a, **k: pytest.fail('unexpected network'))
    assert md.fetch_metadata('nvidia') == {}


def test_existing_database_reopen(tmp_path):
    store = st.StateStore(tmp_path)
    store.upsert_catalog('p','m',8192,{},'unknown')
    reopened = st.StateStore(tmp_path)
    assert reopened.get_catalog()[0]['model'] == 'm'
    with reopened._connect() as db:
        assert db.execute("select value from meta where key='schema_version'").fetchone()[0] == str(st.SCHEMA_VERSION)


def test_adapter_failure_retains_evidence(tmp_path, monkeypatch, caplog):
    import providers
    class Profile:
        env_vars = ()
        def fetch_models(self, **kw):
            return ['arbitrary-model']
    monkeypatch.setattr(providers, 'get_provider_profile', lambda name: Profile())
    store = st.StateStore(tmp_path)
    monkeypatch.setattr(md, 'fetch_metadata', lambda provider: fixture())
    dc.discover_all(['openrouter'], store)
    before = json.loads(store.get_capability('openrouter','arbitrary-model')['capability_json'])
    def fail(provider):
        raise ValueError('Bearer SECRET_TOKEN')
    monkeypatch.setattr(md, 'fetch_metadata', fail)
    dc.discover_all(['openrouter'], store)
    after = json.loads(store.get_capability('openrouter','arbitrary-model')['capability_json'])
    assert after['field_evidence'] == before['field_evidence']
    assert 'SECRET_TOKEN' not in caplog.text
    assert 'SECRET_TOKEN' not in store.db_path.read_bytes().decode(errors='ignore')


def test_fresh_correction_beats_expired():
    old = fixture(1)['arbitrary-model']
    fresh = dict(old, tools='unsupported', cost_tier='paid', retrieved_at=100000, expires_at=200000)
    resolved = md.merge_metadata(fresh, old, 100001)
    assert resolved['tools'] == 'unsupported'
    assert resolved['cost_tier'] == 'paid'


def test_original_version_fixture(tmp_path):
    import sqlite3
    with sqlite3.connect(tmp_path / 'autorouter.db') as db:
        db.executescript("CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL); INSERT INTO meta VALUES('schema_version','1'); CREATE TABLE catalog(provider TEXT,model TEXT,context_length INTEGER,capabilities TEXT,cost_tier TEXT,updated_at REAL,PRIMARY KEY(provider,model)); INSERT INTO catalog VALUES('p','old',8192,'{}','unknown',123);")
    store = st.StateStore(tmp_path)
    assert store.get_catalog()[0]['updated_at'] == 123
    store.upsert_capability('p','old','{}')
    assert store.get_capability('p','old')
