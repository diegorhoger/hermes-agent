"""Tests for the AutoRouter chat-router adapter (PR #80).

Covers:
  * picker row injection (definition site and picker call site);
  * virtual-model resolution via the canonical selector over an isolated
    profile catalog (test fixtures, no real providers);
  * fail-closed behaviour with missing / empty / unusable catalogs;
  * disabled-adapter behaviour (no interposition, no row injection);
  * enable()/disable() restores every modified binding -- including
    the ``list_picker_providers`` binding at its definition site and the
    from-import bindings the inventory/picker call sites use --
    across repeated cycles, multiple adapter instances and module reloads;
  * the wrapped switch_model / resolve_startup_model_route pipelines pass
    ordinary (non-virtual) input through untouched and refuse virtual input
    when resolution fails, before any host call.

No test reads raw prompts, message bodies, credentials or sensitive headers.
Hermes-host tests skip when a Hermes v0.23.1 tree is not importable; they are
never reported as passing.
"""
from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
# NOTE: the repository root must NOT be added to sys.path here: the repo's own
# top-level modules (state.py, router.py, tools.py ...) would shadow the Hermes
# host's packages. The plugin is imported through the ``autorouter`` package
# shell registered by tests/conftest.py.
import os

os.environ.setdefault("HERMES_DISABLE_LAZY_INSTALLS", "1")

from autorouter.autorouter_core.integration import chat_router_adapter as adapter  # noqa: E402
from autorouter.autorouter_core.routing import router as rt_mod  # noqa: E402
from autorouter.autorouter_core.storage import state as state_mod  # noqa: E402
from autorouter.autorouter_core.integration.chat_router_adapter import (  # noqa: E402
    VIRTUAL_MODEL,
    VIRTUAL_PROVIDER,
    ChatRouterAdapter,
    _inject_autorouter_row,
)

_HERMES_IMPORTABLE = False
try:
    import hermes_cli.model_switch  # noqa: F401
    import hermes_cli.model_switch_providers  # noqa: F401
    import agent.agent_runtime_helpers  # noqa: F401
    import agent.agent_init  # noqa: F401

    _HERMES_IMPORTABLE = True
except Exception:
    # Hermes v0.23.1 not importable here: Hermes-dependent tests skip.
    _HERMES_IMPORTABLE = False

requires_hermes = pytest.mark.skipif(not _HERMES_IMPORTABLE, reason="Hermes v0.23.1 not importable")


# ---------------------------------------------------------------------------
# Fixtures: catalog seeds an isolated profile store (test fixture only).
# ---------------------------------------------------------------------------

def _seed_catalog(store, rows):
    """rows: [(provider, model, context_length, capabilities, cost_tier)]"""
    now = 1.0
    expiry = 9999999999.0
    for p, m, ctx, caps, tier in rows:
        store.upsert_catalog(p, m, context_length=ctx,
                             capabilities=caps, cost_tier=tier)
        store.upsert_capability(
            p, m,
            json.dumps({
                "provider": p, "model": m,
                "field_evidence": {
                    "context_window": {"metadata_source": "provider",
                                       "retrieved_at": now, "expires_at": expiry},
                    "tools": {"metadata_source": "provider",
                              "retrieved_at": now, "expires_at": expiry},
                    "cost_tier": {"metadata_source": "provider",
                                  "retrieved_at": now, "expires_at": expiry},
                },
                "context_window": ctx, "tools": caps["tools"],
                "cost_tier": tier, "source": "provider",
            }),
            metadata_source="provider", retrieved_at=now, expires_at=expiry,
        )


@pytest.fixture
def eligible_free_catalog(tmp_path):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "nvidia-free", 131072, {"tools": "supported"}, "free"),
        ("nvidia", "paid-x", 131072, {"tools": "supported"}, "paid"),
        ("nvidia", "small", 4096, {"tools": "supported"}, "free"),
        ("nvidia", "unknown-tools", 32768, {"tools": "unknown"}, "free"),
        ("mock-local", "free-chat", 131072, {"tools": "supported"}, "free"),
    ])
    return store, tmp_path / "store"


def _adapter(enabled=True):
    return ChatRouterAdapter(enabled=enabled)


@pytest.fixture(autouse=True)
def _restore_host_bindings():
    """After every test, force-restore every binding the adapter can touch,
    so no test can leak a wrapper into another."""
    yield
    ChatRouterAdapter(enabled=False).disable()


# ---------------------------------------------------------------------------
# Picker row injection
# ---------------------------------------------------------------------------

def test_picker_row_injected():
    rows = [{"slug": "openrouter", "name": "OpenRouter"}]
    injected = _inject_autorouter_row(rows)
    r = next((x for x in injected if x.get("slug") == "autorouter"), None)
    assert r is not None
    assert r.get("name") == "AutoRouter"
    assert r.get("virtual_model") == VIRTUAL_MODEL
    assert r.get("virtual") is True


def test_picker_row_is_idempotent_when_already_present():
    rows = [
        {"slug": "autorouter", "name": "AutoRouter"},
        {"slug": "openrouter", "name": "OpenRouter"},
    ]
    injected = _inject_autorouter_row(rows)
    assert len(injected) == 2


# ---------------------------------------------------------------------------
# Virtual-model resolution (canonical selector over the profile store)
# ---------------------------------------------------------------------------

def test_virtual_selection_uses_profile_store(eligible_free_catalog):
    store, store_path = eligible_free_catalog
    a = _adapter()
    a._authorized_providers = lambda: ["nvidia", "openrouter"]
    a._profile_store_dir = lambda: store_path
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert provider == "nvidia"
    assert model == "nvidia-free"


def test_virtual_missing_store_fails_closed(tmp_path):
    store_dir = tmp_path / "no-such-dir"
    a = _adapter()
    a._profile_store_dir = lambda: store_dir
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None
    assert model is None
    assert "no AutoRouter catalog" in error


def _no_live_discovery(monkeypatch):
    """Keep selection-time catalog refresh deterministic: zero provider rows."""
    from autorouter.autorouter_core.discovery import discovery as _discovery
    monkeypatch.setattr(_discovery, "discover_all", lambda providers, store=None: {p: [] for p in providers})
    import autorouter.autorouter_core.routing.router as _router
    return None


def test_virtual_empty_catalog_fails_closed(eligible_free_catalog, monkeypatch):
    _no_live_discovery(monkeypatch)
    store_path = eligible_free_catalog[1]
    empty_dir = store_path.parent / "empty"
    empty_dir.mkdir()
    a = _adapter()
    a._profile_store_dir = lambda: empty_dir
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None
    assert model is None
    assert error is not None


def test_virtual_no_eligible_model_fails_closed(eligible_free_catalog, monkeypatch):
    _no_live_discovery(monkeypatch)
    store_path = eligible_free_catalog[1]
    a = _adapter()
    a._profile_store_dir = lambda: store_path
    a._authorized_providers = lambda: ["openrouter"]  # no matching catalog rows
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None
    assert model is None
    assert error is not None


# ---------------------------------------------------------------------------
# Disabled adapter -> no interposition
# ---------------------------------------------------------------------------

@requires_hermes
def test_disabled_adapter_does_not_patch(eligible_free_catalog):
    a = _adapter(enabled=False)
    a.register_switch_model()
    a.register_list_authenticated_providers()
    a.register_switch_agent()
    a.register_init_agent()
    assert a._switch_model_wrapped is False
    assert a._list_auth_wrapped is False
    assert a._switch_agent_wrapped is False
    assert a._init_agent_wrapped is False


@requires_hermes
def test_disabled_adapter_does_not_inject_row(eligible_free_catalog):
    import hermes_cli.model_switch_providers as msp_mod

    rows_before = msp_mod.list_authenticated_providers()
    a = _adapter(enabled=False)
    a.register_list_authenticated_providers()
    rows_after = msp_mod.list_authenticated_providers()
    assert rows_after == rows_before


# ---------------------------------------------------------------------------
# enable()/disable() restores every modified binding
# ---------------------------------------------------------------------------

def _host_bindings():
    mods = {}
    try:
        import hermes_cli.model_switch_providers as msp_mod
        mods["msp"] = msp_mod
    except Exception:
        pass
    try:
        import hermes_cli.model_switch as ms_mod
        mods["ms"] = ms_mod
    except Exception:
        pass
    try:
        import agent.agent_runtime_helpers as ar_mod
        mods["ar"] = ar_mod
    except Exception:
        pass
    try:
        import agent.agent_init as ai_mod
        mods["ai"] = ai_mod
    except Exception:
        pass
    return mods


def _binding_snapshot():
    mods = _host_bindings()
    return {
        ("msp", "list_authenticated_providers"): getattr(mods["msp"], "list_authenticated_providers", None),
        ("msp", "list_picker_providers"): getattr(mods["msp"], "list_picker_providers", None),
        ("ms", "list_authenticated_providers"): getattr(mods["ms"], "list_authenticated_providers", None),
        ("ms", "switch_model"): getattr(mods["ms"], "switch_model", None),
        ("ms", "resolve_startup_model_route"): getattr(mods["ms"], "resolve_startup_model_route", None),
        ("ar", "switch_model"): getattr(mods["ar"], "switch_model", None),
        ("ai", "init_agent"): getattr(mods["ai"], "init_agent", None),
    }


@requires_hermes
def test_enable_disable_restores_all_bindings(eligible_free_catalog):
    before = _binding_snapshot()
    a = ChatRouterAdapter(enabled=True)
    a.enable()
    try:
        mods = _host_bindings()
        assert mods["msp"].list_authenticated_providers is not before[("msp", "list_authenticated_providers")]
        assert mods["msp"].list_picker_providers is not before[("msp", "list_picker_providers")]
        assert mods["ms"].list_authenticated_providers is not before[("ms", "list_authenticated_providers")]
        assert mods["ms"].switch_model is not before[("ms", "switch_model")]
        assert mods["ms"].resolve_startup_model_route is not before[("ms", "resolve_startup_model_route")]
        assert mods["ar"].switch_model is not before[("ar", "switch_model")]
        assert mods["ai"].init_agent is not before[("ai", "init_agent")]
    finally:
        a.disable()
    after = _binding_snapshot()
    assert after == before
    assert a.is_registered() is False


@requires_hermes
def test_repeated_enable_disable_cycles_restore_bindings(eligible_free_catalog):
    before = _binding_snapshot()
    for _ in range(3):
        a = ChatRouterAdapter(enabled=True)
        a.enable()
        a.disable()
        assert _binding_snapshot() == before


@requires_hermes
def test_multiple_adapter_instances_unwind_in_any_order(eligible_free_catalog):
    before = _binding_snapshot()
    a = ChatRouterAdapter(enabled=True)
    b = ChatRouterAdapter(enabled=True)
    a.enable()
    b.enable()
    a.disable()
    b.disable()
    assert _binding_snapshot() == before
    # ...and the reverse order.
    a = ChatRouterAdapter(enabled=True)
    b = ChatRouterAdapter(enabled=True)
    a.enable()
    b.enable()
    b.disable()
    a.disable()
    assert _binding_snapshot() == before


@requires_hermes
def test_module_reload_does_not_leak_wrappers(eligible_free_catalog):
    before = _binding_snapshot()
    a = ChatRouterAdapter(enabled=True)
    a.enable()
    reloaded = importlib.reload(adapter)
    try:
        assert _binding_snapshot() != before  # wrappers still installed after reload
        reloaded.ChatRouterAdapter(enabled=False).disable()
        assert _binding_snapshot() == before
    finally:
        importlib.reload(adapter)


# ---------------------------------------------------------------------------
# Wrapped pipelines: passthrough for ordinary input, fail-closed for virtual
# ---------------------------------------------------------------------------

@requires_hermes
def test_switch_model_passes_ordinary_input_through(monkeypatch, eligible_free_catalog):
    import hermes_cli.model_switch as ms_mod

    calls = []

    def fake_switch_model(**kwargs):
        calls.append(kwargs)
        return "sentinel-result"

    monkeypatch.setattr(ms_mod, "switch_model", fake_switch_model)
    a = ChatRouterAdapter(enabled=True)
    a.register_switch_model()
    try:
        result = ms_mod.switch_model(
            raw_input="some-model", current_provider="openrouter",
            current_model="other", is_global=False, explicit_provider="",
        )
        assert result == "sentinel-result"
        assert calls == [dict(raw_input="some-model", current_provider="openrouter",
                              current_model="other", current_base_url="",
                              current_api_key="", is_global=False,
                              explicit_provider="", user_providers=None,
                              custom_providers=None)]
    finally:
        a.disable()


@requires_hermes
def test_switch_model_resolves_virtual_then_calls_host(monkeypatch, eligible_free_catalog):
    import hermes_cli.model_switch as ms_mod

    store, store_path = eligible_free_catalog
    calls = []

    def fake_switch_model(**kwargs):
        calls.append(kwargs)
        return "sentinel-result"

    monkeypatch.setattr(ms_mod, "switch_model", fake_switch_model)
    a = ChatRouterAdapter(enabled=True)
    a._authorized_providers = lambda: ["nvidia", "openrouter"]
    a._profile_store_dir = lambda: store_path
    a.register_switch_model()
    try:
        result = ms_mod.switch_model(
            raw_input=VIRTUAL_MODEL, current_provider="openrouter",
            current_model="prev", is_global=False, explicit_provider="",
        )
        assert result == "sentinel-result"
        assert len(calls) == 1
        assert calls[0]["raw_input"] == "nvidia-free"
        assert calls[0]["explicit_provider"] == "nvidia"
    finally:
        a.disable()


@requires_hermes
def test_switch_model_fails_closed_when_resolution_impossible(monkeypatch, tmp_path, eligible_free_catalog):
    import hermes_cli.model_switch as ms_mod

    calls = []

    def fake_switch_model(**kwargs):
        calls.append(kwargs)
        return "sentinel-result"

    monkeypatch.setattr(ms_mod, "switch_model", fake_switch_model)
    a = ChatRouterAdapter(enabled=True)
    a._profile_store_dir = lambda: tmp_path / "missing-store"  # resolution impossible
    a.register_switch_model()
    try:
        result = ms_mod.switch_model(
            raw_input=VIRTUAL_MODEL, current_provider="openrouter",
            current_model="prev", is_global=False, explicit_provider="",
        )
        assert result.success is False
        assert result.error_message
        assert calls == []  # the host pipeline is never reached
    finally:
        a.disable()


@requires_hermes
def test_startup_route_resolves_virtual_and_passes_ordinary_through(monkeypatch, eligible_free_catalog):
    import hermes_cli.model_switch as ms_mod

    store, store_path = eligible_free_catalog
    seen = []

    def fake_route(raw_model, **kwargs):
        seen.append((raw_model, kwargs))
        return "ordinary-route"

    monkeypatch.setattr(ms_mod, "resolve_startup_model_route", fake_route)
    a = ChatRouterAdapter(enabled=True)
    a._authorized_providers = lambda: ["nvidia", "openrouter"]
    a._profile_store_dir = lambda: store_path
    a.register_switch_model()
    try:
        route = ms_mod.resolve_startup_model_route(
            VIRTUAL_MODEL, explicit_provider="", current_provider="openrouter",
        )
        assert route.model == "nvidia-free"
        assert route.provider == "nvidia"
        assert seen == []  # the host path is not consulted for the virtual marker

        ordinary = ms_mod.resolve_startup_model_route(
            "some-real-model", explicit_provider="", current_provider="openrouter",
        )
        assert ordinary == "ordinary-route"
        assert seen == [("some-real-model", {"explicit_provider": "", "current_provider": "openrouter",
                                              "user_providers": None, "custom_providers": None,
                                              "alias_config": None})]
    finally:
        a.disable()


@requires_hermes
def test_startup_route_fails_closed_when_resolution_impossible(tmp_path):
    a = ChatRouterAdapter(enabled=True)
    a._profile_store_dir = lambda: tmp_path / "missing-store"
    a.register_switch_model()
    try:
        import hermes_cli.model_switch as ms_mod

        route = ms_mod.resolve_startup_model_route(
            VIRTUAL_MODEL, explicit_provider="", current_provider="openrouter",
        )
        assert route.model == ""  # empty route: the host refuses before network
    finally:
        a.disable()


@requires_hermes
def test_agent_switch_model_fails_closed_by_raising(tmp_path):
    import agent.agent_runtime_helpers as ar_mod

    a = ChatRouterAdapter(enabled=True)
    a._profile_store_dir = lambda: tmp_path / "missing-store"
    a.register_switch_agent()
    with pytest.raises(RuntimeError):
        ar_mod.switch_model(object(), VIRTUAL_MODEL, VIRTUAL_PROVIDER)
    a.disable()


@requires_hermes
def test_agent_switch_model_resolves_virtual(monkeypatch, eligible_free_catalog):
    import agent.agent_runtime_helpers as ar_mod

    store, store_path = eligible_free_catalog
    calls = []

    def fake_switch_model(agent, new_model, new_provider, api_key="", base_url="",
                          api_mode="", capabilities=None):
        calls.append((new_model, new_provider, api_key, base_url, api_mode))
        return "ok"

    monkeypatch.setattr(ar_mod, "switch_model", fake_switch_model)
    a = ChatRouterAdapter(enabled=True)
    a._authorized_providers = lambda: ["nvidia", "openrouter"]
    a._profile_store_dir = lambda: store_path
    a.register_switch_agent()
    try:
        result = ar_mod.switch_model(object(), VIRTUAL_MODEL, "", api_key="keep?", base_url="keep?")
        assert result == "ok"
        assert calls == [("nvidia-free", "nvidia", "", "", "")]
    finally:
        a.disable()


@requires_hermes
def test_init_agent_fails_closed_by_raising(tmp_path):
    import agent.agent_init as ai_mod

    a = ChatRouterAdapter(enabled=True)
    a._profile_store_dir = lambda: tmp_path / "missing-store"
    a.register_init_agent()
    with pytest.raises(RuntimeError):
        ai_mod.init_agent(object(), model=VIRTUAL_MODEL, provider="")
    a.disable()


@requires_hermes
def test_init_agent_resolves_virtual(monkeypatch, eligible_free_catalog):
    import agent.agent_init as ai_mod

    store, store_path = eligible_free_catalog
    calls = []

    def fake_init_agent(agent, *args, **kwargs):
        calls.append(kwargs)
        return "ok"

    monkeypatch.setattr(ai_mod, "init_agent", fake_init_agent)
    a = ChatRouterAdapter(enabled=True)
    a._authorized_providers = lambda: ["nvidia", "openrouter"]
    a._profile_store_dir = lambda: store_path
    a.register_init_agent()
    try:
        result = ai_mod.init_agent(object(), model=VIRTUAL_MODEL, provider="")
        assert result == "ok"
        assert calls == [{"model": "nvidia-free", "provider": "nvidia"}]
    finally:
        a.disable()


# ---------------------------------------------------------------------------
# Plugin entry wiring (the exact failure mode that shipped in HEAD):
# enable_chat_router must load the adapter even while the tools' `enabled`
# gate leaves the plugin's tool registration off.
# ---------------------------------------------------------------------------

class _FakeCtx:
    def __init__(self, settings):
        self._settings = settings
        self.hooks = []
        self.tools = []

    def get_config(self, key, default=None):
        return self._settings.get(key, default)

    def register_hook(self, name, fn):
        self.hooks.append(name)

    def register_tool(self, **kwargs):
        self.tools.append(kwargs.get("name"))


@requires_hermes
def test_plugin_register_never_activates_adapter_even_with_flag(caplog):
    import autorouter

    ctx = _FakeCtx({"enable_chat_router": True, "enabled": False})
    autorouter.register(ctx)
    import hermes_cli.model_switch as ms_mod

    assert getattr(ms_mod.switch_model, "_ar_patched", False) is False


@requires_hermes
def test_plugin_register_does_not_load_adapter_by_default(caplog):
    import autorouter

    ctx = _FakeCtx({"enabled": False})  # no enable_chat_router
    autorouter.register(ctx)
    import hermes_cli.model_switch as ms_mod

    assert getattr(ms_mod.switch_model, "_ar_patched", False) is False


# ---------------------------------------------------------------------------
# Real Hermes model-picker call site
# ---------------------------------------------------------------------------

@requires_hermes
def test_picker_call_site_invokes_adapter(monkeypatch, eligible_free_catalog):
    """The actual picker call site (``list_picker_providers``) returns the
    AutoRouter row while the adapter is enabled, and none once disabled."""
    import hermes_cli.model_switch as ms_mod
    import hermes_cli.model_switch_providers as msp_mod

    a = ChatRouterAdapter(enabled=True)
    a.register_list_authenticated_providers()
    try:
        assert ms_mod.list_authenticated_providers is a._wrapper_list_auth
        assert msp_mod.list_authenticated_providers is a._wrapper_list_auth
        assert msp_mod.list_picker_providers is a._wrapper_picker

        providers = msp_mod.list_picker_providers(
            current_provider="nvidia", current_base_url="",
            user_providers={}, custom_providers=[],
            max_models=20, current_model="", include_moa=False,
            excluded_providers=None, non_blocking_catalogs=False,
            probe_custom_providers=True, probe_current_custom_provider=False,
        )
        row = next((p for p in providers if p.get("slug") == "autorouter"), None)
        assert row is not None, "picker did not invoke the adapter"
        assert row.get("virtual_model") == VIRTUAL_MODEL
    finally:
        a.disable()

    rows_after = msp_mod.list_picker_providers(
        current_provider="nvidia", current_base_url="",
        user_providers={}, custom_providers=[],
        max_models=20, current_model="", include_moa=False,
        excluded_providers=None, non_blocking_catalogs=False,
        probe_custom_providers=True, probe_current_custom_provider=False,
    )
    assert all(p.get("slug") != "autorouter" for p in rows_after)


# ---------------------------------------------------------------------------
# Routing settings actually steer the decision (fail-closed interposed on truth)
# ---------------------------------------------------------------------------

def _hermes_cfg_with(**settings):
    return {"plugins": {"entries": {"autorouter": {"settings": {
        "providers": ["nvidia", "openrouter"],
        **settings,
    }}}}}


def _patch_hermes_config(monkeypatch, **settings):
    import hermes_cli.config as _hcfg

    monkeypatch.setattr(_hcfg, "load_config_readonly", lambda: _hermes_cfg_with(**settings))


def _decision_policies(store):
    with store._connect() as db:
        return [row[0] for row in db.execute("SELECT policy FROM decisions").fetchall()]


def test_routing_policy_flows_into_the_engine_and_the_decision_log(monkeypatch, eligible_free_catalog):
    import hermes_cli.config as _hcfg

    store, store_path = eligible_free_catalog
    _patch_hermes_config(monkeypatch, policy="fastest")
    a = _adapter()
    a._profile_store_dir = lambda: store_path
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert provider == "nvidia"
    assert "fastest" in _decision_policies(store)


def test_routing_unknown_policy_fails_closed(monkeypatch, eligible_free_catalog):
    store, store_path = eligible_free_catalog
    _patch_hermes_config(monkeypatch, policy="yolo")
    a = _adapter()
    a._profile_store_dir = lambda: store_path
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None
    assert model is None
    assert "no eligible free model" in error


def test_routing_min_context_excludes_small_models(monkeypatch, eligible_free_catalog):
    store, store_path = eligible_free_catalog
    _patch_hermes_config(monkeypatch, policy="auto", min_context=200000)
    a = _adapter()
    a._profile_store_dir = lambda: store_path
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None
    assert error is not None


def test_routing_exclude_blocks_the_only_eligible_model(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "nvidia-free", 131072, {"tools": "supported"}, "free"),
    ])
    _patch_hermes_config(monkeypatch, policy="auto",
                         model_exclude=["nvidia/nvidia-free"])
    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None
    assert error is not None


def test_routing_requires_tools_respected(eligible_free_catalog):
    store, store_path = eligible_free_catalog
    # No eligible free row with verified tools: seed a catalog with only unknown-tools rows is
    # covered elsewhere; here assert the preference reaches the engine (no crash, decision recorded).
    _patch = None  # nothing to patch: default settings require tools only when asked
    a = _adapter()
    a._authorized_providers = lambda: ["nvidia", "openrouter"]
    a._routing_settings = lambda: {"policy": "auto", "min_context": 8192,
                                   "requires_tools": True,
                                   "model_include_pairs": [], "model_exclude_pairs": []}
    a._profile_store_dir = lambda: store_path
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None  # nvidia-free has tools supported


def test_routing_requires_tools_fail_closed_when_none_verified(tmp_path):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "only-unknown-tools", 131072, {"tools": "unknown"}, "free"),
    ])
    a = _adapter()
    a._authorized_providers = lambda: ["nvidia"]
    a._routing_settings = lambda: {"policy": "auto", "min_context": 8192,
                                   "requires_tools": True,
                                   "model_include_pairs": [], "model_exclude_pairs": []}
    a._profile_store_dir = lambda: tmp_path / "store"
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None
    assert error is not None


def test_routing_include_allowlist_enforced(monkeypatch, eligible_free_catalog):
    store, store_path = eligible_free_catalog
    # Include only the mock-local row: no authorized included model exists for
    # nvidia (the mock row is not authorized), so selection must fail closed.
    _patch_hermes_config(monkeypatch, policy="auto",
                         model_include=["mock-local/free-chat"])
    a = _adapter()
    a._profile_store_dir = lambda: store_path
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None
    # Adding the resolved row to the allowlist lets the selection through.
    _patch_hermes_config(monkeypatch, policy="auto",
                         model_include=["mock-local/free-chat", "nvidia/nvidia-free"])
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert (provider, model) == ("nvidia", "nvidia-free")


def test_model_include_selects_highest_ranked_among_included(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "aaa-free", 131072, {"tools": "supported"}, "free"),
        ("nvidia", "zzz-free", 131072, {"tools": "supported"}, "free"),
    ])
    a = _adapter()
    a._authorized_providers = lambda: ["nvidia"]
    a._profile_store_dir = lambda: tmp_path / "store"
    # Include ONLY the lower-ranked model: the higher-ranked excluded one must
    # not win; the highest-ranked INCLUDED model must be picked.
    _patch_hermes_config(monkeypatch, policy="auto",
                         model_include=["nvidia/zzz-free"])
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert (provider, model) == ("nvidia", "zzz-free")
    # Both included: the highest-ranked eligible model wins.
    _patch_hermes_config(monkeypatch, policy="auto",
                         model_include=["nvidia/aaa-free",
                                        "nvidia/zzz-free"])
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert (provider, model) == ("nvidia", "aaa-free")


def test_model_include_excludes_higher_ranked_excluded_by_include(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "aaa-free", 131072, {"tools": "supported"}, "free"),
        ("nvidia", "zzz-free", 131072, {"tools": "supported"}, "free"),
    ])
    a = _adapter()
    a._authorized_providers = lambda: ["nvidia"]
    a._profile_store_dir = lambda: tmp_path / "store"
    _patch_hermes_config(monkeypatch, policy="auto", model_include=["nvidia/zzz-free"])
    assert a._resolve_virtual("autorouter", VIRTUAL_MODEL)[:2] == ("nvidia", "zzz-free")


def test_model_include_cannot_enforce_when_catalog_unreadable(monkeypatch, tmp_path):
    class BrokenStore(state_mod.StateStore):
        def get_catalog(self, provider=None):
            raise RuntimeError("sqlite exploded")

    monkeypatch.setattr(state_mod, "StateStore", BrokenStore)
    _patch_hermes_config(monkeypatch, policy="auto",
                         model_include=["nvidia/nvidia-free"])
    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None
    assert error is not None


class TestRuntimeActivationStatus:
    def test_active_when_configured_and_patched(self, monkeypatch):
        monkeypatch.setattr(adapter, "_is_enabled", lambda: True)
        monkeypatch.setattr(adapter, "_host_interceptions_installed", lambda: True)
        status = adapter.runtime_activation_status()
        assert status["configured"] is True
        assert status["runtime"] == "active"

    def test_restart_required_when_configured_but_not_patched(self, monkeypatch):
        monkeypatch.setattr(adapter, "_is_enabled", lambda: True)
        monkeypatch.setattr(adapter, "_host_interceptions_installed", lambda: False)
        status = adapter.runtime_activation_status()
        assert status["runtime"] == "restart_required"
        assert "restart" in status["detail"].lower()

    def test_configured_off_but_patched_requires_restart(self, monkeypatch):
        monkeypatch.setattr(adapter, "_is_enabled", lambda: False)
        monkeypatch.setattr(adapter, "_host_interceptions_installed", lambda: True)
        status = adapter.runtime_activation_status()
        assert status["runtime"] == "restart_required"

    def test_inactive_when_disabled_and_unpatched(self, monkeypatch):
        monkeypatch.setattr(adapter, "_is_enabled", lambda: False)
        monkeypatch.setattr(adapter, "_host_interceptions_installed", lambda: False)
        status = adapter.runtime_activation_status()
        assert status["runtime"] == "inactive"

    def test_unknown_when_marker_unobservable(self, monkeypatch):
        monkeypatch.setattr(adapter, "_is_enabled", lambda: True)
        monkeypatch.setattr(adapter, "_host_interceptions_installed", lambda: None)
        status = adapter.runtime_activation_status()
        assert status["runtime"] == "unknown"


def test_configured_cooldown_reaches_router_config(monkeypatch, eligible_free_catalog):
    store, store_path = eligible_free_catalog
    _patch_hermes_config(monkeypatch, policy="auto", cooldown_seconds=45)

    captured = {}

    class FakeRouter:
        def __init__(self, state):
            self.state = state
            captured.update(state)

        def select(self, **kwargs):
            return {"provider": "nvidia", "model": "nvidia-free"}

    fake_router_mod = type("FakeR", (), {"Router": FakeRouter})
    fake_state_mod = type("FakeS", (), {
        "StateStore": state_mod.StateStore,
        "active_routing_profile": lambda store: (None, None),
    })
    monkeypatch.setattr(adapter, "_load_engine", lambda: (fake_router_mod, fake_state_mod))

    a = _adapter()
    a._profile_store_dir = lambda: store_path
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert captured["cooldown_seconds"] == 45


def test_invalid_cooldown_defaults_to_60(monkeypatch, eligible_free_catalog):
    _, store_path = eligible_free_catalog
    for bad in (True, 0, 86401, "45", None, -1, 3.5):
        _patch_hermes_config(monkeypatch, policy="auto", cooldown_seconds=bad)
        a = _adapter()
        a._profile_store_dir = lambda: store_path
        assert a._routing_settings()["cooldown_seconds"] == 60, bad
    _patch_hermes_config(monkeypatch, policy="auto", cooldown_seconds=86400)
    assert _adapter()._routing_settings()["cooldown_seconds"] == 86400



# ---------------------------------------------------------------------------
# Routing profiles (issue #100) — narrow-only merge, tri-state activation
# ---------------------------------------------------------------------------

from autorouter.autorouter_core.storage.state import RoutingProfileStore  # noqa: E402
from autorouter.autorouter_core.routing import profiles as profiles_mod  # noqa: E402


def _profile_store(tmp_path, name="Test profile"):
    store = RoutingProfileStore(tmp_path / "store")
    profile = store.create({"name": name})
    return store, profile


def test_profile_narrows_provider_route(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "nvidia-free", 131072, {"tools": "supported"}, "free"),
        ("openrouter", "or-free", 131072, {"tools": "supported"}, "free"),
    ])
    rstore = RoutingProfileStore(tmp_path / "store")
    prof = rstore.create({"name": "NVIDIA only", "ranking_policy": "reliable", "providers": ["nvidia"]})
    rstore.set_active(prof["id"])

    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"
    _patch_hermes_config(monkeypatch, policy="auto")
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert provider == "nvidia"


def test_profile_include_forces_choice_over_global_preference(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "a-free", 131072, {"tools": "supported"}, "free"),
        ("nvidia", "z-free", 131072, {"tools": "supported"}, "free"),
    ])
    rstore = RoutingProfileStore(tmp_path / "store")
    prof = rstore.create({"name": "z only",
                          "ranking_policy": "reliable",
                          "providers": ["nvidia"],
                          "model_include": ["nvidia/z-free"]})
    rstore.set_active(prof["id"])

    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert model == "z-free"


def test_profile_cannot_relax_global_tools_requirement(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "needs-nothing", 131072, {"tools": "unknown"}, "free"),
        ("nvidia", "tool-model", 131072, {"tools": "supported"}, "free"),
    ])
    rstore = RoutingProfileStore(tmp_path / "store")
    prof = rstore.create({"name": "tools-off-anyway",
                          "providers": ["nvidia"],
                          "requires_tools": False})
    rstore.set_active(prof["id"])

    _patch_hermes_config(monkeypatch, policy="auto", requires_tools=True)
    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"
    # The global gate must win: tools-unverified model is rejected despite the
    # profile being permissive.
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert model == "tool-model"


def test_profile_stricter_tools_wins_when_global_is_permissive(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "needs-nothing", 131072, {"tools": "unknown"}, "free"),
        ("nvidia", "tool-model", 131072, {"tools": "supported"}, "free"),
    ])
    rstore = RoutingProfileStore(tmp_path / "store")
    prof = rstore.create({"name": "needs-tools",
                          "providers": ["nvidia"],
                          "requires_tools": True})
    rstore.set_active(prof["id"])

    _patch_hermes_config(monkeypatch, policy="auto")  # requires_tools defaults False
    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert model == "tool-model"


def test_profile_stricter_min_context_wins_when_global_lower(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "smallctx", 8192, {"tools": "supported"}, "free"),
        ("nvidia", "bigctx", 131072, {"tools": "supported"}, "free"),
    ])
    rstore = RoutingProfileStore(tmp_path / "store")
    prof = rstore.create({"name": "big ctx only",
                          "providers": ["nvidia"],
                          "min_context": 32768})
    rstore.set_active(prof["id"])

    _patch_hermes_config(monkeypatch, policy="auto", min_context=8192)
    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None
    assert model == "bigctx"


def test_corrupt_active_profile_fails_closed(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "nvidia-free", 131072, {"tools": "supported"}, "free"),
    ])
    rstore = RoutingProfileStore(tmp_path / "store")
    prof = rstore.create({"name": "Corrupt me", "providers": ["nvidia"]})

    # Corrupt the row behind the adapter's back (e.g. manual store surgery).
    with rstore.store._connect() as db:
        db.execute("UPDATE routing_profiles SET min_context = -1 WHERE id = ?", (prof["id"],))
    rstore.set_active(prof["id"])

    _patch_hermes_config(monkeypatch, policy="auto")
    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None and model is None
    assert "default routing profile" in error


def test_deleted_active_profile_fails_closed(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "nvidia-free", 131072, {"tools": "supported"}, "free"),
    ])
    rstore = RoutingProfileStore(tmp_path / "store")
    prof = rstore.create({"name": "Gone", "providers": ["nvidia"]})
    rstore.set_active(prof["id"])
    # Remove the row directly without clearing the meta (simulated crash or surgery).
    with rstore.store._connect() as db:
        db.execute("DELETE FROM routing_profiles WHERE id = ?", (prof["id"],))

    _patch_hermes_config(monkeypatch, policy="auto")
    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert provider is None and model is None
    assert "no longer exists" in error


def test_profile_narrowing_only_never_relaxes(tmp_path, monkeypatch):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "nvidia-free", 131072, {"tools": "supported"}, "free"),
        ("openrouter", "or-free", 131072, {"tools": "supported"}, "free"),
    ])
    rstore = RoutingProfileStore(tmp_path / "store")
    prof = rstore.create({"name": "eng",
                          "providers": ["openrouter"]})
    rstore.set_active(prof["id"])

    # Global defaults stay narrow: only openrouter is authorized.
    _patch_hermes_config(monkeypatch, policy="auto", providers=["openrouter"])
    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"
    provider, model, error = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error is None and provider == "openrouter"


def test_concurrent_activation_settles_to_single_active(tmp_path):
    import threading
    rstore = RoutingProfileStore(tmp_path / "store")
    a = rstore.create({"name": "A"})
    b = rstore.create({"name": "B"})
    results = []

    def worker(choice):
        for _ in range(10):
            rstore.set_active(choice)
        results.append(choice)

    threads = [threading.Thread(target=worker, args=(a["id"],)),
               threading.Thread(target=worker, args=(b["id"],))]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    final = rstore.active_id()
    assert final in {a["id"], b["id"]}
    assert final is not None


def test_profile_activation_change_is_visible_to_resolutions(tmp_path, monkeypatch):
    import threading
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "nvidia-free", 131072, {"tools": "supported"}, "free"),
        ("openrouter", "or-free", 131072, {"tools": "supported"}, "free"),
    ])
    rstore = RoutingProfileStore(tmp_path / "store")
    pa = rstore.create({"name": "A", "providers": ["nvidia"]})
    pb = rstore.create({"name": "B", "providers": ["openrouter"]})

    _patch_hermes_config(monkeypatch, policy="auto")
    a = _adapter()
    a._profile_store_dir = lambda: tmp_path / "store"

    rstore.set_active(pa["id"])
    provider_a, model_a, error_a = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error_a is None and provider_a == "nvidia"

    rstore.set_active(pb["id"])
    provider_b, model_b, error_b = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error_b is None and provider_b == "openrouter"

    # Clearing the default restores the global policy (nvidia+openrouter both allowed)
    rstore.set_active(None)
    provider_c, model_c, error_c = a._resolve_virtual("autorouter", VIRTUAL_MODEL)
    assert error_c is None
    assert provider_c in {"nvidia", "openrouter"}
