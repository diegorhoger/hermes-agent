"""Executor-independent contract and synthetic authority boundary, never live accounts."""

import copy
from dataclasses import replace
import json
from pathlib import Path

import pytest
from autorouter.autorouter_core.configuration import selection_policy as sp
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.evidence import free_access as fa
from autorouter.autorouter_core.integration import tools
from tests.test_policies_v1 import seeded, NOW

A = "a" * 32
B = "b" * 32
ACTIVE = sp.SelectionContext("1" * 32, "2" * 32, "3" * 32)
FIXTURE = Path(__file__).with_name("fixtures") / "selection-policy-v1.json"


def request():
    return json.loads(FIXTURE.read_text())["request"]


def context(**changes):
    base = sp.ConnectionContext(ACTIVE, "openrouter", A, None, (), True, 100, 220)
    return replace(base, **changes)


def candidate(model="a", **changes):
    row = dict(
        provider="openrouter",
        model=model,
        cost_tier="free",
        context_length=16000,
        capabilities={"tools": True},
        field_evidence={
            key: dict(
                metadata_source="controlled-test-fixture",
                retrieved_at=100,
                expires_at=220,
            )
            for key in ("cost_tier", "context_window", "tools")
        },
    )
    row.update(changes)
    return row


def run(rows=None, value=sp.MISSING, **kwargs):
    return router.evaluate_snapshot(
        rows if rows is not None else [candidate()],
        now=150,
        selection_policy=request() if value is sp.MISSING else value,
        **kwargs,
    )


def quota_result(remaining=38, expires=220, scope=A):
    canonical = fa.canonical_scope("openrouter:" + scope)
    rows = fa.normalize_openrouter_quota(
        {
            "data": {
                "free_model_daily_requests": {
                    "limit": 50,
                    "remaining": remaining,
                    "used": 50 - remaining,
                }
            }
        },
        canonical,
        100,
    )
    rows[0]["expires_at"] = expires
    return dict(
        quota_policy_version=1,
        quota_policy="avoid_verified_exhaustion",
        allowed=bool(remaining),
        state="healthy" if remaining else "exhausted",
        preference_available=False,
        allowance=dict(
            schema_version=1,
            provider="openrouter",
            account_scope=canonical,
            quota_windows=rows,
            complete=bool(remaining),
        ),
    )


def evaluator(result):
    # Fixed authoritative result fixture, not another production quota evaluator.
    def evaluate(snapshot, provider, model, scope, now, *, quota_policy):
        out = copy.deepcopy(result)
        out["quota_policy"] = quota_policy
        out["preference_available"] = (
            quota_policy == "prefer_available_allowance" and out["state"] == "healthy"
        )
        return out

    return evaluate


def test_valid_contract_and_legacy_aliases_are_compatible():
    value = request()
    assert sp.validate(value) == value
    assert run()["chosen"]["model"] == "a"
    assert run()["execution_authority"] is False
    for alias in (
        "general",
        "coding",
        "fast-response",
        "reliability-first",
        "free-first",
    ):
        value["preferences"]["policy"] = alias
        out = run(value=value)
        assert out["chosen"] and out["semantic_quality"] == "unknown"
        assert (
            out["selection_policy"]["task_requirements"]["semantic_quality"]
            == "unknown"
        )


@pytest.mark.parametrize("field", list(request()))
def test_missing_required_sections_deny_without_discovery(field):
    value = request()
    value.pop(field)
    assert run(value=value)["no_match"] == "selection_policy_invalid"


@pytest.mark.parametrize("value", [None, [], True, {}, {"schema_version": 2}])
def test_malformed_contract_does_not_default_to_general(value):
    result = run(value=value)
    assert result["chosen"] is None and result["no_match"] == "selection_policy_invalid"


@pytest.mark.parametrize(
    "kind",
    [
        "future",
        "bool_version",
        "unknown_field",
        "paid",
        "unknown_policy",
        "future_task",
        "unknown_task",
        "capability",
        "context",
        "providers",
        "cooldown",
        "concurrency",
        "scope",
        "authority_in_request",
    ],
)
def test_malformed_or_unsupported_requirements_deny(kind):
    value = request()
    if kind == "future":
        value["schema_version"] = 2
    elif kind == "bool_version":
        value["schema_version"] = True
    elif kind == "unknown_field":
        value["prompt"] = "PRIVATE_PROMPT_SENTINEL"
    elif kind == "paid":
        value["hard_eligibility"]["verified_free_only"] = False
    elif kind == "unknown_policy":
        value["preferences"]["policy"] = "paid-fallback"
    elif kind == "future_task":
        value["task_requirements"]["schema_version"] = 2
    elif kind == "unknown_task":
        value["task_requirements"]["label"] = "auto-classify"
    elif kind == "capability":
        value["hard_eligibility"]["required_capabilities"] = {"vision": "required"}
    elif kind == "context":
        value["hard_eligibility"]["min_context"] = "8192"
    elif kind == "providers":
        value["hard_eligibility"]["authorized_providers"] = "openrouter"
    elif kind == "cooldown":
        value["hard_eligibility"]["health"]["respect_cooldowns"] = False
    elif kind == "concurrency":
        value["hard_eligibility"]["max_in_flight"] = True
    elif kind == "scope":
        value["connection_restrictions"]["connection_id"] = "RAW_KEY_SENTINEL"
    else:
        value["connection_restrictions"]["granted"] = True
    out = run(value=value)
    assert out["chosen"] is None and out["no_match"] == "selection_policy_invalid"
    assert "PRIVATE_PROMPT_SENTINEL" not in json.dumps(out)
    assert "RAW_KEY_SENTINEL" not in json.dumps(out)


def test_requirements_compose_before_ranking_and_keep_semantic_quality_unknown():
    value = request()
    value["hard_eligibility"]["required_capabilities"] = {"tools": "required"}
    value["task_requirements"].update(label="coding", min_context=20000)
    rows = [
        candidate("short"),
        candidate("no-tools"),
        candidate("paid"),
        candidate("unknown"),
        candidate("good"),
    ]
    rows[1].update(context_length=32000, capabilities={"tools": False})
    rows[2].update(context_length=32000, cost_tier="paid")
    rows[3].update(context_length=32000, cost_tier="unknown")
    rows[4]["context_length"] = 32000
    out = run(rows, value=value)
    assert out["chosen"]["model"] == "good" and out["semantic_quality"] == "unknown"
    reasons = {row["model"]: row["reason_codes"] for row in out["considered"]}
    assert "context_unknown_or_insufficient" in reasons["short"]
    assert "tools_unverified_or_unsupported" in reasons["no-tools"]
    assert (
        "cost_not_verified_free" in reasons["paid"]
        and "cost_not_verified_free" in reasons["unknown"]
    )
    value["task_requirements"]["required_capabilities"] = {"tools": "forbidden"}
    assert run(rows, value=value)["no_match"] == "selection_policy_invalid"


def test_explicit_health_concurrency_provider_exclusion_and_conflicts():
    value = request()
    hard = value["hard_eligibility"]
    hard["health"].update(require_observed=True, max_age_seconds=300)
    assert (
        "health_observation_required"
        in run(value=value)["considered"][0]["reason_codes"]
    )
    hard["health"]["require_observed"] = False
    hard["max_in_flight"] = 1
    assert not run(value=value)["chosen"]
    assert not run([candidate(in_flight=1)], value=value)["chosen"]
    assert run([candidate(in_flight=0)], value=value)["chosen"]
    hard["max_in_flight"] = None
    hard["exclude"] = [dict(provider="openrouter", model="a")]
    assert not run(value=value)["chosen"]
    hard["exclude"] = []
    hard["authorized_providers"] = []
    assert not run(value=value)["chosen"]
    value["connection_restrictions"]["provider_id"] = "nvidia"
    assert run(value=value)["no_match"] == "selection_policy_invalid"


@pytest.mark.parametrize(
    "kind",
    [
        "missing",
        "json",
        "ungranted",
        "expired",
        "other_session",
        "other_profile",
        "other_request",
        "future_context",
        "other_scope",
        "model_scope",
        "shared_scope",
    ],
)
def test_explicit_connection_requires_current_matching_authority(kind):
    value = request()
    value["connection_restrictions"].update(
        require_authority=True, provider_id="openrouter", connection_id=A
    )
    bound = context()
    if kind == "missing":
        bound = None
    elif kind == "json":
        bound = dict(provider_id="openrouter", connection_id=A, granted=True)
    elif kind == "ungranted":
        bound = context(granted=False)
    elif kind == "expired":
        bound = context(expires_at=149)
    elif kind == "other_session":
        bound = context(context=replace(ACTIVE, session_id="4" * 32))
    elif kind == "other_profile":
        bound = context(context=replace(ACTIVE, profile_id="4" * 32))
    elif kind == "other_request":
        bound = context(context=replace(ACTIVE, request_id="4" * 32))
    elif kind == "future_context":
        bound = context(schema_version=2)
    elif kind == "other_scope":
        bound = context(connection_id=B)
    elif kind == "model_scope":
        bound = context(models=("different-model",))
    else:
        value["connection_restrictions"]["shared_quota_scope"] = B
    out = run(
        [candidate(connection_context=bound)], value=value, selection_context=ACTIVE
    )
    assert out["chosen"] is None
    assert A not in json.dumps(out) and ACTIVE.session_id not in json.dumps(out)


def test_matching_sanctioned_context_is_observation_authority_not_execution():
    value = request()
    value["connection_restrictions"].update(
        require_authority=True,
        provider_id="openrouter",
        connection_id=A,
        models=[dict(provider="openrouter", model="a")],
        shared_quota_scope=B,
    )
    out = run(
        [candidate(connection_context=context(shared_quota_scope=B, models=("a",)))],
        value=value,
        selection_context=ACTIVE,
    )
    assert out["chosen"] and not out["execution_authority"]
    assert (
        out["selection_policy"]["connection_restrictions"]["connection_id"]
        == "required"
    )
    assert A not in json.dumps(out) and B not in json.dumps(out)


@pytest.mark.parametrize("mode", sp.QUOTA_MODES)
@pytest.mark.parametrize(
    "kind",
    [
        "available",
        "unknown",
        "expired",
        "exhausted",
        "other_scope",
        "unsupported",
        "conflicting",
        "wrong_version",
    ],
)
def test_quota_contract_composition_uses_only_bounded_matching_evaluator(mode, kind):
    value = request()
    value["quota_policy"] = mode
    result = quota_result()
    callback = evaluator(result)
    if kind == "unknown":
        callback = None
    elif kind == "expired":
        callback = evaluator(quota_result(expires=149))
    elif kind == "exhausted":
        callback = evaluator(quota_result(0))
    elif kind == "other_scope":
        callback = evaluator(quota_result(scope=B))
    elif kind == "unsupported":
        result["allowance"]["quota_windows"].append(
            dict(dimension="credits", window="month", remaining="999")
        )
        callback = evaluator(result)
    elif kind == "conflicting":
        result["allowance"]["quota_windows"].append(
            copy.deepcopy(result["allowance"]["quota_windows"][0])
        )
        result["allowance"]["complete"] = False
        callback = evaluator(result)
    elif kind == "wrong_version":
        result["quota_policy_version"] = 2
        callback = evaluator(result)
    out = run(
        [candidate(connection_context=context())],
        value=value,
        selection_context=ACTIVE,
        quota_evaluator=callback,
    )
    expected = (
        kind == "available"
        and mode != "require_no_charge_guarantee"
        or kind
        in (
            "unknown",
            "expired",
            "other_scope",
            "unsupported",
            "conflicting",
            "wrong_version",
        )
        and mode in ("prefer_available_allowance", "avoid_verified_exhaustion")
    )
    assert bool(out["chosen"]) == expected
    q = out["considered"][0]["quota_policy_evidence"]
    assert q["preference_available"] == (
        kind == "available" and mode == "prefer_available_allowance"
    )
    assert not q.get("execution_authority")
    assert A not in json.dumps(out)


def test_quota_preferences_never_rescue_paid_and_429_is_not_exhaustion():
    value = request()
    value["quota_policy"] = "prefer_available_allowance"
    rows = [
        candidate("a", connection_context=context()),
        candidate("paid", cost_tier="paid", connection_context=context()),
    ]
    out = run(
        rows,
        value=value,
        selection_context=ACTIVE,
        quota_evaluator=evaluator(quota_result()),
    )
    assert out["chosen"]["model"] == "a"
    assert not next(r for r in out["considered"] if r["model"] == "paid")["eligible"]
    out = run([candidate(health={"last_status": 429})])
    assert (
        out["chosen"]
        and out["considered"][0]["quota_policy_evidence"]["state"] == "unknown"
    )


def test_same_canonical_request_engine_preview_tool_and_dashboard_api(
    tmp_path, monkeypatch
):
    from tests.test_dashboard_api import _load_plugin_api
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    monkeypatch.setattr(router.time, "time", lambda: NOW)
    value = request()
    value["hard_eligibility"]["authorized_providers"] = ["nvidia"]
    store = seeded(tmp_path)
    r = router.Router(dict(store=store, providers=["nvidia"]))
    monkeypatch.setattr(tools._rt(), "get_router", lambda: r)
    expected = r.preview(now=NOW, selection_policy=value, requires_tools=False)
    actual = tools._select_handler({"requires_tools": False, "selection_policy": value})
    assert actual["decision"] == expected
    assert r.select(return_decision=True, selection_policy=value) == expected
    api = _load_plugin_api()
    config = dict(
        available=True, values=dict(state_dir=str(tmp_path), providers=["nvidia"])
    )
    monkeypatch.setattr(api._sr, "read_plugin_config", lambda: config)
    app = FastAPI()
    app.include_router(api.router, prefix="/api/plugins/autorouter")
    before = store.db_path.read_bytes()
    with TestClient(app) as client:
        response = client.post(
            "/api/plugins/autorouter/selection/preview",
            json={"selection_policy": value},
        )
        assert response.status_code == 200 and response.json() == expected
        bad = client.post(
            "/api/plugins/autorouter/selection/preview",
            json={"selection_policy": {"prompt": "PRIVATE_PROMPT_SENTINEL"}},
        )
        assert bad.status_code == 400 and "PRIVATE_PROMPT_SENTINEL" not in bad.text
    assert store.db_path.read_bytes() == before


def test_invalid_request_never_discovers_or_writes(tmp_path, monkeypatch):
    from autorouter.autorouter_core.discovery import discovery
    from autorouter.autorouter_core.storage import state

    monkeypatch.setattr(
        discovery,
        "discover_all",
        lambda *a, **k: pytest.fail("invalid request discovered"),
    )
    r = router.Router(dict(store=state.StateStore(tmp_path), providers=["openrouter"]))
    assert (
        r.select(selection_policy={}, return_decision=True)["no_match"]
        == "selection_policy_invalid"
    )


def test_prefer_mode_ranks_only_fresh_supported_allowance_and_ties_remain_stable():
    value = request()
    value["quota_policy"] = "prefer_available_allowance"
    rows = [
        candidate("a", connection_context=context()),
        candidate("b", connection_context=context()),
    ]
    fresh = evaluator(quota_result())

    def per_model(snapshot, provider, model, scope, now, **kwargs):
        if model == "a":
            result = quota_result()
            result.update(state="unknown", preference_available=False)
            result["allowance"].update(complete=False, quota_windows=[])
            result["quota_policy"] = kwargs["quota_policy"]
            return result
        return fresh(snapshot, provider, model, scope, now, **kwargs)

    out = run(rows, value=value, selection_context=ACTIVE, quota_evaluator=per_model)
    assert out["chosen"]["model"] == "b"
    assert out["ranking_order"][0] == "fresh_supported_allowance"
    assert (
        run(
            list(reversed(rows)),
            value=value,
            selection_context=ACTIVE,
            quota_evaluator=per_model,
        )
        == out
    )
    assert run(rows, value=value, selection_context=ACTIVE)["chosen"]["model"] == "a"


@pytest.mark.parametrize("field", ["cost_tier", "context_window", "tools"])
def test_missing_stale_and_future_field_proofs_deny(field):
    value = request()
    value["hard_eligibility"]["required_capabilities"] = {"tools": "required"}
    for start, end in [(None, None), (100, 149), (151, 220)]:
        row = candidate()
        row["field_evidence"][field].update(retrieved_at=start, expires_at=end)
        assert run([row], value=value)["chosen"] is None


def test_strict_observed_health_age_is_explicit_and_bounded():
    value = request()
    value["hard_eligibility"]["health"].update(
        require_observed=True, max_age_seconds=20
    )
    assert run(
        [candidate(health_reason="available", health={"last_success_at": 140})],
        value=value,
    )["chosen"]
    for timestamp in [None, 100, 151, float("nan")]:
        assert (
            run(
                [
                    candidate(
                        health_reason="available", health={"last_success_at": timestamp}
                    )
                ],
                value=value,
            )["chosen"]
            is None
        )


def test_version_denials_have_bounded_specific_error_codes():
    value = request()
    value["schema_version"] = 2
    assert run(value=value)["contract_error"] == "selection_policy_version_unsupported"
    value = request()
    value["task_requirements"]["schema_version"] = 2
    assert run(value=value)["contract_error"] == "task_requirements_version_unsupported"
    value = request()
    value["preferences"]["policy"] = "not-supported"
    assert run(value=value)["contract_error"] == "ranking_policy_unsupported"


@pytest.mark.parametrize(
    "kwargs",
    [
        {"requires_tools": "yes"},
        {"min_context": None},
        {"max_in_flight": True},
        {"providers": 42},
        {"exclude": 42},
        {"limit": None},
    ],
)
def test_malformed_outer_constraints_are_denied_without_crashing(kwargs):
    assert run(**kwargs)["no_match"] == "selection_policy_invalid"


def test_portable_fixture_and_tool_share_the_contract_schema():
    value = json.loads(FIXTURE.read_text())
    assert value["request_schema"] == sp.request_schema()
    assert (
        tools._SELECT_SCHEMA["parameters"]["properties"]["selection_policy"]
        == sp.request_schema()
    )
    assert sp.validate(value["request"]) == value["request"]


def test_public_contract_does_not_authorize_context_or_leak_callback_diagnostics():
    value = request()
    value["quota_policy"] = "require_fresh_account_allowance"

    def failed(*args, **kwargs):
        raise RuntimeError("RAW_CREDENTIAL_SENTINEL PRIVATE_COMPLETION_SENTINEL")

    out = run(
        [candidate(connection_context=context())],
        value=value,
        selection_context=ACTIVE,
        quota_evaluator=failed,
    )
    assert out["chosen"] is None
    assert "RAW_CREDENTIAL_SENTINEL" not in json.dumps(out)
    assert "PRIVATE_COMPLETION_SENTINEL" not in json.dumps(out)


def test_conflicting_shared_quota_scope_cannot_supply_fresh_allowance():
    value = request()
    value["quota_policy"] = "require_fresh_account_allowance"
    value["connection_restrictions"].update(
        provider_id="openrouter", shared_quota_scope=B
    )
    out = run(
        [candidate(connection_context=context(shared_quota_scope=B))],
        value=value,
        selection_context=ACTIVE,
        quota_evaluator=evaluator(quota_result()),
    )
    assert out["chosen"] is None


def test_legacy_observed_scope_is_not_current_context_for_canonical_policy(
    tmp_path, monkeypatch
):
    monkeypatch.setattr(router.time, "time", lambda: NOW)
    store = seeded(tmp_path)
    expected = json.loads(
        Path(__file__).with_name("fixtures").joinpath("policies-v1.json").read_text()
    )["decision_fixture"]["expected_model"]
    store.upsert_health(
        "nvidia", expected, key_scope="previous-connection", auth_failed=1
    )
    r = router.Router(
        dict(
            store=store,
            providers=["nvidia"],
            credential_scopes={"nvidia": "previous-connection"},
        )
    )
    value = request()
    value["hard_eligibility"]["authorized_providers"] = ["nvidia"]
    result = r.preview(now=NOW, selection_policy=value)
    assert result["chosen"]["model"] == expected
    assert result["chosen"]["connection_authority"] == "unknown"
    assert result["chosen"]["scope_state"] == "scope_unknown"


def test_cached_access_assertion_is_not_current_connection_authority():
    row = candidate(
        free_access={
            "allowed": False,
            "state": "exhausted",
            "reason": "verified_account_quota_exhausted",
        }
    )
    out = run([row])
    assert out["chosen"] and out["chosen"]["free_access"]["state"] == "unknown"


def test_requested_connection_model_scope_is_not_granted_by_a_model_name():
    value = request()
    value["connection_restrictions"]["models"] = [
        dict(provider="openrouter", model="a")
    ]
    out = run(
        [candidate(connection_context=context())], value=value, selection_context=ACTIVE
    )
    assert out["chosen"] is None
    assert "connection_model_scope_unavailable" in out["considered"][0]["reason_codes"]


def test_non_preference_modes_cannot_inject_allowance_ranking():
    result = quota_result()
    result["preference_available"] = True
    decision = sp.quota_decision(
        lambda *args, **kwargs: result,
        None,
        "openrouter",
        "a",
        context(),
        True,
        150,
        "avoid_verified_exhaustion",
    )
    assert decision["allowed"] is True
    assert decision["preference_available"] is False


@pytest.mark.parametrize("mode", sp.QUOTA_MODES)
@pytest.mark.parametrize("state", ["exhausted", "healthy", "unknown", "unavailable"])
def test_verified_exhaustion_overrides_contradictory_evaluator(mode, state):
    value = request()
    value["quota_policy"] = mode
    result = quota_result(0)
    result.update(allowed=True, state=state, preference_available=True)
    out = run(
        [candidate(connection_context=context())],
        value=value,
        selection_context=ACTIVE,
        quota_evaluator=evaluator(result),
    )
    assert out["chosen"] is None
    quota = out["considered"][0]["quota_policy_evidence"]
    assert quota["allowed"] is False
    assert quota["preference_available"] is False
    if mode != "require_no_charge_guarantee":
        assert quota["state"] == "exhausted"
        assert quota["reason"] == "quota_result_invalid"
    assert A not in json.dumps(out) and "account_scope" not in json.dumps(quota)


@pytest.mark.parametrize(
    "state,allowed",
    [
        ("exhausted", False),
        ("exhausted", True),
        ("healthy", False),
        ("unknown", True),
        ("unavailable", True),
    ],
)
@pytest.mark.parametrize("mode", sp.QUOTA_MODES)
def test_available_windows_cannot_support_contradictory_state_or_permission(
    mode, state, allowed
):
    value = request()
    value["quota_policy"] = mode
    result = quota_result()
    result.update(state=state, allowed=allowed)
    out = run(
        [candidate(connection_context=context())],
        value=value,
        selection_context=ACTIVE,
        quota_evaluator=evaluator(result),
    )
    assert out["chosen"] is None
    assert not out["considered"][0]["quota_policy_evidence"]["preference_available"]


@pytest.mark.parametrize("mode", sp.QUOTA_MODES)
@pytest.mark.parametrize(
    "mismatch", ["account", "model", "shared", "unsupported", "expired"]
)
def test_unrelated_or_unsupported_exhaustion_remains_unknown(mode, mismatch):
    value = request()
    value["quota_policy"] = mode
    result = quota_result(0, scope=B if mismatch == "account" else A)
    window = result["allowance"]["quota_windows"][0]
    if mismatch == "model":
        window["model"] = "different-model"
    elif mismatch == "shared":
        window["shared_scope"] = fa.canonical_scope("openrouter:" + B)
    elif mismatch == "unsupported":
        window["dimension"] = "unknown-unit"
    elif mismatch == "expired":
        window["expires_at"] = 149
    # A producer must preserve uncertainty for data outside the applicable window.
    result.update(state="unknown", allowed=True)
    out = run(
        [candidate(connection_context=context())],
        value=value,
        selection_context=ACTIVE,
        quota_evaluator=evaluator(result),
    )
    assert bool(out["chosen"]) == (
        mode in ("prefer_available_allowance", "avoid_verified_exhaustion")
    )
    quota = out["considered"][0]["quota_policy_evidence"]
    assert quota["state"] == "unknown" and not quota["preference_available"]
    assert A not in json.dumps(out) and B not in json.dumps(out)
