import tempfile
from pathlib import Path

import pytest

from autorouter.autorouter_core.storage import state as st


def test_state_store_init_and_summary(tmp_path):
    store = st.StateStore(tmp_path / "state")
    s = store.summary()
    assert "db_path" in s
    assert (tmp_path / "state" / "autorouter.db").exists()


def test_catalog_and_lkg(tmp_path):
    store = st.StateStore(tmp_path / "state")
    store.upsert_catalog("nvidia", "m1", context_length=8192, capabilities={"tools": True}, cost_tier="free")
    rows = store.get_catalog("nvidia")
    assert len(rows) == 1
    store.save_lkg({"nvidia": [{"provider": "nvidia", "model": "m1"}]})
    lkg = store.get_lkg()
    assert lkg["nvidia"][0]["model"] == "m1"


def test_health_cooldown_retired_auth(tmp_path):
    store = st.StateStore(tmp_path / "state")
    store.record_outcome("nvidia", "m1", False, status_code=429)
    h = store.get_health("nvidia", "m1")
    assert h["cooldown_until"] > 0
    store.record_outcome("nvidia", "m2", False, status_code=410, error_type="model_not_found")
    h2 = store.get_health("nvidia", "m2")
    assert h2["retired"] == 1
    store.record_outcome("nvidia", "m3", False, status_code=401)
    h3 = store.get_health("nvidia", "m3")
    assert h3["auth_failed"] == 1
    # availability
    assert not store.is_available("nvidia", "m2")
    assert not store.is_available("nvidia", "m3")


def test_fresh_database_has_health_table(tmp_path):
    """Regression test: a fresh database must have the health table initialized.

    This ensures that StateStore._init_db() correctly creates the health table
    before any health operations are attempted.
    """
    import sqlite3
    store = st.StateStore(tmp_path / "state")

    # Verify the database file exists
    assert store.db_path.exists()

    # Verify the health table exists
    conn = sqlite3.connect(str(store.db_path))
    try:
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='health'"
        ).fetchone()
        assert rows is not None, "health table must exist in fresh database"
        # Verify schema has expected columns
        cols = [r[1] for r in conn.execute(
            "PRAGMA table_info(health)"
        ).fetchall()]
        required = {"provider", "model", "key_scope", "successes", "failures",
                    "consecutive_failures", "cooldown_until", "retired", "auth_failed"}
        assert required.issubset(set(cols)), f"health table missing columns: {required - set(cols)}"
    finally:
        conn.close()

    # Verify health operations work
    h = store.get_health("nvidia", "test-model")
    assert h["provider"] == "nvidia"
    assert h["model"] == "test-model"
    assert h["cooldown_until"] == 0
    assert store.is_available("nvidia", "test-model")

def test_key_scope_status_code_contract(tmp_path):
    """Regression test: verifies that status_code cannot be accidentally written
    into key_scope via positional argument mapping.

    The StateStore.record_outcome() and Router.record_outcome() method signatures
    use keyword-only arguments (separated by *). Forbidden positional calls raise
    TypeError.

    Assertions:
    - StateStore.record_outcome(provider, model, True, 429)                → TypeError
    - StateStore.record_outcome(provider, model, True, status_code=429)     → key_scope='', status_code=429
    - Router.record_outcome(provider, model, True, 429)                     → TypeError
    - Router.record_outcome(provider, model, True, status_code=429)         → success
    - key_scope is never accidentally set to a status code value
    - Cooldown is triggered by 429 on failed request
    """
    import sqlite3
    store = st.StateStore(tmp_path / "state")

    # Record a failed outcome with status_code 429 as keyword argument.
    # Cooldown is only set when the request fails (success=False).
    store.record_outcome("nvidia", "m1", False, status_code=429)
    h = store.get_health("nvidia", "m1")
    assert h["key_scope"] == "", f"key_scope should default to '', got '{h['key_scope']}'"
    assert h["last_status"] == 429, f"last_status should be 429, got {h['last_status']}"

    # Record another failed outcome with status_code 200 as keyword
    store.record_outcome("nvidia", "m2", False, status_code=200)
    h2 = store.get_health("nvidia", "m2")
    assert h2["key_scope"] == "", f"key_scope should default to '', got '{h2['key_scope']}'"
    assert h2["last_status"] == 200, f"last_status should be 200, got {h2['last_status']}"

    # Verify key_scope is never accidentally set to a status code value
    assert h["key_scope"] != 429, "key_scope must never be set to a status code value"
    assert h2["key_scope"] != 200, "key_scope must never be set to a status code value"

    # Verify cooldown is triggered by 429 on failed request
    assert h["cooldown_until"] > 0, "429 on failed request should trigger cooldown"

    # Assert forbidden positional calls raise TypeError

    # StateStore: positional status_code must raise TypeError
    try:
        store.record_outcome("nvidia", "m1", True, 429)
        raise AssertionError("StateStore.record_outcome positional status_code should raise TypeError")
    except TypeError:
        pass  # Expected

    # Router: positional status_code must raise TypeError
    from autorouter.autorouter_core.routing import router as rmod
    router = rmod.Router({"store": store, "policy": "auto", "providers": ["nvidia"], "free_only": True})
    try:
        router.record_outcome("nvidia", "m1", True, 429)
        raise AssertionError("Router.record_outcome positional status_code should raise TypeError")
    except TypeError:
        pass  # Expected

    # Router keyword argument test
    router.record_outcome("nvidia", "m1", True, status_code=429)
    h_router = store.get_health("nvidia", "m1")
    assert h_router["last_status"] == 429
