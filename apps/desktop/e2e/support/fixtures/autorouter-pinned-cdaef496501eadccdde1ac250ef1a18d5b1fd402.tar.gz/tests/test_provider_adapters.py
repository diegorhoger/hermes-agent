"""Provider discovery fixtures use no network, inference or real credentials."""
import json
import logging
from types import SimpleNamespace
from urllib.error import HTTPError, URLError
import pytest
from autorouter.autorouter_core.discovery import adapters as ad, discovery, metadata
from autorouter.autorouter_core.storage import state


@pytest.mark.parametrize('provider,payload,mid,context,tools', [
    ('groq', {'data': [{'id': 'vendor/model', 'context_window': 131072}]}, 'vendor/model', None, 'unknown'),
    ('gemini', {'models': [{'name': 'models/gemini-model', 'inputTokenLimit': 32000,
                          'supportedGenerationMethods': ['generateContent']}]}, 'gemini-model', 32000, 'unknown'),
    ('mistral', {'data': [{'id': 'mistral-model', 'max_context_length': 32000,
                         'capabilities': {'function_calling': True}}]}, 'mistral-model', 32000, 'supported'),
])
def test_success_normalizes_only_documented_fields(provider, payload, mid, context, tools, monkeypatch):
    requests = []
    def fetch(url, headers):
        requests.append((url, headers)); return payload
    monkeypatch.setattr(ad, '_read_json', fetch)
    rows = ad.fetch_catalog(provider, 'fixture-credential', now=100)
    cap = rows[mid]
    assert cap['provider'] == provider and cap['model'] == mid
    assert cap['context_window'] == context and cap['tools'] == tools
    assert cap['cost_tier'] == 'unknown'
    assert cap['retrieved_at'] == 100 and cap['expires_at'] == 100 + ad.TTL
    assert 'fixture-credential' not in json.dumps(rows)
    header = 'x-goog-api-key' if provider == 'gemini' else 'Authorization'
    assert header in requests[0][1] and 'fixture-credential' not in requests[0][0]
    assert metadata.verified_fields(cap, provider, mid, 101)[0]['cost_tier'] == 'unknown'


def test_gemini_pagination_stays_fixed_origin(monkeypatch):
    calls = []
    def fetch(url, headers):
        calls.append(url)
        return {'models': [{'name': 'models/a'}], 'nextPageToken': 'https://evil.invalid/?api_key=secret'} if len(calls) == 1 else {'models': [{'name': 'models/b'}]}
    monkeypatch.setattr(ad, '_read_json', fetch)
    assert set(ad.fetch_catalog('gemini', 'secret', 100)) == {'a', 'b'}
    assert calls[1].startswith(ad.SPECS['gemini'][0] + '?pageSize=1000&pageToken=https%3A')
    monkeypatch.setattr(ad, '_read_json', lambda *a: {'models': [], 'nextPageToken': 'repeat'})
    with pytest.raises(ad.DiscoveryError, match='malformed_pagination'):
        ad.fetch_catalog('gemini', 'secret')


@pytest.mark.parametrize('provider,payload', [
    ('groq', {}), ('groq', {'data': None}), ('groq', {'data': [None]}),
    ('groq', {'data': [{'id': 'same'}, {'id': 'same'}]}),
    ('groq', {'data': [{'id': 'sk-secretsecretsecret'}]}),
    ('gemini', {'models': [{'name': 'wrong-prefix'}]}),
    ('mistral', {'data': [{'id': '<img src=x>'}]}),
])
def test_malformed_catalog_is_sanitized(provider, payload):
    with pytest.raises(ad.DiscoveryError, match='malformed_catalog') as error:
        ad.normalize(provider, payload, 100)
    assert '<img' not in str(error.value) and 'sk-' not in str(error.value)


@pytest.mark.parametrize('code,category', [(401, 'authentication'), (403, 'authentication'),
                                         (429, 'rate_limited'), (500, 'provider_unavailable'), (302, 'http_error')])
def test_transport_status_redaction(code, category, monkeypatch):
    def fail(*args, **kwargs):
        raise HTTPError('https://secret.invalid?api_key=secret', code, 'Bearer sensitive-secret', {}, None)
    monkeypatch.setattr(ad, 'build_opener', lambda *a: SimpleNamespace(open=fail))
    with pytest.raises(ad.DiscoveryError) as error:
        ad.fetch_catalog('groq', 'secret')
    assert str(error.value) == category


def test_timeout_size_and_json_redaction(monkeypatch):
    def fail(*args, **kwargs): raise URLError('secret')
    monkeypatch.setattr(ad, 'build_opener', lambda *a: SimpleNamespace(open=fail))
    with pytest.raises(ad.DiscoveryError, match='transport_error'): ad.fetch_catalog('groq', 'secret')
    class Response:
        def __init__(self, raw): self.raw = raw
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self, count): return self.raw
    for raw, category in [(b'not JSON secret', 'malformed_catalog'), (b'x' * (ad.MAX_BYTES + 1), 'catalog_too_large')]:
        monkeypatch.setattr(ad, 'build_opener', lambda *a: SimpleNamespace(open=lambda *a, **k: Response(raw)))
        with pytest.raises(ad.DiscoveryError, match=category): ad.fetch_catalog('groq', 'secret')
    assert ad._NoRedirect().redirect_request(None, None, 302, '', {}, 'https://evil.invalid') is None


def test_discovery_uses_authorized_adapter_without_profile_or_inference(monkeypatch, tmp_path, caplog):
    import providers
    monkeypatch.setattr(providers, 'get_provider_profile', lambda name: None)
    monkeypatch.setenv('MISTRAL_API_KEY', 'fixture-credential')
    monkeypatch.setattr(ad, '_read_json', lambda *a: {'data': [{'id': 'model', 'max_context_length': 32000,
                                                           'capabilities': {'function_calling': True}}]})
    store = state.StateStore(tmp_path)
    result = discovery.discover_all(['mistral'], store)['mistral']
    assert result[0]['model'] == 'model' and result[0]['cost_tier'] == 'unknown'
    cap = json.loads(store.get_capability('mistral', 'model')['capability_json'])
    assert cap['tools'] == 'supported' and 'fixture-credential' not in json.dumps(cap)
    assert 'fixture-credential' not in caplog.text


def test_removed_models_revoke_old_price_proof_but_failure_preserves_age(monkeypatch, tmp_path):
    import providers
    monkeypatch.setattr(providers, 'get_provider_profile', lambda name: None)
    monkeypatch.setenv('GROQ_API_KEY', 'fixture-credential')
    store = state.StateStore(tmp_path)
    old = dict(provider='groq', model='removed', cost_tier='free', tools='supported', context_window=32000,
               metadata_source='https://provider.example/prices', retrieved_at=100, expires_at=99999999999)
    store.persist_discovered_model(dict(provider='groq', model='removed', cost_tier='free', metadata=old))
    def fail(*a): raise ad.DiscoveryError('provider_unavailable')
    monkeypatch.setattr(ad, '_read_json', fail)
    discovery.discover_all(['groq'], store)
    assert json.loads(store.get_capability('groq', 'removed')['capability_json'])['retrieved_at'] == 100
    monkeypatch.setattr(ad, '_read_json', lambda *a: {'data': []})
    discovery.discover_all(['groq'], store)
    cap = json.loads(store.get_capability('groq', 'removed')['capability_json'])
    assert cap['available'] is False and cap['cost_tier'] == 'unknown'


def test_unknown_provider_no_adapter_and_missing_credential_no_network(monkeypatch):
    monkeypatch.setattr(ad, '_read_json', lambda *a: pytest.fail('network must not run'))
    with pytest.raises(ad.DiscoveryError, match='unsupported_provider'): ad.fetch_catalog('invented', 'secret')
    with pytest.raises(ad.DiscoveryError, match='credential_missing'): ad.fetch_catalog('groq', None)


def test_real_request_is_get_bounded_and_credential_only_in_header(monkeypatch):
    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self, count):
            assert count == ad.MAX_BYTES + 1
            return b'{"data":[]}'
    def open_request(request, timeout):
        assert request.get_method() == 'GET' and timeout == 10
        assert request.full_url == ad.SPECS['groq'][0]
        assert request.get_header('Authorization') == 'Bearer fake-credential'
        return Response()
    monkeypatch.setattr(ad, 'build_opener', lambda *a: SimpleNamespace(open=open_request))
    assert ad.fetch_catalog('groq', 'fake-credential') == {}


def test_missing_price_does_not_renew_independent_proof(monkeypatch, tmp_path):
    import providers
    monkeypatch.setattr(providers, 'get_provider_profile', lambda name: None)
    monkeypatch.setenv('MISTRAL_API_KEY', 'fake-credential')
    monkeypatch.setattr(ad, '_read_json', lambda *a: {'data': [{'id': 'model', 'max_context_length': 32000,
                                                            'capabilities': {'function_calling': True}}]})
    store = state.StateStore(tmp_path)
    old = dict(provider='mistral', model='model', cost_tier='free', tools='supported', context_window=32000,
               metadata_source='https://provider.example/prices', retrieved_at=100, expires_at=200)
    store.persist_discovered_model(dict(provider='mistral', model='model', metadata=old))
    result = discovery.discover_all(['mistral'], store)['mistral'][0]
    assert result['cost_tier'] == 'unknown'  # expired proof cannot be renewed by catalog refresh
    cap = json.loads(store.get_capability('mistral', 'model')['capability_json'])
    assert cap['field_evidence']['cost_tier']['retrieved_at'] == 100
    assert cap['field_evidence']['cost_tier']['expires_at'] == 200


@pytest.mark.parametrize('provider, row', [
    ('mistral', {'id': 'model', 'archived': True, 'max_context_length': 32000}),
    ('groq', {'id': 'model', 'active': False}),
])
def test_unavailable_catalog_row_revokes_prior_free_proof(provider, row):
    old = dict(provider=provider, model='model', cost_tier='free', tools='supported', context_window=32000,
               metadata_source='https://provider.example/prices', retrieved_at=100, expires_at=200)
    fresh = ad.normalize(provider, {'data': [row]}, 150)['model']
    merged = metadata.merge_metadata(fresh, old, 151)
    assert merged['available'] is False
    assert metadata.verified_fields(merged, provider, 'model', 151)[0]['cost_tier'] == 'unknown'
