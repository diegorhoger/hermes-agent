"""Cross-process concurrency tests for the model preference (dispatch #111).

Each test drives *separate Python interpreters* against a file-backed fake
``hermes_cli`` that reproduces the host's real semantics (atomic per-key
read-modify-write under a sibling flock — never the live ~/.hermes/config.yaml).
AutoRouter's plugin-scoped cross-process lock plus the base-hash compare-and-swap
boundary must ensure:

* two writers racing the same base — exactly one wins, the other is refused
  as stale (409 semantics) *before* mutating anything;
* no interleaving can tear the include/exclude/mode triple (single key);
* a stale base never clobbers what the other process persisted;
* a failing preference write leaves the previous state fully intact;
* a fresh process reads back exactly what was persisted (restart persistence).
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]

pytestmark = pytest.mark.skipif(os.name != "posix", reason="fcntl locking is POSIX-only in this harness")


_FAKE_PLUGINS_STATE = '''
import fcntl
import json
import os
from pathlib import Path

_CFG = Path(os.environ["FAKE_HERMES_CONFIG"])
_LOCK = _CFG.with_name(".fake-hermes.lock")


def save_plugin_setting(plugin_id, segments, value):
    if os.environ.get("FAKE_HERMES_FAIL_ON") == "model_preference" and "model_preference" in segments:
        raise RuntimeError("simulated host write failure")
    with open(_LOCK, "a+b") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            try:
                data = json.loads(_CFG.read_text(encoding="utf-8") or "{}")
            except FileNotFoundError:
                data = {}
            entry = data.setdefault("plugins", {}).setdefault("entries", {}).setdefault(
                plugin_id, {}).setdefault("settings", {})
            cursor = entry
            for seg in segments[:-1]:
                cursor = cursor.setdefault(seg, {})
            cursor[segments[-1]] = value
            tmp = _CFG.with_suffix(".tmp")
            tmp.write_text(json.dumps(data), encoding="utf-8")
            os.replace(tmp, _CFG)
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
'''

_FAKE_CONFIG = '''
import json
import os
from pathlib import Path

_CFG = Path(os.environ["FAKE_HERMES_CONFIG"])


def load_config_readonly():
    try:
        return json.loads(_CFG.read_text(encoding="utf-8") or "{}")
    except FileNotFoundError:
        return {}
'''

_CHILD = '''
import importlib.util
import json
import sys

root = sys.argv[1]
action = sys.argv[2]

spec = importlib.util.spec_from_file_location(
    "_autorouter_dashboard_state_reader",
    root + "/dashboard/state_reader.py")
sr = importlib.util.module_from_spec(spec)
sys.modules["_autorouter_dashboard_state_reader"] = sr
spec.loader.exec_module(sr)


def report(payload):
    print("RESULT " + json.dumps(payload, sort_keys=True))


base = json.loads(sys.argv[3])
payload = json.loads(sys.argv[4])

if action == "toggle":
    result = sr.apply_model_preference(payload["toggles"], base)
    report({"kind": "toggle", "stale": bool(result.get("stale")), "ok": result.get("ok"),
            "mode": result.get("mode"), "changed": result.get("changed"),
            "hash": result.get("preference_hash")})
elif action == "reset":
    result = sr.apply_model_preference([], base, reset="unrestricted")
    report({"kind": "reset", "stale": bool(result.get("stale")), "ok": result.get("ok"),
            "mode": result.get("mode"), "changed": result.get("changed"),
            "hash": result.get("preference_hash")})
elif action == "readback":
    values = sr.read_plugin_config().get("values") or {}
    report({"kind": "readback", "hash": sr.model_preference_hash(values),
            "mode": sr.effective_model_preference(values)["mode"],
            "include": sr.effective_model_preference(values)["include"],
            "exclude": sr.effective_model_preference(values)["exclude"]})
'''


@pytest.fixture
def fake_hermes(tmp_path):
    """File-backed fake hermes_cli + writable config; yields (config_path, env)."""
    hermes_pkg = tmp_path / "fakehermes" / "hermes_cli"
    hermes_pkg.mkdir(parents=True)
    (hermes_pkg / "__init__.py").write_text("", encoding="utf-8")
    (hermes_pkg / "plugins_state.py").write_text(_FAKE_PLUGINS_STATE, encoding="utf-8")
    (hermes_pkg / "config.py").write_text(_FAKE_CONFIG, encoding="utf-8")
    config_path = tmp_path / "config.json"
    config_path.write_text(json.dumps({
        "plugins": {"entries": {"autorouter": {"settings": {
            "providers": ["nvidia", "openrouter"],
            "state_dir": str(tmp_path / "state"),
            "model_include": ["nvidia/nvidia-free"],
        }}}},
    }), encoding="utf-8")
    env = dict(os.environ)
    env["FAKE_HERMES_CONFIG"] = str(config_path)
    env["PYTHONPATH"] = str(tmp_path / "fakehermes") + os.pathsep + env.get("PYTHONPATH", "")
    return config_path, env


def _run_child(fake_hermes, action, base, payload, timeout=30):
    config_path, env = fake_hermes
    proc = subprocess.run(
        [sys.executable, "-c", _CHILD, str(ROOT), action, json.dumps(base), json.dumps(payload)],
        capture_output=True, text=True, env=env, timeout=timeout,
    )
    assert proc.returncode == 0, f"child failed: {proc.stderr}"
    for line in proc.stdout.splitlines():
        if line.startswith("RESULT "):
            return json.loads(line[len("RESULT "):])
    raise AssertionError(f"child printed no result: {proc.stdout} {proc.stderr}")


def _state_hash(fake_hermes):
    return _run_child(fake_hermes, "readback", None, {})


def test_two_processes_same_base_exactly_one_wins(fake_hermes):
    base = _state_hash(fake_hermes)["hash"]
    # enabled=true in allowlist mode adds the pair to the include list,
    # producing a real state change that must serialize across processes.
    toggles_a = {"toggles": [{"provider": "openrouter", "model": "alpha:free", "enabled": True}]}
    toggles_b = {"toggles": [{"provider": "openrouter", "model": "beta:free", "enabled": True}]}

    import concurrent.futures

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        fut_a = pool.submit(_run_child, fake_hermes, "toggle", base, toggles_a)
        fut_b = pool.submit(_run_child, fake_hermes, "toggle", base, toggles_b)
        res_a = fut_a.result()
        res_b = fut_b.result()

    outcomes = sorted([res_a["stale"], res_b["stale"]])
    assert outcomes == [False, True], f"expected one stale loser, got {res_a} and {res_b}"
    persisted = _state_hash(fake_hermes)
    winner = res_a if not res_a["stale"] else res_b
    assert persisted["hash"] == winner["hash"]


def test_stale_base_is_refused_before_mutation(fake_hermes):
    base = _state_hash(fake_hermes)["hash"]
    first = _run_child(fake_hermes, "toggle", base,
                       {"toggles": [{"provider": "nvidia", "model": "nvidia-free", "enabled": False}]})
    assert not first["stale"]
    # Same base again — the persisted state has moved on.
    second = _run_child(fake_hermes, "toggle", base,
                        {"toggles": [{"provider": "openrouter", "model": "qwen:free", "enabled": False}]})
    assert second["stale"]
    persisted = _state_hash(fake_hermes)
    assert persisted["hash"] == first["hash"]


def test_conflicting_toggles_same_model_one_wins_atomically(fake_hermes):
    # Fresh allowlist containing exactly the contested model.
    base = _state_hash(fake_hermes)["hash"]
    leg_off = _run_child(fake_hermes, "toggle", base,
                         {"toggles": [{"provider": "nvidia", "model": "nvidia-free", "enabled": False}]})
    assert not leg_off["stale"]
    assert leg_off["mode"] == "none"  # the last allowlisted model went off → none, never unrestricted
    # Now re-enable it in one process while another flips the base.
    base2 = _state_hash(fake_hermes)["hash"]
    on = _run_child(fake_hermes, "toggle", base2,
                    {"toggles": [{"provider": "nvidia", "model": "nvidia-free", "enabled": True}]})
    off = _run_child(fake_hermes, "toggle", base2,
                     {"toggles": [{"provider": "nvidia", "model": "nvidia-free", "enabled": False}]})
    stale = [r for r in (on, off) if r["stale"]]
    fresh = [r for r in (on, off) if not r["stale"]]
    assert len(stale) == 1 and len(fresh) == 1
    persisted = _state_hash(fake_hermes)
    assert persisted["hash"] == fresh[0]["hash"]


def test_partial_failure_leaves_previous_state_intact(fake_hermes, tmp_path):
    base = _state_hash(fake_hermes)["hash"]
    config_path, env = fake_hermes
    env = dict(env)
    env["FAKE_HERMES_FAIL_ON"] = "model_preference"
    before = json.loads(config_path.read_text(encoding="utf-8"))
    with pytest.raises(Exception):
        proc = subprocess.run(
            [sys.executable, "-c", _CHILD, str(ROOT), "toggle", json.dumps(base),
             json.dumps({"toggles": [{"provider": "nvidia", "model": "nvidia-free", "enabled": False}]})],
            capture_output=True, text=True, env=env, timeout=30,
        )
        assert proc.returncode != 0
        raise RuntimeError("unreachable") if proc.returncode == 0 else Exception(proc.stderr)
    after = json.loads(config_path.read_text(encoding="utf-8"))
    assert after == before, "a failed preference write changed the persisted config"


def test_reload_persistence_across_processes(fake_hermes):
    base = _state_hash(fake_hermes)["hash"]
    toggled = _run_child(fake_hermes, "toggle", base,
                         {"toggles": [{"provider": "openrouter", "model": "extra:free", "enabled": True}]})
    assert not toggled["stale"]
    reloaded = _state_hash(fake_hermes)
    assert reloaded["hash"] == toggled["hash"]
    assert "openrouter/extra:free" in reloaded["include"]


def test_concurrent_bulk_operations_converge_consistently(fake_hermes):
    base = _state_hash(fake_hermes)["hash"]

    def bulk(prefix, n):
        toggles = [{"provider": "openrouter", "model": f"bulk-{prefix}-{i}:free", "enabled": True}
                   for i in range(n)]
        return {"toggles": toggles}

    import concurrent.futures

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(_run_child, fake_hermes, "toggle", base, bulk(p, 4))
                   for p in ("a", "b", "c", "d")]
        results = [f.result() for f in futures]

    winners = [r for r in results if not r["stale"]]
    losers = [r for r in results if r["stale"]]
    assert len(winners) == 1, f"expected exactly one winner, got {results}"
    assert len(losers) == 3
    persisted = _state_hash(fake_hermes)
    assert persisted["hash"] == winners[0]["hash"]
    # The loser rebases and retries against fresh state — both edits land.
    rebased = _state_hash(fake_hermes)["hash"]
    retry = _run_child(fake_hermes, "toggle", rebased, bulk("d2", 2))
    assert not retry["stale"]
