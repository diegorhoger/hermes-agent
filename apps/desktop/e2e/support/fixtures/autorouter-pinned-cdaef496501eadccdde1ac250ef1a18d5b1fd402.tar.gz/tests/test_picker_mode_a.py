"""Plugin ``register(ctx)`` exactly one MODE A resolver (issue #116, review repair).

Covers the activation contract a native host must satisfy *when the plugin
registers*:

* exactly one MODE A interception path — the registered
  ``pre_inference_route`` consumer; the legacy monkey-patch adapter is never
  activated, not even on failure;
* strict boolean flags — string "true"/integer 1 never enable anything;
* fail closed when registration fails or the host is unsupported;
* dashboard activation marker written at registration time.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import pytest


class RecordingCtx:
    def __init__(self, config=None):
        self.config = config or {}
        self.hooks = []
        self.tools = []
        self.middleware = {}

    def get_config(self, key, default=None):
        return self.config.get(key, default)

    def register_hook(self, name, cb):
        self.hooks.append((name, cb))

    def register_tool(self, **kwargs):
        self.tools.append(kwargs)

    def register_middleware(self, kind, cb):
        self.middleware[kind] = cb


def _enable_plugins(monkeypatch):
    import autorouter.autorouter_core.discovery.discovery as dc

    monkeypatch.setattr(dc, "discover_all", lambda providers, store=None: {})


def _patch_settings(monkeypatch, native_routing, *, chat_router=False, native=False):
    """Patch both the host probe and the consumer's plugin-config read."""
    overlay = {"enabled": True, "enable_chat_router": chat_router,
               "enable_native_routing": native, "providers": ["nvidia"]}
    monkeypatch.setattr(native_routing, "_read_settings_from_config", lambda: overlay)


def _write_marker(path):
    return json.loads(Path(path).read_text()) if Path(path).is_file() else None


def _chat_router_state(state_dir):
    marker = _write_marker(state_dir / "native-routing-state.json")
    return marker


def test_native_host_mode_a_registers_consumer_no_legacy_adapter(tmp_path, monkeypatch):
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import native_routing, chat_router_adapter
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": ["fixture"], "host_version": "test", "reason": None})
    _patch_settings(monkeypatch, native_routing, chat_router=True)
    adapter_calls = []
    monkeypatch.setattr(chat_router_adapter.ChatRouterAdapter, "enable",
                        lambda self: adapter_calls.append("enable"))

    ctx = RecordingCtx({"enabled": True, "providers": ["nvidia"],
                        "enable_chat_router": True,
                        "state_dir": str(tmp_path)})
    autorouter.register(ctx)

    assert "pre_inference_route" in ctx.middleware, ctx.middleware.keys()
    assert adapter_calls == [], "legacy adapter must not be activated on a native-capable host"
    marker = _chat_router_state(tmp_path)
    assert marker is not None and marker["selection_mode"] == "native"
    assert marker["chat_router"] is True and marker["native_routing_registered"] is True


def test_native_host_mode_b_registered_without_chat_router(tmp_path, monkeypatch):
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import native_routing, chat_router_adapter
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    _patch_settings(monkeypatch, native_routing, native=True)
    adapter_calls = []
    monkeypatch.setattr(chat_router_adapter.ChatRouterAdapter, "enable",
                        lambda self: adapter_calls.append("enable"))

    ctx = RecordingCtx({"enabled": True, "providers": ["nvidia"],
                        "enable_native_routing": True,
                        "state_dir": str(tmp_path)})
    autorouter.register(ctx)
    assert "pre_inference_route" in ctx.middleware
    assert adapter_calls == []
    marker = _chat_router_state(tmp_path)
    assert marker["selection_mode"] == "native"
    assert marker["chat_router"] is False and marker["enable_native_routing"] is True


def test_both_flags_register_one_consumer_no_double_intercept(tmp_path, monkeypatch):
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import native_routing, chat_router_adapter
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    _patch_settings(monkeypatch, native_routing, chat_router=True, native=True)
    adapter_calls = []
    monkeypatch.setattr(chat_router_adapter.ChatRouterAdapter, "enable",
                        lambda self: adapter_calls.append("enable"))

    ctx = RecordingCtx({"enabled": True, "providers": ["nvidia"],
                        "enable_native_routing": True, "enable_chat_router": True,
                        "state_dir": str(tmp_path)})
    autorouter.register(ctx)
    assert list(ctx.middleware) == ["pre_inference_route"]
    assert adapter_calls == []
    marker = _chat_router_state(tmp_path)
    assert marker["selection_mode"] == "native"


def test_both_flags_disabled_registers_nothing(tmp_path, monkeypatch):
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import chat_router_adapter
    adapter_calls = []
    monkeypatch.setattr(chat_router_adapter.ChatRouterAdapter, "enable",
                        lambda self: adapter_calls.append("enable"))

    ctx = RecordingCtx({"enabled": True, "providers": ["nvidia"], "state_dir": str(tmp_path)})
    autorouter.register(ctx)
    assert "pre_inference_route" not in ctx.middleware
    assert adapter_calls == []
    marker = _chat_router_state(tmp_path)
    assert marker["selection_mode"] == "disabled"


def test_unsupported_host_chat_router_fails_closed_no_adapter(tmp_path, monkeypatch):
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import native_routing, chat_router_adapter
    monkeypatch.setattr(native_routing, "detect_host_native_routing", lambda: {
        "supported": False, "signals": [], "host_version": "0.23.1",
        "reason": "host exposes no sanctioned pre-inference route extension"})
    adapter_calls = []
    monkeypatch.setattr(chat_router_adapter.ChatRouterAdapter, "enable",
                        lambda self: adapter_calls.append("enable"))

    ctx = RecordingCtx({"enabled": True, "providers": ["nvidia"],
                        "enable_chat_router": True,
                        "state_dir": str(tmp_path)})
    autorouter.register(ctx)
    assert "pre_inference_route" not in ctx.middleware
    assert adapter_calls == [], "unsupported host must not fall back to the monkey-patch adapter"
    marker = _chat_router_state(tmp_path)
    assert marker["selection_mode"] == "unavailable"
    assert "sanctioned pre-inference route extension" in (marker["reason"] or "")


def test_native_registration_failure_fails_closed_no_adapter(tmp_path, monkeypatch):
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import native_routing, chat_router_adapter
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    adapter_calls = []
    monkeypatch.setattr(chat_router_adapter.ChatRouterAdapter, "enable",
                        lambda self: adapter_calls.append("enable"))

    class FailingCtx(RecordingCtx):
        def register_middleware(self, kind, cb):
            raise RuntimeError("middleware registry refused the registration")

    ctx = FailingCtx({"enabled": True, "providers": ["nvidia"],
                      "enable_chat_router": True,
                      "state_dir": str(tmp_path)})
    autorouter.register(ctx)
    assert adapter_calls == [], "registration failure must not fall back to the monkey-patch adapter"
    marker = _chat_router_state(tmp_path)
    assert marker["selection_mode"] == "unavailable"


def test_registration_by_another_plugin_is_not_this_plugins_consumer(tmp_path, monkeypatch):
    # A pre_inference_route consumer registered by someone else must not make
    # the plugin's MODE A actionable on its own; registration of THIS plugin's
    # consumer is what the activation marker certifies.
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import native_routing
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    _patch_settings(monkeypatch, native_routing, chat_router=True)

    class ForeignConsumerCtx(RecordingCtx):
        def register_middleware(self, kind, cb):
            self.middleware["pre_inference_route"] = lambda **kwargs: {"status": "route", "provider": "nvidia",
                                                                       "model": "nvidia/qwen-coder"}

    ctx = ForeignConsumerCtx({"enabled": True, "providers": ["nvidia"],
                              "enable_chat_router": True,
                              "state_dir": str(tmp_path)})
    autorouter.register(ctx)
    marker = _chat_router_state(tmp_path)
    assert marker is not None and marker["selection_mode"] == "native"


@pytest.mark.parametrize("bad_value", ["true", 1, "yes", "True", 0, None, False, ""])
def test_chat_router_flag_is_strict_boolean(tmp_path, monkeypatch, bad_value):
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import native_routing, chat_router_adapter
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    adapter_calls = []
    monkeypatch.setattr(chat_router_adapter.ChatRouterAdapter, "enable",
                        lambda self: adapter_calls.append("enable"))

    ctx = RecordingCtx({"enabled": True, "providers": ["nvidia"],
                        "enable_chat_router": bad_value,
                        "state_dir": str(tmp_path)})
    autorouter.register(ctx)
    assert "pre_inference_route" not in ctx.middleware
    assert adapter_calls == []
    marker = _chat_router_state(tmp_path)
    assert marker["selection_mode"] == "disabled"


@pytest.mark.parametrize("bad_value", ["true", 1, "yes", "True"])
def test_native_routing_flag_is_strict_boolean(tmp_path, monkeypatch, bad_value):
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import native_routing, chat_router_adapter
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    adapter_calls = []
    monkeypatch.setattr(chat_router_adapter.ChatRouterAdapter, "enable",
                        lambda self: adapter_calls.append("enable"))

    ctx = RecordingCtx({"enabled": True, "providers": ["nvidia"],
                        "enable_native_routing": bad_value,
                        "state_dir": str(tmp_path)})
    autorouter.register(ctx)
    assert "pre_inference_route" not in ctx.middleware
    assert adapter_calls == []
    marker = _chat_router_state(tmp_path)
    assert marker["selection_mode"] == "disabled"


def test_plugin_disabled_registers_none_of_the_routing_machinery(tmp_path, monkeypatch):
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import chat_router_adapter
    adapter_calls = []
    monkeypatch.setattr(chat_router_adapter.ChatRouterAdapter, "enable",
                        lambda self: adapter_calls.append("enable"))

    ctx = RecordingCtx({"enabled": False, "providers": ["nvidia"],
                        "enable_chat_router": True,
                        "state_dir": str(tmp_path)})
    autorouter.register(ctx)
    assert "pre_inference_route" not in ctx.middleware
    assert adapter_calls == []
    marker = _chat_router_state(tmp_path)
    assert marker["selection_mode"] == "disabled"
    # Disabled plugin never advertises chat-router readiness: the marker must
    # not claim available routing when the primary plugin is off.
    assert marker["chat_router"] is False
    assert marker["native_routing_registered"] is False


def test_marker_written_for_mode_a_enabled_roundtrips_into_overview(tmp_path, monkeypatch):
    import autorouter
    _enable_plugins(monkeypatch)
    from autorouter.autorouter_core.integration import native_routing
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    from autorouter.autorouter_core.storage import state as state_mod
    from autorouter.dashboard import state_reader as sr

    state_dir = tmp_path / "state"
    state_dir.mkdir()
    store = state_mod.StateStore(state_dir)

    values = {"enabled": True, "policy": "auto", "free_only": True,
              "providers": ["nvidia"], "cooldown_seconds": 60,
              "state_dir": str(state_dir), "paid_authorized": False,
              "enable_chat_router": True, "min_context": 8192,
              "requires_tools": False, "model_include": [], "model_exclude": []}
    monkeypatch.setattr(sr, "read_plugin_config", lambda: {
        "values": dict(values), "available": True, "reason": None, "managed": False,
    })

    ctx = RecordingCtx({"enabled": True, "providers": ["nvidia"],
                        "enable_chat_router": True,
                        "state_dir": str(state_dir)})
    _patch_settings(monkeypatch, native_routing, chat_router=True)
    autorouter.register(ctx)
    out = sr.assemble_overview()
    assert out["routing"]["chat_routing_state"] == "active"
