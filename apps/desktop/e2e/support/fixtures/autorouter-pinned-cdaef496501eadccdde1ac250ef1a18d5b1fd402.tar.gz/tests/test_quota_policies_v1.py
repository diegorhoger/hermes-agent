"""Explicit quota preflight contracts; no provider, credential or execution access."""
import copy
import json

import pytest
from autorouter.autorouter_core.evidence import free_access as fa

NOW=1794000000.0
SCOPE=fa.canonical_scope('openrouter:'+'a'*32)
OTHER=fa.canonical_scope('openrouter:'+'b'*32)


def snapshot(remaining=38):
    evidence=fa.normalize_openrouter_quota({'data':{'free_model_daily_requests':{
        'limit':50,'remaining':remaining,'used':50-remaining}}},SCOPE,NOW)
    return fa.FreeAccessSnapshot('openrouter',SCOPE,quota_evidence=evidence,
        state='healthy' if remaining else 'exhausted').to_dict()


def decision(value,policy,now=NOW,scope=SCOPE):
    return fa.evaluate_policy(value,'openrouter','example:free',scope,now,quota_policy=policy)


@pytest.mark.parametrize('policy',sorted(fa.QUOTA_POLICIES))
@pytest.mark.parametrize('remaining',[0,38])
def test_each_policy_is_distinct_and_never_invents_billing_authority(policy,remaining):
    value=snapshot(remaining)
    before=copy.deepcopy(value)
    out=decision(value,policy)
    assert out['quota_policy_version']==1 and value==before
    assert out['allowed']==(remaining>0 and policy!='require_no_charge_guarantee')
    assert out['preference_available']==(remaining>0 and policy=='prefer_available_allowance')
    assert not out['hard_stop_guaranteed']
    assert out['allowance']['quota_windows'][0]['dimension']=='requests'
    assert out['allowance']['quota_windows'][0]['currency'] is None


@pytest.mark.parametrize('kind',['missing','stale','unknown_scope','other_scope','unavailable','conflict','unsupported_window'])
@pytest.mark.parametrize('policy',sorted(fa.QUOTA_POLICIES))
def test_missing_or_incompatible_window_evidence_fails_only_explicit_strict_requirements(kind,policy):
    value=snapshot()
    now=NOW
    scope=SCOPE
    if kind=='missing':value={}
    elif kind=='stale':now+=fa.TTL
    elif kind=='unknown_scope':scope=''
    elif kind=='other_scope':scope=OTHER
    elif kind=='unavailable':value['state']='unavailable'
    elif kind=='conflict':value['quota_evidence'].append(copy.deepcopy(value['quota_evidence'][0]))
    else:value['quota_evidence'].append(dict(dimension='credits',window='month',currency='USD',remaining='999'))
    out=decision(value,policy,now,scope)
    assert out['allowed']==(policy in ('prefer_available_allowance','avoid_verified_exhaustion'))
    assert not out['preference_available']
    assert not out['allowance']['complete']
    assert out['state']!='exhausted'


def test_multiple_windows_are_separate_and_unknown_source_never_becomes_free_allowance():
    value=snapshot()
    value['quota_evidence'].append(dict(dimension='credits',window='month',remaining='999',
        source_url='SECRET_UNTRUSTED',label='SECRET_UNTRUSTED'))
    out=decision(value,'require_fresh_account_allowance')
    windows=out['allowance']['quota_windows']
    assert len(windows)==2
    assert windows[0]['remaining']=='38'
    assert windows[1]==dict(dimension='credits',window='month',state='unknown',source_supported=False)
    assert 'SECRET_UNTRUSTED' not in json.dumps(out)
    assert not out['allowed']


def test_unsupported_policy_and_oversized_window_set_do_not_succeed():
    assert not decision(snapshot(),'invented')['allowed']
    value=snapshot()
    value['quota_evidence']*=33
    assert not decision(value,'require_fresh_account_allowance')['allowed']


def test_available_view_retains_original_age_and_expiry():
    value=snapshot()
    out=decision(value,'prefer_available_allowance',NOW+60)
    row=out['allowance']['quota_windows'][0]
    assert row['observed_at']==NOW and row['expires_at']==NOW+fa.TTL
    assert not decision(value,'prefer_available_allowance',NOW+fa.TTL)['preference_available']


@pytest.mark.parametrize('policy',sorted(fa.QUOTA_POLICIES))
def test_known_exhaustion_is_not_erased_by_an_unsupported_additional_window(policy):
    value=snapshot(0)
    value['quota_evidence'].append(dict(dimension='credits',window='month',remaining='999'))
    assert not decision(value,policy)['allowed']


@pytest.mark.parametrize('policy',[None,{},[],42])
def test_malformed_policy_is_denied_without_exception(policy):
    assert not decision(snapshot(),policy)['allowed']


def test_explicit_tool_refresh_exposes_policy_without_fetch_or_selection_write(tmp_path,monkeypatch):
    from types import SimpleNamespace
    from autorouter.autorouter_core.integration import tools
    from autorouter.autorouter_core.storage import state
    store=state.StateStore(tmp_path)
    fa._save(store,snapshot())
    fake=SimpleNamespace(store=store,state={'providers':['openrouter'],'credential_scopes':{'openrouter':SCOPE}},refresh=lambda:{'source':'cached'})
    monkeypatch.setattr(tools,'_rt',lambda:SimpleNamespace(get_router=lambda:fake))
    monkeypatch.setattr(fa.time,'time',lambda:NOW)
    result=tools._refresh_handler({'include_quota':True,'quota_policy':'require_fresh_account_allowance'})
    row=result['quota']['providers'][0]
    assert row['preflight']['allowed'] and row['preflight']['quota_policy_version']==1
    assert row['quota_evidence']==snapshot()['quota_evidence']
    fake.state['credential_scopes']={}
    result=tools._refresh_handler({'include_quota':True,'quota_policy':'require_fresh_account_allowance'})
    assert not result['quota']['providers'][0]['preflight']['allowed']


@pytest.mark.parametrize('remaining',[0,38])
def test_required_unknown_window_survives_cache_roundtrip(tmp_path,remaining):
    from autorouter.autorouter_core.storage.state import StateStore
    store=StateStore(tmp_path)
    value=snapshot(remaining)
    value['quota_evidence'].append(dict(dimension='credits',window='month',remaining='999',
        source_url='SECRET_UNTRUSTED',label='SECRET_UNTRUSTED'))
    fa._save(store,value)
    restored=fa.read_snapshot(store,'openrouter',SCOPE)
    assert len(restored['quota_evidence'])==2
    assert 'SECRET_UNTRUSTED' not in json.dumps(restored)
    assert not decision(restored,'require_fresh_account_allowance')['allowed']
    assert decision(restored,'avoid_verified_exhaustion')['allowed']==bool(remaining)


from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.storage import state
from tests.test_selection_policy_v1 import request, context, ACTIVE

@pytest.mark.parametrize("mode", sorted(fa.QUOTA_POLICIES))
@pytest.mark.parametrize(
    "known,remaining", [(True, 38), (True, 0), (False, 38), (False, 0)]
)
def test_router_uses_integrated_versioned_quota_evaluator_without_callers_injecting_one(
    tmp_path, monkeypatch, mode, known, remaining
):
    monkeypatch.setattr(fa.time, "time", lambda: 150)
    store = state.StateStore(tmp_path)
    cap = dict(
        provider="openrouter",
        model="fixture/model",
        tools="supported",
        context_window=32000,
        cost_tier="free",
        metadata_source="controlled-test-fixture",
        retrieved_at=100,
        expires_at=220,
    )
    store.persist_discovered_model(
        dict(provider="openrouter", model="fixture/model", metadata=cap)
    )
    scope = "openrouter:" + context().connection_id
    evidence = fa.normalize_openrouter_quota(
        {
            "data": {
                "free_model_daily_requests": dict(
                    limit=50, remaining=remaining, used=50 - remaining
                )
            }
        },
        fa.canonical_scope(scope),
        150,
    )
    snap = fa.FreeAccessSnapshot(
        "openrouter",
        fa.canonical_scope(scope),
        quota_evidence=evidence,
        state="healthy" if remaining else "exhausted",
    ).to_dict()
    fa._save(store, snap)
    values = dict(
        store=store,
        providers=["openrouter"],
        selection_context=ACTIVE if known else None,
        connection_contexts={"openrouter": context()},
        credential_scopes={"openrouter": scope},
    )
    r = router.Router(values)
    policy = request()
    policy["quota_policy"] = mode
    expected = (
        mode in ("avoid_verified_exhaustion", "prefer_available_allowance")
        if not known
        else remaining > 0 and mode != "require_no_charge_guarantee"
    )
    result = r.preview(now=150, selection_policy=policy)
    assert bool(result["chosen"]) == expected
    assert not result["execution_authority"]
    if not known:
        assert result["considered"][0]["quota_policy_evidence"]["state"] == "unknown"
    # Missing evaluator is still an explicit denial for strict fresh-account policy.
    if mode == "require_fresh_account_allowance":
        values["quota_policy_evaluator"] = None
        assert (
            router.Router(values).preview(now=150, selection_policy=policy)["chosen"]
            is None
        )
