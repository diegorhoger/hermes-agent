"""Structured source-evidence integrity: no blind substitution may damage URLs.

The pinned candidate registry is observed source data, not prose. Any edit of
it must preserve URLs byte-for-byte (or be a deliberate, reviewed re-pin).
"""
import csv
import hashlib
import io
import json
import re
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
CSV = ROOT / 'data/provider_registry/source-2026-11.csv'
JSON_SNAP = ROOT / 'data/provider_registry/registry-v1.json'
SOURCE = ROOT / 'autorouter_core' / 'discovery' / 'provider_registry.py'

PATTERN = re.compile(r'^https?://[^\s"\',\\]+$')


def rows():
    with CSV.open(newline='', encoding='utf-8') as handle:
        yield from csv.DictReader(handle)


def test_source_sha256_pins_the_example_case():
    assert hashlib.sha256(CSV.read_bytes()).hexdigest() == SOURCE.read_text().split("SOURCE_SHA256 = '")[1].split("'")[0]
    assert 'utm_source=omniroute' in CSV.read_text()


def test_cheaperinference_url_is_exact():
    row = next(r for r in rows() if r['provider_id'] == 'cheaperinference')
    assert row['urls'] == 'https://cheaperinference.com/?utm_source=omniroute'


def test_urls_column_contains_no_neutral_wording():
    for row in rows():
        assert 'the reference integration' not in row['urls']


def test_urls_column_are_parseable_http_urls():
    failures = []
    for row in rows():
        for part in (row['urls'] or '').split(';'):
            part = part.strip().rstrip('.),')
            if not part:
                continue
            try:
                parsed = urlsplit(part)
            except ValueError:
                failures.append((row['provider_id'], part))
                continue
            if parsed.scheme not in ('https', 'http') or not parsed.hostname:
                failures.append((row['provider_id'], part))
                continue
            if '.' not in parsed.hostname and ':' not in parsed.hostname:
                failures.append((row['provider_id'], part))
    assert not failures


def test_snapshot_matches_rebuild():
    spec_text = SOURCE.read_text()
    source_sha = spec_text.split("SOURCE_SHA256 = '")[1].split("'")[0]
    assert source_sha == hashlib.sha256(CSV.read_bytes()).hexdigest()
    spec = __import__('importlib.util').util.spec_from_file_location('pr', __import__('pathlib').Path(SOURCE))
    pr = __import__('importlib.util').util.module_from_spec(spec)
    spec.loader.exec_module(pr)
    rebuilt = pr.serialize(pr.build(CSV.read_text(encoding='utf-8')))
    assert JSON_SNAP.read_text(encoding='utf-8') == rebuilt


def test_every_row_retains_expected_fields_and_count():
    out = list(rows())
    assert len(out) == 249
    assert [int(r['index']) for r in out] == list(range(249))
    assert len({r['provider_id'] for r in out if r['provider_id']}) == len({r['provider_id'] for r in out if r['provider_id']})
