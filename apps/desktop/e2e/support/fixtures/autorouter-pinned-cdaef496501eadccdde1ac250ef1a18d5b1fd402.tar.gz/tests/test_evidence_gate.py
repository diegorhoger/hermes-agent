import json
import time
import pytest
from autorouter.autorouter_core.discovery import metadata, discovery
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.storage import state
from tests.verified_fixture import seed_verified_model


def setup(tmp_path):
    store = state.StateStore(tmp_path)
    store.upsert_catalog('p', 'm', 32768, {'tools': True}, 'free')
    return store, router.Router({'store': store})


@pytest.mark.parametrize('kind', ['missing', 'malformed', 'read_error', 'legacy', 'expired', 'no_source'])
def test_proof_required(tmp_path, monkeypatch, kind):
    store, r = setup(tmp_path)
    cap = dict(provider='p', model='m', context_window=32768, tools='supported', cost_tier='free',
               retrieved_at=time.time()-10, expires_at=time.time()+100, metadata_source='fixture')
    if kind == 'legacy': cap.pop('expires_at')
    if kind == 'expired': cap['expires_at'] = 1
    if kind == 'no_source': cap.pop('metadata_source')
    if kind not in ('missing','read_error'):
        store.upsert_capability('p','m','bad-json' if kind == 'malformed' else json.dumps(cap))
    if kind == 'read_error':
        monkeypatch.setattr(store, 'get_capability', lambda *a: (_ for _ in ()).throw(OSError('read failed')))
    assert r.select(requires_tools=True) is None
    assert r.select_free_model() is None
    resolved = r._resolved_candidates()[0]
    assert resolved['cost_tier'] == 'unknown'
    assert resolved['context_length'] is None
    assert resolved['capabilities']['tools'] == 'unknown'


def test_atomic_failure_between_writes(tmp_path):
    store, r = setup(tmp_path)
    with store._connect() as db:
        db.execute("CREATE TRIGGER reject_cap BEFORE INSERT ON capabilities BEGIN SELECT RAISE(ABORT, 'injected'); END")
    with pytest.raises(Exception, match='injected'):
        store.persist_discovered_model(dict(provider='p', model='new', cost_tier='free', context_length=32768,
                                            capabilities={'tools': True}, metadata={}))
    assert not any(row['model'] == 'new' for row in store.get_catalog())
    assert r.select() is None


@pytest.mark.parametrize('pricing', [None, {}, {'prompt':'bad','completion':'0'}, {'prompt':'1','completion':'0'}])
def test_explicit_pricing_correction(tmp_path, pricing):
    store, r = setup(tmp_path)
    old = metadata.normalize_openrouter({'data':[dict(id='m', pricing={'prompt':'0','completion':'0'},
                      context_length=32768, supported_parameters=['tools'])]})['m']
    new = metadata.normalize_openrouter({'data':[dict(id='m', pricing=pricing)]})['m']
    merged = metadata.merge_metadata(new, old)
    assert merged['cost_tier'] != 'free'
    store.persist_discovered_model(dict(provider='openrouter',model='m',metadata=merged))
    assert r.select() is None


def test_omitted_and_unavailable_keep_original_expiry():
    old = metadata.normalize_openrouter({'data':[dict(id='m', pricing={'prompt':'0','completion':'0'})]}, 100)['m']
    for fresh in ({}, metadata.normalize_openrouter({'data':[{'id':'m'}]},200)['m']):
        merged = metadata.merge_metadata(fresh, old, 201)
        assert merged['cost_tier'] == 'free'
        assert merged['field_evidence']['cost_tier']['retrieved_at'] == 100
        assert metadata.merge_metadata({}, merged, 100000)['cost_tier'] == 'unknown'


def test_mixed_freshness_and_restrictions(tmp_path):
    store, r = setup(tmp_path)
    seed_verified_model(store,'p','m',32768,{'tools':True},'free')
    assert r.select(requires_tools=True)
    cap = json.loads(store.get_capability('p','m')['capability_json'])
    cap['field_evidence'] = {k: {x: cap[x] for x in ('metadata_source','retrieved_at','expires_at')}
                            for k in ('context_window','tools','cost_tier')}
    cap['field_evidence']['tools']['expires_at'] = 1
    store.upsert_capability('p','m',json.dumps(cap))
    resolved = r._resolved_candidates()[0]
    assert resolved['field_freshness']['tools'] == 'stale_or_unverified'
    assert resolved['metadata_freshness'] == 'incomplete_or_stale'
    assert r.select(requires_tools=True) is None
    assert r.select(requires_tools=False)
    for restriction in ('retired','auth_failed'):
        store.upsert_health('p','m', **{restriction:1})
        assert r.select() is None
        store.upsert_health('p','m', **{restriction:0})
