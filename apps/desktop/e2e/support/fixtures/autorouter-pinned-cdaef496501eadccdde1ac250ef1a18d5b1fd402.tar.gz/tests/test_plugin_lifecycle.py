"""Lifecycle contract for plugin register(): disabled registers nothing,
tunable, unreable config refuses, reload is coherent, stale markers clear.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import pytest


class RecordingCtx:
    """Minimal stand-in for the Hermes plugin context."""

    def __init__(self, config=None, fail_keys=(), middleware_kind=None):
        self.config = config or {}
        self.fail_keys = set(fail_keys)
        self.middleware_kind = middleware_kind
        self.hooks, self.tools, self.middleware = [], [], {}

    def get_config(self, key, default=None):
        if key in self.fail_keys:
            raise RuntimeError(f"config key {key} unreadable")
        if key == "plugins":  # not used, but tolerate
            return default
        return self.config.get(key, default)

    def register_hook(self, name, cb):
        self.hooks.append((name, cb))

    def register_tool(self, **kwargs):
        self.tools.append(kwargs)

    def register_middleware(self, kind, callback):
        if self.middleware_kind is not None and kind != self.middleware_kind:
            # registration_failure testing: raise for the factionunder test
            raise RuntimeError("middleware registry refused the callback")
        self.middleware[kind] = callback


def _write_marker(path):
    p = Path(path) / "native-routing-state.json"
    return json.loads(p.read_text()) if p.is_file() else None


_HOST_UNSET = {
    "enabled": True,
    "enable_chat_router": True,
    "enable_native_routing": False,
}


def test_register_plugin_missing_enabled_registers_nothing(tmp_path):
    import autorouter

    ctx = RecordingCtx({"state_dir": str(tmp_path)})
    autorouter.register(ctx)
    assert ctx.hooks == [] and ctx.tools == [] and ctx.middleware == {}
    marker = _write_marker(tmp_path)
    assert marker is not None and marker["selection_mode"] == "disabled"
    assert marker["chat_router"] is False and marker["native_routing_registered"] is False


@pytest.mark.parametrize("flag", [False, 0, "false", "", None])
def test_register_plugin_disabled_registers_nothing_before_routing_registration(tmp_path, flag):
    import autorouter

    ctx = RecordingCtx({
        "enabled": flag,
        "enable_chat_router": True,
        "enable_native_routing": True,
        "state_dir": str(tmp_path),
    })
    # Chat and native routers are BOTH requested — yet the primary disable
    # must block ALL routing registration, not merely off the picker row.
    autorouter.register(ctx)
    assert ctx.middleware == {}
    assert ctx.hooks == [] and ctx.tools == []
    marker = _write_marker(tmp_path)
    assert marker is not None and marker["selection_mode"] == "disabled"
    assert marker["chat_router"] is False and marker["native_routing_registered"] is False


@pytest.mark.parametrize("flag", ["true", "True", 1, "yes", ["true"]])
def test_register_plugin_non_strict_enabled_registers_nothing(tmp_path, flag):
    import autorouter

    ctx = RecordingCtx({
        "enabled": flag,
        "enable_chat_router": True,
        "enable_native_routing": True,
        "state_dir": str(tmp_path),
    })
    autorouter.register(ctx)
    assert ctx.middleware == {}
    marker = _write_marker(tmp_path)
    assert marker is not None and marker["selection_mode"] == "disabled"


def test_register_unreadable_config_fails_closed(tmp_path):
    """Config store unreadable: the plugin cannot publish ANY marker it trusts,
    so it must register NOTHING — no middleware, hooks, tools, or claims."""
    import autorouter

    ctx = RecordingCtx({"state_dir": str(tmp_path)}, fail_keys={"enabled", "enable_chat_router", "enable_native_routing"})
    autorouter.register(ctx)
    assert ctx.middleware == {}
    assert ctx.hooks == [] and ctx.tools == []
    # No activation marker is published: the dashboard keeps its default "inactive".
    assert _write_marker(tmp_path) is None


def test_enabled_chat_router_alone_registers_one_consumer(tmp_path, monkeypatch):
    import autorouter
    from autorouter.autorouter_core.integration import native_routing

    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    monkeypatch.setattr(native_routing, "_read_settings_from_config", lambda: dict(_HOST_UNSET))
    ctx = RecordingCtx({
        "enabled": True,
        "enable_chat_router": True,
        "enable_native_routing": False,
        "state_dir": str(tmp_path),
    })
    autorouter.register(ctx)
    assert list(ctx.middleware) == ["pre_inference_route"]
    marker = _write_marker(tmp_path)
    assert marker is not None and marker["selection_mode"] == "native"
    assert marker["chat_router"] is True and marker["native_routing_registered"] is True


def test_enabled_native_routing_alone_registers_one_consumer(tmp_path, monkeypatch):
    import autorouter
    from autorouter.autorouter_core.integration import native_routing

    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    settings = {"enabled": True, "enable_chat_router": False, "enable_native_routing": True}
    monkeypatch.setattr(native_routing, "_read_settings_from_config", lambda: dict(settings))
    ctx = RecordingCtx({
        "enabled": True,
        "enable_chat_router": False,
        "enable_native_routing": True,
        "state_dir": str(tmp_path),
    })
    autorouter.register(ctx)
    assert list(ctx.middleware) == ["pre_inference_route"]
    marker = _write_marker(tmp_path)
    assert marker is not None and marker["selection_mode"] == "native"
    assert marker["chat_router"] is False and marker["native_routing_registered"] is True


def test_both_flags_register_one_consumer(tmp_path, monkeypatch):
    import autorouter
    from autorouter.autorouter_core.integration import native_routing

    settings = {"enabled": True, "enable_chat_router": True, "enable_native_routing": True}
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    monkeypatch.setattr(native_routing, "_read_settings_from_config", lambda: dict(settings))
    ctx = RecordingCtx({
        "enabled": True,
        "enable_chat_router": True,
        "enable_native_routing": True,
        "state_dir": str(tmp_path),
    })
    autorouter.register(ctx)
    assert list(ctx.middleware) == ["pre_inference_route"]
    marker = _write_marker(tmp_path)
    assert marker is not None and marker["selection_mode"] == "native"


def test_middleware_registration_refused_writes_unavailable_marker(tmp_path, monkeypatch, caplog):
    """A host that exposes the seam but refuses the registration must write
    ``unavailable`` — never a stale ``native`` — and consume nothing."""
    import autorouter
    from autorouter.autorouter_core.integration import native_routing, chat_router_adapter

    settings = {"enabled": True, "enable_chat_router": True, "enable_native_routing": True}
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    monkeypatch.setattr(native_routing, "_read_settings_from_config", lambda: dict(settings))
    monkeypatch.setattr(chat_router_adapter.ChatRouterAdapter, "enable",
                        lambda self: (_ for _ in ()).throw(AssertionError("no legacy adapter")))

    ctx = RecordingCtx({
        "enabled": True,
        "enable_chat_router": True,
        "enable_native_routing": True,
        "state_dir": str(tmp_path),
    }, middleware_kind="")  # refuse any middleware registration
    with caplog.at_level(logging.WARNING):
        autorouter.register(ctx)

    assert ctx.middleware == {}
    assert "pre_inference_route" not in ctx.middleware
    marker = _write_marker(tmp_path)
    assert marker is not None and marker["selection_mode"] == "unavailable"
    assert marker["native_routing_registered"] is False


def test_reload_after_disable_clears_stale_marker_and_middleware(tmp_path, monkeypatch):
    """Cycle: enable -> reload -> disable -> reload. After disable, nothing
    remains registered and the marker claims ``disabled``, never ``native``."""
    import autorouter
    from autorouter.autorouter_core.integration import native_routing

    settings = {"enabled": True, "enable_chat_router": True, "enable_native_routing": True}
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    monkeypatch.setattr(native_routing, "_read_settings_from_config", lambda: dict(settings))

    enabled_missing = {
        "state_dir": str(tmp_path),
        # no enabled key: missing
    }
    ctx_missing = RecordingCtx(enabled_missing)
    ctx_missing.middleware.pop("pre_inference_route", None)
    autorouter.register(ctx_missing)
    assert ctx_missing.middleware == {}
    assert _write_marker(tmp_path)["selection_mode"] == "disabled"

    # Now enable and reload — the plugin is re-imported each test; here we
    # simulate reload on the same RecordingCtx whose config mutated.
    ctx_missing.config = {
        "enabled": True,
        "enable_chat_router": True,
        "enable_native_routing": True,
        "state_dir": str(tmp_path),
    }
    settings["enable_chat_router"] = True
    settings["enable_native_routing"] = True
    autorouter.register(ctx_missing)
    assert "pre_inference_route" in ctx_missing.middleware
    assert _write_marker(tmp_path)["selection_mode"] == "native"

    # Disable and reload again. The host loader disposes ALL registrations
    # on plugin disable — the simulate-unload contract drops them too.
    ctx_disabled = RecordingCtx({
        "enabled": False,
        "enable_chat_router": True,
        "enable_native_routing": True,
        "state_dir": str(tmp_path),
    })
    autorouter.register(ctx_disabled)
    assert ctx_disabled.middleware == {}
    assert ctx_disabled.hooks == [] and ctx_disabled.tools == []
    assert _write_marker(tmp_path)["selection_mode"] == "disabled"

    # Foreign consumer attack: a host where some other plugin already owns a
    # pre_inference_route consumer is NOT the same as ours being registered;
    # marker must still refuse to claim MODE A activation. Authorization is not
    # borrowed from a foreign callback.
    authorized_settings = {
        "enabled": True,
        "enable_chat_router": True,
        "enable_native_routing": True,
        "state_dir": str(tmp_path),
    }
    ctx_foreign = RecordingCtx(authorized_settings)
    ctx_foreign.middleware["pre_inference_route"] = lambda **kwargs: {"status": "route", "provider": "nvidia", "model": "nvidia/x"}


def test_disabled_marker_roundtrips_into_dashboard_inactive(tmp_path, monkeypatch):
    import autorouter
    from autorouter.autorouter_core.integration import native_routing
    from autorouter.dashboard import state_reader as sr

    settings = {"enabled": True, "enable_chat_router": True, "enable_native_routing": True}
    monkeypatch.setattr(native_routing, "detect_host_native_routing",
                        lambda: {"supported": True, "signals": [], "host_version": "test", "reason": None})
    monkeypatch.setattr(native_routing, "_read_settings_from_config", lambda: dict(settings))
    state_dir = tmp_path / "state"
    state_dir.mkdir()
    ctx = RecordingCtx({
        "enabled": True,
        "enable_chat_router": True,
        "enable_native_routing": True,
        "state_dir": str(state_dir),
    })
    autorouter.register(ctx)

    full = {"enabled": True, "policy": "auto", "free_only": True,
            "providers": ["nvidia"], "cooldown_seconds": 60,
            "state_dir": str(state_dir), "paid_authorized": False,
            "enable_chat_router": True, "min_context": 8192,
            "requires_tools": False, "model_include": [], "model_exclude": []}
    monkeypatch.setattr(sr, "read_plugin_config", lambda: {
        "values": dict(full), "available": True, "reason": None, "managed": False,
    })
    # Native marker + enabled configuration together → active report.
    assert sr.assemble_overview()["routing"]["chat_routing_state"] in {"active", "native"}

    # Stale marker test: marker says "native" but the operator disabled the
    # plugin — no reload, no marker rewrite — the dashboard must STILL report
    # inactive; a stale claim is never upgraded into present state.
    monkeypatch.setattr(sr, "read_plugin_config", lambda: {
        "values": {"enabled": False, "enable_chat_router": True,
                   "enable_native_routing": True, "policy": "auto",
                   "free_only": True, "providers": ["nvidia"],
                   "state_dir": str(state_dir), "paid_authorized": False,
                   "min_context": 8192, "requires_tools": False,
                   "model_include": [], "model_exclude": [], "cooldown_seconds": 60},
        "available": True, "reason": None, "managed": False,
    })
    assert sr.assemble_overview()["routing"]["chat_routing_state"] == "inactive"

    # Restore the enabled config for the post-disable-reload portion.
    monkeypatch.setattr(sr, "read_plugin_config", lambda: {
        "values": dict(full), "available": True, "reason": None, "managed": False,
    })

    # Disable; reload the plugin marker to disabled; dashboard shows inactive.
    ctx_disable = RecordingCtx({
        "enabled": False,
        "enable_chat_router": True,
        "enable_native_routing": True,
        "state_dir": str(state_dir),
    })
    autorouter.register(ctx_disable)
    monkeypatch.setattr(sr, "read_plugin_config", lambda: {
        "values": {"enabled": False, "enable_chat_router": True, "enable_native_routing": True,
                   "policy": "auto", "free_only": True, "providers": ["nvidia"],
                   "state_dir": str(state_dir), "paid_authorized": False,
                   "min_context": 8192, "requires_tools": False,
                   "model_include": [], "model_exclude": [], "cooldown_seconds": 60},
        "available": True, "reason": None, "managed": False,
    })
    assert sr.assemble_overview()["routing"]["chat_routing_state"] == "inactive"
