import importlib.util
import sys
from pathlib import Path

import pytest

PACKAGE = "autorouter"
_ROOT = Path(__file__).resolve().parents[1]


class RecordingCtx:
    def __init__(self, config=None):
        self.config = config or {}
        self.hooks = []
        self.tools = []

    def get_config(self, key, default=None):
        return self.config.get(key, default)

    def register_hook(self, name, cb):
        self.hooks.append((name, cb))

    def register_tool(self, **kwargs):
        self.tools.append(kwargs)


def test_register_registers_hooks_and_tools(monkeypatch):
    import autorouter
    ctx = RecordingCtx({"enabled": True, "providers": ["nvidia"]})
    # patch discovery to avoid network
    import autorouter.autorouter_core.discovery.discovery as dc
    monkeypatch.setattr(dc, "discover_all", lambda providers, store=None: {})
    autorouter.register(ctx)
    hook_names = [h[0] for h in ctx.hooks]
    # Only observer hooks are registered; automatic fallback hooks are not
    # registered because Hermes does not supply commitment state to plugins.
    assert "transform_api_error_classification" not in hook_names
    assert "api_request_error" in hook_names
    assert "pre_api_request" in hook_names
    assert "post_api_request" in hook_names
    tool_names = [t["name"] for t in ctx.tools]
    assert "autorouter_status" in tool_names
    assert "autorouter_refresh" in tool_names
    assert "autorouter_select" in tool_names


def test_register_disabled_does_not_register(monkeypatch):
    import autorouter
    ctx = RecordingCtx({"enabled": False})
    autorouter.register(ctx)
    assert ctx.hooks == []
    assert ctx.tools == []


def test_register_disabled_by_default_when_no_config(monkeypatch):
    """Plugin defaults to disabled when 'enabled' config is absent."""
    import autorouter
    ctx = RecordingCtx({})  # no 'enabled' key -> defaults to False
    import autorouter.autorouter_core.discovery.discovery as dc
    monkeypatch.setattr(dc, "discover_all", lambda providers, store=None: {})
    autorouter.register(ctx)
    assert ctx.hooks == []
    assert ctx.tools == []


def test_register_fails_closed_on_config_error(monkeypatch):
    """Plugin fails closed (disabled) when config read raises."""
    import autorouter
    class BadCtx:
        def __init__(self):
            self.hooks = []
            self.tools = []
        def get_config(self, key, default=None):
            raise RuntimeError("config store unavailable")
        def register_hook(self, name, cb):
            self.hooks.append((name, cb))
        def register_tool(self, **kwargs):
            self.tools.append(kwargs)
    ctx = BadCtx()
    import autorouter.autorouter_core.discovery.discovery as dc
    monkeypatch.setattr(dc, "discover_all", lambda providers, store=None: {})
    autorouter.register(ctx)
    assert ctx.hooks == []
    assert ctx.tools == []
