"""Explicit verified evidence for selection fixtures (never used by bypass tests)."""
import json
import time


def seed_verified_model(store, provider, model, context_length=None, capabilities=None, cost_tier=None):
    store.upsert_catalog(provider, model, context_length, capabilities, cost_tier)
    tools = (capabilities or {}).get('tools', 'unknown')
    tools = 'supported' if tools is True else 'unsupported' if tools is False else tools
    now = time.time()
    cap = dict(provider=provider, model=model, context_window=context_length, tools=tools,
               cost_tier=cost_tier or 'unknown', metadata_source='controlled-test-fixture',
               retrieved_at=now, expires_at=now + 3600)
    store.upsert_capability(provider, model, json.dumps(cap), metadata_source=cap['metadata_source'],
                            retrieved_at=now, expires_at=now + 3600)
