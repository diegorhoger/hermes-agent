"""Manifest + frontend hygiene tests for the dashboard plugin.

These are static checks; behavioral coverage lives in
test_dashboard_state_reader.py and test_dashboard_api.py, and browser
interaction evidence lives in tests/browser/harness.html.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pytest

yaml = pytest.importorskip("yaml")

ROOT = Path(__file__).resolve().parents[1]
DASH = ROOT / "dashboard"


def test_manifest_parses_and_is_complete():
    manifest = json.loads((DASH / "manifest.json").read_text())
    for key in ("name", "label", "version", "tab", "entry"):
        assert manifest.get(key), f"manifest missing {key}"
    assert manifest["name"] == "autorouter"
    assert manifest["tab"]["path"] == "/autorouter"
    assert manifest["entry"] == "dist/index.js"
    assert manifest["css"] == "dist/style.css"
    assert manifest["api"] == "plugin_api.py"


def test_manifest_paths_exist_and_stay_inside_dashboard():
    manifest = json.loads((DASH / "manifest.json").read_text())
    for key in ("entry", "css", "api"):
        rel = manifest[key]
        assert ".." not in Path(rel).parts
        assert (DASH / rel).is_file(), f"{key} target missing: {rel}"


def test_bundle_registers_autorouter_and_has_five_tabs():
    src = (DASH / "dist" / "index.js").read_text()
    assert 'register(PLUGIN_NAME' in src or '"autorouter"' in src
    for label in ("Overview", "Providers", "Models", "Analytics", "Settings"):
        assert f'"{label}"' in src


def test_bundle_has_no_html_injection_sinks():
    src = (DASH / "dist" / "index.js").read_text()
    for sink in (".innerHTML", ".outerHTML", "insertAdjacentHTML",
                 "document.write", "eval(", "new Function"):
        assert sink not in src, f"forbidden sink {sink} in bundle"


def test_bundle_uses_text_content_for_untrusted_data():
    src = (DASH / "dist" / "index.js").read_text()
    assert "textContent" in src


def test_bundle_exposes_keyboard_tab_pattern():
    src = (DASH / "dist" / "index.js").read_text()
    for token in ('role: "tablist"', 'role: "tab"', 'role: "tabpanel"',
                  "ArrowLeft", "ArrowRight", "Home", "End", "aria-selected"):
        assert token in src


def test_stylesheet_has_focus_visible_and_reduced_motion():
    css = (DASH / "dist" / "style.css").read_text()
    assert ":focus-visible" in css
    assert "prefers-reduced-motion" in css


def test_plugin_api_has_no_server_or_network_code():
    src = (DASH / "plugin_api.py").read_text() + (DASH / "state_reader.py").read_text()
    for token in ("http.server", "uvicorn", "socket.socket", "0.0.0.0",
                  "requests.", "urllib.request", "fetch("):
        assert token not in src, f"unexpected network/server token: {token}"


def test_plugin_api_read_only_sqlite(monkeypatch, tmp_path):
    """All SQL issued by the reader is SELECT; the DB is opened read-only."""
    import importlib.util
    import sys

    srtest_path = ROOT / "tests" / "test_dashboard_state_reader.py"
    spec = importlib.util.spec_from_file_location("_test_srtest_mod", srtest_path)
    srtest = importlib.util.module_from_spec(spec)
    sys.modules["_test_srtest_mod"] = srtest
    spec.loader.exec_module(srtest)
    sr = srtest.sr

    # seed a real database
    store = srtest._seed_store(tmp_path / "state")
    srtest._seed(store)

    statements: list[str] = []

    class SpyConn:
        def __init__(self, real):
            self._real = real

        def execute(self, sql, params=()):
            statements.append(sql)
            return self._real.execute(sql, params)

        def create_aggregate(self, *args):
            return self._real.create_aggregate(*args)

        def close(self):
            self._real.close()

    real_ro_connect = sr._ro_connect
    monkeypatch.setattr(sr, "_ro_connect", lambda p: SpyConn(real_ro_connect(p)))
    monkeypatch.setattr(sr, "read_plugin_config", lambda: {
        "values": {
            "enabled": True, "policy": "auto", "free_only": True,
            "providers": ["nvidia", "openrouter"], "cooldown_seconds": 60,
            "state_dir": str(tmp_path / "state"), "paid_authorized": False,
        },
        "available": True, "reason": None, "managed": False,
    })

    sr.assemble_overview()
    sr.assemble_providers()
    sr.assemble_models()
    sr.assemble_analytics()

    assert statements, "expected SQL to be issued"
    for sql in statements:
        head = sql.lstrip().upper()
        assert head.startswith("SELECT"), f"non-SELECT SQL issued: {head[:80]}"

    # and the source opens the database read-only
    assert "mode=ro" in (DASH / "state_reader.py").read_text()


def test_no_secrets_in_shipped_files():
    pattern = re.compile(r"(sk-[A-Za-z0-9_-]{16,}|ghp_[A-Za-z0-9]{30,}|xox[baprs]-[A-Za-z0-9-]{10,})")
    text_suffixes = {".json", ".py", ".js", ".css", ".html", ".md", ".yaml", ".txt"}
    checked = 0
    for path in DASH.rglob("*"):
        if path.is_file() and path.suffix in text_suffixes:
            checked += 1
            assert not pattern.search(path.read_text()), f"secret-like token in {path}"
    assert checked >= 5


def test_version_consistency():
    plugin_yaml = yaml.safe_load((ROOT / "plugin.yaml").read_text())
    init_py = (ROOT / "__init__.py").read_text()
    manifest = json.loads((DASH / "manifest.json").read_text())
    m = re.search(r'PLUGIN_VERSION\s*=\s*"([^"]+)"', init_py)
    assert m, "PLUGIN_VERSION not found"
    assert plugin_yaml["version"] == manifest["version"] == m.group(1) == "0.2.0"


def test_paid_authorization_still_absent():
    """The deprecated paid_authorized flag must never become active."""
    manifest = json.loads((DASH / "manifest.json").read_text())
    assert "paid_authorized" not in json.dumps(manifest)
    plugin_yaml = yaml.safe_load((ROOT / "plugin.yaml").read_text())
    assert plugin_yaml["config_schema"]["paid_authorized"].get("deprecated") is True


def test_gitignore_still_ignores_state_but_not_dashboard():
    gitignore = (ROOT / ".gitignore").read_text()
    assert "state/" in gitignore
    assert "!dashboard/dist/" in gitignore
