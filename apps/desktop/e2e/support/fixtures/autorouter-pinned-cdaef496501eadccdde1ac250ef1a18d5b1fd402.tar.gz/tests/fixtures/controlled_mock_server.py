"""Controlled local provider mock for the AutoRouter real-chat proof.

Serves an OpenAI-compatible /v1/chat/completions endpoint on 127.0.0.1:PORT.

Every POST is recorded in a SANITIZED receipt: the request path, redacted
headers, and only the identifiers the agent committed (provider / model /
base_url) are stored. The raw request body — which may contain prompts,
credentials and sensitive headers — is deliberately NOT stored and never
printed. The only exception is a test-only correlation token the harness
embeds in the prompt (``ARREQ-<hex>``); the receipt stores just that token so
route, payload and response can be correlated end to end. No other prompt
content is ever stored or printed.

This is a LOCAL, ISOLATED test double. It never charges a real model and never
reads real credentials. It is only used to prove the sanctioned request path.
"""

from __future__ import annotations

import json
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

_recorded: list[dict] = []
_lock = threading.Lock()
_port = 0

# Test-only correlation token shape, e.g. ARREQ-0123456789ab.
CORRELATION_RE = re.compile(r"ARREQ-[0-9a-f]{12}")


class Handler(BaseHTTPRequestHandler):
    # Headers that may carry secrets or personal data; omitted from the receipt.
    _REDACT_HEADERS = frozenset({
        "authorization", "cookie", "set-cookie", "proxy-authorization",
        "x-api-key", "x-apikey", "x-api-secret", "x-webhook-secret",
        "x-forwarded-client-certificate",
    })

    def _redact(self, value: str) -> str:
        """Redact secrets/prompt content so the receipt is safe to log."""
        low = value.lower()
        if low.startswith(("bearer ", "basic ")) or "api_key" in low or "apikey" in low:
            return value[:12] + "…[REDACTED]"
        if len(value) <= 24:
            return value
        return value[:12] + "…" + value[-8:]

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0) or 0)
        raw = self.rfile.read(length) if length else b""
        request_at = time.time()
        corr = self._correlation_id(raw)
        with _lock:
            _recorded.append({
                "at": request_at,
                "path": self.path,
                "headers": {
                    k: self._redact(v) for k, v in self.headers.items()
                    if k.lower() not in self._REDACT_HEADERS
                },
                "raw_length": len(raw),
                "parsed": self._parse(raw, corr),
            })
        if self.path == "/healthz":
            self._ok({"status": "ok", "mock_local": "controlled"})
            return
        # Record-only endpoint visible after the request, so the harness can dump
        # exactly what the agent sent (redacted).
        if self.path == "/recorded":
            with _lock:
                snapshot = json.loads(json.dumps(list(_recorded)))
            self._json(200, {"recorded": snapshot, "count": len(snapshot)})
            return
        self._sse_completion(corr)
        return

    def do_GET(self):
        if self.path == "/healthz":
            self._json(200, {"status": "ok", "mock_local": "controlled"})
        elif self.path == "/recorded":
            with _lock:
                snapshot = json.loads(json.dumps(list(_recorded)))
            self._json(200, {"recorded": snapshot, "count": len(snapshot)})
        else:
            self._json(404, {"error": "not found"})

    def _correlation_id(self, raw: bytes):
        match = CORRELATION_RE.search(raw.decode("utf-8", errors="ignore"))
        return match.group(0) if match else None

    def _parse(self, raw: bytes, corr):
        """Return a SANITIZED record: identifiers the agent committed, never the
        body contents. The raw bytes are deliberately NOT stored and never
        printed; the only stored snippet is the test-only correlation token."""
        parsed: dict[str, Any] = {}
        try:
            data = json.loads(raw) if raw else {}
            if isinstance(data, dict):
                for key in ("provider", "model", "base_url"):
                    value = data.get(key)
                    if isinstance(value, str) and value:
                        parsed[key] = value
                messages = data.get("messages")
                if isinstance(messages, list):
                    parsed["messages_count"] = len(messages)
        except Exception:
            parsed = {"raw_not_json": True}
        if corr:
            parsed["correlation_id"] = corr
        return parsed

    _sanitize_payload = None  # intentionally removed: no payload preview is kept

    def _sse_completion(self, corr):
        # A valid OpenAI-style SSE completion the agent can consume and stop on.
        # The test-only correlation token is echoed so a caller can prove the
        # response belongs to the request that carried it.
        served = corr or "mock-local"
        body = json.dumps({
            "id": f"mock-local-{served}",
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": "mock-local/free-chat",
            "choices": [{
                "index": 0,
                "delta": {"role": "assistant", "content": f"mocked by controlled provider {served}"},
                "finish_reason": "stop",
            }],
        })
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.end_headers()
        self.wfile.write(("data: " + body + "\n\n").encode())
        self.wfile.write(b"data: [DONE]\n\n")

    def _ok(self, payload):
        self._json(200, payload)

    def _json(self, code, payload):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(payload).encode())

    def log_message(self, fmt, *args):  # silence stdout
        pass


def recorded_requests() -> list[dict]:
    """Thread-safe snapshot of the sanitized receipt."""
    with _lock:
        return [dict(entry) | {"parsed": dict(entry.get("parsed") or {})} for entry in _recorded]


def main(port: int = 0):
    global _port
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    _port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"[CONTROLLED_PROVIDER] mock local provider listening on http://127.0.0.1:{_port}/v1/chat/completions")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
