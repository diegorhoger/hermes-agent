/* Test harness: load the Desktop runtime plugin with stubbed host modules
 * (as the Desktop runtime loader would, minus the live app) and print the
 * registered contributions as JSON. Mirrors the loader's import allowlist:
 * @hermes/plugin-sdk and react* are the ONLY importable specifiers. */
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, cpSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import process from 'node:process'

const [pluginFile, outFile] = process.argv.slice(2)
if (!pluginFile || !outFile) {
  console.error('usage: node desktop_plugin.harness.mjs <plugin.js> <out.json>')
  process.exit(2)
}

const src = readFileSync(pluginFile, 'utf8')

// ---- Static checks mirroring the Desktop runtime door -------------------
const importSpecifiers = []
for (const match of src.matchAll(/(?:from|import)\s*\(?\s*['"]([^'"]+)['"]/g)) {
  importSpecifiers.push(match[1])
}
const allowed = new Set(['@hermes/plugin-sdk', 'react', 'react/jsx-runtime', 'react/jsx-dev-runtime'])
const unsupported = [...new Set(importSpecifiers.filter((s) => !allowed.has(s)))]

// ---- Stub host modules ---------------------------------------------------
const root = mkdtempSync(path.join(tmpdir(), 'autorouter-desktop-stub-'))
const sdkDir = path.join(root, 'node_modules', '@hermes', 'plugin-sdk')
const reactDir = path.join(root, 'node_modules', 'react')
mkdirSync(path.join(sdkDir), { recursive: true })
mkdirSync(path.join(reactDir, 'jsx-runtime'), { recursive: true })

const copies = [
  ['Badge', 'component'], ['Button', 'component'], ['Codicon', 'component'],
  ['EmptyState', 'component'], ['ErrorState', 'component'], ['Input', 'component'],
  ['SearchField', 'component'], ['SegmentedControl', 'component'],
  ['Tabs', 'component'], ['TabsList', 'component'], ['TabsTrigger', 'component'],
  ['Textarea', 'component'], ['ToggleRow', 'component'], ['ListRow', 'component'],
]
const sdkStub = `
export const ROUTES_AREA = 'routes'
export const SIDEBAR_NAV_AREA = 'sidebar.nav'
export const PALETTE_AREA = 'command_palette'
export const STATUSBAR_AREAS = { left: 'statusBar.left', right: 'statusBar.right' }
export const host = {
  navigate: (path) => { globalThis.__NAVIGATE__ = path },
  state: {},
}
export const cn = (...args) => args.flat(Infinity).filter(Boolean).join(' ')
${copies.map(([name]) => `export const ${name} = () => null`).join('\n')}
`
const reactStub = `
export const useState = (initial) => [typeof initial === 'function' ? initial() : initial, () => {}]
export const useEffect = () => {}
export const useMemo = (fn) => fn()
export const useRef = (value) => ({ current: value })
export const useCallback = (fn) => fn
`
const jsxStub = `
export const Fragment = Symbol.for('react.fragment')
export const jsx = (type, props) => ({ type, props })
export const jsxs = (type, props) => ({ type, props })
`
writeFileSync(path.join(sdkDir, 'index.mjs'), sdkStub)
writeFileSync(path.join(sdkDir, 'package.json'), JSON.stringify({ name: '@hermes/plugin-sdk', version: '0.0.0', type: 'module', main: 'index.mjs', exports: { '.': './index.mjs' } }))
writeFileSync(path.join(reactDir, 'index.mjs'), reactStub)
writeFileSync(path.join(reactDir, 'package.json'), JSON.stringify({ name: 'react', version: '0.0.0', type: 'module', main: 'index.mjs', exports: { '.': './index.mjs', './jsx-runtime': './jsx-runtime/index.mjs' } }))
writeFileSync(path.join(reactDir, 'jsx-runtime', 'index.mjs'), jsxStub)

const staged = path.join(root, 'plugin.mjs')
cpSync(pluginFile, staged)

let plugin = null
let loadError = null
try {
  const mod = await import(`file://${staged}`)
  plugin = mod.default
} catch (error) {
  loadError = error instanceof Error ? String(error.stack ?? error.message) : String(error)
}

// ---- Drive register() with a recording ctx -------------------------------
const contributions = []
const navigateCalls = []
globalThis.__NAVIGATE__ = undefined
if (plugin && typeof plugin.register === 'function') {
  const ctx = {
    source: `plugin:${plugin.id ?? 'unknown'}`,
    register: (c) => { contributions.push({ ...c, id: `${plugin.id}:${c.id}` }) },
    registerMany: (cs) => cs.map((c) => contributions.push({ ...c, id: `${plugin.id}:${c.id}` })),
    onDispose: () => {},
    onEvent: () => () => {},
    storage: { get: (_k, fallback) => fallback, set: () => {}, remove: () => {} },
    rest: async () => ({}),
    socket: () => () => {},
    runAction: () => ({ ok: true }),
    listActions: () => [],
    os: {},
    pet: {},
    files: {},
    i18n: { register: () => {}, t: (s) => s, onLocaleChange: () => {} },
    preview: {},
  }
  try {
    plugin.register(ctx)
  } catch (error) {
    loadError = loadError ?? (error instanceof Error ? String(error.stack ?? error.message) : String(error))
  }
  // Exercise the palette command's navigate side effect.
  const palette = contributions.find((c) => c.area === 'command_palette')
  if (palette && typeof palette?.data?.run === 'function') {
    palette.data.run()
  }
}
if (globalThis.__NAVIGATE__) {
  navigateCalls.push(globalThis.__NAVIGATE__)
}

const report = {
  unsupported_imports: unsupported,
  load_error: loadError,
  plugin_id: plugin?.id ?? null,
  plugin_name: plugin?.name ?? null,
  contributions: contributions.map((c) => ({
    id: c.id,
    area: c.area,
    title: c.title ?? null,
    order: c.order ?? null,
    data: c.data ?? null,
    has_render: typeof c.render === 'function',
  })),
  navigate_calls: navigateCalls,
}
writeFileSync(outFile, JSON.stringify(report, null, 2))
