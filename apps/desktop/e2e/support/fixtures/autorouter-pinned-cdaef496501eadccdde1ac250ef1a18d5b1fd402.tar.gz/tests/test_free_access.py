"""Synthetic official-shape account API fixtures; never live credentials/inference."""
import json
import pytest
from autorouter.autorouter_core.discovery import discovery
from autorouter.autorouter_core.evidence import free_access as fa
from autorouter.autorouter_core.health import health
from autorouter.autorouter_core.integration import tools
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.storage import state

NOW = 1000



def payload(remaining=38):
    return {'data':{'free_model_daily_requests':{'limit':50,'remaining':remaining,'used':50-remaining},
        'label':'SENTINEL_PRIVATE_CREDENTIAL','limit_remaining':0,'rate_limit':{'requests':20,'interval':'1m'}}}


@pytest.fixture
def configured(tmp_path,monkeypatch):
    import providers
    store = state.StateStore(tmp_path)
    r = router.Router({'store':store,'providers':['openrouter'],'credential_scopes':{'openrouter':'connection-a'}})
    monkeypatch.setattr(providers,'get_provider_profile',lambda name: object())
    monkeypatch.setattr(discovery,'_resolve_api_key',lambda *args:'SENTINEL_PRIVATE_CREDENTIAL')
    return r


def seed_snapshot(configured, remaining=38, now=NOW):
    scope = fa.canonical_scope('connection-a')
    evidence = fa.normalize_openrouter_quota(payload(remaining), scope, now)
    result = fa.FreeAccessSnapshot('openrouter', scope, quota_evidence=evidence,
        state='exhausted' if remaining == 0 else 'healthy', next_refresh_at=now+fa.MIN_REFRESH).to_dict()
    fa._save(configured.store, result)
    return result


def test_official_response_observation_account_isolation_and_no_secrets(configured):
    result = seed_snapshot(configured)
    scope = health.scope_id('connection-a')
    assert result['account_scope'] == scope
    assert result['quota_evidence'][0]['remaining'] == '38'
    assert result['hard_stop_guaranteed'] is False
    assert fa.evaluate(result,'openrouter','free-model','connection-a',NOW)['state'] == 'healthy'
    assert fa.evaluate(result,'openrouter','free-model','connection-b',NOW)['state'] == 'unknown'
    with configured.store._connect() as db:
        assert 'SENTINEL_PRIVATE_CREDENTIAL' not in '\n'.join(db.iterdump())
    assert configured.store.get_catalog() == []


def test_exhaustion_staleness_and_strict_guarantee(configured,monkeypatch):
    snapshot = seed_snapshot(configured, remaining=0)
    assert not fa.evaluate(snapshot,'openrouter','m','connection-a',NOW)['allowed']
    assert fa.evaluate(snapshot,'openrouter','m','connection-a',NOW+fa.TTL)['state'] == 'unknown'
    snapshot['hard_stop_guaranteed'] = True  # Unattributed boolean is not proof.
    assert not fa.evaluate(snapshot,'openrouter','m','connection-a',NOW,strict_no_charge=True)['allowed']
    assert fa.evaluate({},'p','m',None,NOW)['allowed']
    assert not fa.evaluate({},'p','m',None,NOW,strict_no_charge=True)['allowed']


@pytest.mark.parametrize('body',[None,{}, {'data':{}}, {'data':{'rate_limit':{'requests':20},'limit_remaining':100}},
    {'data':{'free_model_daily_requests':{'used':49,'limit':50,'remaining':20}}},
    {'data':{'free_model_daily_requests':{'used':2,'limit':50,'remaining':-1}}},
    {'data':{'free_model_daily_requests':{'used':2,'limit':50,'remaining':True}}}])
def test_missing_malformed_and_legacy_fields_are_unknown(body):
    assert fa.normalize_openrouter_quota(body,'scope',NOW) == []


def test_failed_observation_invalidates_without_renewing_evidence(configured):
    before = seed_snapshot(configured)
    fa.invalidate_cached(configured.store, 'openrouter', 'connection-a', 503)
    after = fa.read_snapshot(configured.store, 'openrouter', 'connection-a')
    assert after['state'] == 'unavailable'
    assert after['quota_evidence'] == before['quota_evidence']
    assert 'SENTINEL_PRIVATE_CREDENTIAL' not in json.dumps(after)


def test_cached_polling_and_absent_scope_never_read_credentials(configured,monkeypatch):
    monkeypatch.setattr(discovery,'_resolve_api_key',lambda *args:pytest.fail('quota credential read'))
    seed_snapshot(configured)
    first=fa.refresh(configured,now=NOW)
    for _ in range(20):
        assert fa.refresh(configured,now=NOW+1) == first
        fa.read_snapshot(configured.store,'openrouter','connection-a')
    configured.state['credential_scopes']={}
    monkeypatch.setattr(discovery,'_resolve_api_key',lambda *a:pytest.fail('absent scope credential read'))
    assert fa.refresh(configured,now=NOW+100)['providers'][0]['state']=='unknown'


def test_tool_quota_refresh_is_explicit_only(monkeypatch):
    class R:
        def refresh(self):return {'ok':True}
    runtime=tools._rt()
    monkeypatch.setattr(runtime,'get_router',lambda:R())
    monkeypatch.setattr(fa,'refresh',lambda r, **kwargs:{'called':True})
    assert tools._refresh_handler({}) == {'ok':True}
    assert tools._refresh_handler({'include_quota':True})['quota']=={'called':True}
    assert tools._refresh_handler({'include_quota':'true'}) == {'ok':True}


def test_observed_failure_invalidates_only_matching_scope_without_inventing_exhaustion(configured):
    before=seed_snapshot(configured)
    fa.invalidate_cached(configured.store,'openrouter','connection-b',401)
    assert fa.read_snapshot(configured.store,'openrouter','connection-a')==before
    fa.invalidate_cached(configured.store,'openrouter','connection-a',429)
    after=fa.read_snapshot(configured.store,'openrouter','connection-a')
    assert after['state']=='unavailable'
    assert after['quota_evidence']==before['quota_evidence']
    assert after['quota_evidence'][0]['remaining']=='38'


def test_corrupt_storage_degrades_without_network(configured,monkeypatch):
    configured.store.db_path.write_bytes(b'not a sqlite database')
    result=fa.refresh(configured,now=NOW)['providers'][0]
    assert result['state']=='unknown'


def test_cached_payload_cannot_echo_raw_error_body_or_fabricated_guarantee(configured):
    snapshot=seed_snapshot(configured)
    snapshot.update(next_refresh_at='SENTINEL_PRIVATE_CREDENTIAL',state='SENTINEL_PRIVATE_CREDENTIAL',error_category='SENTINEL_PRIVATE_CREDENTIAL',
        hard_stop_guaranteed=True,verified_no_charge_execution=True)
    snapshot['quota_evidence'][0].update(issuer='SENTINEL_PRIVATE_CREDENTIAL',
        currency='SENTINEL_PRIVATE_CREDENTIAL',training_policy='SENTINEL_PRIVATE_CREDENTIAL')
    fa._save(configured.store,snapshot)
    read=fa.read_snapshot(configured.store,'openrouter','connection-a')
    assert 'SENTINEL_PRIVATE_CREDENTIAL' not in json.dumps(read)
    assert not read['hard_stop_guaranteed'] and not read['verified_no_charge_execution']


@pytest.mark.parametrize('scope',[None,'','unknown','scope_unknown'])
def test_unknown_scope_markers_never_become_account_identity(scope):
    assert fa.canonical_scope(scope)==''


def test_counter_consistency_uses_exact_integer_math():
    big=10**30
    body={'data':{'free_model_daily_requests':{'limit':big,'remaining':big-1,'used':2}}}
    assert fa.normalize_openrouter_quota(body,'scope',NOW)==[]


def test_concurrent_connections_claim_one_persisted_refresh_lease(configured):
    from concurrent.futures import ThreadPoolExecutor
    scope=health.scope_id('connection-a')
    with ThreadPoolExecutor(max_workers=8) as pool:
        results=list(pool.map(lambda _:fa._reserve_refresh(configured.store,'openrouter',scope,NOW),range(16)))
    assert sum(claimed for _,claimed in results)==1
    assert all(snapshot['next_refresh_at']==NOW+fa.MIN_REFRESH for snapshot,_ in results)


def test_cached_source_identity_cannot_be_promoted_to_provider_observation(configured):
    snapshot=seed_snapshot(configured)
    snapshot['quota_evidence'][0]['source']='configured'
    fa._save(configured.store,snapshot)
    read=fa.read_snapshot(configured.store,'openrouter','connection-a')
    assert read['state']=='unknown'
    assert read['quota_evidence']==[dict(dimension='requests', window='day', state='unknown', source_supported=False)]


def test_daily_counter_evidence_expires_at_utc_midnight(configured,monkeypatch):
    midnight=86400*20000
    snapshot=seed_snapshot(configured, remaining=0, now=midnight-30)
    assert snapshot['quota_evidence'][0]['expires_at']==midnight
    assert fa.evaluate(snapshot,'openrouter','m','connection-a',midnight-1)['state']=='exhausted'
    assert fa.evaluate(snapshot,'openrouter','m','connection-a',midnight)['state']=='unknown'


def test_conflicting_snapshot_and_allowance_state_is_unknown(configured):
    snapshot=seed_snapshot(configured)
    snapshot['state']='exhausted'
    result=fa.evaluate(snapshot,'openrouter','m','connection-a',NOW)
    assert result['state']=='unknown'
    assert result['allowed']


def test_routing_preview_and_selection_use_cached_scoped_quota_only(configured,monkeypatch):
    import time
    from tests.verified_fixture import seed_verified_model
    seed_verified_model(configured.store,'openrouter','m',16000,{'tools':True},'free')
    now=time.time()
    seed_snapshot(configured, now=now)
    monkeypatch.setattr(discovery,'_resolve_api_key',lambda *args:pytest.fail('selection read credential'))
    before=configured.store.db_path.read_bytes()
    preview=configured.preview(now=now,requires_tools=True)
    assert configured.store.db_path.read_bytes()==before
    chosen=preview['chosen']
    assert chosen['model']=='m'
    assert chosen['free_access']['state']=='healthy'
    assert chosen['free_access']['advertised_zero_price'] is True
    assert chosen['free_access']['verified_no_charge_execution'] is False
    assert configured.select(requires_tools=True)['model']=='m'
    assert configured.preview(now=now,strict_no_charge=True)['chosen'] is None
    assert configured.select(strict_no_charge=True) is None
    record=fa.read_snapshot(configured.store,'openrouter','connection-a')
    record['state']='exhausted'
    record['quota_evidence'][0].update(remaining='0',state='exhausted')
    fa._save(configured.store,record)
    denied=configured.preview(now=now)['considered'][0]
    assert denied['reason_codes']==['verified_account_quota_exhausted']
    assert configured.select() is None
    other=router.Router(dict(configured.state,credential_scopes={'openrouter':'connection-b'}))
    assert other.select()['model']=='m'
    assert other.preview(now=now)['chosen']['free_access']['state']=='unknown'
    # Expired observed exhaustion is unknown; it cannot deny a new allowance window.
    assert configured.preview(now=now+fa.TTL)['chosen']['free_access']['state']=='unknown'


def test_observer_invalidates_cached_quota_only_for_explicit_scope(configured,monkeypatch):
    from autorouter.autorouter_core.integration import runtime
    before=seed_snapshot(configured)
    monkeypatch.setattr(runtime,'get_store',lambda:configured.store)
    monkeypatch.setattr(runtime,'get_router',lambda:configured)
    runtime.on_api_request_error(api_request_id='other',provider='openrouter',model='m',status_code=401,credential_scope='connection-b')
    assert fa.read_snapshot(configured.store,'openrouter','connection-a')==before
    runtime.on_api_request_error(api_request_id='bad',provider='openrouter',model='m',status_code=429,credential_scope='connection-a')
    after=fa.read_snapshot(configured.store,'openrouter','connection-a')
    assert after['state']=='unavailable'
    assert after['quota_evidence']==before['quota_evidence']


def test_preview_reads_quota_once_per_provider_scope(configured,monkeypatch):
    from tests.verified_fixture import seed_verified_model
    import time
    for model in ('a','b','c'):
        seed_verified_model(configured.store,'openrouter',model,16000,{'tools':True},'free')
    seed_snapshot(configured, now=time.time())
    calls=[]
    original=fa.read_snapshot
    def counted(*args):
        calls.append(args[1:])
        return original(*args)
    monkeypatch.setattr(fa,'read_snapshot',counted)
    assert configured.preview()['eligible_count']==3
    assert calls == [('openrouter', 'connection-a')]


@pytest.mark.parametrize('remaining', [0, 38])
def test_cached_refresh_expires_operational_state_without_rewriting_facts(configured, remaining):
    before = seed_snapshot(configured, remaining=remaining, now=NOW)
    after = fa.refresh(configured, now=NOW+fa.TTL)['providers'][0]
    assert after['state'] == 'unknown'
    assert after['quota_evidence'] == before['quota_evidence']
    assert fa.read_snapshot(configured.store, 'openrouter', 'connection-a') == before
