"""Regression evidence for the five PR #5 repair gates."""
import time
from concurrent.futures import ThreadPoolExecutor
import pytest
from autorouter.autorouter_core.integration import runtime
from autorouter.autorouter_core.storage import state
from autorouter.autorouter_core.telemetry import telemetry
from tests.test_dashboard_state_reader import sr, cfg, _seed_store


def counters_for(store):
    with store._connect() as conn:
        return dict(conn.execute('SELECT key,value FROM lifetime_counters').fetchall())


@pytest.mark.parametrize('range_value', ['24h','7d','30d','90d','all'])
def test_complete_range_and_high_offset(cfg, range_value):
    store = _seed_store(cfg)
    now = time.time()
    # More observations than the former cap, with older requests carrying distinct data.
    with store._connect() as conn:
        conn.executemany("INSERT INTO requests(api_request_id,provider,model,status,session_hash,started_at,created_at,input_tokens,output_tokens,latency_ms,error_category) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            [(str(i), 'p', 'm', 'error' if i % 2 else 'success', 'agent', now-10000+i, now, 2, 3, 40, 'Rate limit' if i % 2 else None) for i in range(5105)])
    out = sr.assemble_analytics(now=now, range=range_value, offset=5001, limit=20)
    assert out['summary']['total_requests'] == 5105
    assert out['summary']['input_tokens'] == 10210
    assert out['summary']['output_tokens'] == 15315
    assert out['summary']['latency']['samples'] == 5105
    assert out['by_provider'][0]['requests'] == 5105
    assert out['by_model'][0]['requests'] == 5105
    assert out['by_agent'][0]['requests'] == 5105
    assert out['by_error'][0]['count'] == 2552
    assert len(out['recent_requests']) == 20
    assert out['recent_total'] == 5105
    assert out['recent_requests'][0]['id'] == 104
    filtered = sr.assemble_analytics(now=now, range=range_value, provider='p', status='error', sort='oldest')
    assert filtered['summary']['total_requests'] == 2552
    assert filtered['recent_requests'][0]['id'] == 2
    assert sum(row['total'] for row in filtered['timeline']) == 2552


@pytest.mark.parametrize('first,second', [('success','error'), ('error','success'), ('canceled','success')])
def test_terminal_row_immutable(tmp_path, first, second):
    store = state.StateStore(tmp_path)
    request = store.begin_request(api_request_id='same')
    store.finish_request(request, status=first, input_tokens=10, output_tokens=20)
    before = store.get_request(request)
    store.finish_request(request, status=second, input_tokens=999, output_tokens=999)
    assert store.get_request(request) == before
    assert counters_for(store)['total_requests'] == 1


def test_concurrent_finalization(tmp_path):
    store = state.StateStore(tmp_path)
    request = store.begin_request(api_request_id='same')
    with ThreadPoolExecutor(max_workers=8) as workers:
        list(workers.map(lambda i: store.finish_request(request, status='success' if i % 2 else 'error', input_tokens=i), range(20)))
    row = store.get_request(request)
    counters = counters_for(store)
    assert counters['total_requests'] == 1
    assert counters['total_input_tokens'] == row['input_tokens']
    with store._connect() as conn:
        hourly = dict(conn.execute('SELECT * FROM request_hourly').fetchone())
    assert hourly['total_requests'] == 1
    assert hourly['success_count'] == (row['status'] == 'success')
    assert hourly['error_count'] == (row['status'] == 'error')


def test_percentiles_small_samples():
    for values in ([10], [10,20], [10,20,30,40]):
        assert telemetry.percentile(values, .95) == values[-1]
        assert sr._percentile(values, .95) == values[-1]
    assert telemetry.percentile([10,20,30,40], .5) == 20
    assert sr._percentile([10,20,30,40], .5) == 20


@pytest.fixture
def hooks(tmp_path, monkeypatch):
    store = state.StateStore(tmp_path)
    monkeypatch.setitem(runtime._STATE, 'store', store)
    monkeypatch.setitem(runtime._STATE, 'router', None)
    return store


def test_no_id_no_orphan_and_router_optional(hooks):
    runtime.on_pre_api_request(provider='p', model='m')
    runtime.on_post_api_request(provider='p', model='m', usage={'input_tokens': 2})
    with hooks._connect() as conn:
        rows = conn.execute('SELECT status FROM requests').fetchall()
    assert [row['status'] for row in rows] == ['success']
    assert '_request_ids' not in runtime._STATE


def test_same_id_retry_exhaustion_and_cleanup(hooks):
    runtime.on_pre_api_request(api_request_id='retry', provider='p')
    runtime.on_api_request_error(api_request_id='retry', retry_count=0, max_retries=2, retryable=True, status_code=429)
    request = runtime._request_id_for({'api_request_id':'retry'})
    assert hooks.get_request(request)['status'] == 'pending'
    runtime.on_pre_api_request(api_request_id='retry', retry_count=1)
    runtime.on_post_api_request(api_request_id='retry', retry_count=1)
    assert hooks.get_request(request)['status'] == 'success'
    runtime.on_api_request_error(api_request_id='retry', retry_count=2, max_retries=2, retryable=False)
    assert hooks.get_request(request)['status'] == 'success'
    assert len(hooks.get_request_attempts(request)) == 2
    runtime.on_pre_api_request(api_request_id='exhausted')
    runtime.on_api_request_error(api_request_id='exhausted', retry_count=2, max_retries=2, retryable=True)
    assert hooks.get_request(runtime._request_id_for({'api_request_id':'exhausted'}))['status'] == 'error'
    old = hooks.begin_request(api_request_id='abandoned', started_at=time.time()-7200)
    hooks.expire_pending_requests()
    assert hooks.get_request(old)['status'] == 'canceled'


def test_interleaved_ids_never_cross_associate(hooks):
    for identity in ('a','b'):
        runtime.on_pre_api_request(api_request_id=identity)
    runtime.on_post_api_request(api_request_id='b', usage={'input_tokens':20})
    runtime.on_api_request_error(api_request_id='a', retryable=False, status_code=500)
    assert hooks.get_request(runtime._request_id_for({'api_request_id':'a'}))['status'] == 'error'
    assert hooks.get_request(runtime._request_id_for({'api_request_id':'b'}))['status'] == 'success'


def test_missing_id_retry_error_does_not_leave_orphan(hooks):
    runtime.on_pre_api_request(provider='p')
    runtime.on_api_request_error(provider='p', retryable=True, status_code=429)
    with hooks._connect() as conn:
        assert [row[0] for row in conn.execute('SELECT status FROM requests')] == ['error']


def test_request_detail_contains_complete_attempt_history(cfg):
    store = _seed_store(cfg)
    request = store.begin_request(api_request_id='many-attempts')
    for ordinal in range(55):
        store.record_attempt(request, ordinal, status_code=429, retryable=True)
    store.finish_request(request, status='error')
    detail = sr.assemble_analytics(view='request', request_id=request)
    assert len(detail['attempts']) == 55
    assert detail['attempts'][-1]['ordinal'] == 54


def test_host_post_without_retry_count_keeps_all_attempts(hooks):
    runtime.on_pre_api_request(api_request_id='host-retry', api_call_count=1)
    for retry in range(3):
        runtime.on_api_request_error(api_request_id='host-retry', api_call_count=1,
                                    retry_count=retry, max_retries=5, retryable=True, status_code=429)
    runtime.on_post_api_request(api_request_id='host-retry', api_call_count=1)
    request = runtime._request_id_for({'api_request_id':'host-retry'})
    assert [a['ordinal'] for a in hooks.get_request_attempts(request)] == [0,1,2,3]
    assert hooks.get_request(request)['status'] == 'success'


def test_untrusted_error_bodies_and_identifiers_never_persist(cfg, monkeypatch):
    import json
    store = _seed_store(cfg)
    monkeypatch.setattr(runtime, "get_store", lambda: store)
    monkeypatch.setattr(runtime, "get_router", lambda: None)
    secret = "SENTINEL_PRIVATE_CREDENTIAL_DO_NOT_STORE"
    identity = "opaque-" + secret
    runtime.on_pre_api_request(api_request_id=identity, provider="nvidia", model="test",
        task_id=secret, turn_id=secret, platform="Bearer " + secret)
    runtime.on_api_request_error(api_request_id=identity, provider="nvidia", model="test",
        status_code=401, error={"message": "Credential " + secret + " rejected"}, reason=secret)
    store.record_credential_scope(provider="nvidia", key_scope=secret, reason=secret)
    request_id = runtime._request_id_for({"api_request_id": identity})
    assert request_id is not None
    assert store.get_request(request_id)["error_summary"] == "Auth Error (401)"
    assert store.get_request_attempts(request_id)[0]["reason"] == "Auth Error (401)"
    with store._connect() as conn:
        assert secret not in "\n".join(conn.iterdump())
    assert secret not in json.dumps(sr.assemble_analytics(range="all"))
    assert secret not in json.dumps(sr.assemble_analytics(view="request", request_id=request_id))


def test_analytics_scrubs_every_grouping_from_untrusted_database(cfg):
    import json
    store = _seed_store(cfg)
    secret = "sk-" + "x" * 48
    now = time.time()
    with store._connect() as conn:
        conn.execute("INSERT INTO requests(provider, model, session_hash, error_category, status, started_at, created_at) VALUES(?,?,?,?,?,?,?)",
            (secret, secret, secret, secret, "error", now-1, now-1))
    out = sr.assemble_analytics(now=now, range="all")
    assert out["by_provider"] and out["by_model"] and out["by_agent"] and out["by_error"]
    assert secret not in json.dumps(out)


def test_lifetime_usage_unknown_differs_from_observed_zero(cfg):
    store = _seed_store(cfg)
    request = store.begin_request(provider="p")
    store.finish_request(request)
    assert sr.assemble_analytics(range="all")["lifetime"]["total_input_tokens"] is None
    request = store.begin_request(provider="p")
    store.finish_request(request, input_tokens=0, output_tokens=0)
    assert sr.assemble_analytics(range="all")["lifetime"]["total_input_tokens"] == 0


def test_duplicate_terminal_callbacks_do_not_repeat_health(cfg, monkeypatch):
    from autorouter.autorouter_core.routing.router import Router
    store = _seed_store(cfg)
    router = Router({"store": store})
    monkeypatch.setattr(runtime, "get_store", lambda: store)
    monkeypatch.setattr(runtime, "get_router", lambda: router)
    payload = dict(api_request_id="same-terminal", provider="p", model="m", retry_count=0)
    runtime.on_pre_api_request(**payload)
    runtime.on_post_api_request(**payload)
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(lambda _: runtime.on_post_api_request(**payload), range(8)))
    runtime.on_api_request_error(**payload, status_code=401)
    row = store.get_health("p", "m")
    assert row["successes"] == 1
    assert row["failures"] == 0
    assert row["auth_failed"] == 0


def test_duplicate_retry_ordinal_does_not_repeat_health(cfg, monkeypatch):
    from autorouter.autorouter_core.routing.router import Router
    store = _seed_store(cfg)
    router = Router({"store": store})
    monkeypatch.setattr(runtime, "get_store", lambda: store)
    monkeypatch.setattr(runtime, "get_router", lambda: router)
    payload = dict(api_request_id="same-retry", provider="p", model="m", retry_count=0)
    runtime.on_pre_api_request(**payload)
    for _ in range(2):
        runtime.on_api_request_error(**payload, status_code=500, retryable=True, max_retries=2)
    runtime.on_post_api_request(api_request_id="same-retry", provider="p", model="m", retry_count=1)
    row = store.get_health("p", "m")
    assert row["successes"] == 1
    assert row["failures"] == 1
