from autorouter.autorouter_core.eligibility import eligibility as el


def test_tool_capable_unknown_conservative():
    # Unknown tool support requires evidence, including previously allowlisted IDs.
    assert el.is_tool_capable("nvidia", "llama-3.1-nemotron-70b-instruct", {"tools": "unknown"}) is False
    assert el.is_tool_capable("foo", "bar-model", {"tools": "unknown"}) is False or True  # heuristic may vary
    assert el.is_tool_capable("x", "m", {"tools": False}) is False


def test_context_sufficient():
    assert el.has_sufficient_context(16000, 8192) is True
    assert el.has_sufficient_context(4096, 8192) is False
    assert el.has_sufficient_context(None, 8192) is False


def test_cost_allowed():
    # Fail-closed rules: free is the only allowed tier
    # Free model: eligible regardless of flags
    assert el.cost_allowed("free", True, False) is True
    assert el.cost_allowed("free", True, True) is True
    assert el.cost_allowed("free", False, False) is True
    assert el.cost_allowed("free", False, True) is True

    # Paid model: denied regardless of flags
    assert el.cost_allowed("paid", True, False) is False
    assert el.cost_allowed("paid", True, True) is False
    assert el.cost_allowed("paid", False, False) is False
    assert el.cost_allowed("paid", False, True) is False

    # Premium model: denied regardless of flags
    assert el.cost_allowed("premium", True, False) is False
    assert el.cost_allowed("premium", True, True) is False
    assert el.cost_allowed("premium", False, False) is False
    assert el.cost_allowed("premium", False, True) is False

    # Unknown cost: denied regardless of flags
    assert el.cost_allowed("unknown", True, False) is False
    assert el.cost_allowed("unknown", True, True) is False
    assert el.cost_allowed("unknown", False, False) is False
    assert el.cost_allowed("unknown", False, True) is False

    # Missing cost metadata (None): denied
    assert el.cost_allowed(None, True, False) is False
    assert el.cost_allowed(None, True, True) is False
    assert el.cost_allowed(None, False, False) is False
    assert el.cost_allowed(None, False, True) is False


def test_is_eligible_requires_tools():
    cand = {"provider": "nvidia", "model": "llama-3.1-nemotron-70b-instruct", "context_length": 16000,
            "capabilities": {"tools": True}, "cost_tier": "free"}
    assert el.is_eligible(cand, requires_tools=True, min_context=8192, free_only=True, paid_authorized=False) is True
    # text-only model excluded
    cand2 = {"provider": "nvidia", "model": "text-only", "context_length": 16000,
             "capabilities": {"tools": False}, "cost_tier": "free"}
    assert el.is_eligible(cand2, requires_tools=True, min_context=8192, free_only=True, paid_authorized=False) is False
    # paid-only under free policy excluded
    cand3 = {"provider": "openrouter", "model": "paid-model", "context_length": 16000,
             "capabilities": {"tools": True}, "cost_tier": "paid"}
    assert el.is_eligible(cand3, requires_tools=True, min_context=8192, free_only=True, paid_authorized=False) is False
    # paid model excluded even with paid_authorized=True (fail-closed)
    cand4 = {"provider": "openrouter", "model": "paid-model", "context_length": 16000,
             "capabilities": {"tools": True}, "cost_tier": "paid"}
    assert el.is_eligible(cand4, requires_tools=True, min_context=8192, free_only=False, paid_authorized=True) is False
    # unknown-cost model excluded
    cand5 = {"provider": "nvidia", "model": "unknown-cost", "context_length": 16000,
             "capabilities": {"tools": True}, "cost_tier": "unknown"}
    assert el.is_eligible(cand5, requires_tools=True, min_context=8192, free_only=True, paid_authorized=False) is False
    # missing cost metadata excluded
    cand6 = {"provider": "nvidia", "model": "missing-cost", "context_length": 16000,
             "capabilities": {"tools": True}}
    assert el.is_eligible(cand6, requires_tools=True, min_context=8192, free_only=True, paid_authorized=False) is False
