"""HTTP-layer tests for the dashboard plugin backend (dashboard/plugin_api.py).

Skipped automatically when FastAPI/httpx are not installed; run with:
    uv run --with fastapi --with httpx python -m pytest tests/test_dashboard_api.py
"""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pytest

from autorouter.autorouter_core.providers import registry as _registry


@pytest.fixture(autouse=True)
def _pin_offline_host_registry(monkeypatch):
    """Routing profiles fail closed on a host that recognizes nothing."""
    monkeypatch.setenv("AUTOROUTER_REGISTRY_OFFLINE", "1")


fastapi = pytest.importorskip("fastapi")
httpx = pytest.importorskip("httpx")

from fastapi import FastAPI
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
PLUGIN_API = ROOT / "dashboard" / "plugin_api.py"


def _load_plugin_api():
    name = "_test_autorouter_api"
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, PLUGIN_API)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture()
def state_dir(monkeypatch, tmp_path):
    sd = tmp_path / "state"
    values = {
        "enabled": True,
        "policy": "auto",
        "free_only": True,
        "providers": ["nvidia", "openrouter"],
        "cooldown_seconds": 60,
        "state_dir": str(sd),
        "paid_authorized": False,
    }
    _load_plugin_api()  # ensures the shared state_reader module is registered
    sr_name = "_autorouter_dashboard_state_reader"
    sr = sys.modules.get(sr_name)
    assert sr is not None
    monkeypatch.setattr(sr, "read_plugin_config", lambda: {
        "values": dict(values), "available": True, "reason": None, "managed": False,
    })
    return sd


@pytest.fixture()
def client(state_dir):
    plugin_api = _load_plugin_api()
    app = FastAPI()
    app.include_router(plugin_api.router, prefix="/api/plugins/autorouter")
    with TestClient(app) as c:
        yield c


class TestGetEndpoints:
    def test_overview_empty(self, client):
        r = client.get("/api/plugins/autorouter/overview")
        assert r.status_code == 200
        body = r.json()
        assert body["available"] is False  # db not initialized
        assert "plugin" in body

    def test_providers_empty(self, client):
        r = client.get("/api/plugins/autorouter/providers")
        assert r.status_code == 200
        assert [p["name"] for p in r.json()["providers"]] == ["nvidia", "openrouter"]

    def test_models_empty(self, client):
        r = client.get("/api/plugins/autorouter/models")
        assert r.status_code == 200
        assert r.json()["models"] == []

    def test_analytics_empty(self, client):
        r = client.get("/api/plugins/autorouter/analytics")
        assert r.status_code == 200
        assert r.json()["available"] is False

    def test_settings(self, client):
        r = client.get("/api/plugins/autorouter/settings")
        assert r.status_code == 200
        body = r.json()
        assert body["values"]["policy"] == "auto"
        assert body["values"]["paid_inference"] == "disabled"

    def test_seeded_endpoints(self, client, state_dir):
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        import autorouter_core.storage.state as state_mod
        store = state_mod.StateStore(state_dir)
        seed_verified_model(store, "nvidia", "free-good", context_length=100000,
                             capabilities={"tools": "supported"}, cost_tier="free")
        store.record_outcome("nvidia", "free-good", True, status_code=200)
        store.record_decision("auto", "nvidia", "free-good", "selected", 1)

        overview = client.get("/api/plugins/autorouter/overview").json()
        assert overview["available"] is True
        assert overview["counts"]["discovered_models"] == 1

        models = client.get("/api/plugins/autorouter/models").json()
        assert models["models"][0]["model"] == "free-good"
        assert models["models"][0]["eligible"] is True

        analytics = client.get("/api/plugins/autorouter/analytics").json()
        assert analytics["summary"]["total_requests"] == 0  # decisions are not inference requests


class TestSettingsWrite:
    def test_rejects_paid_authorized(self, client):
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"paid_authorized": True}})
        assert r.status_code == 400

    def test_rejects_enabled(self, client):
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"enabled": True}})
        assert r.status_code == 400

    def test_rejects_unknown_key(self, client):
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"nonsense": 1}})
        assert r.status_code == 400

    def test_rejects_bad_providers(self, client):
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"providers": ["BAD PROVIDER!"]}})
        assert r.status_code == 400

    def test_rejects_bad_policy(self, client):
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"policy": "yolo"}})
        assert r.status_code == 400

    def test_hermes_unavailable_returns_503(self, client, monkeypatch):
        """Sanctioned writer not importable in this env -> 503, never a raw 500."""
        plugin_api = _load_plugin_api()
        monkeypatch.setitem(sys.modules, "hermes_cli", None)
        monkeypatch.setitem(sys.modules, "hermes_cli.plugins_state", None)
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"policy": "smartest"}})
        assert r.status_code == 503

    def test_permission_error_returns_403(self, client, monkeypatch):
        plugin_api = _load_plugin_api()

        def _raise(*args, **kwargs):
            raise PermissionError("Plugin settings cannot be changed in a managed install")

        monkeypatch.setattr(plugin_api, "write_settings", _raise)
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"policy": "smartest"}})
        assert r.status_code == 403
        assert "managed install" in r.json()["detail"]

    def test_valid_update_calls_writer(self, client, monkeypatch):
        plugin_api = _load_plugin_api()
        captured = {}

        def _fake_write(updates):
            captured.update(updates)
            return {"ok": True, "applied": updates}

        monkeypatch.setattr(plugin_api, "write_settings", _fake_write)
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"policy": "coding", "providers": ["Nvidia"]}})
        assert r.status_code == 200
        assert captured == {"policy": "coding", "providers": ["nvidia"]}


class TestNoSecretLeakage:
    def test_overview_redacts_stored_secrets(self, client, state_dir):
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        import autorouter_core.storage.state as state_mod
        store = state_mod.StateStore(state_dir)
        seed_verified_model(store, "nvidia", "leaky", context_length=100000,
                             capabilities={"tools": "supported"}, cost_tier="free")
        store.record_outcome("nvidia", "leaky", False, status_code=500,
                             error_message="boom with sk-secretkey1234567890 inside")
        r = client.get("/api/plugins/autorouter/overview")
        assert "sk-secretkey1234567890" not in r.text
        assert "provider_error" in r.text


class TestPartialSave:
    """A multi-key settings write that fails partway must report the exact
    partial outcome (keys persisted / failed / never attempted), never claim
    the batch was atomic, and map to an accurate HTTP error."""

    @staticmethod
    def _install_fake_hermes(monkeypatch, calls, failing, exc_factory):
        import types

        plugins_state = types.ModuleType("hermes_cli.plugins_state")

        def save_plugin_setting(plugin_id, segments, value):
            calls.append((plugin_id, segments, value))
            if segments and segments[0] == failing:
                raise exc_factory()

        plugins_state.save_plugin_setting = save_plugin_setting
        hermes_cli = types.ModuleType("hermes_cli")
        hermes_cli.plugins_state = plugins_state
        monkeypatch.setitem(sys.modules, "hermes_cli", hermes_cli)
        monkeypatch.setitem(sys.modules, "hermes_cli.plugins_state", plugins_state)

    def test_partial_failure_returns_structured_detail_403(self, client, monkeypatch):
        calls = []
        self._install_fake_hermes(
            monkeypatch, calls, "cooldown_seconds",
            lambda: PermissionError("administrator-managed key: cooldown_seconds"),
        )
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"policy": "smartest",
                                         "cooldown_seconds": 30,
                                         "providers": ["nvidia"]}})
        assert r.status_code == 403
        detail = r.json()["detail"]
        assert detail["partial"] is True
        assert detail["saved"] == ["policy"]
        assert list(detail["failed"]) == ["cooldown_seconds"]
        assert "administrator-managed" in detail["failed"]["cooldown_seconds"]
        assert detail["remaining"] == ["providers"]
        assert "policy" in detail["message"] and "cooldown_seconds" in detail["message"]
        assert [c[1][0] for c in calls] == ["policy", "cooldown_seconds"]

    def test_partial_failure_returns_structured_detail_500(self, client, monkeypatch):
        calls = []
        self._install_fake_hermes(
            monkeypatch, calls, "free_only",
            lambda: ValueError("simulated mid-batch failure"),
        )
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"policy": "fastest",
                                         "free_only": True,
                                         "providers": ["openrouter"]}})
        assert r.status_code == 500
        detail = r.json()["detail"]
        assert detail["partial"] is True
        assert detail["saved"] == ["policy"]
        assert detail["remaining"] == ["providers"]

    def test_full_failure_first_key_reports_nothing_saved(self, client, monkeypatch):
        calls = []
        self._install_fake_hermes(
            monkeypatch, calls, "policy",
            lambda: ValueError("disk full"),
        )
        r = client.put("/api/plugins/autorouter/settings",
                       json={"updates": {"policy": "fastest", "cooldown_seconds": 30}})
        assert r.status_code == 500
        detail = r.json()["detail"]
        assert detail["saved"] == []
        assert detail["failed"] == {"policy": "disk full"}
        assert detail["remaining"] == ["cooldown_seconds"]
        assert [c[1][0] for c in calls] == ["policy"]

from tests.verified_fixture import seed_verified_model


class TestModelsRefresh:
    def test_models_refresh_returns_payload(self, client, monkeypatch):
        plugin_api = _load_plugin_api()
        monkeypatch.setattr(
            plugin_api, "refresh_catalog",
            lambda: {"available": True, "providers": ["nvidia"],
                     "refreshed": {"nvidia": 2}, "total_models": 2,
                     "generated_at": 1234567890.0})
        r = client.post("/api/plugins/autorouter/models/refresh", json={})
        assert r.status_code == 200
        body = r.json()
        assert body["total_models"] == 2
        assert body["refreshed"] == {"nvidia": 2}

    def test_models_refresh_unavailable_is_503(self, client, monkeypatch):
        plugin_api = _load_plugin_api()

        def boom():
            raise RuntimeError("discovery exploded")

        monkeypatch.setattr(plugin_api, "refresh_catalog", boom)
        r = client.post("/api/plugins/autorouter/models/refresh", json={})
        assert r.status_code == 503
        assert r.json()["detail"]["code"] == "refresh_unavailable"


class TestRoutingProfilesWithCatalog:
    def test_preview_selects_expected_model(self, state_dir, client):
        from autorouter.autorouter_core.storage import state as _state
        from .verified_fixture import seed_verified_model
        store = _state.StateStore(state_dir)
        seed_verified_model(store, 'nvidia', 'free-alpha', 16000, {'tools': True}, 'free')
        seed_verified_model(store, 'openrouter', 'free-beta', 16000, {'tools': True}, 'free')
        r = client.post("/api/plugins/autorouter/routing-profiles",
                        json={"name": "NVIDIA only", "providers": ["nvidia"], "ranking_policy": "reliable"})
        profile = r.json()["profile"]
        r = client.post(f"/api/plugins/autorouter/routing-profiles/{profile['id']}/preview")
        body = r.json()
        assert body["chosen"]["provider"] == "nvidia"
        assert body["eligible_count"] == 1
        assert all(row["provider"] == "nvidia" for row in body["eligible"])

    def test_preview_shows_exclusion_reasons(self, state_dir, client):
        from autorouter.autorouter_core.storage import state as _state
        from .verified_fixture import seed_verified_model
        store = _state.StateStore(state_dir)
        seed_verified_model(store, 'nvidia', 'free-alpha', 16000, {'tools': True}, 'free')
        seed_verified_model(store, 'nvidia', 'paid-gamma', 16000, {'tools': True}, 'paid')
        r = client.post("/api/plugins/autorouter/routing-profiles",
                        json={"name": "Tools", "providers": ["nvidia"], "requires_tools": True})
        profile = r.json()["profile"]
        r = client.post(f"/api/plugins/autorouter/routing-profiles/{profile['id']}/preview")
        body = r.json()
        assert body["chosen"]["model"] == "free-alpha"
        excluded = {row["model"]: row["reason_codes"] for row in body["excluded"]}
        assert "cost_not_verified_free" in excluded.get("paid-gamma", [])


class TestRoutingProfiles:
    def test_empty_list(self, client):
        r = client.get("/api/plugins/autorouter/routing-profiles")
        assert r.status_code == 200
        body = r.json()
        assert body["profiles"] == []
        assert body["active"] is None
        assert "ranking_policies" in body

    def test_create_get_update_delete(self, client):
        r = client.post("/api/plugins/autorouter/routing-profiles",
                        json={"name": "API profile", "ranking_policy": "coding",
                              "providers": ["nvidia"], "min_context": 16000,
                              "requires_tools": True, "model_include": ["nvidia/free-model"]})
        assert r.status_code == 201, r.text
        created = r.json()["profile"]
        assert created["id"].startswith("rp_") and created["requires_tools"] is True

        r = client.get(f"/api/plugins/autorouter/routing-profiles/{created['id']}")
        assert r.status_code == 200
        assert r.json()["profile"]["name"] == "API profile"
        assert r.json()["active"] is False

        r = client.put(f"/api/plugins/autorouter/routing-profiles/{created['id']}",
                       json={"min_context": 32000})
        assert r.status_code == 200
        assert r.json()["profile"]["min_context"] == 32000
        assert r.json()["profile"]["created_at"] == created["created_at"]

        r = client.delete(f"/api/plugins/autorouter/routing-profiles/{created['id']}")
        assert r.status_code == 200 and r.json()["deleted"] is True
        assert client.get(f"/api/plugins/autorouter/routing-profiles/{created['id']}").status_code == 404

    def test_create_validation_errors(self, client):
        r = client.post("/api/plugins/autorouter/routing-profiles",
                        json={"name": "x", "ranking_policy": "nonsense"})
        assert r.status_code == 400
        assert r.json()["detail"]["code"] == "profile_invalid"
        r = client.post("/api/plugins/autorouter/routing-profiles",
                        json={"name": "x", "providers": ["zai"]})
        assert r.status_code == 400
        r = client.post("/api/plugins/autorouter/routing-profiles",
                        json={"name": "x", "fallback_policy": "automatic"})
        assert r.status_code == 400
        r = client.post("/api/plugins/autorouter/routing-profiles",
                        json={"name": "x", "verified_free_only": False})
        assert r.status_code == 400

    def test_name_conflict_returns_409(self, client):
        client.post("/api/plugins/autorouter/routing-profiles", json={"name": "Conflict"})
        r = client.post("/api/plugins/autorouter/routing-profiles", json={"name": "conflict"})
        assert r.status_code == 409
        assert r.json()["detail"]["code"] == "profile_name_conflict"

    def test_duplicate_and_activate(self, client):
        r = client.post("/api/plugins/autorouter/routing-profiles", json={"name": "Dup"})
        created = r.json()["profile"]
        r = client.post(f"/api/plugins/autorouter/routing-profiles/{created['id']}/duplicate", json={})
        assert r.status_code == 201
        assert r.json()["profile"]["id"] != created["id"]
        r = client.post(f"/api/plugins/autorouter/routing-profiles/{created['id']}/activate")
        assert r.status_code == 200 and r.json()["active"] == created["id"]
        r = client.get("/api/plugins/autorouter/routing-profiles")
        assert r.json()["active"] == created["id"]
        r = client.post("/api/plugins/autorouter/routing-profiles/deactivate")
        assert r.json()["active"] is None
        r = client.get("/api/plugins/autorouter/routing-profiles")
        assert r.json()["active"] is None

    def test_delete_active_profile_deactivates(self, client):
        r = client.post("/api/plugins/autorouter/routing-profiles", json={"name": "DeleteActive"})
        created = r.json()["profile"]
        client.post(f"/api/plugins/autorouter/routing-profiles/{created['id']}/activate")
        r = client.delete(f"/api/plugins/autorouter/routing-profiles/{created['id']}")
        assert r.json()["deactivated"] is True
        r = client.get("/api/plugins/autorouter/routing-profiles")
        assert r.json()["active"] is None

    def test_preview_empty_catalog(self, client):
        r = client.post("/api/plugins/autorouter/routing-profiles", json={"name": "Preview"})
        created = r.json()["profile"]
        r = client.post(f"/api/plugins/autorouter/routing-profiles/{created['id']}/preview")
        assert r.status_code == 200
        body = r.json()
        assert body["eligible_count"] == 0
        assert body["chosen"] is None
        assert body["execution_authority"] is False

    def test_activate_unknown_profile_404(self, client):
        r = client.post("/api/plugins/autorouter/routing-profiles/rp_missing/activate")
        assert r.status_code == 404
        assert r.json()["detail"]["code"] == "profile_not_found"

    def test_activate_actually_switches_selection(self, client):
        """Profile chosen via activation narrows a preview end-to-end."""
        r = client.post("/api/plugins/autorouter/routing-profiles",
                        json={"name": "Nvidia only", "providers": ["nvidia"]})
        profile = r.json()["profile"]
        r = client.post(f"/api/plugins/autorouter/routing-profiles/{profile['id']}/activate")
        assert r.json()["active"] == profile["id"]
