import pytest

"""Real PluginManager gates; no live user plugins, credentials, or inference."""
OBSERVERS = {"pre_api_request", "post_api_request", "api_request_error"}
TOOLS = {"autorouter_status", "autorouter_refresh", "autorouter_select"}


def test_disabled_plugin_registers_nothing(isolated_host):
    result = isolated_host()
    assert result["registrations"] == []
    assert not result["state_created"]


def test_enabled_plugin_registers_observer_hooks_only(isolated_host):
    result = isolated_host(enabled=True)
    assert set(result["hooks"]) == OBSERVERS
    assert set(result["tools"]) == TOOLS
    assert result["state_created"]


def test_no_automatic_fallback_hook(isolated_host):
    result = isolated_host(enabled=True)
    assert "transform_api_error_classification" not in result["registrations"]
    assert "transform_llm_output" not in result["registrations"]
    assert set(result["registrations"]) == OBSERVERS | TOOLS


def test_normal_hermes_execution_not_modified(isolated_host):
    result = isolated_host(enabled=True, installed=False)
    assert not result["host_enabled"]
    assert result["registrations"] == []
    assert not result["state_created"]


def test_supported_discovery_to_recommendation_through_actual_host(isolated_host):
    result = isolated_host(enabled=True, discovery=True)
    proof = result['discovery_acceptance']
    assert proof['selected']['ok'] and proof['provider']=='openrouter'
    assert proof['catalog_paths']==['native_profile', 'capability_metadata']
    assert proof['expired_rejected'] and proof['strict_guarantee_rejected']
    assert proof['provider_transport']=='synthetic' and not proof['live_entitlement_verified']
    assert result['blocked_network_attempts']==0


def test_real_hermes_registered_tools_share_policy_contract_and_deny_missing_authority(isolated_host):
    result=isolated_host(enabled=True,policy_contract=True)
    assert result['request_trace']==dict(outcomes=['success','error'],actual_registered_hooks=True,decision_apply='unavailable',synthetic_callbacks=True)
    assert result['policy_contract']==dict(schema_version=1,parity=True,model='isolated-policy-model',missing_authority_denied=True,execution_authority=False)
    assert result['blocked_network_attempts']==0


def test_first_use_real_host_refreshes_to_recommendation_with_synthetic_transport(isolated_host):
    result=isolated_host(enabled=True,first_use=True)
    assert result['first_use']==dict(initial='catalog_refresh_required',ready=True,provider_transport='synthetic',live_entitlement=False)
    assert result['blocked_network_attempts']==0


def test_first_use_disabled_host_remains_default_off_without_state(isolated_host):
    result=isolated_host(enabled=False,first_use=True)
    assert result['first_use']['initial']=='activation_required'
    assert result['first_use']['ready'] is False and not result['state_created']


def test_explicit_empty_provider_opt_in_does_not_enable_default_accounts(isolated_host):
    result=isolated_host(enabled=True,first_use=True,providers=[])
    assert result['first_use']['initial']=='providers_required'
    assert not result['first_use']['ready'] and result['blocked_network_attempts']==0


@pytest.mark.parametrize("providers", ["nvidia", {}, ["nvidia", 1], ["unsupported"], ["nvidia", "unsupported"]])
def test_malformed_provider_configuration_denies_actual_host_refresh_and_selection(isolated_host, providers):
    result=isolated_host(enabled=True,first_use=True,providers=providers)
    assert result['first_use']['initial']=='configuration_unavailable'
    assert not result['first_use']['ready']
    assert result['blocked_network_attempts']==0


def test_missing_provider_configuration_retains_only_established_defaults(isolated_host):
    result=isolated_host(enabled=True)
    assert result['authorized_providers']==['nvidia','openrouter']
    assert result['blocked_network_attempts']==0


@pytest.mark.parametrize("partial", [False, True])
def test_all_five_catalogs_share_actual_host_refresh_and_readonly_evidence(isolated_host, partial):
    result=isolated_host(enabled=True,discovery_all=True,partial_catalog=partial)
    proof=result['five_provider_acceptance']
    assert len(proof['counts'])==5 and proof['counts']['groq']==(0 if partial else 1)
    assert proof['catalog_calls']==6 and proof['actual_registered_tool'] is True
    assert proof['selected_provider']=='openrouter' and proof['other_costs']=='unknown'
    assert proof['authentication']=='unverified' and not proof['live_entitlement']
    assert proof['partial_catalog'] is partial and proof['transport']=='synthetic'
    assert result['blocked_network_attempts']==0
