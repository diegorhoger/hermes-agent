"""MODE A (issue #116): explicit picker selection routes through the real consumer."""


def test_explicit_picker_selection_resolves_physical_route_end_to_end(isolated_host):
    result = isolated_host(enabled=True, providers=["openrouter"], picker_mode_a=True)
    proof = result["picker_mode_a"]
    assert proof["registered"] is True
    assert proof["route_provider"] == "openrouter"
    assert proof["route_model"] == "fixture/openrouter-picker-free"
    assert proof["mode_b_passthrough"] is True
    assert proof["wire_never_carries_virtual_id"] is True
    assert set(proof["catalog_calls"]) == {"native_catalog", "public_capability_metadata"}
    assert proof["catalog_calls"].count("native_catalog") >= 1
    assert result["blocked_network_attempts"] == 0


def test_mode_b_stays_off_with_only_chat_router_enabled(isolated_host):
    # The MODE A flag alone never widens into ordinary-session automatic routing:
    # the plain ordinary-session seam metadata must answer passthrough.
    result = isolated_host(enabled=True, providers=["openrouter"], picker_mode_a=True)
    assert result["picker_mode_a"]["mode_b_passthrough"] is True
