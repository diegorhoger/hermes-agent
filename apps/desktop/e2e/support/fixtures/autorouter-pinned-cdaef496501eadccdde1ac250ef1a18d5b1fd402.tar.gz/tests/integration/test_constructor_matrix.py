"""Every matrix case constructs the real agent; no inference is sent."""
import pytest


@pytest.mark.parametrize("enabled,installed", [(False, False), (False, True), (True, False), (True, True)])
def test_constructor_matrix(isolated_host, enabled, installed):
    result = isolated_host(enabled=enabled, installed=installed, construct=True)
    assert result["agent_constructed"]
    assert result["agent_model"] == "isolated-test-model"
    assert bool(result["registrations"]) == (enabled and installed)
