"""Native consumer-to-host-session acceptance (issue #126).

Everything is synthetic, local and disposable. This suite drives the REAL host
flow on a disposable Hermes v0.23.2 host combined with the pre-inference seam
(NousResearch/hermes-agent#156277) and the AutoRouter picker contract (fork
diegorhoger/hermes-agent PR #1):

    PluginManager → AutoRouter register() → strict enablement gate
    → owned pre_inference_route consumer → ordinary session (MODE B) or
    explicit AutoRouter pick (MODE A) → canonical selector →
    authorized physical provider/model → host runtime provider resolution →
    host-owned credential selection → host session/AIAgent construction
    (tui_gateway.server._make_agent) → one localhost SSE request.

No test code injects a credential or endpoint after AutoRouter returns its
decision: the host resolves both from its supported provider/credential
interfaces (the mockinfra user provider profile declares env_vars and a
loopback base_url). All zero-cost catalog evidence is written into the
disposable plugin-data store by the fixture and must never be described as
production entitlement, account allowance or quota evidence.

Refusals must precede client construction: CLIENT_CONSTRUCTED == 0 and zero
wire traffic. Positive runs assert EXTERNAL_CONNECTION_ATTEMPTS == 0,
EXTERNAL_COMPLETED_REQUESTS == 0 and LOCALHOST_CHAT_COMPLETIONS == 1 — the
audit fails the test on any external attempt instead of a vacuous >= 0.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def _source_root(which: str = "combined") -> Path:
    var = "AUTOROUTER_HERMES_SOURCE" if which == "combined" else "AUTOROUTER_HERMES_VANILLA_SOURCE"
    src = os.environ.get(var)
    if not src:
        pytest.skip(f"Set {var} to a clean Hermes git archive ({which})")
    path = Path(src).resolve()
    assert (path / "hermes_cli" / "plugins.py").is_file()
    assert not (path / ".git").exists()
    return path


def _install_plugin(home: Path, source_root: Path) -> None:
    plugin = home / "plugins" / "autorouter"
    plugin.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        ROOT,
        plugin,
        ignore=shutil.ignore_patterns(
            ".git", ".env*", "__pycache__", ".pytest_cache",
            "*.db", "*.sqlite*", "*.log", "state", "tests",
        ),
    )


def _run(home: Path, tmp_path: Path, scenario: str, *, source: str = "combined",
         extra_env: dict | None = None) -> dict:
    sandbox = tmp_path / "home"
    sandbox.mkdir(exist_ok=True)
    env = {
        "HOME": str(sandbox),
        "PATH": os.environ.get("PATH", ""),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(_source_root(source)),
        "HERMES_HOME": str(home),
        "AUTOROUTER_FORBIDDEN_HERMES_HOME": str(Path.home() / ".hermes"),
        "HERMES_BUNDLED_PLUGINS": str(tmp_path / "bundled"),
        "HERMES_ENABLE_PROJECT_PLUGINS": "0",
        "MOCKINFRA_API_KEY": "fixture-mockinfra-key-synthetic",
        "NVIDIA_API_KEY": "fixture-nvidia-key-synthetic",
        "NATIVE_CONSUMER_SCENARIO": scenario,
        "XDG_CACHE_HOME": str(tmp_path / "cache"),
        "XDG_CONFIG_HOME": str(tmp_path / "config"),
        **(extra_env or {}),
    }
    if extra_env:
        for key, value in extra_env.items():
            if value is None:
                env.pop(key, None)
            else:
                env[key] = value
    result_path = tmp_path / "host-result.json"
    result = subprocess.run(
        [sys.executable, str(HERE / "host_worker.py"), str(result_path), "native-consumer"],
        env=env, cwd=tmp_path, capture_output=True, text=True, timeout=240,
    )
    assert result.returncode == 0, result.stderr[-4000:] + result.stdout[-1500:]
    return json.loads(result_path.read_text())


def _chat_wire(payload):
    return [r for r in payload["captured_requests"] if r["path"] == "/v1/chat/completions"]


@pytest.fixture()
def disposable_host(tmp_path):
    source = _source_root("combined")
    home = tmp_path / "nc-host"
    home.mkdir()
    _install_plugin(home, source)
    return home


# ---------------------------------------------------------------- positives


def test_mode_b_ordinary_session_routes_through_consumer_end_to_end(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "positive-mode-b")

    assert payload["plugin_loaded"] is True and payload["plugin_enabled"] is True
    assert payload["consumer_owners"] == ["autorouter"]
    assert payload["host_recognizes_provider"] is True
    assert payload["client_constructed"] == 1
    assert payload["agent_model"] == "mockinfra-free-model"
    assert payload["client_base_url"].startswith("http://127.0.0.1:")
    assert payload["agent_reply"] == "fixture-ok"

    wire = _chat_wire(payload)
    assert len(wire) == 1
    assert wire[0]["model"] == "mockinfra-free-model"
    # The host resolved the synthetic credential itself — never the NVIDIA key.
    assert wire[0]["authorize"] == "Bearer fixture-mockinfra-key-synthetic"
    assert wire[0]["stream"] is True
    assert not wire[0]["has_virtual_marker"]

    # The virtual marker must not appear anywhere on the wire.
    assert "auto-free" not in json.dumps(payload["captured_requests"])

    # Session selection and physical runtime stayed consistent: the persisted
    # session row names the physically-resolved model, not the virtual pin.
    rows = payload.get("session_rows") or []
    assert rows and rows[0]["model"] == "mockinfra-free-model"

    # Explicit audit: zero external attempts; exactly one chat inference on the
    # wire. The host's own local-server probe (/api/show) is a loopback fixture
    # event and is counted separately, never as an inference completion.
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0
    assert payload["EXTERNAL_COMPLETED_REQUESTS"] == 0
    assert payload["DNS_EXTERNAL_ATTEMPTS"] == 0
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] >= 1
    assert payload["LOCALHOST_CHAT_COMPLETIONS"] == 1
    # A host-owned local-server probe (/api/show) may fire exactly once in
    # some environments; it is counted separately, never as inference.
    assert payload["LOCALHOST_PROBE_REQUESTS"] >= 0
    assert payload["CLIENT_CONSTRUCTED"] == 1
    assert payload["network_blocked"] is True


def test_mode_a_virtual_pick_resolves_physical_end_to_end(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "positive-mode-a")

    assert payload["plugin_loaded"] is True and payload["plugin_enabled"] is True
    assert payload["consumer_owners"] == ["autorouter"]
    assert payload["client_constructed"] == 1
    assert payload["agent_model"] == "mockinfra-free-model"
    wire = _chat_wire(payload)
    assert len(wire) == 1
    assert wire[0]["model"] == "mockinfra-free-model"
    assert wire[0]["authorize"] == "Bearer fixture-mockinfra-key-synthetic"
    assert not wire[0]["has_virtual_marker"]
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0
    assert payload["EXTERNAL_COMPLETED_REQUESTS"] == 0
    assert payload["LOCALHOST_CHAT_COMPLETIONS"] == 1
    assert payload["LOCALHOST_PROBE_REQUESTS"] >= 0


def test_explicit_physical_pick_is_never_intercepted(disposable_host, tmp_path):
    # The explicit pick names a model the consumer's tools gate would reject;
    # it must pass through untouched and bind no session route.
    payload = _run(disposable_host, tmp_path, "explicit-physical-never-intercepted")

    assert payload["client_constructed"] == 1
    assert payload["agent_model"] == "mockinfra-no-tools-model"
    wire = _chat_wire(payload)
    assert len(wire) == 1 and wire[0]["model"] == "mockinfra-no-tools-model"
    assert payload["binding_rows"] == 0
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0
    assert payload["LOCALHOST_CHAT_COMPLETIONS"] == 1


def test_mode_b_flag_disabled_proceeds_stock_not_routed(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "mode-b-flag-disabled")

    # The consumer stays silent (passthrough); the stock model from config wins.
    assert payload["client_constructed"] == 1
    assert payload["agent_model"] == "mockinfra-no-tools-model"
    chats = [r for r in payload["captured_requests"] if r["path"] == "/v1/chat/completions"]
    assert len(chats) == 1 and chats[0]["model"] == "mockinfra-no-tools-model"
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0
    assert payload["LOCALHOST_CHAT_COMPLETIONS"] == 1


# ------------------------------------------------------- refusal audit rest


def _assert_clean_refusal(payload, *, expect_client_constructed=0):
    assert payload["client_constructed"] == expect_client_constructed
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0
    assert payload["EXTERNAL_COMPLETED_REQUESTS"] == 0
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0
    assert payload["captured_requests"] == []
    assert payload["DNS_EXTERNAL_ATTEMPTS"] == 0
    assert payload["CLIENT_CONSTRUCTED"] == 0


def test_plugin_disabled_refuses_auto_router_pick(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "plugin-disabled")
    _assert_clean_refusal(payload)


def test_plugin_absent_refuses_auto_router_pick(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "plugin-absent")
    _assert_clean_refusal(payload)


def test_mode_a_flag_disabled_refuses_auto_router_pick(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "mode-a-flag-disabled")
    _assert_clean_refusal(payload)


def test_foreign_consumer_cannot_unlock_the_picker(disposable_host, tmp_path):
    # fakefeed registered a pre_inference_route consumer; the AutoRouter gate
    # is ownership-bound and must not treat it as its own.
    payload = _run(disposable_host, tmp_path, "foreign-consumer")
    _assert_clean_refusal(payload)
    assert payload["consumer_owners"] == ["fakefeed"]


def test_consumer_unloaded_ordinary_session_proceeds_stock(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "consumer-unloaded")

    assert payload["consumer_owners_after_unload"] == []
    # Ordinary sessions fall back to byte-identical stock behavior: the
    # consumer is gone, so the pinned stock model is what reaches the wire.
    assert payload["client_constructed"] == 1
    assert payload["agent_model"] == "mockinfra-no-tools-model"
    wire = _chat_wire(payload)
    assert len(wire) == 1 and wire[0]["model"] == "mockinfra-no-tools-model"
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0


def test_provider_not_host_recognized_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "provider-unrecognized")
    _assert_clean_refusal(payload)
    assert payload["host_recognizes_provider"] is False


def test_provider_unauthorized_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "provider-unauthorized")
    _assert_clean_refusal(payload)


def test_empty_allowlist_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "empty-allowlist")
    _assert_clean_refusal(payload)


def test_invalid_authorization_list_refuses_all(disposable_host, tmp_path):
    # Regression for issue #126 authorization repair: a malformed list grants
    # nothing, even though a verified-free nvidia row exists in the catalog.
    payload = _run(disposable_host, tmp_path, "invalid-provider-list")
    _assert_clean_refusal(payload)


def test_provider_removed_after_discovery_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "provider-removed")
    _assert_clean_refusal(payload)


def test_unknown_price_evidence_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "price-unknown")
    _assert_clean_refusal(payload)


def test_stale_price_evidence_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "price-stale")
    _assert_clean_refusal(payload)


def test_conflicting_price_evidence_refuses(disposable_host, tmp_path):
    # Catalog claims free; persisted capability evidence is fresh but paid.
    payload = _run(disposable_host, tmp_path, "price-conflicting")
    _assert_clean_refusal(payload)


def test_model_without_tools_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "model-lacks-tools")
    _assert_clean_refusal(payload)


def test_insufficient_context_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "context-insufficient")
    _assert_clean_refusal(payload)


def test_routing_profile_excludes_provider_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "profile-excludes")
    _assert_clean_refusal(payload)


def test_explicit_model_preference_none_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "model-preference-none")
    _assert_clean_refusal(payload)


def test_credential_from_wrong_provider_refuses(disposable_host, tmp_path):
    # Only the NVIDIA key is present; the host must not spend it on mockinfra.
    payload = _run(disposable_host, tmp_path, "credential-wrong-provider",
                   extra_env={"MOCKINFRA_API_KEY": None})
    _assert_clean_refusal(payload)


# --------------------------------------------------------- two-phase flows


def test_session_resume_with_invalidated_route_refuses(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "resume-invalidated")

    assert payload["phase1_constructed"] == 1
    assert payload["phase1_model"] == "mockinfra-free-model"
    assert payload["phase1_reply"] == "fixture-ok"
    rows = payload.get("session_rows_phase1") or []
    assert rows and rows[0]["model"] == "mockinfra-free-model"
    # The pricing evidence dies; the resumed session must refuse, not widen.
    assert payload["phase2_constructed"] == 0
    assert "phase2_error" in payload
    assert payload["LOCALHOST_CHAT_COMPLETIONS"] == 1  # only the first build hit the wire
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0


def test_two_sessions_with_different_policies_isolate(disposable_host, tmp_path):
    payload = _run(disposable_host, tmp_path, "two-sessions-different-policies")

    assert payload["phase1_constructed"] == 1
    assert payload["phase1_model"] == "mockinfra-free-model"
    # After the operator sets a default profile excluding mockinfra, the new
    # session refuses while session A's earlier route is not retroactively
    # rewritten (it is rebuilt only on resume).
    assert payload["phase2_constructed"] == 0
    assert payload["LOCALHOST_CHAT_COMPLETIONS"] == 1
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0


# ---------------------------------------------------- unsupported host only


def test_unsupported_host_refuses_auto_router_and_stays_stock(tmp_path):
    source = _source_root("vanilla")
    home = tmp_path / "nc-host-vanilla"
    home.mkdir()
    _install_plugin(home, source)
    payload = _run(home, tmp_path, "unsupported-host", source="vanilla")

    # The sanctioned seam does not exist on stock v0.23.2.
    assert payload["host_extension_present"] is False
    # MODE A refuses — no client, no inference on the wire.
    assert payload["client_constructed"] == 0
    assert payload["mode_a_refused"] is True
    # One stock completion is expected (the byte-identical ordinary session).
    assert payload["LOCALHOST_CHAT_COMPLETIONS"] == 1
    # Ordinary sessions are byte-identical stock: the pinned stock model
    # is built (loopback fixture) without any consumer influence.
    assert payload["stock_client_constructed"] == 1
    assert payload["stock_model"] == "mockinfra-no-tools-model"
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0
