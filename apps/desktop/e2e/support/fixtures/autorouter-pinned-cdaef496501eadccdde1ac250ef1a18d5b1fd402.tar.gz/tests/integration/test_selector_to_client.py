"""End-to-end selector → physical-route → host inference client → localhost wire.

Everything is synthetic, local, and disposable. The fixture stands up a real
localhost HTTP server speaking SSE `chat.completions`, and a mocked provider
"mockinfra" — an out-of-tree Hermes `model-provider` plugin the host
recognizes on its own. The host then:

1. advertises mockinfra through `providers.list_providers()`,
2. discovers its catalog through the profile's `fetch_models()`,
3. runs the AutoRouter selection cache refresh,
4. picks an eligible model through the real selector,
5. builds a real `OpenAI` client through the host runtime ladder,
6. streams a real SSE response from the local server,
7. records health/decision rows and billing evidence through the real store.

No network access is allowed and no real credential is ever used. The local
server is the only endpoint contacted — and each attempt is traced,
`ATTEMPTED_PROVIDER_REQUESTS` vs `COMPLETED_PROVIDER_REQUESTS` (always zero
outside this mock) — and counted separately from `LOCALHOST_COMPLETED_REQUESTS`.

The unsuccessful path never builds a client at all: the selector refuses, no
HTTP request is issued, the mock sees nothing.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def _source_root() -> Path:
    src = os.environ.get("AUTOROUTER_HERMES_SOURCE")
    if not src:
        pytest.skip("Set AUTOROUTER_HERMES_SOURCE to a clean Hermes git archive")
    path = Path(src).resolve()
    assert (path / "hermes_cli" / "plugins.py").is_file()
    assert not (path / ".git").exists()
    return path


def _install_plugin(home: Path) -> None:
    artifact = os.environ.get("AUTOROUTER_TEST_PACKAGE")
    plugin = home / "plugins" / "autorouter"
    plugin.parent.mkdir(parents=True, exist_ok=True)
    if artifact:
        import zipfile

        with zipfile.ZipFile(artifact) as archive:
            archive.extractall(plugin.parent)
    else:
        shutil.copytree(
            ROOT,
            plugin,
            ignore=shutil.ignore_patterns(".git", ".env*", "__pycache__", ".pytest_cache",
                                          "*.db", "*.sqlite*", "*.log", "state"),
        )


def _bundled_providers(tmp_path: Path, source: Path) -> Path:
    bundled = tmp_path / "bundled-providers"
    bundled.mkdir()
    model_providers = source / "plugins" / "model-providers"
    if model_providers.is_dir():
        (bundled / "model-providers").symlink_to(model_providers, target_is_directory=True)
    else:
        (bundled / "model-providers").mkdir()
    return bundled


def _run(home: Path, bundled: Path, tmp_path: Path, scenario: str) -> dict:
    sandbox = tmp_path / "home"
    sandbox.mkdir(exist_ok=True)
    env = {
        "HOME": str(sandbox),
        "PATH": os.environ.get("PATH", ""),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(_source_root()),
        "HERMES_HOME": str(home),
        "AUTOROUTER_FORBIDDEN_HERMES_HOME": str(Path.home() / ".hermes"),
        "HERMES_BUNDLED_PLUGINS": str(bundled),
        "HERMES_ENABLE_PROJECT_PLUGINS": "0",
        "NVIDIA_API_KEY": "fixture-nvidia-key-synthetic",
        "OPENROUTER_API_KEY": "fixture-openrouter-key-synthetic",
        "MOCKINFRA_API_KEY": "fixture-mockinfra-key-synthetic",
        "SELECTOR_TO_CLIENT_SCENARIO": scenario,
        "XDG_CACHE_HOME": str(tmp_path / "cache"),
        "XDG_CONFIG_HOME": str(tmp_path / "config"),
    }
    result_path = tmp_path / "host-result.json"
    result = subprocess.run(
        [sys.executable, str(HERE / "host_worker.py"), str(result_path), "selector-to-client"],
        env=env, cwd=tmp_path, capture_output=True, text=True, timeout=240,
    )
    assert result.returncode == 0, result.stderr[-4000:] + result.stdout[-1500:]
    payload = json.loads(result_path.read_text())
    assert payload["network_blocked"] is True, "acceptance must deny all outbound traffic"
    return payload


@pytest.fixture()
def disposable_host(tmp_path):
    source = _source_root()
    home = tmp_path / "s2c-host"
    home.mkdir()

    bundled = _bundled_providers(tmp_path, source)
    _install_plugin(home)
    return home, bundled


def test_positive_path_selects_and_streams_through_mock_server(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "positive-free")

    assert payload["SCENARIO"] == "positive-free"
    assert payload["refresh"]["ok"] is True

    selection = payload["selection"]
    assert selection["ok"] is True
    assert selection["provider"] == "mockinfra"
    assert selection["model"] == "mockinfra-free-model"

    # The host resolved the registered mockinfra provider through the canonical
    # runtime ladder — the test passed no endpoint, no credential, no api_mode.
    assert payload["runtime_source"] == "env:MOCKINFRA_API_KEY"
    assert payload["runtime_requested_provider"] == "mockinfra"
    assert payload["runtime_provider"] == "mockinfra"
    assert payload["runtime_api_key_present"] is True
    assert payload["runtime_api_key"] == "fixture-mockinfra-key-synthetic"
    assert payload["runtime_base_url"].startswith("http://127.0.0.1:")
    assert payload["runtime_api_mode"] == "chat_completions"

    # The real host built a client whose credential/endpoint/api_mode came from
    # the host — not from this test — and streamed through the local server.
    assert payload["agent_client_type"] == "OpenAI"
    assert payload["agent_reply"] == "fixture-ok"
    assert len(payload["captured_requests"]) == 1
    wire = payload["captured_requests"][0]
    assert wire["path"] == "/v1/chat/completions"
    assert wire["authorize"] == "Bearer fixture-mockinfra-key-synthetic"
    assert wire["model"] == "mockinfra-free-model"
    assert wire["body"]["stream"] is True

    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 1
    assert payload["LOCALHOST_ATTEMPTS"] >= 1
    assert payload["COMPLETED_PROVIDER_REQUESTS"] == 0
    assert payload["blocked_network_attempts"] >= 0  # public catalogue probes refused


def test_unknown_cost_model_never_becomes_eligible(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "unknown-cost")
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload["COMPLETED_PROVIDER_REQUESTS"] == 0
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_stale_price_evidence_never_produces_a_free_route(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "stale-cache")
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_corrupt_cache_refuses_everything(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "corrupt-cache")
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_contradictory_pricing_refuses(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "contradictory-pricing")
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_unauthorized_provider_never_gets_a_client(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "unauthorized")
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_empty_allowlist_refuses(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "empty-allowlist")
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_invalid_provider_refuses(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "invalid-provider")
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_provider_removal_invalidates_route_and_refuses_wire(disposable_host, tmp_path):
    home, bundled = disposable_host

    # Phase 1: the host registers mockinfra, authorization and seed are live,
    # the catalog refreshes, and mockinfra is eligible and selectable.
    payload1 = _run(home, bundled, tmp_path, "provider-removed-pre")
    sel1 = payload1["selection"]
    assert sel1["ok"] is True
    assert sel1["provider"] == "mockinfra"
    assert sel1["model"] == "mockinfra-free-model"
    assert payload1["LOCALHOST_COMPLETED_REQUESTS"] == 0  # phase 1 has no wire calls
    assert "mockinfra" in payload1["host_provider_names"]

    # Remove the plugin through the supported host lifecycle: plugin was
    # installed as a directory tree; a gateway restart re-discovers and finds
    # nothing. We uninstall the tree exactly the way the host sees it.
    shutil.rmtree(home / "plugins" / "model-providers" / "mockinfra")

    # Phase 2 (same fixture, same authorization list): refresh cannot find mockinfra,
    # no catalog row can be written for it, and selection refuses before any wire call.
    payload2 = _run(home, bundled, tmp_path, "provider-removed-post")
    assert payload2["configured_authorization_providers"] == payload1["configured_authorization_providers"]
    assert "mockinfra" not in payload2["host_provider_names"]
    assert payload2["selection"]["ok"] is False
    assert payload2["captured_requests"] == []
    assert payload2["COMPLETED_PROVIDER_REQUESTS"] == 0
    assert payload2["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_other_host_providers_remain_registered_after_fixture_removal(disposable_host, tmp_path):
    home, bundled = disposable_host

    # Discovery still recognizes independent host providers even though this
    # intentionally stale allowlist also names the removed mockinfra provider.
    # A strict allowlist validator may refuse the *whole* stale list; that is
    # safer than silently authorizing unrelated fallbacks.
    payload = _run(home, bundled, tmp_path, "provider-removed-post")
    registry = payload["host_provider_names"]
    assert "mockinfra" not in registry
    assert "nvidia" in registry
    assert "openrouter" in registry
    assert payload["configured_authorization_providers"] == ["nvidia", "openrouter", "mockinfra"]


def test_no_tools_model_cannot_pass_tools_gate(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "tools-required-refuses-no-tools")
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_insufficient_context_refuses_for_context_reasons_not_price(disposable_host, tmp_path):
    """Positive control: low gate passes; high gate fails *because* no model has the required
    context — not because the synthetic price evidence is missing from the seed."""
    home, bundled = disposable_host

    # Positive control: the same fresh catalog qualifies at a low context bar.
    low = _run(home, bundled, tmp_path, "min-context-low")
    assert low["selection"]["ok"] is True

    # Negative control: the same fresh catalog fails the high-context bar only.
    payload = _run(home, bundled, tmp_path, "min-context-high")
    assert payload["selection"]["ok"] is False
    rows = payload["selection"]["decision"].get("considered") or []
    mockinfra_free = [row for row in rows
                      if row.get("provider") == "mockinfra"
                      and str(row.get("model", "")).startswith("mockinfra-free-model")]
    # The fixture registers exactly one verified-free model; it must be the row that fails the context gate.
    assert len(mockinfra_free) == 1, (
        f"expected the single fixture verified-free row in consideration, got: {mockinfra_free}"
    )
    for row in mockinfra_free:
        codes = row.get("reason_codes", [])
        assert "context_unknown_or_insufficient" in codes, (
            f"mockinfra row {row.get('model')} was rejected for something other than context: {codes}"
        )
        assert "cost_not_verified_free" not in codes, (
            f"mockinfra row {row.get('model')} was rejected for price despite a verified-free seed: {codes}"
        )
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_registry_unavailable_refuses(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "registry-unavailable")
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_profile_excludes_mockinfra_from_the_required_set(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "profile-excludes-mockinfra")
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_missing_fixture_credential_refused_by_real_host_resolver(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "missing-credential")
    # The provider is authorized and selected with valid price/capability
    # evidence. Only then is its fixture credential removed, immediately
    # before the actual Hermes runtime resolver runs.
    assert payload["selection"]["ok"] is True
    assert payload["selection"]["provider"] == "mockinfra"
    assert payload["runtime_resolution_attempted"] is True
    assert payload["runtime_resolution_error"], "the real host resolver must reject the missing API key"
    assert payload["agent_client_type"] is None
    assert payload["captured_requests"] == []
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0
    assert payload["COMPLETED_PROVIDER_REQUESTS"] == 0


def test_unresolvable_provider_runtime_fails_before_any_provider_request(disposable_host, tmp_path):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "unresolvable-provider")
    # Provider under the fixture registration is gone; discovery must filter it and the selection
    # must refuse. The host never resolves and never constructs the client.
    assert payload["selection"]["ok"] is False
    assert payload["captured_requests"] == []
    assert payload.get("agent_reply") is None or payload["agent_reply"].startswith(("<resolution-error", "<agent-error"))
    assert payload.get("agent_client_type") is None
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0
    assert payload["COMPLETED_PROVIDER_REQUESTS"] == 0


def test_routing_wrong_key_reaches_mock_but_refuses_authorization(disposable_host, tmp_path):
    """A wrong key may reach the fixture only on loopback; recorded as an attempt
    and never as an outbound provider completion."""
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, "routing-wrong-key")
    selection = payload["selection"]
    assert selection["ok"] is True  # selector cannot know the fixture key is wrong offline
    reply = payload["agent_reply"]
    # The wrong credential reaches only the loopback fixture, where the host honestly returns 401.
    assert "HTTP 401" in reply or "invalid API key" in reply
    # No external request can ever have happened — the wire never leaves loopback.
    assert payload["COMPLETED_PROVIDER_REQUESTS"] == 0
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 1
    captured = payload["captured_requests"]
    assert captured, "wrong-key attempt must land inside the disposable mock"
    for wire in captured:
        assert wire["model"] == "mockinfra-free-model"
        assert wire["path"] == "/v1/chat/completions"
        assert "fixture-wrong-key" in wire.get("authorize", "")
