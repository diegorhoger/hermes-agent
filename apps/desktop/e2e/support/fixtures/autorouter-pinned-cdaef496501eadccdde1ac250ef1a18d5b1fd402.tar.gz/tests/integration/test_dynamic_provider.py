"""Slice D (issue #119): disposable Hermes host with a non-six mock provider.

The mock provider "mockinfra" is a localhost-only Hermes model-provider plugin:
the host recognizes it through its own registry, AutoRouter inventories it,
and a seeded offline models.dev catalog decides verified-free eligibility.
Everything else — the AutoRouter plugin loader, the providers registry, the
eligibility gates — is the real host code. No network, no real credentials,
no paid inference.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

_MOCK_PROVIDER_DIR = "mockinfra"
_MOCK_PROFILE = """\
from providers import register_provider
from providers.base import ProviderProfile


class MockInfraProfile(ProviderProfile):
    def fetch_models(self, **kwargs):
        raise RuntimeError("fetch is forbidden in this acceptance")


mockinfra = MockInfraProfile(
    name="mockinfra",
    aliases=("mockinfra-alias",),
    env_vars=("MOCKINFRA_API_KEY",),
    display_name="MockInfra (test fixture)",
    description="Disposable localhost mock for the ADR-0016 Slice D acceptance",
    fallback_models=("mockinfra-free-model", "mockinfra-unknown-model"),
    base_url="http://127.0.0.1:9/v1",
    api_mode="chat_completions",
    auth_type="api_key",
    supports_model_listing=False,
    supports_health_check=False,
)
register_provider(mockinfra)
"""
_MOCK_MANIFEST = """\
name: mockinfra-provider
kind: model-provider
version: 1.0.0
description: Disposable localhost mock for the ADR-0016 Slice D acceptance
author: AutoRouter acceptance fixture
"""
_MOCK_CATALOG = {
    "mockinfra": {
        "models": {
            "mockinfra-free-model": {
                "limit": {"context": 131072},
                "tool_call": True,
                "cost": {"input": 0.0, "output": 0.0},
            },
            "mockinfra-unknown-model": {
                "limit": {"context": 131072},
                "tool_call": True,
            },
        }
    }
}


def _source_root():
    source = os.environ.get("AUTOROUTER_HERMES_SOURCE")
    if not source:
        pytest.skip("Set AUTOROUTER_HERMES_SOURCE to a clean Hermes git archive")
    source = Path(source).resolve()
    assert (source / "hermes_cli" / "plugins.py").is_file()
    assert not (source / ".git").exists() and not (source / ".env").exists()
    return source


def _install_plugin(home: Path) -> None:
    artifact = os.environ.get("AUTOROUTER_TEST_PACKAGE")
    plugin = home / "plugins" / "autorouter"
    if artifact:
        import zipfile

        with zipfile.ZipFile(artifact) as archive:
            archive.extractall(plugin.parent)
    else:
        shutil.copytree(
            ROOT,
            plugin,
            ignore=shutil.ignore_patterns(".git", ".env*", "__pycache__", ".pytest_cache",
                                          "*.db", "*.sqlite*", "*.log", "state"),
        )


def _bundled_providers(tmp_path: Path, source: Path) -> Path:
    bundled = tmp_path / "bundled-providers"
    bundled.mkdir()
    providers = source / "plugins" / "model-providers"
    if providers.is_dir():
        (bundled / "model-providers").symlink_to(providers, target_is_directory=True)
    else:
        (bundled / "model-providers").mkdir()
    return bundled


def _write_mock_provider(home: Path) -> None:
    provider_dir = home / "plugins" / "model-providers" / _MOCK_PROVIDER_DIR
    provider_dir.mkdir(parents=True)
    (provider_dir / "__init__.py").write_text(_MOCK_PROFILE)
    (provider_dir / "plugin.yaml").write_text(_MOCK_MANIFEST)


def _seed_catalog(home: Path) -> None:
    (home / "models_dev_cache.json").write_text(json.dumps(_MOCK_CATALOG))


def _run(home: Path, bundled: Path, tmp_path: Path, providers_state: str, monkeypatch):
    sandbox = tmp_path / "home"
    sandbox.mkdir(exist_ok=True)
    env = {
        "HOME": str(sandbox),
        "PATH": os.environ.get("PATH", ""),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(_source_root()),
        "HERMES_HOME": str(home),
        "AUTOROUTER_FORBIDDEN_HERMES_HOME": str(Path.home() / ".hermes"),
        "HERMES_BUNDLED_PLUGINS": str(bundled),
        "HERMES_ENABLE_PROJECT_PLUGINS": "0",
        "MOCKINFRA_API_KEY": "fixture-mockinfra-key-synthetic",
        "NVIDIA_API_KEY": "fixture-nvidia-key-synthetic",
        "OPENROUTER_API_KEY": "fixture-openrouter-key-synthetic",
        "DYNAMIC_PROVIDER_AUTHORIZED": providers_state,
        "XDG_CACHE_HOME": str(tmp_path / "cache"),
        "XDG_CONFIG_HOME": str(tmp_path / "config"),
    }
    config = {
        "plugins": {
            "enabled": ["autorouter"],
            "entries": {
                "autorouter": {
                    "settings": {
                        "enabled": True,
                        "free_only": True,
                        "providers": (
                            ["nvidia", "openrouter", "mockinfra"]
                            if providers_state == "1" else ["nvidia", "openrouter"]
                        ),
                        "state_dir": str(home / "autorouter-state"),
                    }
                }
            },
        }
    }
    (home / "config.yaml").write_text(json.dumps(config))
    result_path = tmp_path / "host-result.json"
    result = subprocess.run(
        [sys.executable, str(HERE / "host_worker.py"), str(result_path), "dynamic-provider"],
        env=env, cwd=tmp_path, capture_output=True, text=True, timeout=120,
    )
    assert result.returncode == 0, result.stderr[-4000:] + result.stdout[-1500:]
    payload = json.loads(result_path.read_text())
    assert payload["network_blocked"] is True
    assert payload["blocked_network_attempts"] == 0
    return payload


@pytest.fixture()
def disposable_host(tmp_path, monkeypatch):
    source = _source_root()
    home = tmp_path / "autorouter-host"
    home.mkdir()

    bundled = _bundled_providers(tmp_path, source)
    _install_plugin(home)
    _write_mock_provider(home)
    _seed_catalog(home)
    return home, bundled


def test_host_recognizes_sixth_plus_mock_provider(disposable_host, tmp_path, monkeypatch):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, providers_state="0", monkeypatch=monkeypatch)
    assert payload["mock_provider_host_recognized"] is True
    assert payload["valid_list"] is True  # nvidia/openrouter already valid
    assert payload["six_adapter_rows"] == 6


def test_mock_provider_visible_but_unauthorized_by_default(disposable_host, tmp_path, monkeypatch):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, providers_state="0", monkeypatch=monkeypatch)
    row = payload["mock_row"]
    assert row is not None
    assert row["family"] == "llm_host"
    assert row["authorized"] is False
    assert row["usable_for_routing"] != "ready"
    assert payload["blocked_network_attempts"] == 0


def test_mock_provider_authorized_discovery_and_eligibility(disposable_host, tmp_path, monkeypatch):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, providers_state="1", monkeypatch=monkeypatch)
    row = payload["mock_row"]
    assert row is not None
    assert row["authorized"] is True
    assert row["discovery"] == "host_catalog_disabled"  # profile does not list models
    assert row["provider_id"] == "mockinfra"
    # The six adapter rows remain the adapter family — untouched by the mock.
    assert payload["six_adapter_rows"] == 6

    discovered = {row["model"]: row for row in payload["discovered"]}
    assert set(discovered) == {"mockinfra-free-model", "mockinfra-unknown-model"}
    assert discovered["mockinfra-free-model"]["cost_tier"] == "free"
    assert discovered["mockinfra-free-model"]["context_length"] == 131072
    assert discovered["mockinfra-free-model"]["tools"] == "supported"
    assert discovered["mockinfra-unknown-model"]["cost_tier"] == "unknown"

    assert payload["free_model_rejected"] == [], "verified-free model must pass the eligibility gates"
    assert "cost_not_verified_free" in (payload["unknown_model_rejected"] or [])


def test_stale_pricing_evidence_is_ineligible_and_rejected(disposable_host, tmp_path, monkeypatch):
    """An old (4h+) pricing cache is not verified-free evidence — the model
    must stay invisible to the free-only gate even when the file still exists."""
    home, bundled = disposable_host
    stale_at = time.time() - 5 * 3600
    cache_path = home / "models_dev_cache.json"
    os.utime(cache_path, (stale_at, stale_at))
    payload = _run(home, bundled, tmp_path, providers_state="1", monkeypatch=monkeypatch)
    discovered = {row["model"]: row for row in payload["discovered"]}
    assert discovered["mockinfra-free-model"]["cost_tier"] == "unknown"
    assert "cost_not_verified_free" in (payload["free_model_rejected"] or [])
    assert "cost_not_verified_free" in (payload["unknown_model_rejected"] or [])
    assert payload["blocked_network_attempts"] == 0


def test_six_adapters_and_removal_of_mock_authorization_invalidates_route(disposable_host, tmp_path, monkeypatch):
    home, bundled = disposable_host
    payload = _run(home, bundled, tmp_path, providers_state="0", monkeypatch=monkeypatch)
    # Removing the authorization entry removes any right to select mock-free.
    assert payload["mock_row"]["authorized"] is False
    # Six adapters behave exactly as before: llm_adapter family rows present.
    assert payload["six_adapter_rows"] == 6
    # And host recognition of the mock provider remains truthful.
    assert payload["mock_provider_host_recognized"] is True
