"""Bounded real-agent construction with an explicitly enabled isolated plugin."""


def test_probe(isolated_host):
    result = isolated_host(enabled=True, construct=True)
    assert result["agent_constructed"]
    assert result["elapsed_seconds"] < 30
