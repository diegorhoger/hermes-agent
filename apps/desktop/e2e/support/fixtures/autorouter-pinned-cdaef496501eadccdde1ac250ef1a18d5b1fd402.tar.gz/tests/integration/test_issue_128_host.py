"""Issue #128 — configuration invalidated AFTER consumer registration.

The native consumer is registered under a valid configuration; afterwards the
operator's settings file becomes structurally invalid (``plugins: []``).
Every attempt must refuse before any host client is constructed: zero
requests on the wire, zero client construction, zero outbound traffic — for
both the manual MODE A picker pick and the ordinary MODE B session.

Enabling defense-in-depth: after construction the client can fail in chat;
the worker tracks construction and chat separately so the evidence never
hides a constructed client behind a chat exception. A negative-control test
injects a constructible client whose chat fails and proves the harness
detects it.

Everything here is synthetic, local and disposable.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def _source_root() -> Path:
    src = os.environ.get("AUTOROUTER_HERMES_SOURCE")
    if not src:
        pytest.skip("Set AUTOROUTER_HERMES_SOURCE to a clean Hermes git archive")
    path = Path(src).resolve()
    assert (path / "hermes_cli" / "plugins.py").is_file()
    assert not (path / ".git").exists()
    return path


def _install_plugin(home: Path) -> None:
    plugin = home / "plugins" / "autorouter"
    plugin.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        ROOT,
        plugin,
        ignore=shutil.ignore_patterns(
            ".git", ".env*", "__pycache__", ".pytest_cache",
            "*.db", "*.sqlite*", "*.log", "state", "tests",
        ),
    )


def _run(scenario: str, tmp_path: Path) -> dict:
    source = _source_root()
    home = tmp_path / "issue128-host"
    home.mkdir()
    _install_plugin(home)

    sandbox = tmp_path / "home"
    sandbox.mkdir()
    env = {
        "HOME": str(sandbox),
        "PATH": os.environ.get("PATH", ""),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPATH": str(source),
        "HERMES_HOME": str(home),
        "AUTOROUTER_FORBIDDEN_HERMES_HOME": str(Path.home() / ".hermes"),
        "HERMES_BUNDLED_PLUGINS": str(tmp_path / "bundled"),
        "HERMES_ENABLE_PROJECT_PLUGINS": "0",
        "MOCKINFRA_API_KEY": "fixture-mockinfra-key-synthetic",
        "NVIDIA_API_KEY": "fixture-nvidia-key-synthetic",
        "NATIVE_CONSUMER_SCENARIO": scenario,
        "XDG_CACHE_HOME": str(tmp_path / "cache"),
        "XDG_CONFIG_HOME": str(tmp_path / "config"),
    }
    result_path = tmp_path / "host-result.json"
    result = subprocess.run(
        [sys.executable, str(HERE / "host_worker.py"), str(result_path), "native-consumer"],
        env=env, cwd=tmp_path, capture_output=True, text=True, timeout=240,
    )
    assert result.returncode == 0, result.stderr[-4000:] + result.stdout[-1500:]
    return json.loads(result_path.read_text())


def test_config_invalidated_after_consumer_registration_refuses(tmp_path):
    payload = _run("issue128-corrupt-config-after-load", tmp_path)

    # Consumer was registered under the valid configuration.
    assert payload["plugin_loaded"] is True
    assert payload["plugin_enabled"] is True
    assert payload["consumer_owners"] == ["autorouter"]
    assert payload["consumer_owners_after_corruption"] == ["autorouter"]

    # Construction and chat are tracked separately — a constructed client is
    # never "unconstructed" by a later chat failure.
    for label in ("mode_a", "mode_b"):
        assert payload[f"{label}_client_constructed"] == 0
        assert payload[f"{label}_chat_attempted"] is False
        assert payload[f"{label}_build_error"].startswith("RuntimeError")

    assert payload["client_constructed"] == 0
    assert payload["captured_requests"] == []
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0
    assert payload["EXTERNAL_COMPLETED_REQUESTS"] == 0
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0
    assert payload["DNS_EXTERNAL_ATTEMPTS"] == 0

    # Refusal reason assertions: never an unresolved virtual pick escapes.
    assert "refused" in payload["mode_b_build_error"].lower()
    assert "not construct" not in payload["mode_b_build_error"].lower()


def test_revocation_after_consumer_registration_refuses(tmp_path):
    payload = _run("issue128-revoke-enabled", tmp_path)

    assert payload["plugin_loaded"] is True
    assert payload["plugin_enabled"] is True  # registered under enabled:true
    for label in ("mode_a", "mode_b"):
        assert payload[f"{label}_client_constructed"] == 0
        assert payload[f"{label}_chat_attempted"] is False
        assert payload[f"{label}_build_error"].startswith("RuntimeError")
    assert payload["client_constructed"] == 0
    assert payload["captured_requests"] == []
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0


def test_negative_control_detects_constructed_client(tmp_path):
    """Negative control: agent constructs successfully, then chat fails. The
    harness MUST report client_constructed == 1 — an assertion of refusal-zero
    would otherwise falsely pass."""
    payload = _run("issue128-negative-control", tmp_path)

    for label in ("mode_a", "mode_b"):
        assert payload[f"{label}_client_constructed"] == 1, (
            "the worker must never reset client_constructed=1 to 0\n" + json.dumps(payload, indent=1))
        assert payload[f"{label}_chat_attempted"] is True
        assert payload[f"{label}_chat_error"].startswith("RuntimeError")
    assert payload["client_constructed"] == 1
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0


def test_r5_revocation_of_primary_enabled_values(tmp_path):
    """R5: every non-True primary value after registration refuses both
    MODE A and MODE B with zero construction and zero wire requests."""
    payload = _run("issue128-revoke-values", tmp_path)

    assert payload["plugin_loaded"] is True
    for name, cases in payload["bad_values"].items():
        for label in ("mode_a", "mode_b"):
            case = cases[label]
            assert case["client_constructed"] == 0, (name, label, case)
            assert "RuntimeError" in case.get("error", ""), (name, label, case)
    assert payload["captured_requests"] == []
    assert payload["EXTERNAL_CONNECTION_ATTEMPTS"] == 0
    assert payload["EXTERNAL_COMPLETED_REQUESTS"] == 0
    assert payload["LOCALHOST_COMPLETED_REQUESTS"] == 0
    assert payload["DNS_EXTERNAL_ATTEMPTS"] == 0
