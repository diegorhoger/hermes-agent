"""Opt-in real Hermes tests in disposable credential-free subprocesses."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest


@pytest.fixture
def isolated_host(tmp_path):
    source = os.environ.get("AUTOROUTER_HERMES_SOURCE")
    if not source:
        pytest.skip("Set AUTOROUTER_HERMES_SOURCE to a clean Hermes git archive for real-host tests")
    source = Path(source).resolve()
    if not (source / "hermes_cli" / "plugins.py").is_file():
        pytest.fail("AUTOROUTER_HERMES_SOURCE must contain the supported Hermes plugin loader")
    if (source / ".git").exists() or (source / ".env").exists():
        pytest.fail("Use a clean git archive, never a live Hermes checkout or credential directory")
    home = tmp_path / "hermes-home"
    home.mkdir()
    # Bundled *provider profiles* are part of a packaged Hermes host (its
    # providers/<name>.py equivalents live in plugins/model-providers), so
    # hiding the bundled dir disables provider discovery wholesale on
    # recent hosts. Link only the provider profiles: importing every
    # bundled plugin (dashboards, tools) wastes the 35 s subprocess budget.
    # Fall back to an empty dir when the archive has none.
    bundled = tmp_path / "bundled-providers"
    bundled.mkdir()
    model_providers = source / "plugins" / "model-providers"
    if model_providers.is_dir():
        (bundled / "model-providers").symlink_to(model_providers, target_is_directory=True)
    plugin = home / "plugins" / "autorouter"
    artifact = os.environ.get("AUTOROUTER_TEST_PACKAGE")
    def _builder_at(rev):
        import subprocess
        repo = Path(__file__).resolve().parents[2]
        try:
            src = subprocess.check_output(["git", "show", f"{rev}:tools/build_package.py"], cwd=repo)
        except Exception:
            return None
        import tempfile
        tf = tempfile.NamedTemporaryFile("wb", suffix=".py", delete=False)
        tf.write(src)
        tf.close()
        spec = importlib.util.spec_from_file_location("pkg_builder_%s" % rev[:10], tf.name)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    def verify_package(data):
        # Package contracts evolve; a legacy artifact must verify against the
        # builder that admitted it. Try this worktree first (current contract),
        # then main (the contract in effect when current artifacts ship), then
        # the artifact's own source revision. Any builder that rebuilds the
        # archive byte-for-byte admits it; none -> fail with all reasons.
        import zipfile, io
        try:
            manifest = json.loads(zipfile.ZipFile(io.BytesIO(data)).read("autorouter/PACKAGE-MANIFEST.json"))
            source_sha = manifest.get("source_sha", "")
        except Exception:
            source_sha = ""
        reasons = []
        ancestors = subprocess.check_output(
            ["git", "log", "--format=%H", "origin/main", "--", "tools/build_package.py"],
        ).decode().splitlines()
        candidates = [("this-worktree", _builder_at("HEAD")),
                      ("origin-main", _builder_at("origin/main")),
                      ("artifact-source %s" % source_sha[:12], _builder_at(source_sha))]
        for rev in ancestors:
            candidates.append(("ancestor %s" % rev[:10], _builder_at(rev)))
        for label, mod in candidates:
            if mod is None:
                reasons.append(f"{label}: builder unavailable")
                continue
            try:
                mod.verify(data)
                return
            except Exception as exc:
                reasons.append(f"{label}: {exc}")
        pytest.fail("package failed verification: " + "; ".join(reasons))

    def place(package):
        import zipfile
        data = Path(package).read_bytes()
        verify_package(data)
        with zipfile.ZipFile(package) as archive:
            archive.extractall(plugin.parent)
    if artifact:
        place(artifact)
    else:
        shutil.copytree(Path(__file__).resolve().parents[2], plugin,
            ignore=shutil.ignore_patterns(".git", ".env*", "__pycache__", ".pytest_cache",
                                         "*.db", "*.sqlite*", "*.log", "state"))
    # Do not inherit credentials, HOME-based settings, or other user plugins.
    sandbox_home = tmp_path / "home"
    sandbox_home.mkdir()
    env = {"HOME": str(sandbox_home),
           "AUTOROUTER_FORBIDDEN_HERMES_HOME": str(Path.home() / ".hermes"),
           "PATH": os.environ.get("PATH", ""), "PYTHONDONTWRITEBYTECODE": "1",
           "PYTHONPATH": str(source), "HERMES_HOME": str(home),
           **({"AUTOROUTER_TRACE_NET": "1"} if os.environ.get("AUTOROUTER_TRACE_NET") else {}),
           "XDG_CACHE_HOME": str(tmp_path / "cache"), "XDG_CONFIG_HOME": str(tmp_path / "config"),
           "HERMES_BUNDLED_PLUGINS": str(bundled), "HERMES_ENABLE_PROJECT_PLUGINS": "0"}

    def run(*, enabled=None, installed=True, construct=False, policy_contract=False, first_use=False, providers=None, lifecycle=None, discovery=False, discovery_all=False, partial_catalog=False, picker_mode_a=False):
        if lifecycle:
            assert artifact, "Package lifecycle requires a verified artifact"
            backup = home / "removed-plugin"
            if lifecycle == "remove":
                plugin.rename(backup)
            elif lifecycle == "restore":
                backup.rename(plugin)
            elif lifecycle in ("upgrade", "rollback"):
                plugin.rename(backup)
                try:
                    place(os.environ["AUTOROUTER_PREVIOUS_PACKAGE"] if lifecycle == "rollback" else artifact)
                except Exception:
                    if plugin.exists(): shutil.rmtree(plugin)
                    backup.rename(plugin)
                    raise
                shutil.rmtree(backup)
            else:
                raise ValueError("unknown lifecycle")
        settings = {"state_dir": str(home / "autorouter-state")}
        if enabled is not None:
            settings["enabled"] = enabled
        if discovery_all:
            settings["providers"] = ["nvidia", "openrouter", "groq", "gemini", "mistral"]
        if picker_mode_a:
            settings["enabled"] = True
            settings["providers"] = ["openrouter"]
            settings["enable_chat_router"] = True
        if first_use:
            settings["providers"] = ["openrouter"] if providers is None else providers
        config = {"plugins": {"enabled": ["autorouter"] if installed else [],
                              "entries": {"autorouter": {"settings": settings}}}}
        (home / "config.yaml").write_text(json.dumps(config))
        result_path = tmp_path / "host-result.json"
        command = [sys.executable, str(Path(__file__).with_name("host_worker.py")),
                   str(result_path), "absent" if lifecycle == "remove" else "picker-a" if picker_mode_a else "first-use" if first_use else "discovery-all-partial" if discovery_all and partial_catalog else "discovery-all" if discovery_all else "discovery" if discovery else "policy-contract" if policy_contract else "construct" if construct else "plugins"]
        try:
            result = subprocess.run(command, env=env, cwd=tmp_path, capture_output=True,
                                    text=True, timeout=35)
        except subprocess.TimeoutExpired:
            pytest.fail("Isolated Hermes import/plugin loading/constructor exceeded 35 seconds")
        if result.returncode == 77:
            pytest.skip("Isolated Hermes environment lacks dependency: " + result_path.read_text())
        assert result.returncode == 0, result.stderr[-4000:] + result.stdout[-1000:]
        payload = json.loads(result_path.read_text())
        assert payload["home"] == str(home)
        assert payload["user_home"] == str(sandbox_home)
        assert payload["network_blocked"] is True, "Acceptance must deny all network I/O"
        return payload
    return run
