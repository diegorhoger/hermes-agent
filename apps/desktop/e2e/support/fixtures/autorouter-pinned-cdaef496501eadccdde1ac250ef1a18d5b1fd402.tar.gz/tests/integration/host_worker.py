"""Real-host subprocess entry point; no AutoRouter test doubles are imported."""
import json
import os
from pathlib import Path
import sys
import time

result_path = Path(sys.argv[1])
network_attempts = []
process_attempts = []
production_home = Path(os.environ["AUTOROUTER_FORBIDDEN_HERMES_HOME"]).resolve()


import os as _os
_trace = bool(_os.environ.get("AUTOROUTER_TRACE_NET"))


loopback_attempts = []
loopback_completions = []


def _loopback_allowed():
    try:
        return bool(_os.environ.get("AUTOROUTER_ALLOW_LOOPBACK"))
    except Exception:
        return False


def deny_network(event, args):
    if event in ("subprocess.Popen", "os.system", "os.posix_spawn", "os.exec"):
        process_attempts.append(event)
        raise RuntimeError("Child processes are forbidden in isolated AutoRouter acceptance")
    if event in ("open", "os.listdir", "os.scandir") and isinstance(args[0], (str, bytes)):
        path = Path(os.fsdecode(args[0])).resolve()
        if path == production_home or production_home in path.parents:
            raise PermissionError("Live Hermes configuration and credentials are outside this test")
    # urllib3's import-time IPv6 capability probe (``urllib3.util.connection._has_ipv6("::1")``)
    # makes one loopback bind attempt when `requests` is imported. It is a strictly local
    # family probe (never traffic), needed by every acceptance that imports requests —
    # documented allowance, disjoint from all other socket events.
    if event == "socket.bind":
        address = args[1] if len(args) >= 2 else (args[0] if args else None)
        if isinstance(address, tuple) and address and address[0] == "::1":
            return  # urllib3 IPv6 capability probe; strictly local, never traffic
        if _loopback_allowed() and isinstance(address, tuple) and address and str(address[0]).startswith("127."):
            loopback_attempts.append("bind:" + str(address[0]))
            return
    if event in ("socket.connect", "socket.getaddrinfo", "socket.bind", "socket.sendto", "socket.sendmsg"):
        host_raw = None
        for a in args:
            if isinstance(a, tuple) and a and isinstance(a[0], str):
                host_raw = a[0]
                break
            if isinstance(a, str):
                host_raw = a
                break
        allow = host_raw is not None and str(host_raw).startswith(("127.", "::1"))
        if _loopback_allowed() and allow:
            loopback_attempts.append(event + ":" + str(host_raw))
            return  # local endpoints are loopback fixtures; allowed, still counted as attempted
        network_attempts.append(event)
        if _trace:
            import traceback
            with open("/private/var/folders/2q/g9x952410m58_y3mmg59f2jw0000gn/T/opencode/net-trace.log", "a") as fh:
                traceback.print_stack(file=fh)
                fh.write("\n---- event: %s\n----\n" % (event,))
        raise RuntimeError("Network I/O is forbidden in isolated AutoRouter acceptance")


sys.addaudithook(deny_network)
if sys.argv[2] == "guards":
    import socket
    import subprocess
    blocked = []
    def expect_denial(name, callback):
        try:
            callback()
        except (RuntimeError, PermissionError):
            blocked.append(name)
        else:
            raise AssertionError("Isolation boundary did not block " + name)
    expect_denial("private_file", lambda: (production_home / "sentinel").read_text())
    expect_denial("private_directory", lambda: list(production_home.iterdir()))
    expect_denial("child_process", lambda: subprocess.run([sys.executable, "-c", "pass"]))
    expect_denial("dns", lambda: socket.getaddrinfo("localhost", 9))
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        expect_denial("bind", lambda: sock.bind(("127.0.0.1", 0)))
        expect_denial("connect", lambda: sock.connect(("127.0.0.1", 9)))
        expect_denial("sendto", lambda: sock.sendto(b"fixture", ("127.0.0.1", 9)))
        if hasattr(sock, "sendmsg"):
            expect_denial("sendmsg", lambda: sock.sendmsg([b"fixture"], [], 0, ("127.0.0.1", 9)))
    result_path.write_text(json.dumps({"blocked": blocked}))
    sys.exit(0)
try:
    from hermes_cli.plugins import PluginManager
    from hermes_constants import get_hermes_home
    if sys.argv[2] == "construct":
        from run_agent import AIAgent
except ModuleNotFoundError as exc:
    if exc.name.startswith(("hermes_cli", "run_agent", "hermes_constants")):
        raise
    result_path.write_text(json.dumps({"missing_module": exc.name}))
    sys.exit(77)

def _core(runtime_module):
    """Return the dotted autorouter_core package containing integration.runtime."""
    parts = runtime_module.__package__.split('.')
    if parts and parts[-1] == 'integration':
        parts = parts[:-1]
    return '.'.join(parts)


started = time.monotonic()
manager = PluginManager()
manager.discover_and_load()
loaded = manager._plugins.get("autorouter")
if sys.argv[2] == "absent":
    assert loaded is None
    result_path.write_text(json.dumps(dict(home=str(get_hermes_home()),user_home=str(Path.home()),plugin_absent=True,network_blocked=True,blocked_network_attempts=len(network_attempts))))
    sys.exit(0)
assert loaded is not None, loaded
if loaded.enabled:
    assert loaded.error is None, loaded
active = [entry for entry in manager._ownership_ledger.get("autorouter", []) if entry.active and entry.kind != "tool_override_policy"]
payload = {"home": str(get_hermes_home()), "user_home": str(Path.home()), "host_enabled": loaded.enabled,
           "hooks": sorted(entry.key for entry in active if entry.kind == "hook"),
           "tools": sorted(entry.key for entry in active if entry.kind == "tool"),
           "registrations": sorted(entry.key for entry in active),
           "state_created": (Path(os.environ["HERMES_HOME"]) / "autorouter-state" / "autorouter.db").exists()}
if loaded.enabled and active:
    import importlib
    callback=next(cb for cb in manager._hooks['pre_api_request'] if cb.__module__.endswith('.runtime'))
    payload['authorized_providers']=importlib.import_module(callback.__module__).get_router().state['providers']
if sys.argv[2] == "construct":
    agent = AIAgent(api_key="isolated-test-credential", base_url="http://127.0.0.1:9/v1",
                    provider="nvidia", model="isolated-test-model", platform="test",
                    enabled_toolsets=[], quiet_mode=True, skip_context_files=True,
                    skip_memory=True, skip_background_review=True)
    payload["agent_constructed"] = isinstance(agent, AIAgent)
    payload["agent_model"] = agent.model
if sys.argv[2] == "discovery":
    # Real loader/profile/tool path; only fixed catalog responses are synthetic.
    import importlib
    from io import BytesIO
    from hermes_cli import urllib_security
    callback = next(cb for cb in manager._hooks['pre_api_request'] if cb.__module__.endswith('.runtime'))
    runtime = importlib.import_module(callback.__module__)
    adapters = importlib.import_module(_core(runtime) + '.discovery.adapters')
    tools = importlib.import_module(_core(runtime) + '.integration.tools')
    model = 'fixture/verified-model'
    catalog = {'data': [{'id': model, 'context_length': 32000,
        'supported_parameters': ['tools'], 'pricing': {'prompt': '0', 'completion': '0'}}]}
    calls = []
    def catalog_response(request, timeout):
        assert request.full_url == 'https://openrouter.ai/api/v1/models'
        assert request.get_method() == 'GET' and not request.has_header('Authorization')
        calls.append('native_profile')
        return BytesIO(json.dumps(catalog).encode())
    def metadata_response(url, headers):
        assert url == 'https://openrouter.ai/api/v1/models' and headers == {'Accept': 'application/json'}
        calls.append('capability_metadata')
        return catalog
    urllib_security.open_credentialed_url = catalog_response
    adapters._read_json = metadata_response
    router = runtime.get_router()
    router.state['providers'] = ['openrouter']
    tools._refresh_handler({})
    selected = tools._select_handler({'requires_tools': True, 'min_context': 8192})
    assert {key: selected[key] for key in ('ok', 'provider', 'model')} == {'ok': True, 'provider': 'openrouter', 'model': model}
    assert selected['decision']['semantic_quality'] == 'unknown'
    assert not selected['decision']['execution_authority']
    assert router.preview(requires_tools=True)['chosen']['model'] == model
    assert not tools._select_handler({'strict_no_charge': True})['ok']
    row = runtime.get_store().get_capability('openrouter', model)
    assert router.preview(now=row['expires_at'])['chosen'] is None
    payload['discovery_acceptance'] = {'provider': 'openrouter', 'model': model,
        'selected': selected, 'catalog_paths': calls, 'expired_rejected': True,
        'strict_guarantee_rejected': True, 'provider_transport': 'synthetic',
        'live_entitlement_verified': False}


if sys.argv[2] == "picker-a":
    # MODE A acceptance: an explicit picker selection ("auto-free") resolves to
    # a physical, verified-free route through the REAL host middleware and the
    # REAL AutoRouter consumer shipped in the artifact. No mocks of the
    # routing decision; only catalog transport and synthetic keys are faked.
    import importlib
    from io import BytesIO
    from hermes_cli import urllib_security
    from hermes_cli.plugins import has_middleware, invoke_middleware

    def _host_seam_supported():
        try:
            from hermes_cli.middleware import (PRE_INFERENCE_ROUTE_MIDDLEWARE, VALID_MIDDLEWARE,
                                               apply_pre_inference_route_middleware)
            return PRE_INFERENCE_ROUTE_MIDDLEWARE in VALID_MIDDLEWARE and callable(apply_pre_inference_route_middleware)
        except Exception:
            return False

    if not has_middleware('pre_inference_route'):
        # This worker runs before pytest's skip plumbing sees the file: emit the
        # skip marker on genuinely unsupported hosts (v0.23.1) — and fail hard on a
        # host that supports the seam but registered nothing.
        if _host_seam_supported():
            raise RuntimeError(
                "host supports the pre_inference_route seam but the plugin's consumer did not register "
                "(enable_chat_router with native-capable host must yield a registered consumer)")
        result_path.write_text(json.dumps({"unsupported_host": True,
                                           "reason": "host exposes no sanctioned pre_inference_route extension"}))
        sys.exit(77)

    callback = next(cb for cb in manager._hooks['pre_api_request'] if cb.__module__.endswith('.runtime'))
    runtime = importlib.import_module(callback.__module__)
    adapters = importlib.import_module(_core(runtime) + '.discovery.adapters')
    tools = importlib.import_module(_core(runtime) + '.integration.tools')

    catalog = {
        'data': [
            {'id': 'fixture/openrouter-picker-free', 'context_length': 32000,
             'supported_parameters': ['tools'], 'pricing': {'prompt': '0', 'completion': '0'}},
        ]
    }
    calls = []

    def native_openrouter_catalog(request, timeout):
        assert request.full_url == 'https://openrouter.ai/api/v1/models'
        assert request.get_method() == 'GET'
        assert not request.has_header('Authorization')
        calls.append('native_catalog')
        return BytesIO(json.dumps(catalog).encode())

    def public_metadata(url, headers):
        assert url == 'https://openrouter.ai/api/v1/models'
        assert headers == {'Accept': 'application/json'}
        calls.append('public_capability_metadata')
        return catalog

    urllib_security.open_credentialed_url = native_openrouter_catalog
    adapters._read_json = public_metadata
    assert tools._refresh_handler({})['ok']
    store = runtime.get_store()
    rows = [row for row in store.get_catalog() if row['provider'] == 'openrouter']
    assert any(row['model'] == 'fixture/openrouter-picker-free' for row in rows)

    # The virtual identifier must resolve to the physical fixture model.
    results = invoke_middleware('pre_inference_route',
                                session_id='picker-session',
                                platform='tui',
                                hermes_profile='default',
                                requested_model='auto-free',
                                requested_provider='autorouter',
                                explicit_model=True,
                                selection_mode='manual')
    assert len(results) == 1, results
    route = results[0]
    assert route['status'] == 'route', route
    assert route['provider'] == 'openrouter'
    assert route['model'] == 'fixture/openrouter-picker-free'
    assert route['model'] != 'auto-free'
    assert route['model'] != 'autorouter/auto-free'

    # MODE B isolation: the ordinary-session seam returns passthrough with
    # enable_native_routing off — the MODE A flag never widens into it.
    ordinary = invoke_middleware('pre_inference_route',
                                 session_id='picker-ordinary-session',
                                 platform='tui',
                                 hermes_profile='default',
                                 requested_model='openai/gpt-5.5',
                                 requested_provider='openai',
                                 explicit_model=False)
    assert len(ordinary) == 1
    assert ordinary[0]['status'] == 'passthrough'
    assert ordinary[0]['model'] is None

    payload['picker_mode_a'] = dict(
        registered=True,
        route_provider=route['provider'],
        route_model=route['model'],
        mode_b_passthrough=True,
        wire_never_carries_virtual_id=True,
        catalog_calls=calls,
    )

if sys.argv[2] == "policy-contract":
    import importlib
    callback = next(cb for cb in manager._hooks['pre_api_request'] if cb.__module__.endswith('.runtime'))
    runtime = importlib.import_module(callback.__module__)
    tools = importlib.import_module(_core(runtime) + '.integration.tools')
    router_module = importlib.import_module(_core(runtime) + '.routing.router')
    policy = json.loads((Path(__file__).resolve().parents[1] / 'fixtures/selection-policy-v1.json').read_text())['request']
    router = runtime.get_router()
    router.state['providers'] = ['openrouter']
    store = router.store
    store.upsert_catalog('openrouter', 'isolated-policy-model', 32000, {'tools':True}, 'free')
    proof = dict(provider='openrouter',model='isolated-policy-model',context_window=32000,tools='supported',
        cost_tier='free',metadata_source='isolated synthetic fixture',retrieved_at=100,expires_at=220)
    store.upsert_capability('openrouter','isolated-policy-model',json.dumps(proof),retrieved_at=100,expires_at=220)
    router_module.time.time = lambda: 150.0
    before = store.db_path.read_bytes()
    preview = router.preview(now=150,selection_policy=policy)
    assert store.db_path.read_bytes() == before
    selected = tools._select_handler({'requires_tools':False,'selection_policy':policy})
    assert selected['decision'] == preview
    assert selected['decision']['evidence_report'] == preview['evidence_report']
    assert preview['evidence_report']['schema_version'] == 1
    assert not preview['evidence_report']['execution_authority']
    assert selected['model'] == 'isolated-policy-model'
    assert preview['semantic_quality'] == 'unknown' and not preview['execution_authority']
    strict = dict(policy,quota_policy='require_fresh_account_allowance')
    assert router.preview(now=150,selection_policy=strict)['chosen'] is None
    for profile_id in ('general', 'coding', 'fast-response'):
        import copy
        profiled = copy.deepcopy(policy)
        profiled['task_requirements'].update(label=profile_id,profile=dict(schema_version=1,id=profile_id))
        profiled['preferences']['policy'] = 'fast-response' if profile_id == 'fast-response' else 'general'
        before_profile = store.db_path.read_bytes()
        profile_preview = router.preview(now=150,selection_policy=profiled)
        assert store.db_path.read_bytes() == before_profile
        assert tools._select_handler({'selection_policy':profiled})['decision'] == profile_preview
        assert profile_preview['chosen'] and profile_preview['task_profile']['id'] == profile_id
        assert profile_preview['semantic_quality'] == 'unknown'
    # Actual registered observer callbacks, with synthetic final outcomes and no transport.
    pre = next(cb for cb in manager._hooks['pre_api_request'] if cb.__module__.endswith('.runtime'))
    post = next(cb for cb in manager._hooks['post_api_request'] if cb.__module__.endswith('.runtime'))
    error = next(cb for cb in manager._hooks['api_request_error'] if cb.__module__.endswith('.runtime'))
    observation = dict(api_request_id='isolated-coverage-success',provider='openrouter',model='isolated-policy-model')
    pre(**observation)
    post(**observation,latency_ms=100,status_code=200)
    failed = dict(api_request_id='isolated-coverage-error',provider='openrouter',model='unlisted-failure-model')
    pre(**failed)
    error(**failed,status_code=500,retryable=False,latency_ms=500)
    assert store.get_scoring_observations('openrouter','unlisted-failure-model')['rows'][0]['status'] == 'error'
    trace_module=importlib.import_module(_core(runtime) + '.telemetry.request_trace')
    outcomes=[]
    for identity in ('isolated-coverage-success','isolated-coverage-error'):
        rid=store.find_request_by_api_id(identity)
        trace=trace_module.build(store.get_request(rid),store.get_request_attempts(rid))
        assert trace['decision']['state']==trace['apply']['state']=='unavailable'
        assert trace['end_to_end_correlation']=='unavailable'
        assert trace['metrics']['input_tokens']['state']=='unavailable'
        outcomes.append(trace['completion']['outcome'])
    payload['request_trace']=dict(outcomes=outcomes,actual_registered_hooks=True,decision_apply='unavailable',synthetic_callbacks=True)
    measured = router.preview(now=150,selection_policy=policy)
    coverage = measured['chosen']['score']['coverage']
    assert coverage['samples'] == 1 and coverage['state'] == 'sample_limited'
    assert coverage['attribution'] == 'unknown' and not coverage['active_account_authority']
    assert tools._select_handler({'requires_tools':False,'selection_policy':policy})['decision'] == measured
    adapter_module=importlib.import_module(_core(runtime) + '.routing.execution_adapter')
    adapter=adapter_module.ManualHermesAdapter(router)
    target=dict(schema_version=1,provider=measured['chosen']['provider'],model=measured['chosen']['model'],generated_at=150)
    before_handoff=store.db_path.read_bytes()
    receipt=adapter.handoff(target,confirmed=True,selection_policy=policy,now=150)
    assert receipt['state']=='manual_handoff_pending' and not receipt['applied'] and not receipt['executed']
    assert store.db_path.read_bytes()==before_handoff
    from hermes_cli._parser import build_top_level_parser
    parsed=build_top_level_parser()[0].parse_args(receipt['manual_argv'][1:])
    assert parsed.provider==target['provider'] and parsed.model==target['model']
    assert adapter.apply(target)['state']==adapter.restore(target)['state']=='unavailable_evidence'
    assert store.db_path.read_bytes()==before_handoff
    payload['manual_handoff']=dict(parser_target_matches=True,host_apply=False,actual_request_target='unobserved')
    payload['observation_coverage'] = dict(samples=1,actual_registered_hooks=True,synthetic_callbacks=True,active_account_authority=False)
    payload['task_profiles'] = dict(profiles=3,parity=True,execution_authority=False)
    payload['policy_contract'] = dict(schema_version=1,parity=True,model=selected['model'],
        missing_authority_denied=True,execution_authority=False)
if sys.argv[2] == "policy-contract":
    denied_request=dict(api_request_id='isolated-health-denial',provider='openrouter',model='isolated-policy-model')
    pre(**denied_request)
    error(**denied_request,status_code=401,retryable=False)
    denied_preview=router.preview(now=150,selection_policy=policy)
    guidance=denied_preview['considered'][0]['health_guidance']
    assert denied_preview['chosen'] is None and guidance['category']=='authentication'
    assert guidance['account_binding']=='unknown' and guidance['observed_at']==150
    assert guidance['provider_retry_after'] is None and not guidance['automatic_retry']
    payload['health_guidance']=dict(observed_auth_denial=True,account_binding='unknown',actual_registered_hook=True)
if sys.argv[2] == "first-use":
    import importlib, importlib.util
    from io import BytesIO
    api_path=Path(os.environ['HERMES_HOME'])/'plugins/autorouter/dashboard/plugin_api.py'
    api_spec=importlib.util.spec_from_file_location('_first_use_host_api',api_path)
    api=importlib.util.module_from_spec(api_spec)
    api_spec.loader.exec_module(api)
    initial=api._sr.assemble_first_use()
    if not loaded.enabled or not active:
        assert initial['stage']=='activation_required' and not initial['ready_for_recommendation']
        assert not (Path(os.environ['HERMES_HOME'])/'autorouter-state/autorouter.db').exists()
        payload['first_use']=dict(initial=initial['stage'],ready=False,provider_transport='none')
    else:
        callback=next(cb for cb in manager._hooks['pre_api_request'] if cb.__module__.endswith('.runtime'))
        runtime=importlib.import_module(callback.__module__)
        tools=importlib.import_module(_core(runtime) + '.integration.tools')
        r=runtime.get_router()
        if not r.state['providers']:
            assert initial['stage'] in ('providers_required', 'configuration_unavailable')
            assert tools._refresh_handler({})['ok']
            assert not r.state['providers']
            assert not tools._select_handler({'requires_tools':False})['ok']
            payload['first_use']=dict(initial=initial['stage'],ready=False,provider_transport='none')
        else:
            assert initial['stage']=='catalog_refresh_required'
            from hermes_cli import urllib_security
            adapters=importlib.import_module(_core(runtime) + '.discovery.adapters')
            catalog={'data':[{'id':'fixture/first-use-model','context_length':32000,'supported_parameters':['tools'],'pricing':{'prompt':'0','completion':'0'}}]}
            calls=[]
            def native_catalog(request,timeout):
                assert request.full_url=='https://openrouter.ai/api/v1/models'
                calls.append('native_catalog')
                return BytesIO(json.dumps(catalog).encode())
            def public_metadata(url,headers):
                assert url=='https://openrouter.ai/api/v1/models'
                assert headers == {'Accept': 'application/json'}
                calls.append('public_capability_metadata')
                return catalog
            urllib_security.open_credentialed_url=native_catalog
            adapters._read_json=public_metadata
            assert tools._refresh_handler({})['ok']
            refreshed=api._sr.assemble_first_use()
            assert refreshed['stage']=='recommendation_ready'
            assert refreshed['recommendation']['model']=='fixture/first-use-model'
            assert all(p['authentication']=='unverified' for p in refreshed['providers'])
            assert refreshed['execution_capabilities']['host_confirmed_apply'] is False
            assert refreshed['execution_authority'] is False
            assert calls==['native_catalog','public_capability_metadata']
            payload['first_use']=dict(initial=initial['stage'],ready=True,provider_transport='synthetic',live_entitlement=False)
if sys.argv[2] in ("discovery-all", "discovery-all-partial"):
    import importlib, importlib.util
    from io import BytesIO
    from urllib.parse import urlsplit, parse_qs
    from hermes_cli import urllib_security
    callback=next(cb for cb in manager._hooks['pre_api_request'] if cb.__module__.endswith('.runtime'))
    runtime=importlib.import_module(callback.__module__)
    adapters=importlib.import_module(_core(runtime) + '.discovery.adapters')
    tools=importlib.import_module(_core(runtime) + '.integration.tools')
    keys={name:'SYNTHETIC_CATALOG_ONLY_'+name for name in ('nvidia','groq','gemini','mistral')}
    for name,variable in (('nvidia','NVIDIA_API_KEY'),('groq','GROQ_API_KEY'),('gemini','GEMINI_API_KEY'),('mistral','MISTRAL_API_KEY')):
        os.environ[variable]=keys[name]
    # OpenRouter catalog is public; no key is supplied or inferred.
    catalogs={
        'nvidia':{'data':[{'id':'fixture/nvidia-catalog'}]},
        'openrouter':{'data':[{'id':'fixture/openrouter-free','context_length':32000,'supported_parameters':['tools'],'pricing':{'prompt':'0','completion':'0'}}]},
        'groq':{'data':[{'id':'fixture/groq-catalog','active':True}]},
        'gemini':{'models':[{'name':'models/fixture-gemini-catalog','inputTokenLimit':32000,'supportedGenerationMethods':['generateContent']}]},
        'mistral':{'data':[{'id':'fixture/mistral-catalog','max_context_length':32000,'capabilities':{'function_calling':True}}]},
    }
    calls=[]
    partial=sys.argv[2]=='discovery-all-partial'
    def native_catalog(request,timeout):
        assert request.get_method()=='GET'
        name={'https://integrate.api.nvidia.com/v1/models':'nvidia','https://openrouter.ai/api/v1/models':'openrouter'}[request.full_url]
        assert request.get_header('Authorization')==('Bearer '+keys[name] if name=='nvidia' else None)
        calls.append(name)
        return BytesIO(json.dumps(catalogs[name]).encode())
    def bounded_catalog(url,headers):
        parsed=urlsplit(url)
        endpoint=parsed.scheme+'://'+parsed.netloc+parsed.path
        if endpoint=='https://openrouter.ai/api/v1/models':
            assert headers=={'Accept':'application/json'}
            name='openrouter'
        else:
            name=next(name for name,spec in adapters.SPECS.items() if endpoint==spec[0])
            assert headers.get('x-goog-api-key' if name=='gemini' else 'Authorization')==(keys[name] if name=='gemini' else 'Bearer '+keys[name])
            if name=='gemini':assert parse_qs(parsed.query)=={'pageSize':['1000']}
        assert all(key not in url for key in keys.values())
        calls.append(name)
        if partial and name=='groq':raise adapters.DiscoveryError('authentication')
        return catalogs[name]
    urllib_security.open_credentialed_url=native_catalog
    adapters._read_json=bounded_catalog
    result=tools._refresh_handler({})
    assert result['ok'] is True
    store=runtime.get_store()
    counts={name:sum(row['provider']==name for row in store.get_catalog()) for name in catalogs}
    assert counts=={name:0 if partial and name=='groq' else 1 for name in catalogs}
    assert sorted(calls)==sorted(['nvidia','openrouter','openrouter','groq','gemini','mistral'])
    api_path=Path(os.environ['HERMES_HOME'])/'plugins/autorouter/dashboard/plugin_api.py'
    api_spec=importlib.util.spec_from_file_location('_all_provider_artifact_api',api_path)
    api=importlib.util.module_from_spec(api_spec);api_spec.loader.exec_module(api)
    models=api._sr.assemble_models()
    assert models['preview']['chosen']['provider']=='openrouter'
    assert all(row['eligible'] is False and row['cost_tier']=='unknown' for row in models['models'] if row['provider']!='openrouter')
    inventory=api._sr.assemble_connections()
    # Six discovery integrations incl. Nous Portal; this disposable home neither
    # configures nous nor holds any Nous OAuth state. Presence is probed
    # read-only: the probe is truthful ('not_observed' here) and the operator
    # reason is the missing authorization, never a claimed credential state.
    # The inventory is complete: adapter-backed rows stay six; host-recognized
    # non-six rows (ADR-0016 Slice A) are visible too, with unknown capability axes.
    adapter_rows=[row for row in inventory['connections'] if row['family']=='llm_adapter']
    assert len(adapter_rows)==6
    non_six_adapters=[row for row in adapter_rows if row['provider_id'] not in ('nvidia','openrouter','groq','gemini','mistral','nous')]
    assert non_six_adapters==[]
    nous=next(r for r in inventory['connections'] if r['provider_id']=='nous')
    assert nous['presence']=='not_observed' and nous['reason']=='provider_not_authorized'
    assert nous['credential_source_scope']=='hermes_oauth_store' and nous['masked_credential'] is None
    assert all(row['verification']=='unverified' for row in inventory['connections'])
    guide=api._sr.assemble_first_use()
    assert guide['stage']=='recommendation_ready'
    assert guide['evidence']['provider_refresh_outcome']=='unknown'
    assert ('groq' in guide['evidence']['configured_providers_without_displayed_models']) is partial
    assert all(row['authentication']=='unverified' and row['active_credential_binding']=='unknown' for row in guide['providers'])
    selected=tools._select_handler({'requires_tools':True})
    assert selected['provider']=='openrouter' and selected['model']=='fixture/openrouter-free'
    assert not tools._select_handler({'strict_no_charge':True})['ok']
    with store._connect() as db:
        dump='\n'.join(db.iterdump())
    assert all(key not in dump and key not in json.dumps(models) and key not in json.dumps(inventory) for key in keys.values())
    payload['five_provider_acceptance']=dict(counts=counts,partial_catalog=partial,catalog_calls=len(calls),selected_provider='openrouter',other_costs='unknown',authentication='unverified',live_entitlement=False,transport='synthetic',actual_registered_tool=True)
if sys.argv[2] == "dynamic-provider":
    # ADR-0016 Slice D: an authorized localhost mock provider OUTSIDE the
    # six adapter-backed set becomes discoverable through the host's own
    # provider registry; catalog evidence stays offline (seeded
    # models_dev_cache.json); unknown-cost models stay ineligible.
    import importlib
    import providers as _providers_runtime

    names = sorted(getattr(p, "name", "") for p in _providers_runtime.list_providers())
    payload["host_providers"] = names
    payload["mock_provider_host_recognized"] = "mockinfra" in names

    callback = next(cb for cb in manager._hooks["pre_api_request"] if cb.__module__.endswith(".runtime"))
    runtime = importlib.import_module(callback.__module__)
    core = _core(runtime)
    connections = importlib.import_module(core + ".providers.connections")
    discovery = importlib.import_module(core + ".discovery.discovery")
    elig = importlib.import_module(core + ".eligibility.eligibility")
    valid_list = importlib.import_module(core + ".providers.connections").valid_provider_list
    AUTHORIZED = os.environ.get("DYNAMIC_PROVIDER_AUTHORIZED", "0") == "1"
    providers_cfg = (["nvidia", "openrouter", "mockinfra"] if AUTHORIZED else ["nvidia", "openrouter"])
    config = {"available": True, "managed": False, "values": {"providers": list(providers_cfg)}}
    inventory = connections.inventory(config)
    rows = {row["provider_id"]: row for row in inventory["connections"]}
    six_adapters = [row for row in inventory["connections"] if row["family"] == "llm_adapter"]
    mock = rows.get("mockinfra")
    payload["six_adapter_rows"] = len(six_adapters)
    payload["mock_row"] = None if mock is None else {
        key: mock.get(key) for key in ("family", "authorized", "discovery", "presence",
                                       "usable_for_routing", "provider_id", "label",
                                       "authentication_requirement", "guidance")}
    payload["valid_list"] = valid_list(list(providers_cfg))

    discovered = discovery.discover_provider("mockinfra", store=None)
    discovered.sort(key=lambda r: r["model"])
    payload["discovered"] = [
        {"model": r["model"], "cost_tier": r["cost_tier"],
         "context_length": r["context_length"],
         "tools": (r.get("capabilities") or {}).get("tools")}
        for r in discovered
    ]
    item_free = next((r for r in discovered if r["model"] == "mockinfra-free-model"), None)
    item_unknown = next((r for r in discovered if r["model"] == "mockinfra-unknown-model"), None)
    payload["free_model_rejected"] = None if item_free is None else elig.rejection_reasons(
        {"provider": "mockinfra", "model": item_free["model"],
         "context_length": item_free["context_length"],
         "capabilities": item_free["capabilities"],
         "cost_tier": item_free["cost_tier"], "available": True},
        requires_tools=True, min_context=8192)
    payload["unknown_model_rejected"] = None if item_unknown is None else elig.rejection_reasons(
        {"provider": "mockinfra", "model": item_unknown["model"],
         "context_length": item_unknown["context_length"],
         "capabilities": item_unknown["capabilities"],
         "cost_tier": item_unknown["cost_tier"], "available": True},
        requires_tools=True, min_context=8192)

if sys.argv[2] == "selector-to-client":
    # ADR-0016 completion: an out-of-six provider becomes verified-free
    # selectable, selected through the real AutoRouter selector, handed to
    # the real Hermes AIAgent, and the resulting OpenAI wire request reaches
    # the mocked localhost mock — never anywhere else.
    import importlib

    SCENARIO = os.environ.get("SELECTOR_TO_CLIENT_SCENARIO", "positive-free")
    os.environ["AUTOROUTER_ALLOW_LOOPBACK"] = "127.0.0.1"

    import socket
    import threading
    from http.server import BaseHTTPRequestHandler, HTTPServer

    captured_requests = []

    class _Handler(BaseHTTPRequestHandler):
        def log_message(self, *a, **k):
            pass

        def do_POST(self):
            length = int(self.headers.get("Content-Length") or "0")
            raw = self.rfile.read(length) if length else b"{}"
            try:
                body = json.loads(raw.decode() or "{}")
            except Exception:
                body = {"malformed_body": raw[:128].decode(errors="replace")}
            captured_requests.append({"path": self.path,
                                      "model": body.get("model") if isinstance(body, dict) else None,
                                      "authorize": self.headers.get("Authorization"),
                                      "body": body})
            if self.headers.get("Authorization", "") != "Bearer fixture-mockinfra-key-synthetic":
                out = json.dumps({"error": {"message": "invalid API key", "type": "auth_error"}}).encode()
                self.send_response(401)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(out)))
                self.end_headers()
                self.wfile.write(out)
                self.wfile.flush()
                return
            # SSE chunked answer for chat completions (streaming-shaped)
            model = (body or {}).get("model", "mockinfra-free-model")
            chunks = [
                {"id": "chatcmpl-fixture", "object": "chat.completion.chunk", "created": 0,
                 "model": model,
                 "choices": [{"index": 0, "delta": {"role": "assistant", "content": "fixture-ok"},
                              "finish_reason": None}]},
                {"id": "chatcmpl-fixture", "object": "chat.completion.chunk", "created": 0,
                 "model": model,
                 "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]},
            ]
            encoded = ("".join(f"data: {json.dumps(c)}\n\n" for c in chunks) + "data: [DONE]\n\n").encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(encoded)
            self.wfile.flush()

    server = HTTPServer(("127.0.0.1", 0), _Handler)
    bound_port = server.server_address[1]
    threading.Thread(target=server.serve_forever, daemon=True).start()

    home = Path(os.environ["HERMES_HOME"])

    base_url = f"http://127.0.0.1:{bound_port}/v1"

    _PLUGIN = f"""from providers import register_provider
from providers.base import ProviderProfile

class MockInfraProfile(ProviderProfile):
    def fetch_models(self, **kwargs):
        # Fixture endpoint: enumerate the fixture catalog. Never touches the network.
        return ["mockinfra-free-model", "mockinfra-paid-model", "mockinfra-no-tools-model", "mockinfra-unknown-cost-model"]

mockinfra = MockInfraProfile(
    name="mockinfra",
    aliases=("mockinfra-alias",),
    env_vars=("MOCKINFRA_API_KEY",),
    display_name="MockInfra",
    description="disposable localhost fixture for selector-to-client acceptance",
    fallback_models=("mockinfra-free-model", "mockinfra-paid-model", "mockinfra-no-tools-model", "mockinfra-unknown-cost-model"),
    base_url="{base_url}",
    api_mode="chat_completions",
    auth_type="api_key",
    supports_model_listing=True,
    supports_health_check=False,
)
register_provider(mockinfra)
"""
    _MANIFEST = """name: mockinfra-provider
kind: model-provider
version: 1.0.0
description: disposable localhost fixture
author: autorouter acceptance fixture
"""
    provider_dir = home / "plugins" / "model-providers" / "mockinfra"
    # The post-removal subprocess shares the same isolated HERMES_HOME as the
    # pre-removal subprocess. Do not reinstall what the test just removed.
    if SCENARIO != "provider-removed-post":
        provider_dir.mkdir(parents=True, exist_ok=True)
        (provider_dir / "__init__.py").write_text(_PLUGIN)
        (provider_dir / "plugin.yaml").write_text(_MANIFEST)

    fresh_catalog = {"mockinfra": {"models": {
        "mockinfra-free-model": {"limit": {"context": 131072}, "tool_call": True,
                                   "cost": {"input": 0.0, "output": 0.0}},
        "mockinfra-free-model-variant": {"limit": {"context": 65536}, "tool_call": True,
                                   "cost": {"input": 0.0, "output": 0.0}},
        "mockinfra-paid-model": {"limit": {"context": 131072}, "tool_call": True,
                                  "cost": {"input": 1.0, "output": 2.0}},
        "mockinfra-no-tools-model": {"limit": {"context": 131072}, "tool_call": False,
                                  "cost": {"input": 0.0, "output": 0.0}},
        "mockinfra-unknown-cost-model": {"limit": {"context": 131072}, "tool_call": True,
                                  "cost": {}},
        "mockinfra-unknown-cost-again": {"limit": {"context": 131072}, "tool_call": True,
                                  "cost": {}},
    }}}

    cache_path = home / "models_dev_cache.json"
    scenario = SCENARIO

    def _write(_content, mtime=None):
        json_bytes = json.dumps(_content).encode()
        cache_path.write_bytes(json_bytes)
        if mtime is not None:
            os.utime(cache_path, (mtime, mtime))

    _FRESH_MODEL_META = {
        "mockinfra-free-model": {"limit": {"context": 131072}, "tool_call": True,
                                 "cost": {"input": 0.0, "output": 0.0}},
        "mockinfra-free-model-variant": {"limit": {"context": 65536}, "tool_call": True,
                                 "cost": {"input": 0.0, "output": 0.0}},
        "mockinfra-paid-model": {"limit": {"context": 131072}, "tool_call": True,
                                 "cost": {"input": 1.0, "output": 2.0}},
        "mockinfra-no-tools-model": {"limit": {"context": 131072}, "tool_call": False,
                                 "cost": {"input": 0.0, "output": 0.0}},
        "mockinfra-unknown-cost-model": {"limit": {"context": 131072}, "tool_call": True,
                                 "cost": {}},
        "mockinfra-unknown-cost-again": {"limit": {"context": 131072}, "tool_call": True,
                                 "cost": {}},
    }

    def _only(*names):
        return {"mockinfra": {"models": {n: _FRESH_MODEL_META[n] for n in names}}}
    if scenario == "stale-cache":
        _write(fresh_catalog, time.time() - 5 * 3600)
    elif scenario == "corrupt-cache":
        cache_path.write_bytes(b"{ not json")
    elif scenario == "unknown-cost":
        _write(_only("mockinfra-unknown-cost-model"))
    elif scenario == "tools-required-refuses-no-tools":
        _write(_only("mockinfra-no-tools-model"))
    elif scenario == "contradictory-pricing":
        _write({"mockinfra": {"models": {
            "mockinfra-free-model": {"limit": {"context": 131072}, "tool_call": True,
                                      "cost": {"input": 9.0, "output": 10.0}},
        }}})
    elif scenario == "min-context-high":
        _write(fresh_catalog)  # fresh, verified-free catalog; only the context gate should deny
    elif scenario == "min-context-low":
        _write(fresh_catalog)
    elif scenario == "provider-removed-pre":
        _write(fresh_catalog)  # fresh, verified-free catalog during the pre-removal phase
    elif scenario == "provider-removed-post":
        pass  # the plugin tree is absent on this run; refresh cannot find mockinfra
    else:
        _write(fresh_catalog)

    scene_configs = {
        "positive-free":            {"providers": ["nvidia", "openrouter", "mockinfra"]},
        "unauthorized":             {"providers": ["nvidia", "openrouter"]},
        "empty-allowlist":          {"providers": []},
        "invalid-provider":         {"providers": ["nvidia", "openrouter", "no-such-provider"]},
        # the removal lifecycle happens AFTER refresh; configuration authorises mockinfra first
        "provider-removed-pre":     {"providers": ["nvidia", "openrouter", "mockinfra"]},
        "provider-removed-post":    {"providers": ["nvidia", "openrouter", "mockinfra"]},
        "unsupported-tools":        {"providers": ["mockinfra"]},
        "stale-cache":              {"providers": ["nvidia", "openrouter", "mockinfra"]},
        "corrupt-cache":            {"providers": ["nvidia", "openrouter", "mockinfra"]},
        "unknown-cost":             {"providers": ["nvidia", "openrouter", "mockinfra"]},
        "contradictory-pricing":    {"providers": ["nvidia", "openrouter", "mockinfra"]},
        "requires-tools":           {"providers": ["mockinfra"]},
        "requires-tools-no-models": {"providers": ["mockinfra"]},
        "min-context-high":         {"providers": ["mockinfra"]},
        "min-context-low":          {"providers": ["mockinfra"]},
        "profile-excludes-mockinfra": {"providers": ["mockinfra"]},
        "routing-wrong-key":        {"providers": ["mockinfra"]},
        "registry-unavailable":     {"providers": ["nvidia", "openrouter", "mockinfra"]},
        "tools-required-refuses-no-tools": {"providers": ["mockinfra"]},
    }
    settings_extra = scene_configs.get(scenario, {"providers": ["mockinfra"]})
    payload["configured_authorization_providers"] = list(settings_extra["providers"])

    config = {"plugins": {"enabled": ["autorouter"],
               "entries": {"autorouter": {
                   "settings": {**settings_extra,
                   "enabled": True,
                   "free_only": True,
                   "state_dir": str(home / "autorouter-state")}}}}}

    (home / "config.yaml").write_text(json.dumps(config))

    select_args = {"requires_tools": True, "min_context": 8192}
    if scenario == "min-context-high":
        select_args["min_context"] = 400_000
    elif scenario in ("min-context-low", "positive-free"):
        select_args["min_context"] = 32768

    if scenario == "profile-excludes-mockinfra":
        # A route exclusions profile persists and encodes its authorized provider set.
        select_args = {"selection_policy": {
            "schema_version": 1,
            "hard_eligibility": {
                "verified_free_only": True,
                "required_capabilities": {},
                "min_context": 8192,
                "authorized_providers": ["nvidia", "openrouter"],
                "exclude": [],
                "max_in_flight": None,
                "health": {"respect_failures": True, "respect_cooldowns": True, "require_observed": False},
            },
            "preferences": {"policy": "auto"},
            "task_requirements": {
                "schema_version": 1,
                "label": "general",
                "required_capabilities": {},
                "min_context": 8192,
            },
            "connection_restrictions": {
                "provider_id": None,
                "connection_id": None,
                "require_authority": False,
                "models": [],
                "shared_quota_scope": None,
            },
            "quota_policy": "avoid_verified_exhaustion",
        }}

    if SCENARIO == "registry-unavailable":
        class _BrokenHostModule:
            def __getattr__(self, name):
                raise RuntimeError("host registry unavailable")
        sys.modules["providers"] = _BrokenHostModule()
        sys.modules["agent.models_dev"] = _BrokenHostModule()

    if SCENARIO == "routing-wrong-key":
        # Provider registration and resolver are happy with a wrong key — the mock rejects it.
        os.environ["MOCKINFRA_API_KEY"] = "fixture-wrong-key"

    if SCENARIO == "unresolvable-provider":
        import shutil as _shutil
        _shutil.rmtree(home / "plugins" / "model-providers" / "mockinfra", ignore_errors=True)

    manager = PluginManager()
    manager.discover_and_load()
    selected = {"ok": None}
    callback = next((cb for cb in manager._hooks.get("pre_api_request", []) if cb.__module__.endswith(".runtime")), None)
    runtime = None
    if callback is not None:
        runtime = importlib.import_module(callback.__module__)
    tools_mod = importlib.import_module(_core(runtime) + ".integration.tools") if runtime else None


    payload["registered"] = list(manager._plugins.keys())
    if SCENARIO in ("provider-removed-pre", "provider-removed-post"):
        # This is the host's authoritative model-provider registry, not the
        # unrelated core PluginManager's AutoRouter plugin list.
        from providers import list_providers
        payload["host_provider_names"] = sorted(profile.name for profile in list_providers())
    if tools_mod is not None:
        payload["refresh"] = tools_mod._refresh_handler({})
        selected = tools_mod._select_handler(select_args)
    payload["selection"] = selected

    if SCENARIO == "missing-credential":
        # Prove the selected model was eligible BEFORE revoking its credential.
        # Runtime resolution, not discovery's earlier eligibility decision,
        # must now reject the missing credential before a client is built.
        os.environ.pop("MOCKINFRA_API_KEY", None)

    if selected.get("ok") is True and SCENARIO in (
            "positive-free", "min-context-low", "routing-wrong-key", "missing-credential"):
        payload["runtime_resolution_attempted"] = True
        # Build the real AIAgent using the canonical host provider-runtime resolver:
        # the connection args come from the registered mockinfra profile — not from the test body.
        from run_agent import AIAgent
        from hermes_cli.runtime_provider import resolve_runtime_provider
        chosen = selected
        resolution_error = None
        runtime_entry = None
        try:
            runtime_entry = resolve_runtime_provider(requested=chosen["provider"], target_model=chosen["model"])
        except Exception as exc:
            resolution_error = f"{type(exc).__name__}: {exc}"
        payload["runtime_resolution_error"] = resolution_error
        if runtime_entry is not None:
            payload["runtime_provider"] = runtime_entry.get("provider")
            payload["runtime_source"] = runtime_entry.get("source")
            payload["runtime_requested_provider"] = runtime_entry.get("requested_provider")
            payload["runtime_base_url"] = runtime_entry.get("base_url")
            payload["runtime_api_key_present"] = bool(runtime_entry.get("api_key"))
            payload["runtime_api_mode"] = runtime_entry.get("api_mode")
            payload["runtime_api_key"] = runtime_entry.get("api_key")  # fixture credential — validated by host
            try:
                agent = AIAgent(model=chosen["model"], provider=chosen["provider"],
                                api_mode=runtime_entry.get("api_mode") or "",
                                api_key=runtime_entry.get("api_key") or "",
                                base_url=runtime_entry.get("base_url") or "",
                                platform="test", enabled_toolsets=[], quiet_mode=True,
                                skip_context_files=True, skip_memory=True,
                                skip_background_review=True, max_iterations=2, verbose_logging=False)
                reply = agent.chat("probe")
            except Exception as exc:
                reply = f"<agent-error:{type(exc).__name__}:{exc}>"
            payload["agent_reply"] = reply
            payload["agent_client_type"] = type(getattr(agent, "client", None)).__name__ if "agent" in locals() else None
        else:
            payload["agent_reply"] = f"<resolution-error:{resolution_error}>"
            payload["agent_client_type"] = None

    payload["captured_requests"] = captured_requests
    payload["ATTEMPTED_PROVIDER_REQUESTS"] = len(network_attempts)
    payload["COMPLETED_PROVIDER_REQUESTS"] = 0
    payload["LOCALHOST_ATTEMPTS"] = len(loopback_attempts)
    payload["CAPTURED_LOCALHOST_REQUESTS"] = len(captured_requests)
    payload["LOCALHOST_COMPLETED_REQUESTS"] = len(captured_requests)
    payload["SCENARIO"] = SCENARIO

if sys.argv[2] == "native-consumer":
    # ADR-0015/ADR-0016 completion for issue #126: the real consumer-driven
    # host session path. Nothing here constructs AIAgent directly with
    # AutoRouter's decision: the host's own ordinary-session agent factory
    # (tui_gateway.server._make_agent) builds the agent, the host resolves the
    # provider's credential and endpoint from its supported provider/credential
    # interfaces, and exactly one localhost SSE request may reach the mock.
    # Synthetic zero-cost price evidence is test-only; quota and account
    # entitlement remain UNKNOWN and are never asserted as verified.
    import importlib
    import sqlite3

    SCENARIO = os.environ.get("NATIVE_CONSUMER_SCENARIO", "positive-mode-b")
    os.environ["AUTOROUTER_ALLOW_LOOPBACK"] = "127.0.0.1"

    import socket
    import threading
    from http.server import BaseHTTPRequestHandler, HTTPServer

    captured_requests = []

    class _Handler(BaseHTTPRequestHandler):
        def log_message(self, *a, **k):
            pass

        def _reply_json(self, obj):
            encoded = json.dumps(obj).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(encoded)
            self.wfile.flush()

        def do_GET(self):
            # Loopback probe waterfall (ollama/lm-studio/llamacpp/vllm) fails
            # closed with 501; GET probes are host-owned local-server detection,
            # never inference, and are not counted as provider requests.
            self.send_response(501)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", "2")
            self.end_headers()
            self.wfile.write(b"{}")
            self.wfile.flush()

        def do_POST(self):
            length = int(self.headers.get("Content-Length") or "0")
            raw = self.rfile.read(length) if length else b"{}"
            try:
                body = json.loads(raw.decode() or "{}")
            except Exception:
                body = {"malformed_body": raw[:128].decode(errors="replace")}
            probe = self.path == "/api/show"
            captured_requests.append({"path": self.path,
                                      "model": body.get("model") if isinstance(body, dict) else None,
                                      "authorize": self.headers.get("Authorization"),
                                      "body": body, "method": "POST", "probe": probe})
            if probe:
                # The host's own local-server probe; answer deterministically.
                # Ollama's /api/show contract returns Modelfile text: `parameters`
                # is a newline-separated string, not an object.
                self._reply_json({"parameters": "num_ctx 131072"})
                return
            model = (body or {}).get("model", "mockinfra-free-model")
            chunks = [
                {"id": "chatcmpl-fixture", "object": "chat.completion.chunk", "created": 0,
                 "model": model,
                 "choices": [{"index": 0, "delta": {"role": "assistant", "content": "fixture-ok"},
                              "finish_reason": None}]},
                {"id": "chatcmpl-fixture", "object": "chat.completion.chunk", "created": 0,
                 "model": model,
                 "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}]},
            ]
            encoded = ("".join(f"data: {json.dumps(c)}\n\n" for c in chunks) + "data: [DONE]\n\n").encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(encoded)
            self.wfile.flush()

    server = HTTPServer(("127.0.0.1", 0), _Handler)
    bound_port = server.server_address[1]
    threading.Thread(target=server.serve_forever, daemon=True).start()
    home = Path(os.environ["HERMES_HOME"])
    base_url = f"http://127.0.0.1:{bound_port}/v1"

    # ---- the out-of-six localhost provider, a user model-provider plugin ----
    _PLUGIN = f"""from providers import register_provider
from providers.base import ProviderProfile

class MockInfraProfile(ProviderProfile):
    def fetch_models(self, **kwargs):
        return ["mockinfra-free-model", "mockinfra-paid-model", "mockinfra-no-tools-model", "mockinfra-unknown-cost-model"]

mockinfra = MockInfraProfile(
    name="mockinfra",
    aliases=("mockinfra-alias",),
    env_vars=("MOCKINFRA_API_KEY",),
    display_name="MockInfra",
    description="disposable localhost fixture for native consumer acceptance",
    fallback_models=("mockinfra-free-model", "mockinfra-paid-model", "mockinfra-no-tools-model", "mockinfra-unknown-cost-model"),
    base_url="{base_url}",
    api_mode="chat_completions",
    auth_type="api_key",
    supports_model_listing=True,
    supports_health_check=False,
)
register_provider(mockinfra)
"""
    _MANIFEST = """name: mockinfra-provider
kind: model-provider
version: 1.0.0
description: disposable localhost fixture
author: autorouter acceptance fixture
"""
    if SCENARIO != "provider-unrecognized":
        # provider-unrecognized: catalog rows exist but the host does NOT
        # know mockinfra — authorization evidence never becomes selection.
        provider_dir = home / "plugins" / "model-providers" / "mockinfra"
        provider_dir.mkdir(parents=True, exist_ok=True)
        (provider_dir / "__init__.py").write_text(_PLUGIN)
        (provider_dir / "plugin.yaml").write_text(_MANIFEST)

    if SCENARIO == "foreign-consumer":
        # A different plugin registers a pre_inference_route consumer; the
        # AutoRouter picker gate must ignore it (ownership, not presence).
        foreign_dir = home / "plugins" / "fakefeed"
        foreign_dir.mkdir(parents=True, exist_ok=True)
        (foreign_dir / "__init__.py").write_text(
            'def register(ctx):\n'
            '    ctx.register_middleware("pre_inference_route", lambda **kwargs: {"status": "route", "provider": "mockinfra", "model": "mockinfra-free-model", "reason": "foreign consumer route"})\n')
        (foreign_dir / "plugin.yaml").write_text(
            "name: fakefeed\nversion: 1.0.0\ndescription: foreign pre_inference_route consumer fixture\nkind: standalone\n")

    # ---- seed the plugin-data AutoRouter store with test-only evidence ------
    PLUGIN_ROOT = home / "plugins" / "autorouter"
    import importlib.util as _ilu

    _pkg_spec = _ilu.spec_from_file_location(
        "_autorouter_pkg_seed", PLUGIN_ROOT / "__init__.py",
        submodule_search_locations=[str(PLUGIN_ROOT)])
    _pkg = _ilu.module_from_spec(_pkg_spec)
    _pkg.__package__ = "_autorouter_pkg_seed"
    sys.modules["_autorouter_pkg_seed"] = _pkg
    _pkg_spec.loader.exec_module(_pkg)
    state_mod = importlib.import_module("_autorouter_pkg_seed.autorouter_core.storage.state")

    store_dir = home / "plugin-data" / "autorouter"
    store_dir.mkdir(parents=True, exist_ok=True)
    store = state_mod.StateStore(store_dir)

    FRESH = 1_700_000_000.0
    EXPIRY = 1_900_000_000.0
    PAST = 100.0

    def _seed(rows, *, evidence_expiry=EXPIRY, catalog_tier=None):
        for provider, model, ctx, tools, tier in rows:
            store.upsert_catalog(provider, model, ctx, {"tools": tools},
                                 catalog_tier or tier)
            evidence = {
                "provider": provider,
                "model": model,
                "field_evidence": {
                    field: {"metadata_source": "provider",
                            "retrieved_at": FRESH, "expires_at": evidence_expiry}
                    for field in ("context_window", "tools", "cost_tier")
                },
                "context_window": ctx,
                "tools": tools,
                "cost_tier": tier,
                "source": "provider",
            }
            store.upsert_capability(provider, model, json.dumps(evidence),
                                    retrieved_at=FRESH, expires_at=evidence_expiry)

    if SCENARIO == "price-unknown":
        _seed([("mockinfra", "mockinfra-unknown-cost-model", 131072, "supported", "unknown")])
    elif SCENARIO == "price-stale":
        _seed([("mockinfra", "mockinfra-free-model", 131072, "supported", "free")],
              evidence_expiry=PAST)
    elif SCENARIO == "price-conflicting":
        # Catalog row claims free; the persisted capability evidence is paid
        # and fresh. Evidence wins; the paid capability is never routed.
        _seed([("mockinfra", "mockinfra-free-model", 131072, "supported", "paid")],
              catalog_tier="free")
        store.upsert_catalog("mockinfra", "mockinfra-free-model", 131072,
                             {"tools": "supported"}, "free")
    elif SCENARIO == "model-lacks-tools":
        _seed([("mockinfra", "mockinfra-no-tools-model", 131072, "unsupported", "free")])
    elif SCENARIO == "context-insufficient":
        _seed([("mockinfra", "mockinfra-free-model", 131072, "supported", "free")])
    else:
        _seed([("mockinfra", "mockinfra-free-model", 131072, "supported", "free"),
               ("mockinfra", "mockinfra-paid-model", 131072, "supported", "paid"),
               ("mockinfra", "mockinfra-no-tools-model", 131072, "unsupported", "free"),
               ("mockinfra", "mockinfra-unknown-cost-model", 131072, "supported", "unknown")])
    if SCENARIO == "invalid-provider-list":
        # A verified-free nvidia row would win the route if the malformed
        # list were honored — the regression this repairs.
        _seed([("nvidia", "nvidia-free", 131072, "supported", "free")])

    # ---- a fresh models.dev cache stops the host's background refresh ------
    (home / "models_dev_cache.json").write_text(json.dumps(
        {"mockinfra": {"models": {
            "mockinfra-free-model": {"limit": {"context": 131072}, "tool_call": True,
                                     "cost": {"input": 0.0, "output": 0.0}},
            "mockinfra-paid-model": {"limit": {"context": 131072}, "tool_call": True,
                                     "cost": {"input": 1.0, "output": 2.0}},
            "mockinfra-no-tools-model": {"limit": {"context": 131072}, "tool_call": False,
                                         "cost": {"input": 0.0, "output": 0.0}},
            "mockinfra-unknown-cost-model": {"limit": {"context": 131072}, "tool_call": True,
                                             "cost": {}},
        }}}))

    providers_cfg = {
        "provider-unauthorized": ["nvidia", "openrouter"],
        "empty-allowlist": [],
        "invalid-provider-list": ["nvidia", "openrouter", "no-such-provider"],
        "provider-removed": ["nvidia", "openrouter"],
        "provider-unrecognized": ["mockinfra"],
        "credential-wrong-provider": ["mockinfra"],
    }.get(SCENARIO, ["mockinfra"])
    settings = {
        "enabled": SCENARIO != "plugin-disabled",
        "enable_native_routing": SCENARIO not in ("mode-b-flag-disabled", "foreign-consumer"),
        "enable_chat_router": SCENARIO not in ("mode-a-flag-disabled", "foreign-consumer"),
        "free_only": True,
        "providers": providers_cfg,
        "state_dir": str(home / "autorouter-state"),
        "requires_tools": True,
    }
    if SCENARIO == "context-insufficient":
        settings["min_context"] = 400_000
    if SCENARIO == "model-preference-none":
        settings["model_preference"] = {"mode": "none"}
    enabled_plugins = ["autorouter"] + (["fakefeed"] if SCENARIO == "foreign-consumer" else [])
    if SCENARIO == "plugin-absent":
        enabled_plugins = []
    config = {
        "plugins": {"enabled": enabled_plugins,
                    "entries": {"autorouter": {"settings": settings}}},
        "auxiliary": {"title_generation": {"enabled": False}},
    }
    if SCENARIO in ("mode-b-flag-disabled", "plugin-absent", "consumer-unloaded", "unsupported-host"):
        # Legitimate stock route to the loopback-pinned fixture model the
        # consumer would never choose (fails its tools gate).
        config["model"] = {"default": "mockinfra-no-tools-model", "provider": "mockinfra"}
    (home / "config.yaml").write_text(json.dumps(config))

    # ---- plugin load ----------------------------------------------------------
    # Load through the delivery manager the host itself uses — the same object
    # tui_gateway consults for has_middleware()/invoke_middleware(). A separate
    # PluginManager() instance would not model the host's delivery path.
    from hermes_cli.plugins import get_plugin_manager

    manager = get_plugin_manager()
    manager.discover_and_load()
    loaded = manager._plugins.get("autorouter")

    def _consumer_owners():
        owners = []
        for key, entries in (getattr(manager, "_ownership_ledger", {}) or {}).items():
            for entry in entries:
                if (getattr(entry, "kind", None) == "middleware"
                        and getattr(entry, "key", None) == "pre_inference_route"
                        and getattr(entry, "active", False)):
                    owners.append(key)
        return owners

    from providers import get_provider_profile

    unsupported_marker = None
    try:
        from hermes_cli import middleware as _mw

        unsupported_marker = hasattr(_mw, "PRE_INFERENCE_ROUTE_MIDDLEWARE")
    except Exception:
        unsupported_marker = False

    payload.update({
        "SCENARIO": SCENARIO,
        "plugin_loaded": bool(loaded),
        "plugin_enabled": bool(loaded.enabled) if loaded else None,
        "plugin_error": (str(loaded.error)[:512] if loaded and loaded.enabled and loaded.error else None),
        "consumer_owners": sorted(_consumer_owners()),
        "host_extension_present": unsupported_marker,
        "host_recognizes_provider": bool(get_provider_profile("mockinfra")),
        "network_blocked": True,
    })

    if SCENARIO == "issue128-negative-control":
        import run_agent

        def _boom(self, *args, **kwargs):
            raise RuntimeError("injected chat failure")

        run_agent.AIAgent.chat = _boom
        for label, build_mode in (("mode_a", "explicit-virtual"), ("mode_b", "ordinary")):
            from tui_gateway import server as tui_server

            kwargs = {"session_id": f"sess-issue128-{label}"}
            if build_mode == "explicit-virtual":
                kwargs["model_override"] = {"model": "auto-free", "provider": "autorouter"}
            try:
                agent = tui_server._make_agent(kwargs["session_id"], kwargs["session_id"], **kwargs)
            except Exception as exc:
                payload[f"{label}_client_constructed"] = 0
                payload[f"{label}_build_error"] = f"{type(exc).__name__}: {exc}"
                payload[f"{label}_chat_attempted"] = False
                continue
            payload[f"{label}_client_constructed"] = 1
            try:
                payload[f"{label}_reply"] = agent.chat("probe")
                payload[f"{label}_chat_attempted"] = True
            except Exception as exc:
                payload[f"{label}_chat_attempted"] = True
                payload[f"{label}_chat_error"] = f"{type(exc).__name__}: {exc}"
        payload["client_constructed"] = int(bool(payload.get("mode_a_client_constructed"))
                                            or bool(payload.get("mode_b_client_constructed")))
        payload["captured_requests"] = captured_requests
        payload["EXTERNAL_CONNECTION_ATTEMPTS"] = len(network_attempts)
        payload["EXTERNAL_COMPLETED_REQUESTS"] = 0
        payload["LOCALHOST_COMPLETED_REQUESTS"] = len(captured_requests)
        payload["DNS_EXTERNAL_ATTEMPTS"] = sum(1 for a in network_attempts if "getaddrinfo" in a)
        payload["CLIENT_CONSTRUCTED"] = payload["client_constructed"]
        result_path.write_text(json.dumps(payload))
        sys.exit(0)

    if SCENARIO == "issue128-revoke-values":
        # R5: after consumer registration, ANY non-True primary enabled must
        # refuse both modes, pre-client, zero outbound requests.
        import json as _json

        raw = _json.loads((home / "config.yaml").read_text())
        base_settings = raw["plugins"]["entries"]["autorouter"]["settings"]

        def _try_build(label, build_mode, settings):
            case = dict(settings)
            cfg = {**raw,
                   "plugins": {**raw["plugins"],
                               "entries": {"autorouter": {"settings": case}}}}
            (home / "config.yaml").write_text(_json.dumps(cfg))
            kwargs = {"session_id": f"sess-issue128-values-{label}"}
            if build_mode == "explicit-virtual":
                kwargs["model_override"] = {"model": "auto-free", "provider": "autorouter"}
            try:
                from tui_gateway import server as tui_server

                agent = tui_server._make_agent(kwargs["session_id"], kwargs["session_id"], **kwargs)
                try:
                    agent.chat("probe")
                except Exception:
                    pass
                return {"client_constructed": 1}
            except Exception as exc:
                return {"client_constructed": 0, "error": f"{type(exc).__name__}: {exc}"}

        bad_cases = [("false", False), ("missing", "__missing__"), ("null", None),
                     ("zero", 0), ("str-false", "false"), ("str-true", "true")]
        payload["bad_values"] = {}
        for name, bad in bad_cases:
            case = dict(base_settings)
            if bad == "__missing__":
                case.pop("enabled", None)
            else:
                case["enabled"] = bad
            payload["bad_values"][name] = {
                "mode_a": _try_build(f"a-{name}", "explicit-virtual", case),
                "mode_b": _try_build(f"b-{name}", "ordinary", case),
            }
        # restore the valid enabled config so the payload tells the truth
        (home / "config.yaml").write_text(_json.dumps(raw))
        payload["captured_requests"] = captured_requests
        payload["EXTERNAL_CONNECTION_ATTEMPTS"] = len(network_attempts)
        payload["EXTERNAL_COMPLETED_REQUESTS"] = 0
        payload["LOCALHOST_COMPLETED_REQUESTS"] = len(captured_requests)
        payload["DNS_EXTERNAL_ATTEMPTS"] = sum(1 for a in network_attempts if "getaddrinfo" in a)
        result_path.write_text(_json.dumps(payload))
        sys.exit(0)

    if SCENARIO == "issue128-revoke-enabled":
        # R3: the plugin is revoked (enabled: false) AFTER it registered;
        # both MODE A and MODE B must refuse with zero client construction.
        raw = json.loads((home / "config.yaml").read_text())
        raw["plugins"]["entries"]["autorouter"]["settings"]["enabled"] = False
        (home / "config.yaml").write_text(json.dumps(raw))
        for label, build_mode in (("mode_a", "explicit-virtual"), ("mode_b", "ordinary")):
            try:
                from tui_gateway import server as tui_server

                kwargs = {"session_id": f"sess-issue128-revoke-{label}"}
                if build_mode == "explicit-virtual":
                    kwargs["model_override"] = {"model": "auto-free", "provider": "autorouter"}
                agent = tui_server._make_agent(kwargs["session_id"], kwargs["session_id"], **kwargs)
            except Exception as exc:
                payload[f"{label}_client_constructed"] = 0
                payload[f"{label}_build_error"] = f"{type(exc).__name__}: {exc}"
                payload[f"{label}_chat_attempted"] = False
                continue
            payload[f"{label}_client_constructed"] = 1
            try:
                payload[f"{label}_reply"] = agent.chat("probe")
                payload[f"{label}_chat_attempted"] = True
            except Exception as exc:
                payload[f"{label}_chat_attempted"] = True
                payload[f"{label}_chat_error"] = f"{type(exc).__name__}: {exc}"
        payload["client_constructed"] = int(bool(payload.get("mode_a_client_constructed"))
                                            or bool(payload.get("mode_b_client_constructed")))
        payload["captured_requests"] = captured_requests
        payload["EXTERNAL_CONNECTION_ATTEMPTS"] = len(network_attempts)
        payload["EXTERNAL_COMPLETED_REQUESTS"] = 0
        payload["LOCALHOST_COMPLETED_REQUESTS"] = len(captured_requests)
        payload["DNS_EXTERNAL_ATTEMPTS"] = sum(1 for a in network_attempts if "getaddrinfo" in a)
        payload["CLIENT_CONSTRUCTED"] = payload["client_constructed"]
        result_path.write_text(json.dumps(payload))
        sys.exit(0)

    if SCENARIO == "issue128-corrupt-config-after-load":
        # Post-registration configuration invalidation (issue #128): the
        # operator's config becomes structurally invalid AFTER the consumer
        # was registered. Every attempt must refuse; the mock must see zero
        # requests and no client may be constructed.
        (home / "config.yaml").write_text("plugins: []\n")
        payload["consumer_owners_after_corruption"] = sorted(_consumer_owners())
        for label, build_mode in (("mode_a", "explicit-virtual"), ("mode_b", "ordinary")):
            from tui_gateway import server as tui_server

            kwargs = {"session_id": f"sess-issue128-{label}"}
            if build_mode == "explicit-virtual":
                kwargs["model_override"] = {"model": "auto-free", "provider": "autorouter"}
            # Construction and chat are tracked separately. A constructed
            # client is never "unconstructed" by a later chat failure.
            try:
                agent = tui_server._make_agent(kwargs["session_id"], kwargs["session_id"], **kwargs)
            except Exception as exc:
                payload[f"{label}_client_constructed"] = 0
                payload[f"{label}_build_error"] = f"{type(exc).__name__}: {exc}"
                payload[f"{label}_chat_attempted"] = False
                continue

            payload[f"{label}_client_constructed"] = 1
            try:
                payload[f"{label}_reply"] = agent.chat("probe")
                payload[f"{label}_chat_attempted"] = True
            except Exception as exc:
                payload[f"{label}_chat_attempted"] = True
                payload[f"{label}_chat_error"] = f"{type(exc).__name__}: {exc}"
        payload["client_constructed"] = int(bool(payload.get("mode_a_client_constructed"))
                                            or bool(payload.get("mode_b_client_constructed")))
        payload["captured_requests"] = captured_requests
        payload["EXTERNAL_CONNECTION_ATTEMPTS"] = len(network_attempts)
        payload["EXTERNAL_COMPLETED_REQUESTS"] = 0
        payload["LOCALHOST_COMPLETED_REQUESTS"] = len(captured_requests)
        payload["DNS_EXTERNAL_ATTEMPTS"] = sum(1 for a in network_attempts if "getaddrinfo" in a)
        payload["CLIENT_CONSTRUCTED"] = payload["client_constructed"]
        result_path.write_text(json.dumps(payload))
        sys.exit(0)

    def _build_and_chat(sid, build_mode="ordinary", override_model=None):
        from tui_gateway import server as tui_server

        kwargs = {"session_id": sid}
        if build_mode == "explicit-virtual":
            kwargs["model_override"] = {"model": "auto-free", "provider": "autorouter"}
        elif build_mode == "explicit-physical" and override_model:
            kwargs["model_override"] = {"model": override_model, "provider": "mockinfra"}
        return tui_server._make_agent(sid, sid, **kwargs)

    def _audit():
        dns_ext = sum(1 for a in network_attempts if "getaddrinfo" in a)
        dns_local = sum(1 for a in loopback_attempts if "getaddrinfo" in a)
        chat = sum(1 for r in captured_requests if r["path"] == "/v1/chat/completions")
        probes = len(captured_requests) - chat
        return {
            "EXTERNAL_CONNECTION_ATTEMPTS": len(network_attempts),
            "EXTERNAL_COMPLETED_REQUESTS": 0,
            "LOCALHOST_CONNECTION_ATTEMPTS": len(loopback_attempts),
            "LOCALHOST_COMPLETED_REQUESTS": len(captured_requests),
            "LOCALHOST_CHAT_COMPLETIONS": chat,
            "LOCALHOST_PROBE_REQUESTS": probes,
            "DNS_EXTERNAL_ATTEMPTS": dns_ext,
            "DNS_LOCALHOST_ATTEMPTS": dns_local,
            "CLIENT_CONSTRUCTED": payload.get("client_constructed", 0),
        }

    def _session_rows(session_id):
        db_path = home / "state.db"
        if not db_path.is_file():
            return []
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=5)
            try:
                rows = conn.execute(
                    "SELECT id, model FROM sessions WHERE id = ?", (session_id,)).fetchall()
            finally:
                conn.close()
            return [{"id": r[0], "model": r[1]} for r in rows]
        except Exception:
            return []

    def _binding_rows():
        try:
            conn = sqlite3.connect(f"file:{store_dir / 'autorouter.db'}?mode=ro", uri=True, timeout=5)
            try:
                rows = conn.execute(
                    "SELECT key FROM meta WHERE key LIKE 'native_route_binding:%'").fetchall()
            finally:
                conn.close()
            return len(rows)
        except Exception:
            return -1

    two_phase = SCENARIO in ("resume-invalidated", "two-sessions-different-policies", "profile-excludes")
    if two_phase:
        from tui_gateway import server as tui_server

        def _invalidate_capabilities():
            store2 = state_mod.StateStore(store_dir)
            with store2._connect() as conn:
                rows = conn.execute(
                    "SELECT model, capability_json FROM capabilities WHERE provider = 'mockinfra'").fetchall()
                for model, cap_json in rows:
                    try:
                        data = json.loads(cap_json)
                    except Exception:
                        continue
                    for info in (data.get("field_evidence") or {}).values():
                        if isinstance(info, dict):
                            info["retrieved_at"] = PAST
                            info["expires_at"] = PAST + 1
                    data["retrieved_at"] = PAST
                    data["expires_at"] = PAST + 1
                    conn.execute(
                        "UPDATE capabilities SET capability_json = ?, retrieved_at = ?, expires_at = ? "
                        "WHERE provider = 'mockinfra' AND model = ?",
                        (json.dumps(data), PAST, PAST + 1, model))
                conn.commit()

        def _make_profile(providers_list, name):
            profile_store = state_mod.RoutingProfileStore(store_dir)
            created = profile_store.create({
                "name": name,
                "description": "dispatch-131 acceptance fixture",
                "ranking_policy": "auto",
                "providers": providers_list,
                "model_include": [],
                "model_exclude": [],
                "min_context": 8192,
                "requires_tools": False,
                "health": {"respect_failures": True, "respect_cooldowns": True, "require_observed": False},
                "task_tags": [],
                "fallback_policy": "refuse",
            })
            profile_store.set_active(created["id"])
            return created

        sid = "sess-" + SCENARIO
        if SCENARIO == "profile-excludes":
            _make_profile(["nvidia", "openrouter"], "exclude-mockinfra-fixture")
            try:
                agent = tui_server._make_agent(sid, sid, session_id=sid)
                payload["client_constructed"] = 1
                payload["agent_reply"] = agent.chat("probe")
                payload["agent_model"] = agent.model
            except Exception as exc:
                payload["client_constructed"] = 0
                payload["error"] = f"{type(exc).__name__}: {exc}"
        elif SCENARIO == "two-sessions-different-policies":
            agent1 = tui_server._make_agent("sess-two-sessions-a", "sess-two-sessions-a",
                                            session_id="sess-two-sessions-a")
            payload["phase1_constructed"] = 1
            payload["phase1_model"] = agent1.model
            payload["phase1_reply"] = agent1.chat("probe")
            _make_profile(["nvidia", "openrouter"], "exclude-mockinfra-fixture")
            try:
                agent2 = tui_server._make_agent("sess-two-sessions-b", "sess-two-sessions-b",
                                                session_id="sess-two-sessions-b")
                payload["phase2_constructed"] = 1
                payload["phase2_model"] = agent2.model
                payload["phase2_reply"] = agent2.chat("probe")
            except Exception as exc:
                payload["phase2_constructed"] = 0
                payload["phase2_error"] = f"{type(exc).__name__}: {exc}"
            payload["session_rows_a"] = _session_rows("sess-two-sessions-a")
        elif SCENARIO == "resume-invalidated":
            agent1 = tui_server._make_agent("sess-resume-invalidated", "sess-resume-invalidated",
                                            session_id="sess-resume-invalidated")
            payload["phase1_constructed"] = 1
            payload["phase1_model"] = agent1.model
            payload["phase1_reply"] = agent1.chat("probe")
            _invalidate_capabilities()
            try:
                agent2 = tui_server._make_agent("sess-resume-invalidated", "sess-resume-invalidated",
                                                session_id="sess-resume-invalidated")
                payload["phase2_constructed"] = 1
                payload["phase2_model"] = agent2.model
                payload["phase2_reply"] = agent2.chat("probe")
            except Exception as exc:
                payload["phase2_constructed"] = 0
                payload["phase2_error"] = f"{type(exc).__name__}: {exc}"
            payload["session_rows_phase1"] = _session_rows("sess-resume-invalidated")
    else:
        sid = "sess-" + SCENARIO
        if SCENARIO == "consumer-unloaded":
            print("unloading autorouter consumer", flush=True)
            manager.unload("autorouter")
            payload["consumer_owners_after_unload"] = sorted(_consumer_owners())
            try:
                agent = _build_and_chat(sid, "ordinary")
                payload["client_constructed"] = 1
                payload["agent_model"] = agent.model
                payload["agent_reply"] = agent.chat("probe")
            except Exception as exc:
                payload["client_constructed"] = 0
                payload["error"] = f"{type(exc).__name__}: {exc}"
        elif SCENARIO == "unsupported-host":
            # MODE A pick on a host without the sanctioned seam: refuse.
            try:
                agent = _build_and_chat(sid, "explicit-virtual")
                payload["client_constructed"] = 1
                payload["agent_model"] = agent.model
            except Exception as exc:
                payload["client_constructed"] = 0
                payload["error"] = f"{type(exc).__name__}: {exc}"
            payload["mode_a_refused"] = payload.get("client_constructed") == 0
            # MODE B: no consumer → stock route (mockinfra-no-tools-model).
            try:
                agent = _build_and_chat(sid + "-stock", "ordinary")
                payload["stock_client_constructed"] = 1
                payload["stock_model"] = agent.model
                payload["stock_reply"] = agent.chat("probe")
            except Exception as exc:
                payload["stock_client_constructed"] = 0
                payload["stock_error"] = f"{type(exc).__name__}: {exc}"
        elif SCENARIO in ("positive-mode-a", "mode-a-flag-disabled", "plugin-disabled",
                          "plugin-absent", "foreign-consumer"):
            try:
                agent = _build_and_chat(sid, "explicit-virtual")
                payload["client_constructed"] = 1
                payload["agent_model"] = agent.model
                client = getattr(agent, "client", None)
                payload["client_base_url"] = str(getattr(client, "base_url", None)) if client is not None else None
                payload["agent_client_type"] = type(client).__name__
                payload["agent_reply"] = agent.chat("probe")
            except Exception as exc:
                payload["client_constructed"] = 0
                payload["error"] = f"{type(exc).__name__}: {exc}"
        elif SCENARIO == "explicit-physical-never-intercepted":
            agent = _build_and_chat(sid, "explicit-physical", "mockinfra-no-tools-model")
            payload["client_constructed"] = 1
            payload["agent_model"] = agent.model
            payload["agent_reply"] = agent.chat("probe")
            payload["binding_rows"] = _binding_rows()
        elif SCENARIO == "mode-b-flag-disabled":
            agent = _build_and_chat(sid, "ordinary")
            payload["client_constructed"] = 1
            payload["agent_model"] = agent.model
            payload["agent_reply"] = agent.chat("probe")
        else:  # positive-mode-b and all refusal scenarios (ordinary session)
            try:
                build_mode = "ordinary"
                agent = _build_and_chat(sid, build_mode)
                payload["client_constructed"] = 1
                payload["agent_model"] = agent.model
                client = getattr(agent, "client", None)
                payload["client_base_url"] = str(getattr(client, "base_url", None)) if client is not None else None
                payload["agent_client_type"] = type(client).__name__
                payload["agent_reply"] = agent.chat("probe")
                payload["session_rows"] = _session_rows(sid)
            except Exception as exc:
                payload["client_constructed"] = 0
                payload["error"] = f"{type(exc).__name__}: {exc}"

    wire = [{
        "path": r["path"],
        "model": r["model"],
        "authorize": r["authorize"],
        "probe": bool(r.get("probe")),
        "stream": (r["body"] or {}).get("stream"),
        "has_virtual_marker": any(
            marker in json.dumps(r["body"])
            for marker in ("auto-free", "autorouter/auto-free", "\"autorouter\"")
        ) if isinstance(r.get("body"), dict) else None,
    } for r in captured_requests]
    payload["captured_requests"] = wire
    payload.update(_audit())
    payload["binding_rows"] = _binding_rows()
    payload.update({
        "ELAPSED": None,
        "SCENARIO_DONE": True,
    })

payload["elapsed_seconds"] = time.monotonic() - started
payload["blocked_network_attempts"] = len(network_attempts)
payload["network_blocked"] = True
payload["blocked_process_attempts"] = len(process_attempts)
result_path.write_text(json.dumps(payload))
