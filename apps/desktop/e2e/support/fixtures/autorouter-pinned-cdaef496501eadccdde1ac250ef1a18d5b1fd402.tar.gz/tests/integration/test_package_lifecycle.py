"""Verified artifact placement; no native installer or live provider claim.

Two complementary lifecycle proofs, calibrated to what genuinely exists in
this repository's history:

* ``test_verified_package_lifecycle_preserves_profile_data`` — artifact
  mechanics (upgrade / rollback / removal / restoration) with the genuine
  predecessor artifact. Requires ``AUTOROUTER_TEST_PACKAGE`` (current
  artifact under test) and ``AUTOROUTER_PREVIOUS_PACKAGE`` (deployed
  predecessor). The predecessor's schema is derived from its own package
  manifest contents, never assumed; a cross-schema rollback pair or an
  undetectable schema is skipped with a precise reason, not failed.
* ``test_verified_package_lifecycle_migrates_authentic_schema4_fixture`` —
  schema-4 → current migration coverage built from a clearly labeled
  historical fixture: a database created at runtime by executing the real
  historical storage code (revision ``ab7fa52b55850f9fd6178e0b4ec77e551b055ee8``,
  the last commit whose storage layer reports ``SCHEMA_VERSION = 4``).
  This is not a released artifact — the deterministic packager landed
  after schema 4 — so no historical release zip exists to install; the
  fixture reproduces the historical schema faithfully by running the
  historical code itself.
"""

import importlib.util
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import types
import zipfile
from pathlib import Path

import pytest

# Last commit whose storage layer reports SCHEMA_VERSION = 4
# (autorouter_core/state.py at that revision; verified with git show).
HISTORICAL_SCHEMA4_REVISION = "ab7fa52b55850f9fd6178e0b4ec77e551b055ee8"


def _package_schema_version(path):
    """Schema version declared inside the artifact zip itself, or None."""
    try:
        with zipfile.ZipFile(path) as archive:
            for name in archive.namelist():
                if not name.endswith("state.py"):
                    continue
                match = re.search(
                    rb"SCHEMA_VERSION\s*=\s*(\d+)", archive.read(name)
                )
                if match:
                    return int(match.group(1))
    except (OSError, zipfile.BadZipFile):
        return None
    return None


def _records(db, schema):
    conn = sqlite3.connect(db)
    try:
        assert (
            conn.execute(
                "SELECT value FROM meta WHERE key='schema_version'"
            ).fetchone()[0]
            == str(schema)
        )
        assert "event_observed_at" in {
            row[1] for row in conn.execute("PRAGMA table_info(health_circuits)")
        }
        return (
            conn.execute("SELECT * FROM catalog").fetchall(),
            conn.execute("SELECT COUNT(*) FROM requests").fetchone(),
        )
    finally:
        conn.close()


def _checkpoint(db):
    """Force the host's committed WAL frames into the main file.

    Byte-level snapshots of the main file are only deterministic once
    the WAL is truncated; the host leaves checkpointing to the last
    connection's close, which is not guaranteed to leave the main
    file current.
    """
    conn = sqlite3.connect(db)
    try:
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    finally:
        conn.close()


def _insert_fixture_row(db):
    with sqlite3.connect(db) as conn:
        conn.execute(
            "INSERT INTO catalog(provider,model,context_length,capabilities,cost_tier,updated_at) "
            "VALUES('fixture','retained',8192,'{}','unknown',100)"
        )
    _checkpoint(db)


def _historical_schema4_fixture(tmp_path):
    """Create a genuine schema-4 database with the real historical code.

    Extracts the flat plugin layout of ``HISTORICAL_SCHEMA4_REVISION`` from
    git and instantiates its ``StateStore`` in a scratch directory. Returns
    the fixture database path. Skips with a precise reason when the git
    object is unavailable.
    """
    repo = Path(__file__).resolve().parents[2]
    try:
        listing = subprocess.check_output(
            ["git", "-C", str(repo), "ls-tree", "-r", "--name-only",
             HISTORICAL_SCHEMA4_REVISION],
            text=True,
            stderr=subprocess.PIPE,
        ).splitlines()
        sources = {
            name: subprocess.check_output(
                ["git", "-C", str(repo), "show",
                 f"{HISTORICAL_SCHEMA4_REVISION}:{name}"],
                stderr=subprocess.PIPE,
            )
            for name in listing
            if "/" not in name and name.endswith(".py")
        }
    except (subprocess.CalledProcessError, OSError) as exc:
        pytest.skip(
            f"authentic schema-4 migration fixture unavailable: git revision "
            f"{HISTORICAL_SCHEMA4_REVISION[:12]} is not readable in this checkout ({exc})"
        )
    fixture = tmp_path / "schema4-historical-source"
    fixture.mkdir()
    for name, data in sources.items():
        (fixture / name).write_bytes(data)

    package_name = "autorouter_schema4_hist"
    package = types.ModuleType(package_name)
    package.__path__ = [str(fixture)]
    saved = dict(sys.modules)
    sys.modules[package_name] = package
    try:
        spec = importlib.util.spec_from_file_location(
            f"{package_name}.state", fixture / "state.py"
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules[f"{package_name}.state"] = module
        spec.loader.exec_module(module)
        assert module.SCHEMA_VERSION == 4, (
            f"historical fixture {HISTORICAL_SCHEMA4_REVISION[:12]} reports "
            f"SCHEMA_VERSION={module.SCHEMA_VERSION}, expected 4"
        )
        store = module.StateStore(tmp_path / "schema4-fixture-state")
        return store.db_path
    finally:
        for name in list(sys.modules):
            if name == package_name or name.startswith(package_name + "."):
                del sys.modules[name]
        sys.modules.update(saved)


def test_verified_package_lifecycle_preserves_profile_data(isolated_host):
    previous = os.environ.get("AUTOROUTER_PREVIOUS_PACKAGE")
    current = os.environ.get("AUTOROUTER_TEST_PACKAGE")
    if not current or not previous:
        pytest.skip(
            "package lifecycle requires AUTOROUTER_TEST_PACKAGE and "
            "AUTOROUTER_PREVIOUS_PACKAGE (the deployed predecessor artifact); "
            "neither exists for schema 4, so schema-4 rollback is covered by "
            "the authentic-fixture test instead"
        )
    prev_schema = _package_schema_version(previous)
    current_schema = _package_schema_version(current)
    if prev_schema is None or current_schema is None:
        pytest.skip(
            "predecessor or current schema is undetectable from the artifact "
            "packages; refusing to assume schema versions"
        )
    if prev_schema != current_schema:
        pytest.skip(
            f"cross-schema rollback pair unavailable: predecessor schema "
            f"{prev_schema} vs current schema {current_schema}; no released "
            f"schema-{current_schema - 1} artifact exists to roll back with "
            f"(schema-4→current migration is covered by the "
            f"authentic-fixture test instead)"
        )

    default = isolated_host()
    assert default["host_enabled"] and not default["state_created"]
    # Establish a prior-version data snapshot before testing a schema upgrade.
    isolated_host(enabled=False, lifecycle="rollback")
    enabled = isolated_host(enabled=True)
    assert enabled["state_created"] and len(enabled["hooks"]) == 3
    db = Path(enabled["home"]) / "autorouter-state" / "autorouter.db"
    _insert_fixture_row(db)

    _checkpoint(db)
    before = _records(db, current_schema)
    snapshot = db.read_bytes()
    upgraded = isolated_host(enabled=True, lifecycle="upgrade")
    assert upgraded["state_created"] and _records(db, current_schema) == before
    # Restore the matching snapshot before loading the previous writer.
    # Drop stale WAL frames first: a checkpoint may not have run, and
    # replaying them against an older main file yields an undefined catalog.
    for suffix in ("-wal", "-shm"):
        db.with_suffix(db.suffix + suffix).unlink(missing_ok=True)
    db.unlink(missing_ok=True)
    db.write_bytes(snapshot)
    rolled_back = isolated_host(enabled=True, lifecycle="rollback")
    assert rolled_back["state_created"] and _records(db, prev_schema) == before
    upgraded = isolated_host(enabled=True, lifecycle="upgrade")
    assert upgraded["blocked_network_attempts"] == 0 and _records(
        db, current_schema
    ) == before
    removed = isolated_host(lifecycle="remove", installed=False)
    assert removed["plugin_absent"] and _records(db, current_schema) == before
    restored = isolated_host(enabled=True, lifecycle="restore")
    assert restored["state_created"] and _records(db, current_schema) == before


def test_verified_package_lifecycle_migrates_authentic_schema4_fixture(
    isolated_host, tmp_path
):
    current = os.environ.get("AUTOROUTER_TEST_PACKAGE")
    if not current:
        pytest.skip(
            "schema-4 migration requires AUTOROUTER_TEST_PACKAGE (the current "
            "artifact under test)"
        )
    current_schema = _package_schema_version(current)
    if current_schema is None:
        pytest.skip("current artifact does not declare a readable SCHEMA_VERSION")
    assert current_schema >= 6, f"expected current schema >= 6, got {current_schema}"

    fixture_db = _historical_schema4_fixture(tmp_path)

    isolated_host()
    enabled = isolated_host(enabled=True)
    home = Path(enabled["home"])
    state_dir = home / "autorouter-state"
    # Replace the fresh current-schema database with the authentic
    # historical schema-4 fixture database (host process has exited).
    for suffix in ("-wal", "-shm"):
        (state_dir / f"autorouter.db{suffix}").unlink(missing_ok=True)
    shutil.copy(fixture_db, state_dir / "autorouter.db")
    _insert_fixture_row(state_dir / "autorouter.db")
    before = _records(state_dir / "autorouter.db", 4)

    # Load the current artifact against the historical schema-4 database:
    # the plugin must migrate 4 -> current_schema, preserving all fixture data.
    upgraded = isolated_host(enabled=True, lifecycle="upgrade")
    assert upgraded["state_created"]
    assert _records(state_dir / "autorouter.db", current_schema) == before

    _checkpoint(state_dir / "autorouter.db")
    snapshot = (state_dir / "autorouter.db").read_bytes()
    upgraded = isolated_host(enabled=True, lifecycle="upgrade")
    assert upgraded["blocked_network_attempts"] == 0
    assert _records(state_dir / "autorouter.db", current_schema) == before

    removed = isolated_host(lifecycle="remove", installed=False)
    assert removed["plugin_absent"]
    assert _records(state_dir / "autorouter.db", current_schema) == before

    # Restore the migrated snapshot before loading the current writer again.
    for suffix in ("-wal", "-shm"):
        (state_dir / f"autorouter.db{suffix}").unlink(missing_ok=True)
    (state_dir / "autorouter.db").unlink(missing_ok=True)
    (state_dir / "autorouter.db").write_bytes(snapshot)
    restored = isolated_host(enabled=True, lifecycle="restore")
    assert restored["state_created"]
