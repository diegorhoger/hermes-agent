"""Actual SQLite and HTTP model previews share non-neutral routing observations."""
import json
import sqlite3
import time

import pytest
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.storage import state
from tests.test_dashboard_state_reader import sr
from tests.test_dashboard_api import _load_plugin_api

NOW = 150
SCOPES = ('', 'SENTINEL_ACCOUNT_REFERENCE_A', 'SENTINEL_ACCOUNT_REFERENCE_B')


def seeded_store(path):
    store = state.StateStore(path)
    for model in ('alpha','beta'):
        store.upsert_catalog('nvidia',model,16000,{'tools':True},'free')
        cap = dict(provider='nvidia',model=model,context_window=16000,tools='supported',cost_tier='free',
                   metadata_source='controlled-test-fixture',retrieved_at=100,expires_at=200)
        store.upsert_capability('nvidia',model,json.dumps(cap),retrieved_at=100,expires_at=200)
        for scope in SCOPES:
            success = (model == 'alpha') if scope == SCOPES[2] else (model == 'beta')
            for ordinal in range(10):
                request = store.begin_request(api_request_id=f'{scope}-{model}-{ordinal}',
                    provider='nvidia',model=model,key_scope=scope,started_at=140)
                store.record_attempt(request,0,provider='nvidia',model=model,
                    status_code=200 if success else 500,duration_ms=100 if success else 5000)
                store.finish_request(request,status='success' if success else 'error',ended_at=NOW,
                    latency_ms=100 if success else 5000)
    return store


@pytest.mark.parametrize('scope,expected', [(SCOPES[0],'beta'),(SCOPES[1],'beta'),(SCOPES[2],'alpha')])
def test_dashboard_and_router_frozen_preview_parity_with_actual_scoped_outcomes(tmp_path, monkeypatch, scope, expected):
    monkeypatch.setattr(time,'time',lambda:NOW)
    store = seeded_store(tmp_path)
    values = dict(state_dir=str(tmp_path),enabled=True,providers=['nvidia'],policy='auto',
                  free_only=True,credential_scopes={'nvidia':scope})
    config = dict(available=True,values=values,managed=False)
    monkeypatch.setattr(sr,'read_plugin_config',lambda:config)
    statements = []
    connect = sr._ro_connect
    def trace_readonly(path):
        conn = connect(path)
        if conn is not None:
            conn.set_trace_callback(statements.append)
        return conn
    monkeypatch.setattr(sr,'_ro_connect',trace_readonly)
    before = store.db_path.read_bytes()
    expected_preview = router.Router(dict(values,store=store)).preview(now=NOW)
    result = sr.assemble_models(now=NOW)
    assert result['preview'] == expected_preview
    assert result['preview']['chosen']['model'] == expected
    assert all(row['score']['observations']['samples'] == 10 for row in result['preview']['considered'])
    assert result['preview']['chosen']['score']['factors']['reliability']['value'] > .5
    assert all(sql.lstrip().upper().startswith('SELECT') for sql in statements)
    assert store.db_path.read_bytes() == before
    assert all(raw not in json.dumps(result) for raw in SCOPES[1:])

    # The actual FastAPI handler must carry the same SQLite evidence, not a mocked payload.
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    api = _load_plugin_api()
    monkeypatch.setattr(api._sr,'read_plugin_config',lambda:config)
    app = FastAPI()
    app.include_router(api.router,prefix='/api/plugins/autorouter')
    with TestClient(app) as client:
        response = client.get('/api/plugins/autorouter/models')
    assert response.status_code == 200
    assert response.json()['preview'] == expected_preview
    assert all(raw not in response.text for raw in SCOPES[1:])
    assert store.db_path.read_bytes() == before


def test_dashboard_missing_scoring_index_remains_readonly_and_does_not_migrate(tmp_path, monkeypatch):
    monkeypatch.setattr(time,'time',lambda:NOW)
    store = seeded_store(tmp_path)
    with store._connect() as conn:
        conn.execute('DROP INDEX idx_requests_scoring')
    monkeypatch.setattr(sr,'read_plugin_config',lambda:dict(available=True,managed=False,
        values=dict(state_dir=str(tmp_path),providers=['nvidia'],policy='auto',free_only=True)))
    before = store.db_path.read_bytes()
    result = sr.assemble_models(now=NOW)
    assert result['preview']['chosen']['model'] == 'alpha'  # Same documented prior as normal preview.
    assert result['preview'] == router.Router({'store':store,'providers':['nvidia']}).preview(now=NOW)
    assert not result['preview']['chosen']['score']['observations']['available']
    assert result['preview']['chosen']['score']['observations']['samples'] == 0
    assert store.db_path.read_bytes() == before
    with sqlite3.connect(store.db_path) as conn:
        assert conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name='idx_requests_scoring'").fetchone()[0] == 0


def test_legacy_raw_scope_health_denial_matches_readonly_router(tmp_path, monkeypatch):
    monkeypatch.setattr(time,'time',lambda:NOW)
    store = seeded_store(tmp_path)
    scope = SCOPES[1]
    with store._connect() as conn:
        conn.execute("INSERT INTO health(provider,model,key_scope,auth_failed) VALUES(?,?,?,1)",
                     ('nvidia','beta',scope))
        conn.execute("UPDATE meta SET value='2' WHERE key='schema_version'")
    values = dict(state_dir=str(tmp_path),providers=['nvidia'],policy='auto',free_only=True,
                  credential_scopes={'nvidia':scope})
    monkeypatch.setattr(sr,'read_plugin_config',lambda:dict(available=True,managed=False,values=values))
    before = store.db_path.read_bytes()
    result = sr.assemble_models(now=NOW)
    assert result['preview'] == router.Router(dict(values,store=store)).preview(now=NOW)
    beta = next(row for row in result['preview']['considered'] if row['model']=='beta')
    assert not beta['eligible'] and 'auth_failed' in beta['reason_codes']
    assert store.db_path.read_bytes() == before
    assert scope not in json.dumps(result)


def test_corrupt_typed_sqlite_health_is_denied_without_fabricated_auth(tmp_path, monkeypatch):
    from autorouter.autorouter_core.health import health
    monkeypatch.setattr(time,'time',lambda:NOW)
    store = seeded_store(tmp_path)
    private_body = 'PRIVATE_CORRUPT_HEALTH_VALUE'
    store.upsert_health('nvidia','beta',cooldown_until=private_body)
    values = dict(state_dir=str(tmp_path),providers=['nvidia'],policy='auto',free_only=True)
    config = dict(available=True,managed=False,values=values)
    monkeypatch.setattr(sr,'read_plugin_config',lambda:config)
    observed = health.decision(store,'nvidia','beta',now=NOW)
    assert not observed['available'] and observed['reason'] == 'health_invalid'
    assert not observed['health'].get('auth_failed')
    before = store.db_path.read_bytes()
    expected = router.Router(dict(values,store=store)).preview(now=NOW)
    result = sr.assemble_models(now=NOW)
    assert result['preview'] == expected
    beta = next(row for row in result['models'] if row['model']=='beta')
    assert not beta['eligible']
    assert 'health_invalid' in beta['reason_codes'] and 'auth_failed' not in beta['reason_codes']
    assert beta['health']['reason'] == 'health_invalid' and not beta['health']['auth_failed']
    overview = sr.assemble_overview(now=NOW)
    assert overview['counts']['healthy'] == 0
    assert overview['counts']['health_unknown'] == 1
    assert overview['counts']['health_invalid'] == 1
    assert overview['counts']['auth_failed'] == overview['counts']['cooldown'] == 0
    assert private_body not in json.dumps(result) + json.dumps(overview)
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    api = _load_plugin_api()
    monkeypatch.setattr(api._sr,'read_plugin_config',lambda:config)
    app = FastAPI()
    app.include_router(api.router,prefix='/api/plugins/autorouter')
    with TestClient(app) as client:
        models = client.get('/api/plugins/autorouter/models')
        summary = client.get('/api/plugins/autorouter/overview')
    assert models.status_code == summary.status_code == 200
    assert models.json()['preview'] == expected
    assert summary.json()['counts']['health_invalid'] == 1
    assert summary.json()['counts']['healthy'] == 0
    assert summary.json()['counts']['health_unknown'] == 1
    assert private_body not in models.text + summary.text
    assert store.db_path.read_bytes() == before


def test_legacy_error_body_is_not_reexposed_by_readonly_api_or_preview(tmp_path, monkeypatch):
    monkeypatch.setattr(time,'time',lambda:NOW)
    store = seeded_store(tmp_path)
    private_body = 'Credential SENTINEL_LEGACY_PRIVATE_CREDENTIAL rejected by provider'
    with store._connect() as conn:
        conn.execute("INSERT INTO health(provider,model,key_scope,failures,last_status,last_error,last_failure_at) VALUES('nvidia','alpha','',1,500,?,140)", (private_body,))
        conn.execute("UPDATE meta SET value='2' WHERE key='schema_version'")
    values = dict(state_dir=str(tmp_path),providers=['nvidia'],policy='auto',free_only=True)
    config = dict(available=True,managed=False,values=values)
    monkeypatch.setattr(sr,'read_plugin_config',lambda:config)
    before = store.db_path.read_bytes()
    model_result = sr.assemble_models(now=NOW)
    overview = sr.assemble_overview(now=NOW)
    assert private_body not in json.dumps(model_result) + json.dumps(overview)
    assert next(row for row in model_result['models'] if row['model']=='alpha')['health']['last_error'] == 'legacy_error'
    assert overview['recent_failures'][0]['error'] == 'legacy_error'
    expected = router.Router(dict(values,store=store)).preview(now=NOW)
    assert model_result['preview'] == expected
    assert store.get_health('nvidia','alpha')['last_error'] == 'legacy_error'
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    api = _load_plugin_api()
    monkeypatch.setattr(api._sr,'read_plugin_config',lambda:config)
    app = FastAPI()
    app.include_router(api.router,prefix='/api/plugins/autorouter')
    with TestClient(app) as client:
        models = client.get('/api/plugins/autorouter/models')
        summary = client.get('/api/plugins/autorouter/overview')
    assert models.status_code == summary.status_code == 200
    assert private_body not in models.text + summary.text
    assert store.db_path.read_bytes() == before
    with sqlite3.connect(store.db_path) as conn:
        assert conn.execute("SELECT last_error FROM health WHERE model='alpha'").fetchone()[0] == private_body
        assert conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0] == '2'


def test_legacy_telemetry_error_fields_use_existing_allowlist_without_writes(tmp_path, monkeypatch):
    monkeypatch.setattr(time,'time',lambda:NOW)
    store = state.StateStore(tmp_path)
    ids = []
    sentinels = ('OPAQUE_LEGACY_CREDENTIAL_SENTINEL_83','ANOTHER_PRIVATE_UPSTREAM_BODY_91')
    for i, private_body in enumerate(sentinels):
        request = store.begin_request(api_request_id=f'legacy-{i}',provider='nvidia',model='alpha')
        ids.append(request)
        store.record_attempt(request,0,provider='nvidia',model='alpha',status_code=500)
        store.finish_request(request,status='error',ended_at=NOW)
        with store._connect() as conn:
            conn.execute('UPDATE requests SET error_category=?,error_summary=? WHERE id=?',(private_body,private_body,request))
            conn.execute('UPDATE request_attempts SET reason=?,error_category=? WHERE request_id=?',(private_body,private_body,request))
            conn.execute("UPDATE meta SET value='2' WHERE key='schema_version'")
    config = dict(available=True,managed=False,values=dict(state_dir=str(tmp_path),providers=['nvidia']))
    monkeypatch.setattr(sr,'read_plugin_config',lambda:config)
    before = store.db_path.read_bytes()
    summary = sr.assemble_analytics(now=NOW,range='all')
    detail = sr.assemble_analytics(now=NOW,view='request',request_id=ids[0])
    assert summary['by_error'] == [{'category':'Other','count':2,'last_seen':float(NOW)}]
    assert all(row['error_category'] is None for row in summary['recent_requests'])
    assert detail['request']['error_summary'] is detail['request']['error_category'] is None
    assert detail['attempts'][0]['reason'] is detail['attempts'][0]['error_category'] is None
    assert all(secret not in json.dumps(summary)+json.dumps(detail) for secret in sentinels)
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    api = _load_plugin_api()
    monkeypatch.setattr(api._sr,'read_plugin_config',lambda:config)
    app = FastAPI()
    app.include_router(api.router,prefix='/api/plugins/autorouter')
    with TestClient(app) as client:
        listing = client.get('/api/plugins/autorouter/analytics?range=all')
        request_detail = client.get(f'/api/plugins/autorouter/analytics?view=request&request_id={ids[0]}')
    assert listing.status_code == request_detail.status_code == 200
    assert listing.json()['by_error'] == summary['by_error']
    assert all(secret not in listing.text+request_detail.text for secret in sentinels)
    assert store.db_path.read_bytes() == before
    with sqlite3.connect(store.db_path) as conn:
        assert conn.execute('SELECT error_summary FROM requests WHERE id=?',(ids[0],)).fetchone()[0] == sentinels[0]
        assert conn.execute('SELECT reason FROM request_attempts WHERE request_id=?',(ids[0],)).fetchone()[0] == sentinels[0]


@pytest.mark.parametrize('field', ['auth_failed', 'retired', 'successes', 'failures', 'consecutive_failures', 'last_latency_ms', 'last_success_at', 'last_failure_at', 'last_status'])
def test_corrupt_typed_health_never_escapes_or_fabricates_auth(tmp_path, monkeypatch, caplog, field):
    from autorouter.autorouter_core.health import health
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    monkeypatch.setattr(time,'time',lambda:NOW)
    store=seeded_store(tmp_path)
    secret='PRIVATE_CORRUPT_HEALTH_SENTINEL_91'
    store.upsert_health('nvidia','beta',**{field:secret})
    config=dict(available=True,managed=False,values=dict(state_dir=str(tmp_path),providers=['nvidia'],free_only=True,policy='auto'))
    api=_load_plugin_api()
    monkeypatch.setattr(api._sr,'read_plugin_config',lambda:config)
    observed=health.decision(store,'nvidia','beta',now=NOW)
    assert observed['reason']=='health_invalid' and not observed['available']
    assert not observed['health'].get('auth_failed')
    before=store.db_path.read_bytes()
    app=FastAPI();app.include_router(api.router,prefix='/api/plugins/autorouter')
    with TestClient(app) as client:
        models=client.get('/api/plugins/autorouter/models')
        overview=client.get('/api/plugins/autorouter/overview')
        providers=client.get('/api/plugins/autorouter/providers')
    assert models.status_code==overview.status_code==providers.status_code==200
    assert models.json()['available'] and overview.json()['available'] and providers.json()['available']
    beta=next(row for row in models.json()['models'] if row['model']=='beta')
    assert beta['reason_codes']==['health_invalid'] and not beta['health']['auth_failed']
    assert overview.json()['counts']['health_invalid']==1
    assert overview.json()['counts']['auth_failed']==0
    assert secret not in models.text+overview.text+providers.text+caplog.text
    assert store.db_path.read_bytes()==before


def test_corrupt_circuit_reason_is_generic_and_secret_safe(tmp_path, monkeypatch, caplog):
    from autorouter.autorouter_core.health import health
    monkeypatch.setattr(time,'time',lambda:NOW)
    store=seeded_store(tmp_path)
    for _ in range(3): store.record_outcome('nvidia','beta',False,status_code=503,now=140)
    private='PRIVATE_CORRUPT_CIRCUIT_REASON_81'
    with store._connect() as conn:
        conn.execute("UPDATE health_circuits SET reason=? WHERE layer='provider'",(private,))
    config=dict(available=True,managed=False,values=dict(state_dir=str(tmp_path),providers=['nvidia']))
    monkeypatch.setattr(sr,'read_plugin_config',lambda:config)
    before=store.db_path.read_bytes()
    result=sr.assemble_models(now=NOW)
    assert result['preview']['chosen'] is None
    assert all(row['reason_codes']==['health_invalid'] for row in result['models'])
    assert private not in json.dumps(result)+caplog.text
    assert store.db_path.read_bytes()==before
    assert health.decision(store,'nvidia','beta',now=NOW)['reason']=='health_invalid'
