"""Required-scenario tests: in-flight quota, side-effect replay safety,
stream fail-closed, exhaustion result, session identity, Kanban safeguards."""

import sys
from pathlib import Path

import pytest

from autorouter.autorouter_core.routing import failover as fv
from autorouter.autorouter_core.integration import runtime as rt
from autorouter.autorouter_core.storage import state as st
from autorouter.autorouter_core.routing import integration as ig


@pytest.fixture()
def seeded_runtime(tmp_path):
    """Runtime with a small two-provider free catalog for select tests."""
    store = st.StateStore(tmp_path / "state")
    seed_verified_model(store, "nvidia", "n1", context_length=32000,
                         capabilities={"tools": True}, cost_tier="free")
    seed_verified_model(store, "openrouter", "o1", context_length=32000,
                         capabilities={"tools": True}, cost_tier="free")
    rt.configure(policy="auto", free_only=True, paid_authorized=False,
                 providers=["nvidia", "openrouter"],
                 cooldown_seconds=60, state_dir=tmp_path / "state")
    rt.get_state()["store"] = store
    from autorouter.autorouter_core.routing import router as rmod
    router = rmod.Router(rt.get_state())
    rt.get_state()["router"] = router
    yield rt.get_state(), store, router
    rt.get_state()["store"] = None
    rt.get_state()["router"] = None


# 6. In-flight provider quotas prevent concurrent overload
def test_inflight_quota_blocks_selection(seeded_runtime):
    _, store, router = seeded_runtime
    # Both catalog entries point at nvidia/o1 distinct tuples — saturate nvidia.
    assert store.reserve("nvidia", "n1") == 1
    assert store.reserve("nvidia", "n1") == 2
    chosen = router.select(requires_tools=True, max_in_flight=2)
    # nvidia is saturated; only openrouter remains eligible.
    assert chosen is not None
    assert chosen["provider"] == "openrouter"
    # Saturate the second provider too → quota-driven exhaustion.
    store.reserve("openrouter", "o1")
    store.reserve("openrouter", "o1")
    assert router.select(requires_tools=True, max_in_flight=2) is None


def test_inflight_reservation_releases(seeded_runtime):
    _, store, router = seeded_runtime
    with router.inflight("nvidia", "n1"):
        assert store.get_in_flight("nvidia", "n1") == 1
    assert store.get_in_flight("nvidia", "n1") == 0


def test_inflight_release_on_exception(seeded_runtime):
    _, store, router = seeded_runtime
    with pytest.raises(RuntimeError):
        with router.inflight("openrouter", "o1"):
            raise RuntimeError("boom")
    assert store.get_in_flight("openrouter", "o1") == 0


# 13. Committed state prevents retry and fallback (defense-in-depth)
# NOTE: Hermes does not supply streamed_committed / tool_side_effects_committed
# to the classifier in real execution. These flags are defense-in-depth only,
# active when a test harness or future Hermes version supplies them.
def test_committed_stream_blocks_fallback():
    out = fv.classify({"status_code": 429, "provider": "nvidia", "model": "m1",
                       "tool_side_effects_committed": True, "streamed_committed": True})
    assert out is not None
    assert out["retryable"] is False, "committed stream must not be retryable"
    assert out["should_fallback"] is False, "committed stream must not trigger fallback"


def test_committed_tool_effect_blocks_fallback():
    out = fv.classify({"status_code": 429, "provider": "nvidia", "model": "m1",
                       "tool_side_effects_committed": True})
    assert out is not None
    assert out["retryable"] is False, "committed tool effect must not be retryable"
    assert out["should_fallback"] is False, "committed tool effect must not trigger fallback"


def test_precommit_429_allows_fallback():
    out = fv.classify({"status_code": 429, "provider": "nvidia", "model": "m1"})
    assert out is not None
    assert out["retryable"] is True, "precommit 429 must be retryable"
    assert out["should_fallback"] is True, "precommit 429 must allow fallback"


def test_uncommitted_stream_error_still_fails_over():
    out = fv.classify({"status_code": 429, "provider": "nvidia", "model": "m1",
                       "streamed_committed": False})
    assert out is not None
    assert out["should_fallback"] is True


# 15. All providers unavailable yields a controlled exhaustion result
def test_exhaustion_result_structured():
    out = fv.exhaustion([{"provider": "nvidia", "model": "m1", "status": 429},
                         {"provider": "openrouter", "model": "m2", "status": 401}])
    assert out["condition"] == "PROVIDERS_EXHAUSTED"
    assert out["task_complete"] is False
    assert out["retryable"] is False
    assert out["preserve_task"] is True


# 8 & 17. Exhaustion must not trigger Kanban respawn; plugin touches no Kanban state
def test_exhaustion_no_kanban_respawn(seeded_runtime, monkeypatch):
    _, store, router = seeded_runtime
    store.set_cooldown("nvidia", "n1", 600)
    store.set_cooldown("openrouter", "o1", 600)
    store.upsert_health("nvidia", "n1", retired=1)
    store.upsert_health("openrouter", "o1", retired=1)
    selected = router.select(requires_tools=True)
    assert selected is None  # exhaustion at selection level

    # The plugin must never import/mutate Kanban state on this path.
    result = fv.exhaustion()
    assert result["no_kanban_respawn"] is True
    assert result["preserve_session"] is True
    assert "kanban" not in sys.modules or getattr(
        sys.modules["kanban"], "_autorouter_loaded", False) is False


# 16. Existing Hermes session identity remains unchanged during failover
def test_session_identity_preserved(seeded_runtime):
    _, store, router = seeded_runtime
    seed_verified_model(store, "nvidia", "n2", context_length=32000,
                         capabilities={"tools": True}, cost_tier="free")
    store.set_cooldown("nvidia", "n1", 600)  # force selection onto alternatives

    class FakeAgent:
        session_id = "sess-1234"
        conversation_id = "conv-5678"

    agent = FakeAgent()
    before = (agent.session_id, agent.conversation_id)
    assert ig.apply_to_agent(agent) is False
    after = (agent.session_id, agent.conversation_id)
    assert before == after  # failover config changes nothing about identity


# Plugin state contract: route-level auth failure recorded, but no credential
# material is persisted in the decisions/events tables the plugin writes.
def test_state_store_never_records_credentials(seeded_runtime, tmp_path):
    _, store, _router = seeded_runtime
    store.record_outcome("nvidia", "n1", success=False, status_code=401)
    h = store.get_health("nvidia", "n1")
    assert h["auth_failed"] == 1  # route disabled...
    # ...yet the store never stores raw API credentials as structured fields.
    conn_keys = {"provider", "model", "key_scope", "successes", "failures",
                 "consecutive_failures", "last_status", "last_error",
                 "last_latency_ms", "last_success_at", "last_failure_at",
                 "cooldown_until", "retired", "auth_failed"}
    assert set(h.keys()) <= conn_keys




from tests.verified_fixture import seed_verified_model
