"""Coverage of existing operational observations; no benchmark or host authority."""

import json
from dataclasses import replace
from pathlib import Path
import pytest
from autorouter.autorouter_core.configuration import selection_policy as sp
from autorouter.autorouter_core.integration import tools
from autorouter.autorouter_core.routing import scoring, router
from autorouter.autorouter_core.storage import state
from tests.test_selection_policy_v1 import ACTIVE, A, B, context
from tests.test_task_profiles_v1 import policy
from tests.test_adaptive_scoring import sample, observed, NOW
from tests.verified_fixture import seed_verified_model


def coverage(rows=(), now=NOW, available=True, attribution="unknown"):
    return scoring.observation_coverage(
        scoring.summarize_observations(rows, now=now, available=available),
        now=now,
        attribution=attribution,
    )


@pytest.mark.parametrize(
    "count,expected",
    [
        (0, "cold_start"),
        (1, "sample_limited"),
        (10, "sample_limited"),
        (64, "bounded_sample"),
        (80, "bounded_sample"),
    ],
)
def test_coverage_counts_confidence_and_limit_are_exact(count, expected):
    data = coverage([sample(identity=i) for i in range(count)])
    assert data["schema_version"] == 1 and data["state"] == expected
    assert data["samples"] == min(count, 64) and data["sample_limit"] == 64
    assert data["confidence"] == pytest.approx(min(count, 64) / (min(count, 64) + 5))
    assert data["active_account_authority"] is False
    assert (
        data["current_availability"] == "unknown"
        and data["semantic_quality"] == "unknown"
    )
    assert data["reliability_state"] == (
        "neutral_prior" if not count else "historical_estimate"
    )


def test_unavailable_storage_is_not_zero_or_healthy():
    data = coverage(available=False)
    assert data["state"] == "unavailable" and data["source"] == "unknown"
    assert data["samples"] is None and data["confidence"] is None
    assert data["latency_samples"] is None and data["latency_state"] == "unavailable"
    assert data["current_availability"] == "unknown"


def test_decay_ages_and_original_staleness_boundary():
    data = coverage([sample(observed=NOW - scoring.HALF_LIFE_SECONDS)])
    assert data["state"] == "stale" and data["effective_samples"] == 0.5
    assert data["age_seconds"] == scoring.HALF_LIFE_SECONDS
    assert data["stale_after"] == NOW
    assert data["last_observed_at"] == NOW - scoring.HALF_LIFE_SECONDS
    assert data["latency_state"] == "stale"
    later = coverage([sample(observed=NOW - scoring.HALF_LIFE_SECONDS)], now=NOW + 100)
    assert later["stale_after"] == data["stale_after"]
    assert later["confidence"] < data["confidence"]


@pytest.mark.parametrize(
    "row",
    [
        sample(observed=NOW + 1),
        sample(observed=float("nan")),
        sample(status="pending"),
        sample(observed=-1),
    ],
)
def test_invalid_future_or_missing_callbacks_do_not_become_measurements(row):
    data = coverage([row])
    assert data["state"] == "cold_start" and data["samples"] == 0
    assert data["latency_state"] == "unknown" and data["latency_ewma_ms"] is None
    json.dumps(data, allow_nan=False)


def test_non_latency_callback_does_not_extend_speed_freshness():
    rows = [
        sample(observed=NOW - scoring.HALF_LIFE_SECONDS, identity=1),
        sample(latency=None, identity=2),
    ]
    data = coverage(rows)
    assert data["state"] == "sample_limited"
    assert data["latency_state"] == "stale"
    assert data["last_latency_observed_at"] == NOW - scoring.HALF_LIFE_SECONDS


def scoped_store(tmp_path, monkeypatch):
    monkeypatch.setattr(router.time, "time", lambda: NOW)
    store = state.StateStore(tmp_path)
    for name in ("alpha", "beta"):
        seed_verified_model(store, "nvidia", name, 16000, {"tools": True}, "free")
        for account in (A, B):
            for n in range(8):
                observed(
                    store,
                    name,
                    scope="nvidia:" + account,
                    identity=f"{account}-{name}-{n}",
                    status="success"
                    if (name == "alpha") == (account == A)
                    else "error",
                )
    return store


@pytest.mark.parametrize("account,expected", [(A, "alpha"), (B, "beta")])
def test_authorized_current_context_reads_only_matching_scoped_observations(
    tmp_path, monkeypatch, account, expected
):
    store = scoped_store(tmp_path, monkeypatch)
    bound = context(
        provider_id="nvidia",
        connection_id=account,
        observed_at=NOW - 10,
        expires_at=NOW + 100,
    )
    values = dict(
        store=store,
        providers=["nvidia"],
        policy="reliable",
        selection_context=ACTIVE,
        connection_contexts={"nvidia": bound},
    )
    r = router.Router(values)
    result = r.preview(now=NOW)
    assert result["chosen"]["model"] == expected
    for row in result["considered"]:
        coverage = row["score"]["coverage"]
        assert (
            coverage["samples"] == 8
            and coverage["attribution"] == "authorized_observation"
        )
        assert coverage["active_account_authority"] is True
        report = next(
            c
            for c in result["evidence_report"]["candidates"]
            if c["model"] == row["model"]
        )
        assert report["ranking"]["coverage"] == coverage
    assert A not in json.dumps(result) and B not in json.dumps(result)


def test_revoked_or_cross_session_context_cannot_reuse_scoped_metrics(
    tmp_path, monkeypatch
):
    store = scoped_store(tmp_path, monkeypatch)
    bound = context(provider_id="nvidia", observed_at=NOW - 10, expires_at=NOW + 100)
    for bad in (
        replace(bound, granted=False),
        replace(bound, context=replace(ACTIVE, session_id="4" * 32)),
        None,
    ):
        r = router.Router(
            dict(
                store=store,
                providers=["nvidia"],
                selection_context=ACTIVE,
                connection_contexts={"nvidia": bad},
            )
        )
        out = r.preview(now=NOW)
        assert all(c["score"]["coverage"]["samples"] == 0 for c in out["considered"])
        assert all(
            c["score"]["coverage"]["attribution"] == "unknown"
            for c in out["considered"]
        )


def test_attempts_across_providers_and_missing_callbacks_stay_out_of_coverage(
    tmp_path, monkeypatch
):
    monkeypatch.setattr(router.time, "time", lambda: NOW)
    store = state.StateStore(tmp_path)
    observed(store, identity="good")
    observed(store, identity="cross", attempts=[("nvidia", "m"), ("openrouter", "m")])
    observed(store, identity=None)
    store.begin_request(api_request_id="pending", provider="nvidia", model="m")
    data = store.get_scoring_observations("nvidia", "m")
    c = coverage(data["rows"], available=data["available"])
    assert c["samples"] == 1


def test_coverage_fixture_is_portable_and_synthetic():
    fixture = json.loads(
        (
            Path(__file__).with_name("fixtures") / "observation-coverage-v1.json"
        ).read_text()
    )
    assert fixture["synthetic"] and not fixture["semantic_benchmark"]
    assert fixture["cold_start"] == coverage()
    assert fixture["single_success"] == coverage([sample()])


def test_caller_label_cannot_grant_active_account_authority():
    from tests.test_selection_policy_v1 import candidate, run

    result = run([candidate(observation_scope="authorized_observation")])
    assert result["chosen"]["score"]["coverage"]["attribution"] == "unknown"
    assert not result["chosen"]["score"]["coverage"]["active_account_authority"]


@pytest.mark.parametrize("count", [None, True, -1, 65, "1"])
def test_invalid_coverage_counts_remain_unavailable(count):
    stats = scoring.summarize_observations([sample()], now=NOW)
    stats["samples"] = count
    data = scoring.observation_coverage(stats, now=NOW)
    assert data["state"] == "unavailable"
    assert data["samples"] is None and data["confidence"] is None
