"""Pure preview, selection equivalence and zero side effect regression gates."""
import copy
import json
import time

import pytest

from autorouter.autorouter_core.routing.router import Router, evaluate_snapshot
from autorouter.autorouter_core.storage.state import StateStore
from .verified_fixture import seed_verified_model


def candidate(model='a', **changes):
    return dict(provider='nvidia', model=model, context_length=16000,
                capabilities={'tools': True}, cost_tier='free', **changes)


def test_pure_deterministic_and_all_rejections():
    rows = [candidate('z'), candidate('a'), candidate('paid')]
    rows[2]['cost_tier'] = 'paid'
    rows += [candidate('short'), candidate('tools'), candidate('retired'), candidate('auth'), candidate('cooldown')]
    rows[3]['context_length'] = 1
    rows[4]['capabilities'] = {}
    rows[5]['health'] = {'retired': 1}
    rows[6]['health'] = {'auth_failed': 1}
    rows[7]['health'] = {'cooldown_until': 200}
    original = copy.deepcopy(rows)
    a = evaluate_snapshot(rows, now=100, requires_tools=True)
    b = evaluate_snapshot(list(reversed(rows)), now=100, requires_tools=True)
    assert a == b
    assert a['chosen']['model'] == 'a'
    assert rows == original
    reasons = {c['model']: c['reason_codes'] for c in a['considered']}
    assert reasons['paid'] == ['cost_not_verified_free']
    assert reasons['short'] == ['context_unknown_or_insufficient']
    assert reasons['tools'] == ['tools_unverified_or_unsupported']
    assert reasons['retired'] == ['retired']
    assert reasons['auth'] == ['auth_failed']
    assert reasons['cooldown'] == ['cooldown']
    assert a['semantic_quality'] == 'unknown'


@pytest.mark.parametrize('policy', ['auto', 'fastest', 'reliable', 'smartest', 'coding', 'priority'])
def test_preview_matches_selection_without_writes_network_or_credentials(tmp_path, monkeypatch, policy):
    store = StateStore(tmp_path)
    seed_verified_model(store, 'nvidia', 'a', 16000, {'tools': True}, 'free')
    seed_verified_model(store, 'openrouter', 'b', 32000, {'tools': True}, 'free')
    router = Router({'store': store, 'policy': policy, 'providers': ['nvidia', 'openrouter']})
    def forbidden(*args, **kwargs):
        raise AssertionError('preview performed a side effect')
    import autorouter.autorouter_core.discovery.discovery as discovery
    monkeypatch.setattr(discovery, 'discover_all', forbidden)
    import urllib.request
    monkeypatch.setattr(urllib.request, 'urlopen', forbidden)
    import os
    monkeypatch.setattr(os, 'getenv', forbidden)
    original = store.record_decision
    monkeypatch.setattr(store, 'record_decision', forbidden)
    before = (tmp_path / 'autorouter.db').read_bytes()
    a = router.preview(now=time.time(), requires_tools=True)
    assert (tmp_path / 'autorouter.db').read_bytes() == before
    monkeypatch.setattr(store, 'record_decision', original)
    chosen = router.select(requires_tools=True)
    assert chosen['model'] == a['chosen']['model']
    assert chosen['provider'] == a['chosen']['provider']
    assert sum(f['contribution'] for f in a['chosen']['score']['factors'].values()) == a['chosen']['score']['total']


def test_provider_exclusions_and_display_bound():
    rows = [candidate(str(i)) for i in range(600)]
    assert evaluate_snapshot(rows, now=100, providers=[])['chosen'] is None
    result = evaluate_snapshot(rows, now=100, exclude={('nvidia', '0')})
    assert result['truncated'] and result['total_considered'] == 600
    assert len(result['considered']) == 500
    assert result['chosen']['model'] != '0'


def test_empty_and_malformed_evidence_do_not_discover(tmp_path, monkeypatch):
    router = Router({'store': None})
    assert router.preview()['chosen'] is None
    store = StateStore(tmp_path)
    store.upsert_catalog('nvidia', 'a', 32000, {'tools': True}, 'free')
    store.upsert_capability('nvidia', 'a', '{broken', retrieved_at=1, expires_at=99999999999)
    router = Router({'store': store})
    assert router.preview()['chosen'] is None


def test_preview_sql_trace_and_stale_proof(tmp_path, monkeypatch):
    store = StateStore(tmp_path)
    seed_verified_model(store, 'nvidia', 'a', 16000, {'tools': True}, 'free')
    statements = []
    connect = store._connect
    def trace_connect():
        conn = connect()
        conn.set_trace_callback(statements.append)
        return conn
    monkeypatch.setattr(store, '_connect', trace_connect)
    router = Router({'store': store})
    result = router.preview(now=time.time() + 7200)
    assert result['chosen'] is None
    assert 'cost_not_verified_free' in result['considered'][0]['reason_codes']
    assert not any(sql.lstrip().upper().startswith(('INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER')) for sql in statements)


@pytest.mark.parametrize('field,value', [('last_latency_ms', 'NaN'), ('last_latency_ms', -1000),
    ('successes', 'NaN'), ('failures', float('inf')), ('cooldown_until', -1)])
def test_malformed_health_is_denied_and_json_safe(field, value):
    row = candidate(health={field: value})
    result = evaluate_snapshot([row], now=100)
    assert result['chosen'] is None
    assert 'health_invalid' in result['considered'][0]['reason_codes']
    json.dumps(result, allow_nan=False)


def test_missing_database_preview_never_recreates_files(tmp_path):
    store = StateStore(tmp_path)
    for path in tmp_path.iterdir():
        path.unlink()
    assert list(tmp_path.iterdir()) == []
    assert Router({'store': store}).preview()['chosen'] is None
    assert list(tmp_path.iterdir()) == []


def test_readonly_preview_never_uses_writable_connector(tmp_path, monkeypatch):
    store = StateStore(tmp_path)
    seed_verified_model(store, 'nvidia', 'a', 16000, {'tools': True}, 'free')
    def forbidden(*args, **kwargs):
        raise AssertionError('writable connector used')
    monkeypatch.setattr(StateStore, '_connect', forbidden)
    assert Router({'store': store}).preview()['chosen']['model'] == 'a'


def test_selection_records_full_eligible_count_after_display_truncation(monkeypatch):
    rows = [candidate(str(i)) for i in range(501)]
    class Store:
        def get_health(self, *args): return {}
        def get_in_flight(self, *args): return 0
        def record_decision(self, *args): self.recorded = args
    store = Store()
    router = Router({'store': store})
    monkeypatch.setattr(router, '_resolved_candidates', lambda: rows)
    assert router.select() is not None
    assert store.recorded[-1] == 501
    result = evaluate_snapshot(rows, now=100)
    assert result['eligible_count'] == 501
    assert len(result['ranked']) == 500
