"""Frozen-clock operational ranking, attribution and indexed-read regressions."""
import json
import sqlite3
import time

import pytest
from autorouter.autorouter_core.integration import runtime
from autorouter.autorouter_core.routing import scoring, router
from autorouter.autorouter_core.storage import state
from autorouter.autorouter_core.telemetry import telemetry
from tests.verified_fixture import seed_verified_model

NOW = 2_000_000_000


def sample(status='success', latency=100, observed=NOW, identity=1):
    return dict(id=identity, status=status, latency_ms=latency, ended_at=observed)


def observed(store, model='m', *, status='success', scope='', identity='sample', latency=100, attempts=None):
    request = store.begin_request(api_request_id=identity, provider='nvidia', model=model, key_scope=scope)
    for ordinal, (provider, actual_model) in enumerate(attempts or [('nvidia', model)]):
        store.record_attempt(request, ordinal, provider=provider, model=actual_model,
                             status_code=200 if status == 'success' else 500)
    store.finish_request(request, status=status, latency_ms=latency, ended_at=NOW)
    return request


def test_cold_start_prior_and_sample_confidence():
    empty = scoring.summarize_observations([], now=NOW)
    single = scoring.summarize_observations([sample()], now=NOW)
    robust = scoring.summarize_observations([sample('success' if i < 60 else 'error', identity=i) for i in range(64)], now=NOW)
    assert empty['reliability'] == .5 and empty['speed'] == .5
    assert empty['confidence'] == 0 and empty['latency_ewma_ms'] is None
    assert single['reliability'] == pytest.approx(3/5)
    assert robust['reliability'] == pytest.approx(62/68)
    assert robust['confidence'] > single['confidence'] > 0
    assert single['speed'] < robust['speed'] < 1


def test_decay_ewma_and_staleness_under_frozen_clock():
    rows = [sample(latency=100, observed=NOW-scoring.HALF_LIFE_SECONDS, identity=1), sample(latency=300, identity=2)]
    current = scoring.summarize_observations(rows, now=NOW)
    expected_ewma = (.7 * .3 * .5 * 100 + .3 * 300) / (.7 * .3 * .5 + .3)
    assert current['latency_ewma_ms'] == pytest.approx(expected_ewma)
    assert current['effective_samples'] == 1.5
    assert current['reliability'] == pytest.approx(3.5/5.5)
    stale = scoring.summarize_observations(rows, now=NOW+10*scoring.HALF_LIFE_SECONDS)
    assert stale['stale']
    assert abs(stale['reliability']-.5) < .001
    assert abs(stale['speed']-.5) < .001
    assert stale['last_observed_at'] == NOW


def test_pending_future_malformed_samples_and_bounded_window():
    rows = [sample('pending'), sample(observed=NOW+1), sample(observed=float('nan'))]
    assert scoring.summarize_observations(rows, now=NOW)['samples'] == 0
    result = scoring.summarize_observations([sample(latency=float('inf'), identity=i) for i in range(100)], now=NOW)
    assert result['samples'] == 64 and result['latency_samples'] == 0
    json.dumps(result, allow_nan=False)


@pytest.mark.parametrize('policy', scoring.WEIGHTS)
def test_semantic_quality_is_unknown_and_context_does_not_rank(policy):
    candidate = dict(provider='nvidia',model='m',capabilities={'tools':True},context_length=8192)
    low = scoring.score_breakdown(candidate,policy=policy,now=NOW)
    high = scoring.score_breakdown(dict(candidate,context_length=2_000_000),policy=policy,now=NOW)
    assert low == high
    assert low['semantic_quality'] == 'unknown'
    assert 'context_capacity' not in low['factors']
    assert low['factors']['semantic_quality']['value'] == .5
    assert sum(f['weight'] for f in low['factors'].values()) == pytest.approx(1)


def test_indexed_bounded_read_and_scope_isolation(tmp_path, monkeypatch):
    monkeypatch.setattr(time, 'time', lambda: NOW)
    store = state.StateStore(tmp_path)
    for i in range(80):
        observed(store,scope='account-A',identity=f'A-{i}')
    observed(store,scope='account-B',identity='B',status='error')
    data = store.get_scoring_observations('nvidia','m','account-A')
    assert len(data['rows']) == 64
    assert all(row['status'] == 'success' for row in data['rows'])
    assert store.get_scoring_observations('nvidia','m','account-B')['rows'][0]['status'] == 'error'
    assert store.get_scoring_observations('nvidia','m')['rows'] == []
    with store._connect() as conn:
        plan = conn.execute('EXPLAIN QUERY PLAN SELECT id FROM requests INDEXED BY idx_requests_scoring WHERE provider=? AND model=? AND key_scope=? ORDER BY created_at DESC,id DESC LIMIT 64', ('nvidia','m',telemetry.redact_key_scope('account-A'))).fetchall()
    assert any('SEARCH requests USING' in row['detail'] and 'idx_requests_scoring' in row['detail'] for row in plan)
    assert not any('SCAN requests' in row['detail'] for row in plan)


def test_unattributed_or_heterogeneous_requests_do_not_calibrate_model(tmp_path, monkeypatch):
    monkeypatch.setattr(time, 'time', lambda: NOW)
    store = state.StateStore(tmp_path)
    observed(store, identity='valid')
    observed(store, identity=None)
    observed(store, identity='cross-provider', attempts=[('nvidia','m'),('openrouter','m')])
    observed(store, identity='cross-model', attempts=[('nvidia','m'),('nvidia','other')])
    observed(store, identity='too-many-attempts', attempts=[('nvidia','m')]*17)
    missing_attempt = store.begin_request(api_request_id='no-attempt',provider='nvidia',model='m')
    store.finish_request(missing_attempt, ended_at=NOW)
    assert len(store.get_scoring_observations('nvidia','m')['rows']) == 1


def test_missing_or_legacy_database_stats_are_unavailable_without_writes(tmp_path):
    from autorouter.autorouter_core.storage.snapshot import ReadOnlyStateStore
    path = tmp_path/'missing.db'
    assert not ReadOnlyStateStore(path).get_scoring_observations('nvidia','m')['available']
    assert not path.exists()
    conn = sqlite3.connect(path)
    conn.execute('CREATE TABLE catalog(provider,model)')
    conn.close()
    before = path.read_bytes()
    assert not ReadOnlyStateStore(path).get_scoring_observations('nvidia','m')['available']
    assert path.read_bytes() == before


def test_scope_changes_never_restore_specific_request_attribution(tmp_path, monkeypatch):
    monkeypatch.setattr(time, 'time', lambda: NOW)
    store = state.StateStore(tmp_path)
    monkeypatch.setattr(runtime,'get_store',lambda:store)
    monkeypatch.setattr(runtime,'get_router',lambda:None)
    base = dict(api_request_id='changing-scope',provider='nvidia',model='m')
    runtime.on_pre_api_request(**base,credential_scope='account-A')
    runtime.on_api_request_error(**base,credential_scope='account-B',status_code=429,retry_count=0,max_retries=2,retryable=True)
    runtime.on_api_request_error(**base,credential_scope='account-A',status_code=429,retry_count=1,max_retries=2,retryable=True)
    runtime.on_post_api_request(**base,credential_scope='account-A',retry_count=2,latency_ms=100)
    request = store.find_request_by_api_id('changing-scope')
    assert store.get_request(request)['key_scope'] == ''
    assert store.get_scoring_observations('nvidia','m','account-A')['rows'] == []
    assert store.get_scoring_observations('nvidia','m','account-B')['rows'] == []
    assert len(store.get_scoring_observations('nvidia','m')['rows']) == 1
    # A duplicate terminal callback cannot erase a completed, consistently attributed request.
    good = observed(store,scope='account-A',identity='consistent')
    store.reconcile_request_scope(good,'')
    assert store.get_request(good)['key_scope'] == telemetry.redact_key_scope('account-A')
    assert 'account-A' not in json.dumps(store.get_request(good))


def test_observed_telemetry_changes_ranking_and_preview_is_identical(tmp_path, monkeypatch):
    monkeypatch.setattr(time,'time',lambda:NOW)
    store = state.StateStore(tmp_path)
    for model, context in [('one',16000),('robust',16000),('paid',128000)]:
        seed_verified_model(store,'nvidia',model,context,{'tools':True},'paid' if model=='paid' else 'free')
    observed(store,model='one',identity='one')
    for i in range(64):
        observed(store,model='robust',identity=f'robust-{i}',status='success' if i<60 else 'error')
    for i in range(64):
        observed(store,model='paid',identity=f'paid-{i}')
    route = router.Router({'store':store,'policy':'reliable','providers':['nvidia']})
    reads = []
    original_read = state.StateStore.get_scoring_observations
    def trace_read(self, provider, model, key_scope=""):
        reads.append(model)
        return original_read(self, provider, model, key_scope)
    monkeypatch.setattr(state.StateStore, 'get_scoring_observations', trace_read)
    before = (tmp_path/'autorouter.db').read_bytes()
    preview = route.preview(now=NOW)
    assert (tmp_path/'autorouter.db').read_bytes() == before
    assert preview['chosen']['model'] == route.select()['model'] == 'robust'
    assert preview['chosen']['score']['observations']['samples'] == 64
    assert set(reads) == {'one','robust'}
    paid = next(row for row in preview['considered'] if row['model']=='paid')
    assert not paid['eligible'] and paid['score'] is None
    assert 'cost_not_verified_free' in paid['reason_codes']


from tests.test_dashboard_state_reader import sr, cfg, _seed_store


def test_analytics_distinguishes_decisions_outcomes_and_current_scoring_samples(cfg, monkeypatch):
    monkeypatch.setattr(time,'time',lambda:NOW)
    store = _seed_store(cfg)
    observed(store,identity='attributed')
    observed(store,identity=None)
    store.record_decision('reliable','nvidia','m','selected',1)
    store.record_decision('reliable','nvidia','m','selected',1)
    before = store.db_path.read_bytes()
    result = sr.assemble_analytics(now=NOW,range='24h')
    assert result['summary']['total_requests'] == 2  # General callback accounting is preserved.
    assert result['selection_distribution']['total'] == 2
    assert result['selection_distribution']['source'] == 'recorded_selection_decisions'
    metric = result['adaptive_scoring']['models'][0]
    assert metric['statistics']['samples'] == 1
    assert metric['credential_scope'] == 'unknown'
    assert metric['statistics']['latency_p95_ms'] == 100
    assert result['timeline'][0]['latency']['samples'] == 2
    assert store.db_path.read_bytes() == before
    filtered = sr.assemble_analytics(now=NOW,range='24h',status='error')
    assert filtered['summary']['total_requests'] == 0
    assert filtered['selection_distribution']['total'] == 2
    assert not filtered['selection_distribution']['status_filter_applies']


def test_additive_scoring_index_rolls_back_on_interrupted_initialization(tmp_path, monkeypatch):
    store = state.StateStore(tmp_path)
    observed(store, identity='preserved')
    with store._connect() as conn:
        conn.execute('DROP INDEX idx_requests_scoring')
    original = state.StateStore._init_telemetry_schema
    def fail_after_index(self, conn):
        original(self, conn)
        raise sqlite3.OperationalError('interrupted after scoring index')
    monkeypatch.setattr(state.StateStore,'_init_telemetry_schema',fail_after_index)
    with pytest.raises(sqlite3.OperationalError,match='interrupted'):
        state.StateStore(tmp_path)
    with sqlite3.connect(store.db_path) as conn:
        assert conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='index' AND name='idx_requests_scoring'").fetchone()[0] == 0
        assert conn.execute('SELECT COUNT(*) FROM requests').fetchone()[0] == 1
    monkeypatch.setattr(state.StateStore,'_init_telemetry_schema',original)
    upgraded = state.StateStore(tmp_path)
    assert len(upgraded.get_scoring_observations('nvidia','m')['rows']) == 1


def test_dashboard_adaptive_scoring_marks_insufficient_samples(cfg):
    """Mirrors the live review window: a handful of pre-merge error attempts
    must not present a fabricated reliability/confidence figure."""
    store = _seed_store(cfg)
    for i in range(4):
        observed(store, model='auto-free-route', identity=f'hist-{i}', status='error')
    result = sr.assemble_analytics(now=NOW, range='all')
    metric = next(m for m in result['adaptive_scoring']['models'] if m['model'] == 'auto-free-route')
    stats = metric['statistics']
    assert stats['samples'] == 4
    assert stats['sample_state'] == 'insufficient_samples'
    assert stats['min_samples'] == 10
    assert stats['reliability'] is None
    assert stats['confidence'] is None
    # Raw evidence stays visible; nothing is rewritten or inflated.
    assert stats['effective_samples'] is not None and stats['effective_samples'] > 0
    assert stats['latency_samples'] is not None
