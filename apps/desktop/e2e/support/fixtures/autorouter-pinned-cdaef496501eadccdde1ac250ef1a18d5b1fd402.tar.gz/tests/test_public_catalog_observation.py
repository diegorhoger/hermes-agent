"""Replay a dated unauthenticated metadata observation, never live inference."""
import json
from pathlib import Path

from autorouter.autorouter_core.discovery import metadata
from autorouter.autorouter_core.evidence import evidence
from autorouter.autorouter_core.routing.router import evaluate_snapshot

SNAPSHOT = Path(__file__).resolve().parents[1] / 'docs/internal/provider-intelligence/observed-openrouter-2026-11-06.json'


def candidates_at(snapshot, now):
    rows = []
    for item in snapshot['zero_price_model_evidence']:
        # Recreate the normalizer's field envelope without changing source ages.
        record = dict(provider='openrouter',model=item['model'],tools=item['tools'],
            context_window=item['context_window'],metadata_source=item['source'],
            retrieved_at=item['observed_at'],expires_at=item['expires_at'],
            access_evidence=item['access_evidence'],
            cost_tier=evidence.price_tier(item['access_evidence'][0]['prices'],
                                           item['access_evidence'][0]['currency']))
        fields, statuses, sources = metadata.verified_fields(record,'openrouter',item['model'],now)
        rows.append(dict(provider='openrouter',model=item['model'],context_length=fields['context_window'],
            capabilities={'tools':fields['tools']},cost_tier=fields['cost_tier'],field_evidence=sources))
    return rows


def test_dated_metadata_eligibility_replay_expires_without_account_guarantee():
    original = SNAPSHOT.read_bytes()
    snapshot = json.loads(original)
    assert snapshot['credential_reads'] == snapshot['inference_calls'] == snapshot['production_changes'] == 0
    assert snapshot['source'] == 'https://openrouter.ai/api/v1/models'
    assert len(snapshot['zero_price_model_evidence']) == snapshot['fresh_zero_price_models'] == 16
    now = snapshot['observed_at'] + 1
    rows = candidates_at(snapshot,now)
    preview = evaluate_snapshot(rows,providers=['openrouter'],requires_tools=True,min_context=8192,now=now)
    assert sorted(row['model'] for row in preview['ranked']) == sorted(snapshot['eligible_model_ids'])
    assert preview['eligible_count'] == snapshot['eligible_tools_and_context_8192_models'] == 13
    strict = evaluate_snapshot(rows,providers=['openrouter'],requires_tools=True,min_context=8192,now=now,strict_no_charge=True)
    assert strict['chosen'] is None  # Public model prices do not establish an account hard billing stop.
    expired_at = max(item['expires_at'] for item in snapshot['zero_price_model_evidence']) + 1
    expired = evaluate_snapshot(candidates_at(snapshot,expired_at),providers=['openrouter'],requires_tools=True,min_context=8192,now=expired_at)
    assert expired['chosen'] is None
    assert all(row['cost_tier']=='unknown' for row in candidates_at(snapshot,expired_at))
    assert SNAPSHOT.read_bytes() == original
