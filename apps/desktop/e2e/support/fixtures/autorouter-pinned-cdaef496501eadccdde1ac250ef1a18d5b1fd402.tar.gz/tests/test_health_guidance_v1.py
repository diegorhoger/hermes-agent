"""Health guidance explains local observations; it never authorizes retry/execution."""

import json
from dataclasses import replace
from pathlib import Path
import pytest
from autorouter.autorouter_core.health import health, health_guidance as hg
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.storage import state
from tests.test_selection_policy_v1 import (
    candidate,
    run,
    request,
    context,
    ACTIVE,
    A,
    B,
    quota_result,
    evaluator,
)
from tests.verified_fixture import seed_verified_model


@pytest.mark.parametrize(
    "code,error,category,boundary",
    [
        (401, None, "authentication", "credential"),
        (403, None, "authentication", "credential"),
        (429, None, "rate_limit", "connection"),
        (503, None, "temporary_service", "provider"),
        (None, "TimeoutError", "transport", "connection"),
        (None, "ConnectionError", "transport", "connection"),
        (404, "model_not_found", "model_unavailable", "model"),
        (500, None, "temporary_service", "provider"),
    ],
)
def test_failure_categories_and_boundaries_have_original_provenance(
    tmp_path, code, error, category, boundary
):
    store = state.StateStore(tmp_path)
    store.record_outcome(
        "nvidia", "m", False, key_scope="A", status_code=code, error_type=error, now=100
    )
    result = health.decision(store, "nvidia", "m", "A", now=101)
    row = candidate(
        health=result["health"],
        health_reason=result["reason"],
        circuit_state=result["circuit"],
        health_observations=result["observations"],
    )
    guidance = hg.describe(row, [], now=101)
    assert guidance["category"] == category and guidance["boundary"] == boundary
    assert guidance["observed_at"] == 100 and guidance["age_seconds"] == 1
    assert guidance["source"] == "persisted_health_record"
    assert guidance["current_availability"] == "unknown"
    assert guidance["provider_retry_after"] is None
    assert not guidance["automatic_retry"] and not guidance["execution_authority"]
    assert guidance["account_binding"] == (
        "not_applicable" if boundary in ("provider", "model") else "unknown"
    )
    assert guidance["next_actions"]


def test_unobserved_default_rows_are_not_available_health(tmp_path):
    result = health.decision(state.StateStore(tmp_path), "nvidia", "missing", now=150)
    assert result["available"] is True
    assert result["reason"] == "health_unknown"
    guidance = hg.describe(candidate(health=result["health"]), [], now=150)
    assert guidance["category"] == "unknown" and guidance["observed_at"] is None


def test_429_hint_is_not_quota_exhaustion_or_trusted_provider_retry_after(tmp_path):
    store = state.StateStore(tmp_path)
    store.record_outcome(
        "nvidia",
        "m",
        False,
        key_scope="A",
        status_code=429,
        trusted_reason="quota_exhausted",
        retry_after=120,
        now=100,
    )
    result = health.decision(store, "nvidia", "m", "A", now=101)
    row = candidate(
        health=result["health"],
        health_reason=result["reason"],
        circuit_state=result["circuit"],
        health_observations=result["observations"],
    )
    guidance = hg.describe(row, [], now=101)
    assert guidance["category"] == "rate_limit"
    assert guidance["local_reconsider_at"] == 220
    assert guidance["provider_retry_after"] is None
    assert "does not establish exhausted allowance" in guidance["explanation"]
    assert (
        hg.describe(dict(row, health_reason="quota_exhausted"), [], now=101)["category"]
        == "rate_limit"
    )


def test_half_open_is_reconsideration_not_recovered_health(tmp_path):
    store = state.StateStore(tmp_path)
    for moment in (100, 101, 102):
        store.record_outcome("nvidia", "m", False, status_code=503, now=moment)
    data = health.decision(store, "nvidia", "m", now=133)
    assert data["circuit"] == "half_open" and data["available"]
    assert data["reason"] == "health_unknown"
    guidance = hg.describe(
        candidate(
            health=data["health"],
            health_reason=data["reason"],
            circuit_state=data["circuit"],
            health_observations=data["observations"],
        ),
        [],
        now=133,
    )
    assert (
        guidance["category"] == "temporary_service"
        and guidance["circuit_state"] == "half_open"
    )
    assert not guidance["automatic_retry"]
    store.record_outcome("nvidia", "m", True, now=134)
    recovered = health.decision(store, "nvidia", "m", now=135)
    note = hg.describe(
        candidate(
            health=recovered["health"],
            health_reason=recovered["reason"],
            circuit_state=recovered["circuit"],
            health_observations=recovered["observations"],
        ),
        [],
        now=135,
    )
    assert note["category"] == "observed_success" and note["observed_at"] == 134
    assert note["current_availability"] == "unknown"


def scoped_router(tmp_path, monkeypatch, account):
    monkeypatch.setattr(router.time, "time", lambda: 150)
    store = state.StateStore(tmp_path)
    seed_verified_model(store, "nvidia", "m", 16000, {"tools": True}, "free")
    store.record_outcome(
        "nvidia", "m", False, key_scope="nvidia:" + A, status_code=401, now=140
    )
    bound = context(
        provider_id="nvidia", connection_id=account, observed_at=100, expires_at=220
    )
    return router.Router(
        dict(
            store=store,
            providers=["nvidia"],
            selection_context=ACTIVE,
            connection_contexts={"nvidia": bound},
        )
    )


@pytest.mark.parametrize("account,denied", [(A, True), (B, False)])
def test_account_a_denial_does_not_poison_b_or_leak_identity(
    tmp_path, monkeypatch, account, denied
):
    r = scoped_router(tmp_path, monkeypatch, account)
    result = r.preview(now=150)
    assert (result["chosen"] is None) == denied
    guidance = result["considered"][0]["health_guidance"]
    assert guidance["category"] == ("authentication" if denied else "unknown")
    assert guidance["active_account_authority"] is True
    assert guidance == result["evidence_report"]["candidates"][0]["health_guidance"]
    assert A not in json.dumps(result) and B not in json.dumps(result)


def test_verified_quota_has_distinct_provider_observation_times():
    value = request()
    value["quota_policy"] = "avoid_verified_exhaustion"
    result = run(
        [candidate(connection_context=context())],
        value=value,
        selection_context=ACTIVE,
        quota_evaluator=evaluator(quota_result(0)),
    )
    guidance = result["considered"][0]["health_guidance"]
    assert guidance["category"] == "verified_quota_exhaustion"
    assert (
        guidance["observed_at"] == 100
        and guidance["quota_observation_expires_at"] == 220
    )
    assert guidance["source"] == "https://openrouter.ai/api/v1/key"
    assert guidance["provider_retry_after"] is None


@pytest.mark.parametrize("kind", ["stale", "future", "invalid", "private"])
def test_unknown_invalid_and_stale_evidence_remains_honest(kind):
    row = candidate(health={"last_failure_at": 100}, health_reason="auth")
    now = 150
    reasons = []
    if kind == "stale":
        now = 100 + hg.DISPLAY_STALE_SECONDS
    elif kind == "future":
        row["health"]["last_failure_at"] = 151
    elif kind == "invalid":
        reasons = ["health_invalid"]
    else:
        row.update(
            prompt="PRIVATE",
            health={"last_error": "sk-SECRET"},
            health_observations=[{"reason": [], "raw": "PRIVATE"}],
        )
    result = hg.describe(row, reasons, now=now)
    assert result["evidence_state"] == (
        "stale"
        if kind == "stale"
        else "unavailable"
        if kind == "invalid"
        else "unknown"
    )
    assert "PRIVATE" not in json.dumps(result) and "SECRET" not in json.dumps(result)
    assert result["current_availability"] == "unknown"


def test_health_guidance_fixture_is_synthetic_and_current():
    fixture = json.loads(
        (Path(__file__).with_name("fixtures") / "health-guidance-v1.json").read_text()
    )
    assert fixture["synthetic"] and not fixture["live_availability"]
    assert fixture["unknown"] == hg.describe(candidate(), [], now=150)


def test_dashboard_counts_unobserved_as_unknown_and_keeps_selection_eligible(
    tmp_path, monkeypatch
):
    from tests.test_dashboard_state_reader import sr

    monkeypatch.setattr(router.time, "time", lambda: 150)
    store = state.StateStore(tmp_path)
    seed_verified_model(store, "nvidia", "m", 16000, {"tools": True}, "free")
    monkeypatch.setattr(
        sr,
        "read_plugin_config",
        lambda: dict(
            available=True,
            managed=False,
            values=dict(state_dir=str(tmp_path), providers=["nvidia"], policy="auto"),
        ),
    )
    out = sr.assemble_overview(now=150)
    assert out["counts"]["healthy"] == 0 and out["counts"]["health_unknown"] == 1
    assert router.Router(dict(store=store, providers=["nvidia"])).preview(now=150)[
        "chosen"
    ]
    store.record_outcome("nvidia", "m", True, now=140)
    out = sr.assemble_overview(now=150)
    assert out["counts"]["healthy"] == 1 and out["counts"]["health_unknown"] == 0


def test_multiple_local_failures_have_deterministic_scope_correct_priority():
    events = [
        dict(
            reason="provider_error",
            layer="provider",
            state="open",
            observed_at=100,
            local_reconsider_at=200,
            failures=3,
        ),
        dict(
            reason="auth",
            layer="credential",
            state="open",
            observed_at=110,
            local_reconsider_at=210,
            failures=1,
        ),
    ]
    first = hg.describe(candidate(health_observations=events), [], now=150)
    second = hg.describe(
        candidate(health_observations=list(reversed(events))), [], now=150
    )
    assert first == second
    assert first["category"] == "authentication" and first["boundary"] == "credential"
    assert first["account_binding"] == "unknown"


def test_closed_recovery_cannot_hide_newer_unrecovered_transport_failure(tmp_path):
    store = state.StateStore(tmp_path)
    store.record_outcome("nvidia", "m", False, status_code=401, now=100)
    store.record_outcome("nvidia", "m", True, now=110)
    store.record_outcome("nvidia", "m", False, error_type="TimeoutError", now=120)
    data = health.decision(store, "nvidia", "m", now=150)
    assert data["available"] and data["reason"] == "health_unknown"
    note = hg.describe(
        candidate(
            health=data["health"],
            health_reason=data["reason"],
            circuit_state=data["circuit"],
            health_observations=data["observations"],
        ),
        [],
        now=150,
    )
    assert note["category"] == "transport" and note["observed_at"] == 120
    assert note["observations"][0]["unrecovered"] is True
    assert note["current_availability"] == "unknown"


def legacy_v3_store(tmp_path):
    store = state.StateStore(tmp_path)
    with store._connect() as conn:
        conn.execute("ALTER TABLE health_circuits DROP COLUMN event_observed_at")
        conn.execute("UPDATE meta SET value='3' WHERE key='schema_version'")
    return store


def test_legacy_denial_migration_preserves_event_time_not_migration_time(
    tmp_path, monkeypatch
):
    store = legacy_v3_store(tmp_path)
    store.upsert_health("nvidia", "m", auth_failed=1, last_failure_at=100)
    monkeypatch.setattr(state.time, "time", lambda: 1000000)
    migrated = state.StateStore(tmp_path)
    rows = migrated.get_health_circuits("nvidia", "m")
    assert rows[0]["updated_at"] == 1000000
    assert rows[0]["event_observed_at"] == 100
    data = health.decision(migrated, "nvidia", "m", now=1000001)
    note = hg.describe(
        candidate(
            health=data["health"],
            health_reason=data["reason"],
            circuit_state=data["circuit"],
            health_observations=data["observations"],
        ),
        [],
        now=1000001,
    )
    assert note["observed_at"] == 100 and note["evidence_state"] == "stale"
    assert note["source"] == "persisted_health_record"


def test_unlabelled_v3_circuit_stays_unknown_and_readonly_does_not_migrate(tmp_path):
    from autorouter.autorouter_core.storage.snapshot import ReadOnlyStateStore

    store = legacy_v3_store(tmp_path)
    store.upsert_health("nvidia", "m", auth_failed=1, last_failure_at=100)
    with store._connect() as conn:
        conn.execute(
            "INSERT INTO health_circuits(provider,layer,model,scope,failures,threshold,opened_until,reason,updated_at) VALUES('nvidia','credential','','',1,1,2000000,'auth',1000000)"
        )
    before = store.db_path.read_bytes()
    data = health.decision(
        ReadOnlyStateStore(store.db_path), "nvidia", "m", now=1000001
    )
    note = hg.describe(
        candidate(
            health=data["health"],
            health_reason=data["reason"],
            circuit_state=data["circuit"],
            health_observations=data["observations"],
        ),
        [],
        now=1000001,
    )
    assert note["observed_at"] is None and note["source"] == "unknown"
    assert store.db_path.read_bytes() == before
    upgraded = state.StateStore(tmp_path)
    assert upgraded.get_health_circuits("nvidia", "m")[0]["event_observed_at"] is None


def test_event_timestamp_column_migration_rolls_back_atomically(tmp_path, monkeypatch):
    store = legacy_v3_store(tmp_path)

    def fail(*args):
        raise RuntimeError("migration stopped")

    monkeypatch.setattr(
        state.StateStore, "_preserve_legacy_denials", staticmethod(fail)
    )
    with pytest.raises(RuntimeError, match="migration stopped"):
        state.StateStore(tmp_path)
    with store._connect() as conn:
        columns = {r[1] for r in conn.execute("PRAGMA table_info(health_circuits)")}
        assert "event_observed_at" not in columns
        assert (
            conn.execute(
                "SELECT value FROM meta WHERE key='schema_version'"
            ).fetchone()[0]
            == "3"
        )


def test_legacy_success_uses_success_time_not_earlier_failure_time():
    note = hg.describe(
        candidate(
            health={"last_failure_at": 100, "last_success_at": 140},
            health_reason="available",
        ),
        [],
        now=150,
    )
    assert note["category"] == "observed_success" and note["observed_at"] == 140
    assert note["age_seconds"] == 10


def test_exhaustion_provenance_comes_from_denying_cached_gate_not_unknown_evaluator():
    from autorouter.autorouter_core.evidence.free_access import canonical_scope

    exhausted = quota_result(0)
    snapshot = dict(
        schema_version=1,
        provider="openrouter",
        account_scope=canonical_scope("openrouter:" + A),
        state="exhausted",
        quota_evidence=exhausted["allowance"]["quota_windows"],
    )
    unknown = quota_result()
    unknown.update(state="unknown", allowed=True)
    unknown["allowance"].update(
        complete=False,
        quota_windows=[dict(dimension="unsupported_tokens", window="unknown")],
    )
    out = run(
        [
            candidate(
                connection_context=context(),
                quota_snapshot=snapshot,
                health={"last_failure_at": 140},
            )
        ],
        selection_context=ACTIVE,
        quota_evaluator=evaluator(unknown),
    )
    note = out["considered"][0]["health_guidance"]
    assert out["chosen"] is None and note["category"] == "verified_quota_exhaustion"
    assert note["observed_at"] == 100 and note["quota_observation_expires_at"] == 220
    assert note["source"] == "https://openrouter.ai/api/v1/key"


def test_missing_quota_provenance_never_borrows_unrelated_health_time():
    row = candidate(
        health={"last_failure_at": 140},
        free_access=dict(
            allowed=False,
            state="exhausted",
            reason="verified_account_quota_exhausted",
            quota_evidence=[],
        ),
    )
    out = router.evaluate_snapshot([row], now=150)
    note = out["considered"][0]["health_guidance"]
    assert note["category"] == "verified_quota_exhaustion"
    assert note["observed_at"] is None and note["source"] == "unknown"


@pytest.mark.parametrize("value", ["sk-SECRET", -1, float("inf")])
def test_invalid_event_metadata_cannot_become_fresh_or_leak(tmp_path, value):
    store = state.StateStore(tmp_path)
    store.record_outcome("nvidia", "m", False, status_code=401, now=100)
    with store._connect() as conn:
        conn.execute("UPDATE health_circuits SET event_observed_at=?", (value,))
    data = health.decision(store, "nvidia", "m", now=150)
    assert data["reason"] == "health_invalid" and not data["available"]
    assert "SECRET" not in json.dumps(data)


def test_legacy_newer_failure_is_not_hidden_by_an_older_success():
    note = hg.describe(
        candidate(
            health={
                "last_success_at": 100,
                "last_failure_at": 140,
                "last_error": "transport_error",
            },
            health_reason="health_unknown",
        ),
        [],
        now=150,
    )
    assert note["category"] == "transport" and note["observed_at"] == 140
    assert note["current_availability"] == "unknown"


@pytest.mark.parametrize("recovered", [False, True])
def test_explicit_cooldown_uses_new_restriction_time_not_previous_success(
    tmp_path, monkeypatch, recovered
):
    store = state.StateStore(tmp_path)
    if recovered:
        store.record_outcome(
            "nvidia", "m", False, status_code=429, key_scope="A", now=100
        )
        store.record_outcome("nvidia", "m", True, key_scope="A", now=110)
    monkeypatch.setattr(state.time, "time", lambda: 150)
    store.set_cooldown("nvidia", "m", 60, key_scope="A")
    data = health.decision(store, "nvidia", "m", "A", now=151)
    note = hg.describe(
        candidate(
            health=data["health"],
            health_reason=data["reason"],
            circuit_state=data["circuit"],
            health_observations=data["observations"],
        ),
        [],
        now=151,
        authorized=True,
    )
    assert note["category"] == "rate_limit"
    assert note["observed_at"] == 150 and note["age_seconds"] == 1
    assert note["local_reconsider_at"] == 210
    assert note["category"] != "verified_quota_exhaustion"
    assert not data["available"]
    assert health.decision(store, "nvidia", "m", "B", now=151)["available"]
