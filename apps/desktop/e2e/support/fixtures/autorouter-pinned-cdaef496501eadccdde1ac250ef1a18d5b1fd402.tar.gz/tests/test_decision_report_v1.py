"""One evidence projection of existing decisions, with no I/O or account authority."""

import json
from pathlib import Path
import pytest
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.telemetry import decision_report as dr
from tests.test_selection_policy_v1 import (
    candidate,
    run,
    request,
    context,
    ACTIVE,
    quota_result,
    evaluator,
    A,
    B,
)
from tests.test_task_profiles_v1 import policy


@pytest.mark.parametrize(
    "kind",
    [
        "free",
        "paid",
        "unknown",
        "expired",
        "revoked",
        "tools",
        "context",
        "retired",
        "auth",
        "cooldown",
        "scope",
        "strict",
    ],
)
def test_explanation_follows_exact_canonical_decision(kind):
    value = policy("coding", tools_required=kind == "tools")
    row = candidate()
    if kind in ("paid", "unknown"):
        row["cost_tier"] = kind
    elif kind == "expired":
        row["field_evidence"]["cost_tier"]["expires_at"] = 149
    elif kind == "revoked":
        row["cost_tier"] = "unknown"
    elif kind == "tools":
        row["capabilities"]["tools"] = False
    elif kind == "context":
        row["context_length"] = 1
    elif kind == "retired":
        row["retired"] = True
    elif kind == "auth":
        row["health"] = {"auth_failed": 1}
    elif kind == "cooldown":
        row["health"] = {"cooldown_until": 200}
    elif kind == "scope":
        value["connection_restrictions"]["require_authority"] = True
    elif kind == "strict":
        value["quota_policy"] = "require_no_charge_guarantee"
    result = run([row], value=value)
    report = result["evidence_report"]
    assert report == dr.build(result)
    assert report["schema_version"] == 1 and report["policy"]["schema_version"] == 1
    assert (
        report["task"]["profile_id"] == "coding"
        and report["task"]["profile_version"] == 1
    )
    assert bool(report["recommendation"]) == bool(result["chosen"]) == (kind == "free")
    proof = report["candidates"][0]
    assert proof["eligible"] == result["considered"][0]["eligible"]
    assert proof["reason_codes"] == result["considered"][0]["reason_codes"]
    assert proof["next_actions"] or kind == "free"
    assert proof["hard_gates"]["result"] == ("passed" if kind == "free" else "denied")
    assert report["selection_requirements"] == result["selection_policy"]
    assert report["execution_authority"] is False
    assert report["semantic_quality"] == "unknown"


@pytest.mark.parametrize(
    "mode",
    [
        "prefer_available_allowance",
        "require_fresh_account_allowance",
        "avoid_verified_exhaustion",
        "require_no_charge_guarantee",
    ],
)
@pytest.mark.parametrize("remaining", [0, 38])
def test_report_scoped_quota_agrees_and_never_exports_account_identifiers(
    mode, remaining
):
    value = request()
    value["quota_policy"] = mode
    result = run(
        [candidate(connection_context=context())],
        value=value,
        selection_context=ACTIVE,
        quota_evaluator=evaluator(quota_result(remaining)),
    )
    report = result["evidence_report"]
    quota = report["candidates"][0]["quota"]
    assert bool(report["recommendation"]) == bool(result["chosen"])
    assert quota["state"] == result["considered"][0]["quota_policy_evidence"]["state"]
    assert quota["guaranteed_no_charge"] is False
    serialized = json.dumps(report)
    assert A not in serialized and B not in serialized
    assert "account_scope" not in serialized and "shared_scope" not in serialized
    if mode != "require_no_charge_guarantee":
        assert quota["windows"][0]["observed_at"] == 100
        assert quota["windows"][0]["expires_at"] == 220


def test_field_provenance_freshness_and_private_strings_are_safely_projected():
    row = candidate()
    row["field_evidence"]["cost_tier"]["metadata_source"] = (
        "https://openrouter.ai/api/v1/models"
    )
    row["field_evidence"]["tools"].update(
        metadata_source="https://evil.test/path?api_key=SECRET", prompt="PRIVATE"
    )
    row.update(prompt="PRIVATE", api_key="SECRET", credential_scope=A)
    out = run([row])
    report = out["evidence_report"]
    text = json.dumps(report)
    assert "SECRET" not in text and "PRIVATE" not in text and A not in text
    fields = report["candidates"][0]["hard_gates"]["capability_evidence"]
    assert fields["cost_tier"]["source"] == "https://openrouter.ai/api/v1/models"
    assert fields["tools"]["source"] == "unknown"
    assert (
        fields["cost_tier"]["retrieved_at"] == 100
        and fields["cost_tier"]["expires_at"] == 220
    )
    assert fields["cost_tier"]["execution_entitlement"] == "unknown"


@pytest.mark.parametrize("version", [0, 2, True, None, "1"])
def test_unsupported_report_versions_reject(version):
    with pytest.raises(ValueError, match="decision_report_version_unsupported"):
        dr.build(run(), schema_version=version)


def test_report_is_bounded_deterministic_and_no_match_is_not_paid_fallback():
    rows = [candidate(str(i)) for i in range(520)]
    result = run(rows)
    assert len(result["evidence_report"]["candidates"]) == 500
    assert result["evidence_report"]["total_considered"] == 520
    assert result["evidence_report"]["truncated"] is True
    assert len(json.dumps(result["evidence_report"])) < 2500000
    assert result["evidence_report"] == run(list(reversed(rows)))["evidence_report"]
    empty = run([])["evidence_report"]
    assert empty["outcome"] == "no_match" and empty["recommendation"] is None
    assert empty["evidence_availability"] == "absent"
    assert empty["next_actions"] == ["refresh_public_evidence"]


def test_bad_request_is_explained_without_echoing_unknown_fields():
    value = request()
    value["prompt"] = "PRIVATE"
    report = run(value=value)["evidence_report"]
    assert report["recommendation"] is None
    assert report["contract_error"] == "selection_policy_invalid"
    assert report["next_actions"] == ["correct_explicit_requirements"]
    assert "PRIVATE" not in json.dumps(report)


def test_missing_and_corrupt_database_report_unavailable_without_writes(
    tmp_path, monkeypatch
):
    from tests.test_dashboard_state_reader import sr

    values = dict(state_dir=str(tmp_path), providers=["openrouter"], policy="auto")
    monkeypatch.setattr(
        sr, "read_plugin_config", lambda: dict(available=True, values=values)
    )
    missing = sr.assemble_models(now=150)
    assert missing["evidence_report"]["outcome"] == "unavailable"
    assert missing["evidence_report"]["evidence_availability"] == "database_missing"
    db = tmp_path / "autorouter.db"
    assert not db.exists()
    db.write_bytes(b"not SQLite PRIVATE")
    before = db.read_bytes()
    corrupted = sr.assemble_models(now=150)
    assert corrupted["evidence_report"]["recommendation"] is None
    assert corrupted["evidence_report"]["outcome"] == "unavailable"
    assert db.read_bytes() == before and "PRIVATE" not in json.dumps(corrupted)


def test_portable_report_fixture_matches_canonical_projection():
    fixture = json.loads(
        (Path(__file__).with_name("fixtures") / "decision-report-v1.json").read_text()
    )
    assert fixture["synthetic"] and not fixture["live_entitlement"]
    assert fixture["expected"] == run()["evidence_report"]


def test_legacy_cached_exhaustion_is_not_hidden_by_unknown_account_authority():
    row = candidate(
        free_access=dict(
            allowed=False,
            state="exhausted",
            reason="verified_account_quota_exhausted",
            quota_evidence=[],
        )
    )
    result = router.evaluate_snapshot([row], now=150)
    report = result["evidence_report"]
    assert report["recommendation"] is None
    assert report["candidates"][0]["quota"]["state"] == "exhausted"
    assert report["candidates"][0]["active_connection"]["state"] == "unknown"


@pytest.mark.parametrize(
    "identity", ["sk-SECRET", "x" * 10000, "scope_" + "a" * 64, "prompt body PRIVATE"]
)
def test_invalid_identity_cannot_expand_or_leak_through_report(identity):
    report = run([candidate(identity)])["evidence_report"]
    assert identity not in json.dumps(report)
    assert report["recommendation"]["model"] == "[redacted_identity]"
    assert report["candidates"][0]["model"] == "[redacted_identity]"


def test_unavailable_observations_are_not_reported_as_zero_samples():
    report = run()["evidence_report"]
    ranking = report["candidates"][0]["ranking"]
    assert ranking["measurement_state"] == "unavailable"
    assert ranking["observations"]["samples"] is None
    assert ranking["observations"]["latency_ewma_ms"] is None
    assert ranking["source"] == "unknown"


@pytest.mark.parametrize("limit", [1, 500])
def test_selected_evidence_survives_alphabetical_display_truncation(limit):
    rows = [candidate("a-" + str(i).zfill(3), cost_tier="paid") for i in range(500)]
    rows.append(candidate("z-winner"))
    result = run(rows, limit=limit)
    report = result["evidence_report"]
    assert report["recommendation"]["model"] == "z-winner"
    assert len(report["candidates"]) == limit
    winner = next(row for row in report["candidates"] if row["model"] == "z-winner")
    assert winner["eligible"] and winner["hard_gates"]["result"] == "passed"
    assert (
        winner["hard_gates"]["capability_evidence"]["cost_tier"]["freshness"] == "fresh"
    )
    assert winner["ranking"]["total"] == result["chosen"]["score"]["total"]
    assert winner["quota"]["state"] == "unknown"
    assert report["truncated"] and report["total_considered"] == 501
    assert report == run(list(reversed(rows)), limit=limit)["evidence_report"]
