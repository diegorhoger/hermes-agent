"""ADR-0016 Slice B — coherent, single-read pricing evidence.

Every test writes the real per-test HERMES_HOME cache file and exercises the
real snapshot path — no mocking of the snapshot itself — so the same code
path that runs in production is the path that is verified here.
"""

import hashlib
import json
import os
import time
from pathlib import Path

import pytest

from autorouter.autorouter_core.discovery import catalog_enrich
from autorouter.autorouter_core.discovery import discovery

# Provider catalog under which the mock-like fixtures live; the host maps
# nothing for an unknown slug, so the fallback (provider id as-is) applies.
_P = "deepseek"

_FRESH = {
    _P: {"models": {
        "deepseek-free-test": {"limit": {"context": 131072}, "tool_call": True,
                               "cost": {"input": 0.0, "output": 0.0}},
        "deepseek-paid-test": {"limit": {"context": 131072}, "tool_call": True,
                               "cost": {"input": 1.0, "output": 2.0}},
        "deepseek-noprice-test": {"limit": {"context": 65536}, "tool_call": True,
                                  "cost": {}},
        "deepseek-nan-test": {"limit": {"context": 65536}, "tool_call": True,
                              "cost": {"input": float("nan"), "output": 0.0}},
        "deepseek-inf-test": {"limit": {"context": 65536}, "tool_call": True,
                              "cost": {"input": float("inf"), "output": 0.0}},
        "deepseek-neg-test": {"limit": {"context": 65536}, "tool_call": True,
                              "cost": {"input": -0.5, "output": 0.0}},
        "deepseek-incomplete-a": {"limit": {"context": 65536}, "tool_call": True,
                                   "cost": {"input": 0.0}},
        "deepseek-incomplete-b": {"limit": {"context": 65536}, "tool_call": True,
                                   "cost": {"output": 0.0}},
        "deepseek-no-entry-text": {"limit": {"context": 32768}, "tool_call": False},
    }}
}


def _home() -> Path:
    env = os.environ.get("HERMES_HOME")
    assert env, "tests assume the hermetic per-test HERMES_HOME"
    return Path(env)


def _fresh_home_cache(payload, age_seconds=60.0, mtime=None):
    """Write the catalog into the per-test HERMES_HOME with a controlled mtime."""
    path = _home() / "models_dev_cache.json"
    now = time.time()
    data = json.dumps(payload)
    path.write_text(data)
    if mtime is not None:
        path_mtime = mtime
    else:
        path_mtime = now - age_seconds
    os.utime(path, (path_mtime, path_mtime))
    return path


@pytest.fixture(autouse=True)
def _isolated_hermes_home(tmp_path, monkeypatch):
    home = tmp_path / "hermes"
    home.mkdir()
    monkeypatch.setenv("HERMES_HOME", str(home))
    return home


@pytest.fixture()
def fresh_cache():
    return _fresh_home_cache(_FRESH)


# ── Freshness and source identity ──────────────────────────────────────

def test_fresh_zero_price_is_eligibility_evidence(fresh_cache):
    out = catalog_enrich.enrich("deepseek", "deepseek-free-test")
    assert out["cost_tier"] == "free"
    assert out["pricing_status"] == "zero_price"
    assert out["context_window"] == 131072
    assert out["cache_source"] == "https://models.dev/api.json"
    assert out["expires_at"] > out["retrieved_at"] > 0


def test_stale_cache_is_refused(monkeypatch, tmp_path):
    """A cache older than the host TTL must not vouch for pricing."""
    stale = _fresh_home_cache(_FRESH, age_seconds=5 * 3600)
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None


def test_missing_cache_is_refused():
    target = _home() / "models_dev_cache.json"
    if target.exists():
        target.unlink()
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None


def test_future_dated_cache_is_refused():
    future_mtime = time.time() + 3600  # one hour into the future
    _fresh_home_cache(_FRESH, mtime=future_mtime)
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None


def test_corrupt_cache_is_refused():
    path = _home() / "models_dev_cache.json"
    path.write_text("{ not json at all ")
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None
    path.write_text("[]")
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None
    path.write_text("{}")
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None


def test_patched_mirror_global_is_refused(monkeypatch):
    """A patched MODELS_DEV_URL global never satisfies free eligibility either."""
    _fresh_home_cache(_FRESH)
    import agent.models_dev as md

    monkeypatch.setattr(md, "MODELS_DEV_URL", "https://evil.example/models.json")
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None


def test_config_override_mirror_is_refused(monkeypatch):
    """A models_dev.url config override is untrusted without a trust contract."""
    _fresh_home_cache(_FRESH)
    import agent.models_dev as md

    monkeypatch.setattr(md, "_cfg_get", lambda *a, **kw: "https://evil.example/models.json")
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None


def test_provider_mismatch_is_refused(fresh_cache):
    """Price evidence belongs to the provider keys in the cache; nothing is borrowed."""
    # Hermes catalog maps canonical id to its models.dev id (deepseek), never back again;
    # a differently-named host provider must not inherit pricing from its neighbours either.
    assert catalog_enrich.enrich("anthropic", "deepseek-free-test") is None


def test_model_mismatch_is_refused(fresh_cache):
    assert catalog_enrich.enrich("deepseek", "nonsense-model") is None
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test-extra") is None


# ── Prices ─────────────────────────────────────────────────────────────

def test_positive_prices_are_paid(fresh_cache):
    out = catalog_enrich.enrich("deepseek", "deepseek-paid-test")
    assert out["cost_tier"] == "paid"


def test_missing_prices_are_unknown(fresh_cache):
    out = catalog_enrich.enrich("deepseek", "deepseek-noprice-test")
    assert out["cost_tier"] == "unknown"


def test_nonfinite_and_negative_prices_are_unknown(fresh_cache):
    for model in ("deepseek-nan-test", "deepseek-inf-test", "deepseek-neg-test"):
        out = catalog_enrich.enrich("deepseek", model)
        assert out is not None and out["cost_tier"] == "unknown" and out["pricing_status"] == "unknown"


def test_incomplete_prices_are_unknown(fresh_cache):
    for model in ("deepseek-incomplete-a", "deepseek-incomplete-b"):
        out = catalog_enrich.enrich("deepseek", model)
        assert out["cost_tier"] == "unknown"


# ── Swap / replacement races ───────────────────────────────────────────

def test_cache_replaced_between_stat_and_open(monkeypatch, tmp_path):
    fresh_path = _fresh_home_cache(_FRESH)
    pre_mtime = fresh_path.stat().st_mtime
    other = tmp_path / "other.json"
    other.write_text(json.dumps(_FRESH))
    os.utime(other, (pre_mtime, pre_mtime))

    from pathlib import Path as _Path

    real_open = _Path.open
    swapped = {"done": False}

    def sneaky_open(self, *args, **kwargs):
        if self == fresh_path and not swapped["done"]:
            os.replace(other, fresh_path)   # atomic swap to a different inode
            swapped["done"] = True
        return real_open(self, *args, **kwargs)

    monkeypatch.setattr(_Path, "open", sneaky_open)
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None


def test_cache_mutated_during_read(monkeypatch, tmp_path):
    fresh_path = _fresh_home_cache(_FRESH)

    real_fstat = os.fstat
    state = {"first": False}

    def sneaky_fstat(fd):
        st = real_fstat(fd)
        if not state["first"]:
            state["first"] = True
            stale_mtime = st.st_mtime + 5
            os.utime(fresh_path, (stale_mtime, stale_mtime))  # in-place mtime bump
        return st

    monkeypatch.setattr(os, "fstat", sneaky_fstat)
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None


# ── Divergent-memory vs divergent-disk: disk must win ──────────────────

def test_memory_says_free_disk_says_paid_disk_wins(monkeypatch, tmp_path):
    """Contradictory sources: fresh disk wins; stale memory is ignored."""
    import sys
    import types

    fake = types.ModuleType("agent.models_dev")
    fake.MODELS_DEV_URL = "https://models.dev/api.json"
    fake._MODELS_DEV_CACHE_TTL = 4 * 3600
    fake._get_models_dev_url = lambda: "https://models.dev/api.json"
    fake._disk_cache_age_seconds = lambda: 0.0
    fake._models_dev_cache = {
        _P: {"models": {"deepseek-free-test": {"cost": {"input": 0.0, "output": 0.0}, "tool_call": True}}}
    }
    monkeypatch.setitem(sys.modules, "agent.models_dev", fake)

    disk_catalog = json.loads(json.dumps(_FRESH))
    disk_catalog[_P]["models"]["deepseek-free-test"]["cost"] = {"input": 1.5, "output": 2.0}
    _fresh_home_cache(disk_catalog)
    out = catalog_enrich.enrich("deepseek", "deepseek-free-test")
    assert out["cost_tier"] == "paid"


def test_memory_says_paid_disk_says_free_disk_wins(monkeypatch, tmp_path):
    """Correct direction: a freshly fetched disk snapshot is authoritative even if
    memory holds conflicting positive prices."""
    import sys
    import types

    fake = types.ModuleType("agent.models_dev")
    fake.MODELS_DEV_URL = "https://models.dev/api.json"
    fake._MODELS_DEV_CACHE_TTL = 4 * 3600
    fake._get_models_dev_url = lambda: "https://models.dev/api.json"
    fake._disk_cache_age_seconds = lambda: 0.0
    fake._models_dev_cache = {
        _P: {"models": {"deepseek-free-test": {"cost": {"input": 9.0, "output": 9.0}, "tool_call": True}}}
    }
    monkeypatch.setitem(sys.modules, "agent.models_dev", fake)

    _fresh_home_cache(_FRESH)  # disk is fresh, zero price
    out = catalog_enrich.enrich("deepseek", "deepseek-free-test")
    assert out["cost_tier"] == "free"
    assert out["pricing_status"] == "zero_price"


def test_in_memory_records_are_not_consulted(monkeypatch, tmp_path):
    """An in-memory registry snapshot claiming everything is free does not leak
    into the disk-backed proof path: only the coherently read bytes can produce free."""
    import sys
    import types

    fake = types.ModuleType("agent.models_dev")
    fake.MODELS_DEV_URL = "https://models.dev/api.json"
    fake._MODELS_DEV_CACHE_TTL = 4 * 3600
    fake._get_models_dev_url = lambda: "https://models.dev/api.json"
    fake._disk_cache_age_seconds = lambda: 0.0
    fake._models_dev_cache = {
        _P: {"models": {"deepseek-free-test": {"cost": {"input": 0.0, "output": 0.0}, "tool_call": True}}}
    }
    monkeypatch.setitem(sys.modules, "agent.models_dev", fake)
    # No disk cache present: memory-only truth must NOT authorize.
    target = _home() / "models_dev_cache.json"
    if target.exists():
        target.unlink()
    assert catalog_enrich.enrich("deepseek", "deepseek-free-test") is None
    # Fresh disk says positive prices, memory still says free-zero: disk wins.
    stale_catalog = json.loads(json.dumps(_FRESH))
    stale_catalog[_P]["models"]["deepseek-free-test"]["cost"] = {"input": 1.5, "output": 2.0}
    _fresh_home_cache(stale_catalog)
    out = catalog_enrich.enrich("deepseek", "deepseek-free-test")
    assert out["cost_tier"] == "paid"


# ── End-to-end eligibility ─────────────────────────────────────────────

def test_discovery_uses_only_coherent_snapshot(fresh_cache):
    rows = discovery._resolved_models("deepseek", ["deepseek-free-test", "deepseek-paid-test"], {}, None)
    by_id = {row["model"]: row for row in rows}
    assert by_id["deepseek-free-test"]["cost_tier"] == "free"
    assert by_id["deepseek-paid-test"]["cost_tier"] == "paid"
    assert by_id["deepseek-free-test"]["metadata"]["retrieved_at"] > 0
    assert "disk cache" in by_id["deepseek-free-test"]["metadata"]["metadata_source"]


def test_stale_cache_rows_never_reach_free(fresh_cache):
    stale = _fresh_home_cache(_FRESH, age_seconds=5 * 3600)
    rows = discovery._resolved_models("deepseek", ["deepseek-free-test"], {}, None)
    assert rows[0]["cost_tier"] == "unknown"
