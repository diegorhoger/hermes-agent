"""Combined schema upgrade tests; no inferred credential authority."""

import pytest
from autorouter.autorouter_core.storage import state
from tests.test_dashboard_state_reader import sr


def test_schema_v4_upgrades_attempt_scope_without_inventing_legacy_identity(tmp_path):
    store = state.StateStore(tmp_path)
    rid = store.begin_request(
        api_request_id="legacy", provider="openrouter", model="m", key_scope="old"
    )
    store.record_attempt(rid, 0, provider="openrouter", model="m")
    with store._connect() as db:
        db.execute("ALTER TABLE request_attempts DROP COLUMN key_scope")
        db.execute("UPDATE meta SET value='4' WHERE key='schema_version'")
    before = store.db_path.read_bytes()
    view = sr._assemble_request_detail(store.db_path, rid, 150)
    assert view["available"] and view["attempts"][0]["key_scope"] == ""
    assert store.db_path.read_bytes() == before
    upgraded = state.StateStore(tmp_path)
    assert upgraded.get_request_attempts(rid)[0]["key_scope"] == ""
    with upgraded._connect() as db:
        assert (
            db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[
                0
            ]
            == str(state.SCHEMA_VERSION)
        )
        assert "event_observed_at" in {
            r[1] for r in db.execute("PRAGMA table_info(health_circuits)")
        }


@pytest.mark.parametrize("version", [3, 4])
@pytest.mark.parametrize("known_scope", [False, True])
def test_legacy_schema_upgrade_preserves_attempts_and_health_provenance(
    tmp_path, version, known_scope
):
    store = state.StateStore(tmp_path)
    rid = store.begin_request(
        api_request_id="legacy-scope", provider="openrouter", model="m"
    )
    store.record_attempt(
        rid, 0, provider="openrouter", model="m", key_scope="authorized-observation"
    )
    original = store.get_request_attempts(rid)[0]
    with store._connect() as db:
        db.execute(
            "INSERT INTO health_circuits(provider,layer,model,scope,failures,threshold,opened_until,reason,updated_at,event_observed_at) VALUES('openrouter','credential','','',1,1,300,'auth',200,100)"
        )
        if not known_scope:
            db.execute("ALTER TABLE request_attempts DROP COLUMN key_scope")
        if version == 3:
            db.execute("ALTER TABLE health_circuits DROP COLUMN event_observed_at")
        db.execute(
            "UPDATE meta SET value=? WHERE key='schema_version'", (str(version),)
        )
    upgraded = state.StateStore(tmp_path)
    current = upgraded.get_request_attempts(rid)[0]
    for key in ("ordinal", "provider", "model", "created_at"):
        assert current[key] == original[key]
    assert current["key_scope"] == (original["key_scope"] if known_scope else "")
    assert not upgraded.record_attempt(
        rid, 0, provider="nvidia", model="changed", key_scope="other"
    )
    assert upgraded.get_request_attempts(rid)[0] == current
    with upgraded._connect() as db:
        assert (
            db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[
                0
            ]
            == str(state.SCHEMA_VERSION)
        )
        rows = db.execute(
            "SELECT event_observed_at,updated_at FROM health_circuits"
        ).fetchall()
        assert len(rows) == 1 and rows[0]["event_observed_at"] == (
            100 if version == 4 else None
        )
        assert rows[0]["updated_at"] == 200
    assert state.StateStore(tmp_path).get_request_attempts(rid)[0] == current


@pytest.mark.parametrize("version", [3, 4])
def test_schema5_failure_rolls_back_scope_column_and_version(
    tmp_path, monkeypatch, version
):
    store = state.StateStore(tmp_path)
    with store._connect() as db:
        db.execute("ALTER TABLE request_attempts DROP COLUMN key_scope")
        db.execute(
            "UPDATE meta SET value=? WHERE key='schema_version'", (str(version),)
        )

    def fail(*args):
        raise RuntimeError("synthetic migration failure")

    monkeypatch.setattr(
        state.StateStore, "_preserve_legacy_denials", staticmethod(fail)
    )
    with pytest.raises(RuntimeError, match="synthetic migration failure"):
        state.StateStore(tmp_path)
    with store._connect() as db:
        assert "key_scope" not in {
            r[1] for r in db.execute("PRAGMA table_info(request_attempts)")
        }
        assert db.execute(
            "SELECT value FROM meta WHERE key='schema_version'"
        ).fetchone()[0] == str(version)
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
