"""Offline candidate-registry acceptance; no provider SDK, credentials, or inference calls."""
import csv
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys

import pytest
from autorouter.autorouter_core.discovery import provider_registry as registry
from autorouter.autorouter_core.eligibility import eligibility
from autorouter.autorouter_core.routing import router
from autorouter.autorouter_core.storage import state


@pytest.fixture
def source_rows():
    return list(csv.DictReader(registry.SOURCE.open(encoding='utf-8')))


def csv_text(rows):
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=registry.COLUMNS)
    writer.writeheader()
    writer.writerows(rows)
    return out.getvalue()


def test_lossless_249_and_provenance(source_rows):
    document = registry.load_registry()
    assert document['source_commit'] == registry.SOURCE_COMMIT
    assert document['source_sha256'] == hashlib.sha256(registry.SOURCE.read_bytes()).hexdigest()
    assert len(document['entries']) == 249
    assert [entry['source_index'] for entry in document['entries']] == list(range(249))
    assert [entry['source_claim'] for entry in document['entries']] == source_rows
    assert len({entry['canonical_id'] for entry in document['entries']}) == 249
    missing = document['entries'][141]
    assert missing['source_provider_id'] is None
    assert missing['canonical_id'] == 'pir-141-unidentified'
    assert registry.find_candidates('NaN.Builders')[0] == missing


def test_stable_ids_and_no_alias_overwrite(source_rows):
    original = registry.ingest(csv_text(source_rows))
    assert registry.ingest(csv_text(list(reversed(source_rows)))) == original
    a, b = dict(source_rows[0]), dict(source_rows[1])
    b['provider_id'], b['name'] = a['provider_id'], a['name']
    entries = registry.ingest(csv_text([a,b]))
    assert entries[0]['canonical_id'] != entries[1]['canonical_id']
    assert len(registry.find_candidates(a['provider_id'], {'entries': entries})) == 2


def test_deterministic_idempotent_cli(tmp_path):
    pkg_src = Path(registry.__file__).parent  # autorouter_core/discovery
    shutil.copytree(pkg_src, tmp_path / 'autorouter_core' / 'discovery')
    data = tmp_path / 'data/provider_registry'
    data.mkdir(parents=True)
    shutil.copy(registry.SOURCE, data / registry.SOURCE.name)
    command = [sys.executable, str(tmp_path / 'autorouter_core' / 'discovery' / 'provider_registry.py')]
    for _ in range(2):
        assert subprocess.run(command, capture_output=True).returncode == 0
        assert (data / registry.OUTPUT.name).read_bytes() == registry.OUTPUT.read_bytes()
    assert subprocess.run(command + ['--check'], capture_output=True).returncode == 0
    (data / registry.OUTPUT.name).write_text('{}')
    assert subprocess.run(command + ['--check'], capture_output=True).returncode == 1


def test_protocols_modalities_variants_and_deprecation():
    def entry(source_id): return registry.find_candidates(source_id)[0]
    assert entry('oneminai')['protocol_hint'] == 'proprietary_chat'
    assert entry('runwayml')['protocol_hint'] == 'async_video'
    assert entry('runwayml')['modalities'] == ['video']
    assert entry('jina-ai')['variant_kind'] == 'specialized'
    assert 'chat' not in entry('jina-ai')['modalities']
    for native, gateway in [('nvidia','g4f-nvidia'), ('gemini','g4f-gemini')]:
        assert entry(native)['canonical_id'] != entry(gateway)['canonical_id']
        assert entry(gateway)['variant_kind'] == 'gateway'
        assert entry(gateway)['experimental'] is True
        assert entry(gateway)['trust_state'] == 'unverified'
        assert entry(gateway)['related_source_provider_id'] == native
    assert entry('naga-ai')['canonical_id'] != entry('naga-ac')['canonical_id']
    assert entry('qwen-cloud-token-plan')['variant_kind'] == 'plan'
    assert entry('agnes-cn')['variant_kind'] == 'region'
    assert entry('glm-cn')['related_source_provider_id'] == 'glm'
    deprecated = [e for e in registry.load_registry()['entries'] if e['registry_status'] == 'deprecated']
    assert len(deprecated) == 5
    assert all(e['variant_kind'] == 'deprecated' and not e['active'] for e in deprecated)


def test_unknowns_and_claims_never_become_eligibility(tmp_path, monkeypatch):
    import socket
    monkeypatch.setattr(socket, 'create_connection', lambda *a, **k: pytest.fail('unexpected network'))
    store = state.StateStore(tmp_path)
    for entry in registry.load_registry()['entries']:
        assert not entry['active'] and not entry['operationally_integrated']
        assert entry['verification_state'] == 'unverified_source_claim'
        assert entry['autorouter_default_eligible'] is False
        for key in ('models','context_length','tools','streaming','pricing','quota','verified_at','expires_at'):
            assert entry[key] is None
    assert store.get_catalog() == []
    assert router.Router({'store':store}).select_free_model() is None
    assert eligibility.cost_allowed('free')
    for cost in ('paid','premium','unknown',None):
        assert not eligibility.cost_allowed(cost, free_only=False, paid_authorized=True)


@pytest.mark.parametrize('url', ['javascript:alert(1)', 'file:///etc/passwd', '//example.com',
    'http://127.0.0.1/test', 'http://[::1]/', 'http://localhost/', 'https://host.local',
    'https://example.com:bad/', 'https://example.com:444/', 'https://example..com',
    'https://example.com/path?utm_source=source', 'https://example.com/#section', 'https://example.com/has space'])
def test_reject_unsafe_url(url):
    assert registry.safe_url(url) is None


def test_url_evidence_not_api_endpoint(source_rows):
    assert registry.safe_url('https://Example.COM/v1.') == 'https://example.com/v1'
    row = dict(source_rows[0], urls='javascript:alert(1); https://example.com/docs')
    entry = registry.ingest(csv_text([row]))[0]
    assert entry['rejected_url_count'] == 1
    assert entry['url_evidence'] == ['https://example.com/docs']
    assert 'api_url' not in entry
    assert entry['source_claim']['urls'] == row['urls']


@pytest.mark.parametrize('change', [dict(index='01'), dict(index='-1'), dict(name=''),
    dict(provider_id='../escape'), dict(status='active'), dict(verification='verified'),
    dict(autorouter_default_eligible='True'), dict(classification='free')])
def test_malformed_rows_rejected(source_rows, change):
    with pytest.raises(ValueError): registry.ingest(csv_text([dict(source_rows[0], **change)]))


def test_duplicate_index_missing_columns_and_pinned_source(source_rows):
    with pytest.raises(ValueError, match='duplicate'): registry.ingest(csv_text([source_rows[0]] * 2))
    with pytest.raises(ValueError): registry.ingest('index,name\n0,test\n')
    with pytest.raises(ValueError): registry.ingest(csv_text(source_rows) + 'malformed,record\n')
    with pytest.raises(ValueError, match='checksum'): registry.build(csv_text(source_rows))


@pytest.mark.parametrize('secret', ['sk-' + 'x'*30, 'Bearer ' + 'a'*30,
    'password=supersecret', 'https://name:supersecret@example.com/path',
    'https://example.com/?token=supersecret', 'https://example.com/?api_key%3Dsupersecret'])
def test_credentials_rejected_without_echo(source_rows, secret, caplog, capsys):
    with pytest.raises(ValueError) as error:
        registry.ingest(csv_text([dict(source_rows[0], notes=secret)]))
    assert secret not in str(error.value)
    assert secret not in caplog.text
    assert secret not in capsys.readouterr().out
    assert secret not in registry.OUTPUT.read_text()


def test_corrupt_snapshot_rejected(tmp_path, monkeypatch):
    path = tmp_path / 'snapshot.json'
    path.write_text('{}')
    monkeypatch.setattr(registry, 'OUTPUT', path)
    with pytest.raises(ValueError, match='snapshot'): registry.load_registry()
