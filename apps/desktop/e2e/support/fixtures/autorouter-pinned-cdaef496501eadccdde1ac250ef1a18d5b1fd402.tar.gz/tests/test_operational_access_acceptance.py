"""Host-blocked acceptance wrapper for the structured-scope contract; synthetic scoped facts, no credential producer."""
from types import SimpleNamespace

import pytest
from autorouter.autorouter_core.evidence import free_access, scope_quota
from autorouter.autorouter_core.integration import runtime
from autorouter.autorouter_core.storage import state

NOW=1794000000.0
A='a'*32
B='b'*32


@pytest.fixture
def access(tmp_path,monkeypatch):
    store=state.StateStore(tmp_path)
    monkeypatch.setattr(scope_quota.time,'time',lambda:NOW)
    return store


def observation(scope,remaining):
    return dict(status='ok',provider_id='openrouter',credential_scope_id=scope,
        quota_source='official_key_limits',limit=50,remaining=remaining,used=50-remaining,
        observed_at=NOW,expires_at=NOW+120)


def test_authorized_producer_facts_are_isolated_and_unknown_never_borrows(access):
    for scope,remaining in [(A,38),(B,0)]:
        assert scope_quota.ingest(access,'openrouter','openrouter:'+scope,observation(scope,remaining))
    def evaluate(scope,now=NOW):
        snap=free_access.read_snapshot(access,'openrouter',scope)
        return free_access.evaluate(snap,'openrouter','example:free',scope,now)
    assert evaluate('openrouter:'+A)['state']=='healthy'
    assert evaluate('openrouter:'+B)['state']=='exhausted'
    assert evaluate('')['state']=='unknown'
    assert evaluate('openrouter:'+'c'*32)['state']=='unknown'
    assert evaluate('openrouter:'+A,NOW+120)['state']=='unknown'
    assert evaluate('openrouter:'+B,NOW+120)['state']=='unknown'
    assert not evaluate('openrouter:'+A)['hard_stop_guaranteed']


@pytest.mark.parametrize('status',[401,403,429,500,503,504])
def test_observed_failure_only_invalidates_authoritative_matching_scope(access,status):
    for scope in (A,B):
        assert scope_quota.ingest(access,'openrouter','openrouter:'+scope,observation(scope,38))
    before=free_access.read_snapshot(access,'openrouter','openrouter:'+A)['quota_evidence']
    free_access.invalidate_cached(access,'openrouter','openrouter:'+A,status)
    one=free_access.read_snapshot(access,'openrouter','openrouter:'+A)
    two=free_access.read_snapshot(access,'openrouter','openrouter:'+B)
    assert one['state']=='unavailable'
    assert one['quota_evidence']==before
    assert two['state']=='healthy'
    assert one['state']!='exhausted'


@pytest.mark.parametrize('metadata',[None,{},'previous-account',
    dict(provider_id='openrouter',credential_scope_id=None,identity_status='unknown')])
def test_standard_host_missing_scope_and_quota_api_never_infers_identity(access,monkeypatch,metadata):
    # This is the sanctioned surface available on an unextended host, not a host patch.
    ctx=SimpleNamespace(get_config=lambda *args:True)
    monkeypatch.setattr(runtime,'_STATE',{'store':access,'ctx':ctx})
    runtime.on_pre_api_request(provider='openrouter',model='example:free',
        credential_scope=metadata,api_request_id='native-request')
    assert free_access.read_snapshot(access,'openrouter','')['state']=='unknown'
    assert not runtime.get_state().get('credential_scopes')
    with access._connect() as db:
        assert db.execute("SELECT count(*) FROM capabilities WHERE model LIKE '__quota__:%'").fetchone()[0]==0


def test_wrong_scope_result_is_rejected_without_reassigning_account(access):
    assert not scope_quota.ingest(access,'openrouter','openrouter:'+A,observation(B,38))
    assert free_access.read_snapshot(access,'openrouter','openrouter:'+A)['state']=='unknown'
    assert free_access.read_snapshot(access,'openrouter','openrouter:'+B)['state']=='unknown'
