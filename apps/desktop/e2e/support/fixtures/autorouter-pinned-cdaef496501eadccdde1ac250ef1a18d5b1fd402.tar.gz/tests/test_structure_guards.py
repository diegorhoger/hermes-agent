"""Structure regression guard: professionally organized runtime package.

These tests fail when the plugin root gains a new runtime ``*.py`` module or
when ``autorouter_core/`` is left flat with no subpackages. They do not
introspect contents, only naming and membership.
"""
from pathlib import Path
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT / 'autorouter_core'

ALLOWED_ROOT_PY = {'__init__.py'}
ALLOWED_SUB = {'routing', 'discovery', 'providers', 'eligibility', 'evidence', 'health', 'telemetry', 'storage', 'integration', 'configuration'}


def test_repository_root_has_no_unauthorized_runtime_modules():
    found = {p.name for p in ROOT.glob('*.py')}
    unexpected = found - ALLOWED_ROOT_PY
    assert not unexpected, f'unexpected root runtime modules: {unexpected}'


def test_core_package_is_feature_grouped():
    found = {p.name for p in CORE.iterdir() if p.is_dir() and not p.name.startswith(('.', '__'))}
    assert found == ALLOWED_SUB, f'expected {ALLOWED_SUB}, found {found}'


@pytest.mark.parametrize('sub', sorted(ALLOWED_SUB))
def test_every_subpackage_has_an_init(sub):
    init = CORE / sub / '__init__.py'
    assert init.is_file(), f'missing {sub}/__init__.py'


def test_mock_server_is_not_in_the_runtime_package():
    mocks = sorted(CORE.rglob('controlled_mock_server.py'))
    assert not mocks, mocks


def test_test_files_are_not_in_the_runtime_package():
    """Tracked runtime tree must not carry test tooling, bytecode or local state.

    Untracked __pycache__ directories are expected after a local pytest run and are
    not a repository defect; the distribution gate lives in tools/build_package.py
    and in test_package_v1 / test_build_inventory. Here we inspect git-tracked files.
    """
    try:
        out = subprocess.run(
            ['git', 'ls-files', '--', 'autorouter_core'],
            cwd=ROOT, capture_output=True, text=True, check=True,
        ).stdout.splitlines()
    except Exception:
        out = [str(p.relative_to(ROOT)) for p in CORE.rglob('*') if p.is_file()]
    forbidden = (
        'conftest.py', 'controlled_mock_server.py', '__pycache__', '.pyc',
        '.db', '.sqlite', '.sqlite3', '.log', '.pytest_cache', '.env',
    )
    bad = [p for p in out if any(part in p for part in forbidden)]
    assert not bad, bad
