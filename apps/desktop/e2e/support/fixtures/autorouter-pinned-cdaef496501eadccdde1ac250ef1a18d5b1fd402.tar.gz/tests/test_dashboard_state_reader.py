"""Tests for the dashboard state reader (dashboard/state_reader.py).

Loads the module from its file path exactly as the Hermes plugin loader
loads plugin_api.py — as a standalone module, not as part of the
``autorouter`` package.
"""

from __future__ import annotations

import importlib.util
import json
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
STATE_READER = ROOT / "dashboard" / "state_reader.py"


def _load_state_reader():
    name = "_test_autorouter_state_reader"
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, STATE_READER)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


sr = _load_state_reader()


@pytest.fixture()
def cfg(monkeypatch, tmp_path):
    """Point the reader at an isolated state dir with a test config."""
    state_dir = tmp_path / "state"
    values = {
        "enabled": True,
        "policy": "auto",
        "free_only": True,
        "providers": ["nvidia", "openrouter"],
        "cooldown_seconds": 60,
        "state_dir": str(state_dir),
        "paid_authorized": False,
    }
    monkeypatch.setattr(sr, "read_plugin_config", lambda: {
        "values": dict(values), "available": True, "reason": None, "managed": False,
    })
    return state_dir


def _seed_store(state_dir: Path):
    """Create and populate a real autorouter.db under state_dir."""
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    import autorouter_core.storage.state as state_mod
    store = state_mod.StateStore(state_dir)
    return store


def _now() -> float:
    return time.time()


# ---------------------------------------------------------------------------
# empty / missing / corrupt database
# ---------------------------------------------------------------------------

class TestEmptyAndCorrupt:
    def test_missing_db_overview(self, cfg):
        out = sr.assemble_overview()
        assert out["available"] is False
        assert "not initialized" in out["reason"]
        assert set(out["unavailable"]) >= {"counts", "recent_decisions", "recent_failures"}

    def test_missing_db_models(self, cfg):
        out = sr.assemble_models()
        assert out["available"] is True
        assert out["models"] == []
        assert "not initialized" in out["reason"]

    def test_missing_db_analytics(self, cfg):
        out = sr.assemble_analytics()
        assert out["available"] is False

    def test_missing_db_providers(self, cfg):
        out = sr.assemble_providers()
        names = [p["name"] for p in out["providers"]]
        assert names == ["nvidia", "openrouter"]
        assert all(p["discovered_models"] == 0 for p in out["providers"])
        assert "database" in out["unavailable"]

    def test_corrupt_db(self, cfg):
        cfg.mkdir(parents=True)
        (cfg / "autorouter.db").write_bytes(b"this is definitely not sqlite")
        overview = sr.assemble_overview()
        assert overview["available"] is False
        assert "corrupt" in overview["reason"] or "could not be" in overview["reason"]
        assert sr.assemble_models()["available"] is False
        assert sr.assemble_analytics()["available"] is False
        providers = sr.assemble_providers()
        assert providers["available"] is False

    def test_partial_schema_db(self, cfg):
        """A DB that is valid sqlite but lacks the tables degrades gracefully."""
        import sqlite3

        cfg.mkdir(parents=True)
        conn = sqlite3.connect(cfg / "autorouter.db")
        conn.execute("CREATE TABLE catalog(provider TEXT, model TEXT)")
        conn.close()
        assert sr.assemble_overview()["available"] is False
        assert sr.assemble_models()["available"] is False
        assert sr.assemble_analytics()["available"] is False
        assert sr.assemble_providers()["available"] is False

    def test_empty_db_seeded(self, cfg):
        _seed_store(cfg)  # creates schema, no rows
        overview = sr.assemble_overview()
        assert overview["available"] is True
        assert overview["counts"]["discovered_models"] == 0
        assert overview["counts"]["healthy"] == 0
        assert overview["last_catalog_refresh"] is None
        models = sr.assemble_models()
        assert models["models"] == []


# ---------------------------------------------------------------------------
# seeded store behaviour
# ---------------------------------------------------------------------------

def _seed(store):
    seed_verified_model(store, "nvidia", "free-good", context_length=131072,
                         capabilities={"tools": "supported"}, cost_tier="free")
    seed_verified_model(store, "nvidia", "free-small", context_length=4096,
                         capabilities={"tools": "supported"}, cost_tier="free")
    seed_verified_model(store, "openrouter", "paid-pro", context_length=200000,
                         capabilities={"tools": "supported"}, cost_tier="paid")
    seed_verified_model(store, "openrouter", "free-unknown-cost", context_length=32768,
                         capabilities={"tools": "unknown"}, cost_tier="unknown")
    seed_verified_model(store, "openrouter", "free-nocontext", context_length=None,
                         capabilities={"tools": "unknown"}, cost_tier="free")
    seed_verified_model(store, "nvidia", "retired-one", context_length=16384,
                         capabilities={"tools": "supported"}, cost_tier="free")
    store.record_outcome("nvidia", "retired-one", False, status_code=404, error_type="model_not_found",
                         error_message="model gone, key sk-livekey1234567890 leaked?")
    store.record_decision("auto", "nvidia", "free-good", "selected", 3)
    store.record_decision("auto", "nvidia", "free-good", "selected", 5)
    store.record_decision("coding", "openrouter", "paid-pro", "selected", 1)
    store.record_event("pre_api_request", "nvidia", "free-good")
    # Seed telemetry requests for analytics tests (inference, not decisions)
    try:
        rid1 = store.begin_request(provider="nvidia", model="free-good", task_id="t1")
        store.finish_request(rid1, status="success", input_tokens=100, output_tokens=50, latency_ms=1200, ttft_ms=80)
        rid2 = store.begin_request(provider="nvidia", model="free-good", task_id="t2")
        store.finish_request(rid2, status="success", input_tokens=200, output_tokens=80, latency_ms=1500, ttft_ms=90)
        rid3 = store.begin_request(provider="openrouter", model="paid-pro", task_id="t3")
        store.finish_request(rid3, status="error", error_category="timeout", input_tokens=50, output_tokens=0, latency_ms=3000)
    except Exception:
        pass


class TestSeededStore:
    def test_overview_counts(self, cfg):
        store = _seed_store(cfg)
        _seed(store)
        out = sr.assemble_overview()
        assert out["available"] is True
        counts = out["counts"]
        assert counts["discovered_models"] == 6
        assert counts["retired"] == 1
        assert counts["healthy"] == 0
        assert counts["health_unknown"] == 5
        assert counts["decisions"] == 3
        assert counts["events"] == 1
        assert out["last_catalog_refresh"] is not None
        assert len(out["recent_decisions"]) == 3
        assert out["recent_decisions"][0]["ts"] >= out["recent_decisions"][-1]["ts"]

    def test_secret_redaction_in_failures(self, cfg):
        store = _seed_store(cfg)
        _seed(store)
        out = sr.assemble_overview()
        blob = json.dumps(out)
        assert "sk-livekey1234567890" not in blob
        assert "model_retired" in blob

    def test_models_eligibility(self, cfg):
        store = _seed_store(cfg)
        _seed(store)
        out = sr.assemble_models()
        models = {m["model"]: m for m in out["models"]}
        assert models["free-good"]["eligible"] is True
        assert models["free-good"]["reasons"] == []
        assert models["free-small"]["eligible"] is False
        assert "context_unknown_or_insufficient" in models["free-small"]["reason_codes"]
        assert models["paid-pro"]["eligible"] is False
        assert "cost_not_verified_free" in models["paid-pro"]["reason_codes"]
        assert models["free-unknown-cost"]["eligible"] is False
        assert models["free-nocontext"]["eligible"] is False
        assert models["retired-one"]["eligible"] is False
        assert any("retired" in r for r in models["retired-one"]["reasons"])

    def test_free_only_consistency(self, cfg):
        """Every model marked eligible must satisfy the free-only boundary."""
        store = _seed_store(cfg)
        _seed(store)
        out = sr.assemble_models()
        for m in out["models"]:
            if m["eligible"]:
                assert m["cost_tier"] == "free"
                assert m["context_length"] is not None and m["context_length"] >= 8192
                assert not m["health"]["retired"]
                assert not m["health"]["auth_failed"]
                assert not (
                    m["health"]["cooldown_until"]
                    and m["health"]["cooldown_until"] * 1000 > time.time() * 1000
                )

    def test_eligibility_matches_eligibility_module(self, cfg):
        """Reader agrees with eligibility.py on the catalog rows."""
        store = _seed_store(cfg)
        _seed(store)
        spec = importlib.util.spec_from_file_location(
            "_test_eligibility", ROOT / "autorouter_core" / "eligibility" / "eligibility.py")
        el = importlib.util.module_from_spec(spec)
        sys.modules["_test_eligibility"] = el
        spec.loader.exec_module(el)

        out = sr.assemble_models()
        rows = {(m["provider"], m["model"]): m for m in out["models"]}
        for (provider, model), row in rows.items():
            candidate = {
                "provider": provider,
                "model": model,
                "context_length": row["context_length"],
                "capabilities": {"tools": row["tools"] if row["tools"] != "unknown" else "unknown"},
                "cost_tier": row["cost_tier"],
            }
            base = el.is_eligible(candidate, requires_tools=False, min_context=8192,
                                  free_only=True, paid_authorized=False, store=None)
            health_ok = row["health"]["available"]
            assert row["eligible"] == bool(base and health_ok)

    def test_providers_summary(self, cfg, monkeypatch):
        # The hostname "providers" module is not importable here; simulate the
        # host-absent path (auth presence cannot be probed).
        import providers

        monkeypatch.setattr(providers, "get_provider_profile", lambda name: None)
        store = _seed_store(cfg)
        _seed(store)
        out = sr.assemble_providers()
        by_name = {p["name"]: p for p in out["providers"]}
        assert by_name["nvidia"]["discovered_models"] == 3
        assert by_name["openrouter"]["discovered_models"] == 3
        assert by_name["nvidia"]["retired"] == 1
        assert by_name["nvidia"]["failures"] == 1
        assert by_name["openrouter"]["configured"] is True
        assert by_name["nvidia"]["auth"] == "unknown"  # providers module mocked -> unknown

    def test_analytics_by_provider_and_policy(self, cfg):
        store = _seed_store(cfg)
        _seed(store)
        out = sr.assemble_analytics()
        assert out["available"] is True
        # telemetry: three inference requests seeded
        assert out["summary"]["total_requests"] == 3
        assert sum(r["requests"] for r in out["by_provider"]) == 3
        assert out["by_provider"][0]["provider"] == "nvidia"
        assert isinstance(out["timeline"], list)
        # unsupported list present
        assert "unsupported" in out
        blob = json.dumps(out)
        assert "sk-livekey1234567890" not in blob

    def test_analytics_events_by_kind(self, cfg):
        store = _seed_store(cfg)
        _seed(store)
        out = sr.assemble_analytics()
        # events_by_kind replaced by telemetry; ensure unsupported notes exist
        assert out["available"] is True
        assert "unsupported" in out
        assert len(out["unsupported"]) > 0

    def test_models_pagination_cli(self, cfg):
        store = _seed_store(cfg)
        _seed(store)
        out = sr.assemble_models(page=1, page_size=2)
        assert len(out["models"]) == 2
        assert out["page"] == 1
        assert out["page_size"] == 2
        assert out["total_catalog"] >= 2
        last = sr.assemble_models(page=99, page_size=2)
        assert last["page"] == last["total_pages"]
        empty = sr.assemble_models(page=1, page_size=2, query="zzz-no-match")
        assert empty["models"] == [] and empty["total"] == 0 and empty["total_catalog"] >= 1
        out_all = sr.assemble_models()
        assert out_all["truncated"] is False
        assert out_all["total_catalog"] == len(out_all["models"]) or out_all["total_pages"] > 1


# ---------------------------------------------------------------------------
# availability mirror vs StateStore.is_available
# ---------------------------------------------------------------------------

class TestAvailabilityMirror:
    def test_mirror_matches_store(self, cfg):
        store = _seed_store(cfg)
        seed_verified_model(store, "nvidia", "m1", context_length=8192,
                             capabilities=None, cost_tier="free")
        store.record_outcome("nvidia", "m1", False, status_code=404, error_type="model_not_found")
        out = sr.assemble_models()
        row = next(m for m in out["models"] if m["model"] == "m1")
        assert row["health"]["available"] == store.is_available("nvidia", "m1")
        store.record_outcome("nvidia", "m2", True, status_code=200) if False else None

        # cooldown case
        seed_verified_model(store, "nvidia", "m2", context_length=8192,
                             capabilities=None, cost_tier="free")
        store.record_outcome("nvidia", "m2", False, status_code=429)
        out = sr.assemble_models()
        row = next(m for m in out["models"] if m["model"] == "m2")
        assert row["health"]["available"] == store.is_available("nvidia", "m2")
        assert row["health"]["available"] is False


# ---------------------------------------------------------------------------
# scrubbing
# ---------------------------------------------------------------------------

class TestScrub:
    @pytest.mark.parametrize("raw", [
        "sk-abc123def456ghi",
        "Bearer abcdef1234567890token",
        "api_key=supersecretvalue123",
        "token: abcdef12345",
        "password = hunter2hunter2",
        "ghp_abcdefghijklmnopqrstuvwxyz0123456789",
    ])
    def test_secrets_redacted(self, raw):
        out = sr.scrub(raw)
        assert out is not None
        for fragment in ("sk-abc123def456ghi", "abcdef1234567890token",
                         "supersecretvalue123", "hunter2hunter2",
                         "ghp_abcdefghijklmnopqrstuvwxyz0123456789"):
            if fragment in raw:
                assert fragment not in out

    def test_control_chars_and_truncation(self):
        assert sr.scrub("a\x00b\x1fc") == "abc"
        long = "x" * 500
        assert len(sr.scrub(long, 100)) <= 100

    def test_none_passthrough(self):
        assert sr.scrub(None) is None


# ---------------------------------------------------------------------------
# settings validation (no Hermes required)
# ---------------------------------------------------------------------------

class TestSettingsValidation:
    def test_valid_updates(self):
        clean, errors = sr.validate_settings_updates(
            {"policy": "smartest", "cooldown_seconds": 30,
             "free_only": True, "providers": ["Nvidia", "openrouter", "nvidia"]})
        assert errors == []
        assert clean["policy"] == "smartest"
        assert clean["cooldown_seconds"] == 30
        assert clean["providers"] == ["nvidia", "openrouter"]

    def test_rejects_paid_authorized(self):
        clean, errors = sr.validate_settings_updates({"paid_authorized": True})
        assert clean == {}
        assert any("paid_authorized" in e for e in errors)

    def test_rejects_enabled_and_state_dir(self):
        _, errors = sr.validate_settings_updates({"enabled": True, "state_dir": "/tmp/x"})
        assert any("enabled" in e for e in errors)
        assert any("state_dir" in e for e in errors)

    def test_rejects_unknown_key(self):
        _, errors = sr.validate_settings_updates({"bogus": 1})
        assert any("unknown" in e for e in errors)

    def test_rejects_bad_policy(self):
        _, errors = sr.validate_settings_updates({"policy": "yolo"})
        assert errors

    def test_rejects_bool_cooldown_and_range(self):
        _, errors = sr.validate_settings_updates({"cooldown_seconds": True})
        assert errors
        _, errors = sr.validate_settings_updates({"cooldown_seconds": 0})
        assert errors
        _, errors = sr.validate_settings_updates({"cooldown_seconds": 86401})
        assert errors

    def test_rejects_bad_providers(self):
        _, errors = sr.validate_settings_updates({"providers": ["ok-name", "BAD NAME!"]})
        assert errors
        _, errors = sr.validate_settings_updates({"providers": "nvidia"})
        assert errors

    def test_empty_updates(self):
        _, errors = sr.validate_settings_updates({})
        assert errors

    def test_write_settings_without_hermes(self, monkeypatch):
        """No Hermes in test env → sanctioned writer unavailable → RuntimeError."""
        monkeypatch.setitem(sys.modules, "hermes_cli", None)
        monkeypatch.setitem(sys.modules, "hermes_cli.plugins_state", None)
        with pytest.raises(RuntimeError):
            sr.write_settings({"policy": "auto"})


# ---------------------------------------------------------------------------
# state-directory resolution (B2) — runtime registration is authoritative
# ---------------------------------------------------------------------------

class TestStateDirResolution:
    """The dashboard must read the same SQLite database the running plugin
    writes. Runtime registration (``register()``) ignores
    ``AUTOROUTER_STATE_DIR`` and uses ``state_dir`` from config (or the
    plugin-local ``state/`` directory); the dashboard must resolve
    identically."""

    @pytest.fixture(autouse=True)
    def isolated_storage_profile(self, tmp_path, monkeypatch):
        sr._load_submodule("state_dir")
        monkeypatch.setenv("HERMES_HOME", str(tmp_path / "profile"))

    _BASE_VALUES = {
        "enabled": True,
        "policy": "auto",
        "free_only": True,
        "providers": ["nvidia", "openrouter"],
        "cooldown_seconds": 60,
        "paid_authorized": False,
    }

    def _config(self, sr, monkeypatch, **overrides):
        values = {**self._BASE_VALUES, **overrides}
        monkeypatch.setattr(sr, "read_plugin_config", lambda: {
            "values": dict(values), "available": True, "reason": None, "managed": False,
        })
        return values

    @staticmethod
    def _seed(state_dir):
        store = _seed_store(state_dir)
        _seed(store)

    def test_default_state_dir(self, monkeypatch, tmp_path):
        plugin_root = tmp_path / "profile/plugins/autorouter"
        default_dir = plugin_root / "state"
        self._seed(default_dir)
        monkeypatch.setattr(sr, "_PLUGIN_ROOT", plugin_root)
        # conflicting env override must not be honored (runtime ignores it)
        env_dir = tmp_path / "envdir"
        monkeypatch.setenv("AUTOROUTER_STATE_DIR", str(env_dir))
        values = self._config(sr, monkeypatch, state_dir="")
        destination = tmp_path / "profile/plugin-data/autorouter/autorouter.db"
        assert sr._db_path(values) == default_dir / "autorouter.db"
        assert not destination.parent.exists()
        sr._load_submodule("state_dir").initialize_state_dir("", plugin_root)
        assert sr._db_path(values) == destination

    def test_explicit_configured_state_dir(self, monkeypatch, tmp_path):
        configured = tmp_path / "configured"
        self._seed(configured)
        env_dir = tmp_path / "envdir"
        monkeypatch.setenv("AUTOROUTER_STATE_DIR", str(env_dir))
        values = self._config(sr, monkeypatch, state_dir=str(configured))
        assert sr._db_path(values) == configured / "autorouter.db"

    def test_conflicting_env_and_config_config_wins(self, monkeypatch, tmp_path):
        configured = tmp_path / "configured"
        self._seed(configured)  # 6 seeded models, 3 decisions
        env_dir = tmp_path / "envdir"
        self._seed(env_dir)     # same seed; overwrite env db with a distinct shape
        import sqlite3

        with sqlite3.connect(env_dir / "autorouter.db") as conn:
            conn.execute("DELETE FROM catalog")
            conn.execute("DELETE FROM decisions")
            conn.execute("INSERT INTO catalog(provider, model, context_length, capabilities, cost_tier, updated_at)"
                         " VALUES ('env-only', 'env-only-model', 100000, '{}', 'free', 1)")
        monkeypatch.setenv("AUTOROUTER_STATE_DIR", str(env_dir))
        values = self._config(sr, monkeypatch, state_dir=str(configured))
        overview = sr.assemble_overview()
        assert overview["counts"]["discovered_models"] == 6  # configured DB, not env
        assert overview["available"] is True

    def test_conflicting_env_and_default_config_default_wins(self, monkeypatch, tmp_path):
        plugin_root = tmp_path / "profile/plugins/autorouter"
        default_dir = plugin_root / "state"
        self._seed(default_dir)
        env_dir = tmp_path / "envdir"
        self._seed(env_dir)
        import sqlite3

        with sqlite3.connect(env_dir / "autorouter.db") as conn:
            conn.execute("DELETE FROM catalog")
        monkeypatch.setattr(sr, "_PLUGIN_ROOT", plugin_root)
        monkeypatch.setenv("AUTOROUTER_STATE_DIR", str(env_dir))
        values = self._config(sr, monkeypatch, state_dir="")
        models = sr.assemble_models()
        assert len(models["models"]) == 6  # plugin-local default, not env

    def test_readers_consistent_with_configured_dir(self, monkeypatch, tmp_path):
        """Overview, Providers, Models and Analytics all read the same DB."""
        configured = tmp_path / "configured"
        self._seed(configured)
        monkeypatch.setenv("AUTOROUTER_STATE_DIR", str(tmp_path / "envdir"))
        self._config(sr, monkeypatch, state_dir=str(configured))
        overview = sr.assemble_overview()
        models = sr.assemble_models()
        providers = sr.assemble_providers()
        analytics = sr.assemble_analytics()
        assert overview["available"] is True
        assert models["available"] is True
        assert len(models["models"]) == overview["counts"]["discovered_models"]
        assert sum(p["discovered_models"] for p in providers["providers"]) == 6
        # telemetry analytics exists; decisions are no longer counted
        assert analytics["available"] is True
        assert analytics["summary"]["total_requests"] == 3

    def test_env_override_pointing_at_missing_db_is_ignored(self, monkeypatch, tmp_path):
        """Env dir without a database must not shadow the configured DB."""
        configured = tmp_path / "configured"
        self._seed(configured)
        monkeypatch.setenv("AUTOROUTER_STATE_DIR", str(tmp_path / "does-not-exist"))
        self._config(sr, monkeypatch, state_dir=str(configured))
        assert sr.assemble_overview()["counts"]["discovered_models"] == 6


# ---------------------------------------------------------------------------
# settings persistence (B3) — per-key writes, accurate partial-failure report
# ---------------------------------------------------------------------------

class TestWriteSettingsPartialFailure:
    """Hermes has no multi-key transaction; each key is written individually
    by save_plugin_setting. A failure mid-batch must report exactly which
    keys persisted, which failed and which were never attempted."""

    @staticmethod
    def _install_fake_hermes(monkeypatch, calls, failing, exc_factory):
        import sys
        import types

        plugins_state = types.ModuleType("hermes_cli.plugins_state")

        def save_plugin_setting(plugin_id, segments, value):
            calls.append((plugin_id, segments, value))
            if segments and segments[0] == failing:
                raise exc_factory()

        plugins_state.save_plugin_setting = save_plugin_setting
        hermes_cli = types.ModuleType("hermes_cli")
        hermes_cli.plugins_state = plugins_state
        monkeypatch.setitem(sys.modules, "hermes_cli", hermes_cli)
        monkeypatch.setitem(sys.modules, "hermes_cli.plugins_state", plugins_state)
        return plugins_state

    def test_failure_on_second_write_is_reported(self, monkeypatch):
        calls = []
        self._install_fake_hermes(
            monkeypatch, calls, "cooldown_seconds",
            lambda: RuntimeError("simulated second-write failure"),
        )
        with pytest.raises(sr.SettingsWriteError) as excinfo:
            sr.write_settings({"policy": "smartest", "cooldown_seconds": 90, "providers": ["nvidia"]})
        err = excinfo.value
        # first key persisted, second failed, third never attempted
        assert err.saved == ["policy"]
        assert err.failed == "cooldown_seconds"
        assert err.remaining == ["providers"]
        assert calls == [
            ("autorouter", ("policy",), "smartest"),
            ("autorouter", ("cooldown_seconds",), 90),
        ]
        assert "simulated second-write failure" in err.reason

    def test_failure_on_first_write_reports_nothing_saved(self, monkeypatch):
        calls = []
        self._install_fake_hermes(
            monkeypatch, calls, "policy",
            lambda: ValueError("simulated first-write failure"),
        )
        with pytest.raises(sr.SettingsWriteError) as excinfo:
            sr.write_settings({"policy": "smartest", "free_only": True, "cooldown_seconds": 30})
        err = excinfo.value
        assert err.saved == []
        assert err.failed == "policy"
        assert err.remaining == ["free_only", "cooldown_seconds"]
        assert len(calls) == 1

    def test_permission_error_origin_is_preserved(self, monkeypatch):
        calls = []
        self._install_fake_hermes(
            monkeypatch, calls, "providers",
            lambda: PermissionError("administrator-managed key: providers"),
        )
        with pytest.raises(sr.SettingsWriteError) as excinfo:
            sr.write_settings({"policy": "auto", "providers": ["nvidia"]})
        err = excinfo.value
        assert isinstance(err.original, PermissionError)
        assert err.saved == ["policy"]
        assert err.failed == "providers"
        assert err.remaining == []

    def test_all_writes_succeed_returns_assembled_settings(self, monkeypatch):
        calls = []
        self._install_fake_hermes(monkeypatch, calls, "__never__",
                                  lambda: RuntimeError("unreachable"))
        sentinel = {"available": True, "values": {"policy": "smartest"}}
        monkeypatch.setattr(sr, "assemble_settings", lambda: sentinel)
        out = sr.write_settings({"policy": "smartest", "cooldown_seconds": 90})
        assert out is sentinel
        assert calls == [
            ("autorouter", ("policy",), "smartest"),
            ("autorouter", ("cooldown_seconds",), 90),
        ]

    def test_settings_notes_do_not_claim_multi_key_atomicity(self):
        out = sr.assemble_settings()
        joined = " ".join(out["notes"])
        assert "no multi-key transaction" in joined
        assert "one key at a time" in joined

from tests.verified_fixture import seed_verified_model


def test_mixed_field_freshness_display(cfg):
    store = _seed_store(cfg)
    seed_verified_model(store, 'p', 'm', 32768, {'tools':True}, 'free')
    cap = json.loads(store.get_capability('p','m')['capability_json'])
    cap['field_evidence'] = {key: {k: cap[k] for k in ('metadata_source','retrieved_at','expires_at')}
                             for key in ('context_window','tools','cost_tier')}
    cap['field_evidence']['context_window']['expires_at'] = 1
    store.upsert_capability('p','m',json.dumps(cap))
    row = sr.assemble_models()['models'][0]
    assert row['eligible'] is False
    assert row['context_length'] is None
    assert row['field_freshness']['cost_tier'] == 'fresh'
    assert row['field_freshness']['context_window'] == 'stale_or_unverified'
    assert row['metadata_freshness'] == 'incomplete_or_stale'
    assert row['field_evidence']['context_window']['expires_at'] == 1


def test_catalog_only_dashboard_ineligible(cfg):
    store = _seed_store(cfg)
    store.upsert_catalog('p','m',32768,{'tools':True},'free')
    row = sr.assemble_models()['models'][0]
    assert row['eligible'] is False
    assert row['cost_tier'] == 'unknown'
    assert row['tools'] == 'unknown'


def test_provider_circuit_selection_and_dashboard_agree(cfg):
    store = _seed_store(cfg)
    seed_verified_model(store,'nvidia','outage-model',16000,{'tools':True},'free')
    for _ in range(3): store.record_outcome('nvidia','other-model',False,status_code=503)
    out=sr.assemble_models()
    row=out['models'][0]
    assert not row['eligible']
    assert row['health']['reason']=='provider_error'
    assert row['health']['circuit_state']=='open'
    assert out['preview']['chosen'] is None


# ---------------------------------------------------------------------------
# Routing control center (Overview): new settings keys + decision facts
# ---------------------------------------------------------------------------

class TestRoutingSettingsValidation:
    def test_enable_chat_router_boolean_only(self):
        clean, errors = sr.validate_settings_updates({"enable_chat_router": True})
        assert errors == []
        assert clean["enable_chat_router"] is True
        clean, errors = sr.validate_settings_updates({"enable_chat_router": False})
        assert errors == []
        _, errors = sr.validate_settings_updates({"enable_chat_router": "yes"})
        assert errors

    def test_min_context_bounds_and_type(self):
        clean, errors = sr.validate_settings_updates({"min_context": 16384})
        assert errors == []
        assert clean["min_context"] == 16384
        for bad in (2047, 2000001, 8192.0, "8192", True):
            _, errors = sr.validate_settings_updates({"min_context": bad})
            assert errors, bad

    def test_requires_tools_boolean_only(self):
        clean, errors = sr.validate_settings_updates({"requires_tools": True})
        assert errors == []
        assert clean["requires_tools"] is True
        _, errors = sr.validate_settings_updates({"requires_tools": 1})
        assert errors

    def test_model_include_exclude_roundtrip(self):
        updates = {"model_include": ["nvidia/nvidia-free", "openrouter/vendor/model:free"],
                   "model_exclude": ["nvidia/paid-x"]}
        clean, errors = sr.validate_settings_updates(updates)
        assert errors == []
        assert clean["model_include"] == ["nvidia/nvidia-free", "openrouter/vendor/model:free"]
        assert clean["model_exclude"] == ["nvidia/paid-x"]

    def test_model_include_exclude_dedup_and_pattern(self):
        clean, errors = sr.validate_settings_updates(
            {"model_include": ["nvidia/nvidia-free", "nvidia/nvidia-free", "NVIDIA/x", "/noprov", "nvidia/"]})
        assert clean == {}
        assert errors
        clean, errors = sr.validate_settings_updates({"model_include": ["nvidia/nvidia-free", "nvidia/nvidia-free"]})
        assert errors == []
        assert clean["model_include"] == ["nvidia/nvidia-free"]

    def test_model_exclude_rejects_bad_types_and_overflow(self):
        _, errors = sr.validate_settings_updates({"model_exclude": "nvidia/nvidia-free"})
        assert errors
        # MAX_MODEL_KEYS is 512 — the endpoint supports catalog-scale bulk opt-out;
        # overflow beyond the cap is rejected with nothing written.
        _, errors = sr.validate_settings_updates({"model_exclude": [f"nvidia/{i}" for i in range(513)]})
        assert errors

    def test_new_keys_are_editable_in_settings(self):
        clean, errors = sr.validate_settings_updates(
            {"enable_chat_router": True, "min_context": 8192, "requires_tools": False,
             "model_include": [], "model_exclude": []})
        assert errors == []
        assert set(clean) == {"enable_chat_router", "min_context", "requires_tools", "model_include", "model_exclude"}


class TestRoutingOverview:
    def test_routing_defaults_when_keys_absent(self, cfg):
        _seed_store(cfg)
        out = sr.assemble_overview()
        routing = out["routing"]
        assert routing["chat_routing_enabled"] is False
        assert routing["chat_routing_state"] == "inactive"
        assert routing["policy"] == "auto"
        assert routing["min_context"] in (None, 8192)
        assert routing["requires_tools"] is False
        assert routing["model_include"] == []
        assert routing["model_exclude"] == []
        assert routing["last_decision"] is None

    def test_routing_block_reports_unavailable_without_activation_marker(self, monkeypatch, tmp_path):
        state_dir = tmp_path / "state"
        values = {
            "enabled": True, "policy": "reliable", "free_only": True,
            "providers": ["nvidia"], "cooldown_seconds": 60,
            "state_dir": str(state_dir), "paid_authorized": False,
            "enable_chat_router": True, "min_context": 16384, "requires_tools": True,
            "model_include": ["nvidia/free-good"], "model_exclude": ["nvidia/paid-x"],
        }
        monkeypatch.setattr(sr, "read_plugin_config", lambda: {
            "values": dict(values), "available": True, "reason": None, "managed": False,
        })
        _seed_store(state_dir)
        out = sr.assemble_overview()
        routing = out["routing"]
        # Fail-closed surface when nothing recorded an activation: configuration alone is not activation.
        assert routing["chat_routing_enabled"] is True
        assert routing["chat_routing_state"] == "unavailable"
        assert routing["runtime_activation"]["runtime"] == "unavailable"
        assert routing["runtime_activation"]["configured"] is True
        assert routing["policy"] == "reliable"
        assert routing["min_context"] == 16384
        assert routing["requires_tools"] is True
        assert routing["model_include"] == ["nvidia/free-good"]
        assert routing["model_exclude"] == ["nvidia/paid-x"]

    def test_routing_block_reports_native_with_activation_marker(self, monkeypatch, tmp_path):
        state_dir = tmp_path / "state"
        values = {
            "enabled": True, "policy": "reliable", "free_only": True,
            "providers": ["nvidia"], "cooldown_seconds": 60,
            "state_dir": str(state_dir), "paid_authorized": False,
            "enable_chat_router": True, "min_context": 16384, "requires_tools": True,
            "model_include": ["nvidia/free-good"], "model_exclude": ["nvidia/paid-x"],
        }
        monkeypatch.setattr(sr, "read_plugin_config", lambda: {
            "values": dict(values), "available": True, "reason": None, "managed": False,
        })
        _seed_store(state_dir)
        state_dir.mkdir(parents=True, exist_ok=True)
        (state_dir / "native-routing-state.json").write_text(
            '{"schema_version": 1, "selection_mode": "native", "chat_router": true, '
            '"native_routing_registered": true, "host_supported": true}', encoding="utf-8")
        out = sr.assemble_overview()
        routing = out["routing"]
        assert routing["chat_routing_state"] == "active"
        assert routing["runtime_activation"]["runtime"] == "active"

    def test_last_decision_carries_facts(self, cfg):
        store = _seed_store(cfg)
        _seed(store)
        out = sr.assemble_overview()
        last = out["routing"]["last_decision"]
        assert last is not None
        assert last["policy"] == "coding"          # the most recent recorded decision
        assert last["provider"] == "openrouter"
        assert last["model"] == "paid-pro"
        assert last["reason"] == "selected"
        assert last["candidates"] == 1
        facts = last["facts"]
        assert facts["context_length"] == 200000
        assert facts["cost_tier"] == "paid"
        assert facts["tools"] == "supported"
        assert "circuit_state" in facts
        assert last["ts"] is not None


class TestRoutingRuntimeActivation:
    def _overview_with_marker(self, monkeypatch, cfg, *, marker, enable_chat_router=True):
        values = {
            "enabled": True, "policy": "auto", "free_only": True,
            "providers": ["nvidia"], "cooldown_seconds": 60,
            "state_dir": str(cfg), "paid_authorized": False,
            "enable_chat_router": enable_chat_router, "min_context": 8192,
            "requires_tools": False, "model_include": [], "model_exclude": [],
        }
        monkeypatch.setattr(sr, "read_plugin_config", lambda: {
            "values": dict(values), "available": True, "reason": None, "managed": False,
        })
        _seed_store(cfg)
        if marker is not None:
            cfg.mkdir(parents=True, exist_ok=True)
            (cfg / "native-routing-state.json").write_text(marker, encoding="utf-8")
        return sr.assemble_overview()["routing"]

    def test_native_marker_reports_active(self, cfg, monkeypatch):
        routing = self._overview_with_marker(
            monkeypatch, cfg,
            marker='{"schema_version": 1, "selection_mode": "native"}')
        assert routing["runtime_activation"]["runtime"] == "active"
        assert routing["chat_routing_state"] == "active"
        assert routing["runtime_activation"]["configured"] is True

    def test_unavailable_marker_reports_unavailable(self, cfg, monkeypatch):
        routing = self._overview_with_marker(
            monkeypatch, cfg,
            marker='{"schema_version": 1, "selection_mode": "unavailable", '
                   '"reason": "host exposes no sanctioned pre_inference_route extension"}')
        assert routing["runtime_activation"]["runtime"] == "unavailable"
        assert routing["chat_routing_state"] == "unavailable"
        assert "host exposes no sanctioned pre_inference_route extension" in             routing["runtime_activation"]["detail"]

    def test_absent_marker_is_unavailable_never_active(self, cfg, monkeypatch):
        routing = self._overview_with_marker(monkeypatch, cfg, marker=None)
        assert routing["runtime_activation"]["runtime"] == "unavailable"
        assert routing["chat_routing_state"] == "unavailable"
        assert routing["runtime_activation"]["detail"]

    def test_disabled_marker_reports_inactive(self, cfg, monkeypatch):
        routing = self._overview_with_marker(
            monkeypatch, cfg, marker='{"schema_version": 1, "selection_mode": "disabled"}',
            enable_chat_router=False)
        assert routing["runtime_activation"]["runtime"] == "inactive"
        assert routing["chat_routing_state"] == "inactive"
        assert routing["runtime_activation"]["configured"] is False




def test_refresh_partial_failure_never_overwrites_prior_evidence(cfg, monkeypatch):
    """One failing provider must not wipe the other provider's prior catalog
    evidence, and must never fabricate success."""
    prior_models = {"nvidia": [{"provider": "nvidia", "model": "keep-me", "context_length": 65536,
                                 "capabilities": {"tools": "supported"}, "cost_tier": "free"}]}
    store = _seed_store(cfg)
    for p, ms in prior_models.items():
        for m in ms:
            store.upsert_catalog(m["provider"], m["model"], context_length=m["context_length"],
                                  capabilities=m["capabilities"], cost_tier=m["cost_tier"])
    real_load = sr._load_submodule

    class PartialDiscovery:
        @staticmethod
        def discover_all(providers, store=None):
            return {"nvidia": [dict(m) for m in prior_models["nvidia"]],
                    "openrouter": []}  # openrouter transiently fails -> empty

    def fake_load(name):
        if name == "discovery":
            return PartialDiscovery()
        return real_load(name)

    monkeypatch.setattr(sr, "_load_submodule", fake_load)
    out = sr.refresh_catalog()
    assert out["available"] is True
    assert out["refreshed"] == {"nvidia": 1, "openrouter": 0}
    assert out["total_models"] == 1
    rows = {r["model"] for r in sr.assemble_models()["models"]}
    assert "keep-me" in rows  # prior nvidia evidence retained
class TestRefreshCatalog:
    def test_refresh_happy_path_persists_catalog(self, cfg, monkeypatch):
        state_dir = cfg
        _seed_store(state_dir)  # empty catalog baseline
        real_load = sr._load_submodule

        class FakeDiscovery:
            @staticmethod
            def discover_all(providers, store=None):
                assert providers == ["nvidia", "openrouter"]
                assert store is not None
                store.upsert_catalog("nvidia", "refresh-a", context_length=65536,
                                      capabilities={"tools": "supported", "vision": "supported"},
                                      cost_tier="free")
                store.upsert_catalog("openrouter", "refresh-b", context_length=131072,
                                      capabilities={"tools": "unknown"}, cost_tier="unknown")
                return {"nvidia": [{"provider": "nvidia", "model": "refresh-a"}],
                        "openrouter": [{"provider": "openrouter", "model": "refresh-b"}]}

        def fake_load(name):
            if name == "discovery":
                return FakeDiscovery()
            return real_load(name)

        monkeypatch.setattr(sr, "_load_submodule", fake_load)
        out = sr.refresh_catalog()
        assert out["available"] is True
        assert out["refreshed"] == {"nvidia": 1, "openrouter": 1}
        assert out["total_models"] == 2
        models = sr.assemble_models()["models"]
        assert {m["model"] for m in models} == {"refresh-a", "refresh-b"}

    def test_refresh_without_providers(self, cfg, monkeypatch):
        monkeypatch.setattr(sr, "read_plugin_config", lambda: {
            "values": {"enabled": True, "policy": "auto", "free_only": True,
                       "providers": [], "cooldown_seconds": 60,
                       "state_dir": str(cfg), "paid_authorized": False},
            "available": True, "reason": None, "managed": False,
        })
        out = sr.refresh_catalog()
        assert out["available"] is False
        assert "authorized providers" in out["reason"]

    def test_refresh_config_unreadable(self, cfg, monkeypatch):
        monkeypatch.setattr(sr, "read_plugin_config", lambda: {
            "values": dict(sr._DEFAULTS), "available": False,
            "reason": "unreadable", "managed": False,
        })
        out = sr.refresh_catalog()
        assert out["available"] is False
        assert out["refreshed"] == {}

    def test_refresh_discovery_exception_is_honest(self, cfg, monkeypatch):
        real_load = sr._load_submodule

        class Boom:
            @staticmethod
            def discover_all(providers, store=None):
                raise RuntimeError("network down")

        def fake_load(name):
            if name == "discovery":
                return Boom()
            return real_load(name)

        monkeypatch.setattr(sr, "_load_submodule", fake_load)
        out = sr.refresh_catalog()
        assert out["available"] is False
        assert out["refreshed"] == {}
        assert "nothing was persisted" in out["reason"]


def _real_submodule(name):
    raise AssertionError("unexpected submodule: " + name)


class TestInventoryFields:
    def test_latency_and_vision_surface(self, cfg, tmp_path):
        import json as _json
        import time as _time

        store = _seed_store(cfg)
        seed_verified_model(store, "nvidia", "free-good", context_length=131072,
                            capabilities={"tools": "supported"}, cost_tier="free")
        # Record vision support as capability evidence (the same store the dashboard reads).
        now = _time.time()
        cap = _json.dumps({"provider": "nvidia", "model": "free-good",
                           "context_window": 131072, "tools": "supported",
                           "cost_tier": "free", "metadata_source": "controlled-test-fixture",
                           "retrieved_at": now, "expires_at": now + 3600,
                           "vision": "supported"})
        store.upsert_capability("nvidia", "free-good", cap,
                                metadata_source="controlled-test-fixture",
                                retrieved_at=now, expires_at=now + 3600)
        store.record_outcome("nvidia", "free-good", True, status_code=200, latency_ms=321)
        row = next(m for m in sr.assemble_models()["models"] if m["model"] == "free-good")
        assert row["vision"] == "supported"
        assert row["health"]["last_latency_ms"] == 321
        assert row["catalog_refreshed_at"] is not None

    def test_vision_unknown_when_not_recorded(self, cfg):
        store = _seed_store(cfg)
        seed_verified_model(store, "nvidia", "free-good", context_length=131072,
                            capabilities={"tools": "supported"}, cost_tier="free")
        row = next(m for m in sr.assemble_models()["models"] if m["model"] == "free-good")
        assert row["vision"] == "unknown"
        assert row["catalog_refreshed_at"] is not None
