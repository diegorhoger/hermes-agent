"""Mock HTTP servers for AutoRouter G4 failover testing."""

import http.server
import socketserver
import threading
import time
import json


# Primary server on port 19999 - returns 429 on first request then empty stream
primary_429_count = [0]


class PrimaryHandler(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        global primary_429_count
        primary_429_count[0] += 1
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length else b''
        if primary_429_count[0] <= 1:
            # First request: return HTTP 429
            self.send_response(429)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            self.wfile.write(b'Rate limited')
        else:
            # Subsequent requests: return empty SSE stream (simulates provider failure)
            self.send_response(200)
            self.send_header('Content-type', 'text/event-stream')
            self.end_headers()
            # Write an SSE comment to keep the connection alive but no actual events
            self.wfile.write(b': keep-alive\n\n')
            # After first empty stream, mark as exhausted for this session
            if primary_429_count[0] == 2:
                # On second request, return actual JSON that will be rejected as empty stream
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'response': 'exhausted'}).encode())

    def do_GET(self):
        global primary_429_count
        primary_429_count[0] += 1
        if self.path == '/v1/chat/completions':
            if primary_429_count[0] <= 2:
                self.send_response(429)
                self.send_header('Content-type', 'text/plain')
                self.end_headers()
                self.wfile.write(b'Rate limited')
            else:
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({'response': 'success from alt'}).encode())
        else:
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({'model': 'test'}).encode())

    def log_message(self, format, *args):
        pass


# Alternative server on port 19998 - returns proper SSE response
class AltHandler(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length else b''
        self.send_response(200)
        self.send_header('Content-type', 'text/event-stream')
        self.end_headers()
        # Proper SSE formatted response with a finish_reason
        self.wfile.write(b'data: {"choices": [{"delta": {"content": "success from alt"}, "finish_reason": "stop"}]}')
        self.wfile.write(b'\n\n')
        # Send a second data event to signal completion
        self.wfile.write(b'data: {"choices": [{"delta": {}, "finish_reason": "stop"}]}')
        self.wfile.write(b'\n\n')

    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps({'model': 'alt answer'}).encode())

    def log_message(self, format, *args):
        pass


def start_servers():
    """Start both mock servers and return them."""
    primary_server = socketserver.TCPServer(('127.0.0.1', 19999), PrimaryHandler)
    primary_thread = threading.Thread(target=primary_server.serve_forever, daemon=True)
    primary_thread.start()

    alt_server = socketserver.TCPServer(('127.0.0.1', 19998), AltHandler)
    alt_thread = threading.Thread(target=alt_server.serve_forever, daemon=True)
    alt_thread.start()

    print('Mock servers started')
    print('Primary on http://127.0.0.1:19999 (429 then empty stream = 3 retries)')
    print('Alternative on http://127.0.0.1:19998 (proper SSE response)')
    return primary_server, alt_server


if __name__ == '__main__':
    start_servers()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print('Shutting down')
        primary_server.shutdown()
        alt_server.shutdown()