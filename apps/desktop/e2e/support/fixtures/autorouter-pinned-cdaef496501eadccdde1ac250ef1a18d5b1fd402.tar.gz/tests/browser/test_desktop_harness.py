"""Browser interactions for the Hermes Desktop runtime plugin, driven against
a fixture API with the real React render path (not mocked components)."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

playwright = pytest.importorskip("playwright")
from playwright.sync_api import sync_playwright  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
HARNESS_HTML = ROOT / "tests" / "browser" / "desktop-harness.html"
BUNDLE = ROOT / "tests" / "browser" / ".tmp" / "desktop-harness.bundle.js"
ESBUILD = Path("/Users/prometheos/.hermes/hermes-agent/ui-tui/node_modules/.bin/esbuild")
NODE_MODULES = Path("/Users/prometheos/.hermes/hermes-agent/apps/desktop/node_modules")

_CHROME_CANDIDATES = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    shutil.which("google-chrome"),
    shutil.which("chromium"),
    shutil.which("chromium-browser"),
    shutil.which("chrome"),
]
CHROME = next((p for p in _CHROME_CANDIDATES if p and Path(p).exists()), None)


def _ensure_bundle() -> bool:
    if ESBUILD.exists() and (NODE_MODULES / "react").exists() and (NODE_MODULES / "react-dom").exists():
        subprocess.run([
            str(ESBUILD), "--bundle",
            str(ROOT / "tests" / "browser" / "desktop-harness" / "bootstrap.mjs"),
            f"--alias:@hermes/plugin-sdk={ROOT / 'tests' / 'browser' / 'desktop-harness' / 'sdk-stub.mjs'}",
            f"--alias:react={NODE_MODULES / 'react'}",
            f"--alias:react-dom={NODE_MODULES / 'react-dom'}",
            f"--alias:react/jsx-runtime={NODE_MODULES / 'react' / 'jsx-runtime.js'}",
            "--format=esm", f"--outfile={BUNDLE}", "--log-level=warning",
        ], check=True, cwd=ROOT)
        return True
    return BUNDLE.exists()


@pytest.fixture(scope="module")
def browser():
    if CHROME is None:
        pytest.skip("Chrome/Chromium not found for desktop harness")
    if not _ensure_bundle():
        pytest.skip("Desktop harness bundle could not be built (esbuild/react missing)")
    with sync_playwright() as pw:
        instance = pw.chromium.launch(executable_path=CHROME, headless=True)
        yield instance
        instance.close()


@pytest.fixture()
def page(browser):
    p = browser.new_page()
    yield p
    p.close()


def _open(page):
    import http.server, threading
    handler = http.server.SimpleHTTPRequestHandler
    class _Quiet(handler):
        def log_message(self, *args):
            pass
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Quiet)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]
    try:
        page.goto(f"http://127.0.0.1:{port}/tests/browser/desktop-harness.html")
        page.wait_for_function("globalThis.__HARNESS_MOUNTED__ === true", timeout=10000)
    finally:
        httpd.shutdown()


def _open_url(page, query):
    import http.server, threading
    handler = http.server.SimpleHTTPRequestHandler
    class _Quiet(handler):
        def log_message(self, *args):
            pass
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Quiet)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]
    try:
        page.goto(f"http://127.0.0.1:{port}/tests/browser/desktop-harness.html{query}")
        page.wait_for_function("globalThis.__HARNESS_MOUNTED__ === true", timeout=10000)
    finally:
        httpd.shutdown()


def test_profiles_tab_lists_saved_profiles(page):
    _open(page)
    page.get_by_role("tab", name="Profiles").click()
    page.wait_for_selector("text=Nightly builder")
    page.wait_for_selector("text=Fast replies")
    # the seeded active profile (rp_1, Nightly builder) is badged in the list
    nightly = page.locator("button", has_text="Nightly builder").first
    assert nightly.locator("text=active").first.is_visible()


def test_create_profile_roundtrip(page):
    _open(page)
    page.get_by_role("tab", name="Profiles").click()
    page.wait_for_selector("text=Nightly builder")
    page.get_by_role("button", name="New profile").click()
    page.wait_for_selector("text=New routing profile")
    page.get_by_placeholder("e.g. Nightly free builder").fill("Dispatch verification profile")
    page.get_by_role("button", name="Create profile").click()
    page.wait_for_selector("text=Routing profile created.")
    page.wait_for_selector("text=Dispatch verification profile")
    calls = page.evaluate("globalThis.__HARNESS_CALLS__.map(c => c.method + ' ' + c.path)")
    assert any(c.startswith("POST /routing-profiles") for c in calls)


def test_create_requires_name(page):
    _open(page)
    page.get_by_role("tab", name="Profiles").click()
    page.wait_for_selector("text=Nightly builder")
    page.get_by_role("button", name="New profile").click()
    page.wait_for_selector("text=New routing profile")
    page.get_by_role("button", name="Create profile").click()
    page.wait_for_selector("text=Name is required.")
    calls = page.evaluate("globalThis.__HARNESS_CALLS__.map(c => c.method + ' ' + c.path)")
    assert not any(c.startswith("POST /routing-profiles") for c in calls)


def test_preview_shows_eligible_selection(page):
    _open(page)
    page.get_by_role("tab", name="Profiles").click()
    page.wait_for_selector("text=Nightly builder")
    page.get_by_role("button", name="Preview eligible models").click()
    page.wait_for_selector("text=Would route to")
    page.wait_for_selector("text=nvidia/llama-3.3-70b-instruct")
    page.wait_for_selector("text=tools_unverified_or_unsupported")
    calls = page.evaluate("globalThis.__HARNESS_CALLS__.map(c => c.method + ' ' + c.path)")
    assert any(c.startswith("POST /routing-profiles/rp_1/preview") for c in calls)


def test_activate_and_deactivate_roundtrip(page):
    _open(page)
    page.get_by_role("tab", name="Profiles").click()
    page.wait_for_selector("text=Fast replies")
    page.get_by_role("button", name="Fast replies").click()
    page.wait_for_selector("text=Set as AutoRouter default")
    page.get_by_role("button", name="Set as AutoRouter default").click()
    page.wait_for_selector("text=Default set for AutoRouter sessions created from now on")
    # Overview renders the active-profile strip
    page.get_by_role("tab", name="Overview").click()
    page.wait_for_selector("text=Default routing profile.")
    page.wait_for_selector("text=Fast replies")


def test_delete_requires_confirmation(page):
    _open(page)
    page.get_by_role("tab", name="Profiles").click()
    page.wait_for_selector("text=Fast replies")
    page.get_by_role("button", name="Fast replies").click()
    page.wait_for_selector("text=Delete")
    page.get_by_role("button", name="Delete").click()
    page.wait_for_selector("text=Click again to delete")
    page.get_by_role("button", name="Click again to delete").click()
    page.wait_for_selector("text=Profile deleted.")
    calls = page.evaluate("globalThis.__HARNESS_CALLS__.map(c => c.method + ' ' + c.path)")
    assert any(c.startswith("DELETE /routing-profiles/rp_2") for c in calls)


def test_models_tab_pagination_next_previous(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    calls = page.evaluate("globalThis.__HARNESS_CALLS__.map(c => c.path)")
    assert any("/models?page=1" in c for c in calls)
    page.get_by_role("button", name="Next page").click()
    page.wait_for_selector("text=page 2 of 3")
    page.get_by_role("button", name="Next page").click()
    page.wait_for_selector("text=page 3 of 3")
    # Last page: Next disabled
    assert page.get_by_role("button", name="Next page").is_disabled()
    calls = page.evaluate("globalThis.__HARNESS_CALLS__.map(c => c.path)")
    assert any("/models?page=2" in c for c in calls)
    assert any("/models?page=3" in c for c in calls)
    page.get_by_role("button", name="Previous page").click()
    page.wait_for_selector("text=page 2 of 3")
    page.get_by_role("button", name="Previous page").click()
    page.wait_for_selector("text=page 1 of 3")
    assert page.get_by_role("button", name="Previous page").is_disabled()


def test_models_tab_search_and_filter_exercise_catalog(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    page.get_by_placeholder("Filter by provider or model…").fill("synthetic/model-0")
    page.wait_for_selector("text=synthetic/model-000")
    # A search that matches nothing yields the empty state, not a broken table.
    page.get_by_placeholder("Filter by provider or model…").fill("zzz-no-such-model")
    page.wait_for_selector("text=Nothing matches", timeout=5000)
    # Eligibility filter narrows the catalog server-side.
    page.get_by_placeholder("Filter by provider or model…").fill("")
    page.get_by_role("tab", name="Models").click()
    page.get_by_text("Eligible", exact=True).click()
    page.wait_for_selector("text=eligible")
    calls = page.evaluate("globalThis.__HARNESS_CALLS__.map(c => c.path)")
    assert any("eligibility=eligible" in c for c in calls)


def test_pin_guard_banner_hidden_for_clear_state(page):
    _open(page)
    page.wait_for_selector("text=Overview")
    assert page.locator("text=Virtual default route unresolved").count() == 0
    assert page.locator("text=autorouter/auto-free").count() == 0


def test_pin_guard_banner_shown_for_unresolved_pin(page):
    _open_url(page, "?vpg=unresolved_pin")
    page.wait_for_selector("text=Virtual default route unresolved")
    assert page.locator("text=autorouter/auto-free").first.is_visible()
    assert page.locator("text=configuration was NOT modified").first.is_visible()


def test_providers_action_cell_visible_at_narrow_width(page):
    page.set_viewport_size({"width": 560, "height": 900})
    _open(page)
    page.get_by_role("tab", name="Providers").click()
    page.wait_for_selector("text=Hermes credential inventory")
    action = page.get_by_role("button", name="Enable for AutoRouter").first
    action.wait_for(state="visible")
    box = action.bounding_box()
    page_width = page.evaluate("document.documentElement.clientWidth")
    assert box is not None
    assert box["x"] + box["width"] <= page_width + 1, (
        f"action cell clipped: right edge {box['x'] + box['width']} exceeds page width {page_width}")


def test_models_preference_toggle_flow_saves_and_refreshes(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    llama = page.get_by_role("switch", name="Enable nvidia/llama-3.3-70b-instruct in AutoRouter")
    assert llama.get_attribute("aria-checked") == "true"
    llama.click()
    page.wait_for_function(
        "globalThis.__HARNESS_CALLS__.some(c => c.method === 'POST' && c.path === '/models/preference')",
        timeout=5000,
    )
    calls = page.evaluate("globalThis.__HARNESS_CALLS__.map(c => ({method: c.method, path: c.path, body: c.body}))")
    posts = [c for c in calls if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert len(posts) == 1
    body = posts[0]["body"] if isinstance(posts[0]["body"], dict) else json.loads(posts[0]["body"])
    assert body["toggles"] == [{"provider": "nvidia", "model": "llama-3.3-70b-instruct", "enabled": False}]
    assert body["base"]
    # after refetch the switch is off and the count reflects it
    page.wait_for_function(
        "globalThis.__HARNESS_CALLS__.filter(c => c.path.startsWith('/models?')).length >= 2",
        timeout=5000,
    )
    assert page.get_by_role("switch", name="Enable nvidia/llama-3.3-70b-instruct in AutoRouter").get_attribute("aria-checked") == "false"


def test_models_preference_disabled_row_shows_reason_and_excludes_from_enabled_filter(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    "disabled by you" in page.content() or page.wait_for_selector("text=disabled by you")
    deepseek = page.get_by_role("switch", name="Enable nvidia/deepseek-r1 in AutoRouter")
    assert deepseek.get_attribute("aria-checked") == "false"
    page.get_by_role("combobox", name="Filter by inclusion preference").select_option("off")
    page.wait_for_function(
        "globalThis.__HARNESS_CALLS__.some(c => c.path.includes('preference=off'))",
        timeout=5000,
    )
    page.wait_for_selector("text=deepseek-r1", timeout=5000)
    assert "llama-3.3-70b-instruct" not in page.content()


def test_models_bulk_disable_every_page_shows_zero_enabled_banner(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    posts_before = len([c for c in page.evaluate("globalThis.__HARNESS_CALLS__.map(c => ({method: c.method, path: c.path}))")
                        if c["method"] == "POST" and c["path"] == "/models/preference"])
    for expected in ["page 1 of 3", "page 2 of 3", "page 3 of 3"]:
        page.wait_for_selector(f"text={expected}")
        page.get_by_role("button", name="Disable page").click()
        page.wait_for_function(
            f"globalThis.__HARNESS_CALLS__.filter(c => c.method === 'POST' && c.path === '/models/preference').length >= {posts_before + ['page 1 of 3', 'page 2 of 3', 'page 3 of 3'].index(expected) + 1}",
            timeout=5000,
        )
        if expected != "page 3 of 3":
            page.get_by_role("button", name="Next page").click()
    page.wait_for_selector("text=No model is enabled", timeout=5000)
    posts = [c for c in page.evaluate("globalThis.__HARNESS_CALLS__.map(c => ({method: c.method, path: c.path, body: c.body}))")
             if c["method"] == "POST" and c["path"] == "/models/preference"]
    body0 = posts[0]["body"] if isinstance(posts[0]["body"], dict) else json.loads(posts[0]["body"])
    assert len(body0["toggles"]) == 50


def test_models_enable_all_via_bulk_includes_page(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    deepseek = page.get_by_role("switch", name="Enable nvidia/deepseek-r1 in AutoRouter")
    assert deepseek.get_attribute("aria-checked") == "false"
    page.get_by_role("button", name="Enable page").click()
    page.wait_for_function(
        "globalThis.__HARNESS_CALLS__.some(c => c.method === 'POST' && c.path === '/models/preference')",
        timeout=5000,
    )
    page.wait_for_selector("text=123 enabled / 0 off", timeout=5000)


# ---------------------------------------------------------------------------
# Preference conflict handling (dispatch #111): a 409 re-fetches authoritative
# state and never blindly replays when the mode changed underneath us.
# ---------------------------------------------------------------------------

def _desktop_calls(page):
    return page.evaluate("globalThis.__HARNESS_CALLS__.map(c => ({method: c.method, path: c.path, body: c.body}))")


def test_models_conflict_mode_change_conflicts_and_never_replays(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    page.evaluate("globalThis.__HARNESS_SET_PREF__({mode: 'allowlist', model_include: ['openrouter/qwen3-coder:free'], model_exclude: []})")
    llama = page.get_by_role("switch", name="Enable nvidia/llama-3.3-70b-instruct in AutoRouter")
    llama.click()
    # The client re-fetches fresh state and refuses to replay: exactly one POST, one GET.
    page.wait_for_function(
        "globalThis.__HARNESS_CALLS__.some(c => c.method === 'GET' && c.path === '/models/preference')",
        timeout=5000,
    )
    page.wait_for_selector("text=Another writer changed the model preference", timeout=5000)
    posts = [c for c in _desktop_calls(page) if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert len(posts) == 1


def test_models_conflict_same_mode_rebases_and_applies(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    page.evaluate("globalThis.__HARNESS_SET_PREF__({mode: 'unrestricted', model_exclude: ['nvidia/synthetic/model-900:free']})")
    llama = page.get_by_role("switch", name="Enable nvidia/llama-3.3-70b-instruct in AutoRouter")
    llama.click()
    page.wait_for_function(
        "globalThis.__HARNESS_CALLS__.filter(c => c.method === 'POST' && c.path === '/models/preference').length >= 2",
        timeout=5000,
    )
    posts = [c for c in _desktop_calls(page) if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert len(posts) == 2
    first = posts[0]["body"] if isinstance(posts[0]["body"], dict) else json.loads(posts[0]["body"])
    second = posts[1]["body"] if isinstance(posts[1]["body"], dict) else json.loads(posts[1]["body"])
    assert first["base"] != second["base"]
    page.wait_for_function(
        "globalThis.__HARNESS_CALLS__.filter(c => c.path.startsWith('/models?')).length >= 2",
        timeout=5000,
    )
    assert page.get_by_role("switch", name="Enable nvidia/llama-3.3-70b-instruct in AutoRouter").get_attribute("aria-checked") == "false"


def test_models_none_mode_banner_and_two_step_reset(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    page.evaluate("globalThis.__HARNESS_SET_PREF__({mode: 'none', model_include: [], model_exclude: ['nvidia/deepseek-r1']})")
    page.get_by_role("combobox", name="Filter by inclusion preference").select_option("off")
    page.wait_for_selector("text=No model is enabled", timeout=5000)
    switches = page.locator("[data-model-toggle]")
    for i in range(switches.count()):
        assert switches.nth(i).get_attribute("aria-checked") == "false"
    # First click arms the reset; no request goes out yet.
    page.get_by_role("button", name="Reset to unrestricted", exact=True).click()
    posts = [c for c in _desktop_calls(page) if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert len(posts) == 0
    page.get_by_role("button", name="Confirm reset", exact=True).click()
    page.wait_for_function(
        "globalThis.__HARNESS_CALLS__.some(c => c.method === 'POST' && c.path === '/models/preference' && c.body && (typeof c.body === 'object' ? c.body : JSON.parse(c.body)).reset === 'unrestricted')",
        timeout=5000,
    )
    page.wait_for_function(
        "!document.body.innerText.includes('No model is enabled')",
        timeout=5000,
    )


def test_models_last_off_disables_everything_and_stays_disabled(page):
    """End-to-end Desktop flow: seed allowlist with ONE model, turn it off,
    verify no other model silently becomes selectable."""
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    page.evaluate("globalThis.__HARNESS_SET_PREF__({mode: 'allowlist', model_include: ['nvidia/llama-3.3-70b-instruct'], model_exclude: []})")
    # Force a re-fetch by switching the preference filter off and back on.
    page.get_by_role("combobox", name="Filter by inclusion preference").select_option("off")
    page.wait_for_selector("text=not in the model allowlist", timeout=5000)
    page.get_by_role("combobox", name="Filter by inclusion preference").select_option("all")
    page.wait_for_selector("text=Allowlist mode", timeout=5000)
    llama = page.get_by_role("switch", name="Enable nvidia/llama-3.3-70b-instruct in AutoRouter")
    llama.click()
    page.wait_for_selector("text=No model is enabled", timeout=5000)
    posts = [c for c in _desktop_calls(page) if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert posts, "expected the last-off toggle to be persisted"
    body = posts[-1]["body"] if isinstance(posts[-1]["body"], dict) else json.loads(posts[-1]["body"])
    assert body["toggles"] == [{"provider": "nvidia", "model": "llama-3.3-70b-instruct", "enabled": False}]
    switches = page.locator("[data-model-toggle]")
    for i in range(switches.count()):
        assert switches.nth(i).get_attribute("aria-checked") == "false"


# ---------------------------------------------------------------------------
# Regression (dispatch 114): rapidly changing filters must not leave stale
# rows on screen. The renderer's REST effect only re-ran when the request
# string changed identity, so flipping a filter back to an earlier value
# reissued no request and the empty/stale state from the interim filter
# lingered until something else happened to refresh.
# ---------------------------------------------------------------------------

def test_preference_filter_roundtrip_restores_full_catalog(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    pref = page.get_by_role("combobox", name="Filter by inclusion preference")
    pref.select_option("off")
    page.wait_for_selector("text=page 1 of 1", timeout=5000)
    assert page.locator("tbody tr").count() == 1
    pref.select_option("all")
    page.wait_for_selector("text=page 1 of 3", timeout=5000)
    assert page.locator("tbody tr").count() == 50


def test_provider_filter_roundtrip_restores_full_catalog(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    provider = page.get_by_role("combobox", name="Filter by provider")
    provider.select_option("nvidia")
    page.wait_for_selector("text=page 1 of 2", timeout=5000)
    assert page.locator("tbody tr").count() == 50
    provider.select_option("")
    page.wait_for_selector("text=page 1 of 3", timeout=5000)
    assert page.locator("tbody tr").count() == 50


def test_search_roundtrip_restores_full_catalog(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    search = page.get_by_placeholder("Filter by provider or model…")
    search.fill("llama-3.3-70b")
    page.wait_for_selector("text=page 1 of 1", timeout=5000)
    assert page.locator("tbody tr").count() == 1
    search.fill("")
    page.wait_for_selector("text=page 1 of 3", timeout=5000)
    assert page.locator("tbody tr").count() == 50


def test_eligibility_filter_roundtrip_restores_full_catalog(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    page.get_by_role("radio", name="Eligible", exact=True).click()
    page.wait_for_function(
        "window.__HARNESS_CALLS__.some(c => c.path.indexOf('eligibility=eligible') >= 0)",
        timeout=5000,
    )
    page.get_by_role("radio", name="All", exact=True).click()
    page.wait_for_function(
        "window.__HARNESS_CALLS__.filter(c => c.path.indexOf('eligibility=all') >= 0).length >= 2",
        timeout=5000,
    )
    page.wait_for_selector("text=page 1 of 3", timeout=5000)
    assert page.locator("tbody tr").count() == 50


def test_delayed_out_of_order_preference_response_does_not_clobber_current_view(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    pref = page.get_by_role("combobox", name="Filter by inclusion preference")
    page.evaluate("globalThis.__HARNESS_DELAY__ = { 'preference=off': 600 }")
    pref.select_option("off")
    pref.select_option("all")
    page.wait_for_function(
        "document.querySelectorAll('tbody tr').length === 50",
        timeout=5000,
    )
    # The delayed preference=off response must land after the fresh
    # preference=all response; the alive guard must drop it.
    page.wait_for_timeout(900)
    assert page.locator("tbody tr").count() == 50
    page.wait_for_function(
        "window.__HARNESS_CALLS__.filter(c => c.path.indexOf('preference=off') >= 0).length === 1",
        timeout=5000,
    )
    assert page.locator("tbody tr").count() == 50


# ---------------------------------------------------------------------------
# Desktop acceptance coverage for the Settings tab (dispatch 115): edit, save,
# reset/restore and partial-save reporting, driven through the real React
# SettingsTab against the fixture API. The live Desktop is not touched by
# these tests.
# ---------------------------------------------------------------------------

def test_settings_tab_loads_and_saves_only_changed_keys(page):
    _open(page)
    page.get_by_role("tab", name="Settings").click()
    page.wait_for_selector("text=Selection policy")
    cooldown = page.get_by_role("spinbutton", name="Cooldown after retryable failure (seconds)")
    assert cooldown.input_value() == "60"
    cooldown.fill("120")
    page.get_by_role("button", name="Save changes").click()
    page.wait_for_selector("text=Settings saved.")
    page.wait_for_function(
        "globalThis.__HARNESS_CALLS__.some(c => c.method === 'PUT' && c.path === '/settings')",
        timeout=5000,
    )
    calls = _desktop_calls(page)
    puts = [c for c in calls if c["method"] == "PUT" and c["path"] == "/settings"]
    assert len(puts) == 1
    body = puts[0]["body"] if isinstance(puts[0]["body"], dict) else json.loads(puts[0]["body"])
    assert body["updates"] == {"cooldown_seconds": 120}
    # After save the form re-adopts persisted state and reports no changes.
    page.wait_for_selector("text=No changes")


def test_settings_reset_restores_saved_values_without_writing(page):
    _open(page)
    page.get_by_role("tab", name="Settings").click()
    page.wait_for_selector("text=Selection policy")
    cooldown = page.get_by_role("spinbutton", name="Cooldown after retryable failure (seconds)")
    cooldown.fill("180")
    page.wait_for_selector("text=Changed: cooldown_seconds")
    page.get_by_role("button", name="Reset", exact=True).click()
    assert page.get_by_role("spinbutton", name="Cooldown after retryable failure (seconds)").input_value() == "60"
    calls = _desktop_calls(page)
    assert not any(c["method"] == "PUT" for c in calls)


def test_settings_partial_save_reports_saved_failed_and_remaining(page):
    _open(page)
    page.get_by_role("tab", name="Settings").click()
    page.wait_for_selector("text=Selection policy")
    page.evaluate("globalThis.__HARNESS_SETTINGS_FAIL_KEY__ = 'min_context'")
    cooldown = page.get_by_role("spinbutton", name="Cooldown after retryable failure (seconds)")
    cooldown.fill("120")
    min_context = page.get_by_role("spinbutton", name="Minimum context (tokens)")
    min_context.fill("16384")
    policy = page.get_by_role("combobox", name="Policy")
    policy.select_option("coding")
    page.get_by_role("button", name="Save 3 changes").click()
    page.wait_for_selector("text=Partially saved.", timeout=5000)
    alert = page.get_by_role("alert")
    assert "Saved: cooldown_seconds" in alert.inner_text()
    assert "Failed: min_context" in alert.inner_text()
    assert "Not attempted: policy" in alert.inner_text()
    calls = _desktop_calls(page)
    put = next((c for c in calls if c["method"] == "PUT" and c["path"] == "/settings"), None)
    assert put is not None
    page.evaluate("globalThis.__HARNESS_SETTINGS_FAIL_KEY__ = null")


def test_settings_successful_save_then_reload_roundtrip(page):
    _open(page)
    page.get_by_role("tab", name="Settings").click()
    page.wait_for_selector("text=Selection policy")
    requires_tools = page.get_by_role("switch", name="Require tool-calling support")
    assert requires_tools.get_attribute("aria-checked") == "true"
    requires_tools.click()
    page.get_by_role("button", name="Save changes").click()
    page.wait_for_selector("text=Settings saved.")
    assert page.get_by_role("switch", name="Require tool-calling support").get_attribute("aria-checked") == "false"
    calls = _desktop_calls(page)
    put = next(c for c in calls if c["method"] == "PUT" and c["path"] == "/settings")
    body = put["body"] if isinstance(put["body"], dict) else json.loads(put["body"])
    assert body["updates"] == {"requires_tools": False}


# ---------------------------------------------------------------------------
# Desktop acceptance coverage for the remaining Profiles interactions
# (edit roundtrip, duplicate, clear default) — dispatch 115.
# ---------------------------------------------------------------------------

def test_edit_profile_roundtrip_saves_changes(page):
    _open(page)
    page.get_by_role("tab", name="Profiles").click()
    page.wait_for_selector("text=Fast replies")
    page.get_by_role("button", name="Fast replies").click()
    page.wait_for_selector("text=Set as AutoRouter default")
    page.get_by_role("button", name="Edit", exact=True).click()
    page.wait_for_selector("text=Edit profile")
    name_input = page.get_by_placeholder("e.g. Nightly free builder")
    name_input.fill("Fast replies v2")
    page.get_by_role("button", name="Save changes").click()
    page.wait_for_selector("text=Routing profile saved.")
    calls = _desktop_calls(page)
    puts = [c for c in calls if c["method"] == "PUT" and c["path"] == "/routing-profiles/rp_2"]
    assert len(puts) == 1
    body = puts[0]["body"] if isinstance(puts[0]["body"], dict) else json.loads(puts[0]["body"])
    assert body["name"] == "Fast replies v2"
    page.wait_for_selector("text=Fast replies v2")


def test_duplicate_profile_roundtrip(page):
    _open(page)
    page.get_by_role("tab", name="Profiles").click()
    page.wait_for_selector("text=Fast replies")
    page.get_by_role("button", name="Fast replies").click()
    page.wait_for_selector("text=Duplicate")
    page.get_by_role("button", name="Duplicate").click()
    page.wait_for_selector("text=Profile duplicated.")
    calls = _desktop_calls(page)
    assert any(c["method"] == "POST" and c["path"] == "/routing-profiles/rp_2/duplicate" for c in calls)
    page.wait_for_selector("text=Fast replies copy")


def test_clear_default_roundtrip(page):
    _open(page)
    page.get_by_role("tab", name="Profiles").click()
    page.wait_for_selector("text=Nightly builder")
    # rp_1 (Nightly builder) is the seeded active profile.
    page.locator("button", has_text="Nightly builder").first.click()
    page.wait_for_selector("text=Clear default")
    page.get_by_role("button", name="Clear default").click()
    page.wait_for_selector("text=No default routing profile is set.")
    calls = _desktop_calls(page)
    assert any(c["method"] == "POST" and c["path"] == "/routing-profiles/deactivate" for c in calls)


# ---------------------------------------------------------------------------
# Eligibility filter confirmation (dispatch 115): the Eligible pill narrows
# the catalog server-side and shows only eligible rows.
# ---------------------------------------------------------------------------

def test_eligibility_filter_shows_only_eligible_rows(page):
    _open(page)
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=page 1 of 3")
    page.get_by_role("radio", name="Eligible", exact=True).click()
    page.wait_for_function(
        "window.__HARNESS_CALLS__.some(c => c.path.indexOf('eligibility=eligible') >= 0)",
        timeout=5000,
    )
    page.wait_for_timeout(500)
    rows = page.locator("tbody tr")
    assert rows.count() > 0
    for i in range(rows.count()):
        assert "eligible" in rows.nth(i).inner_text().lower()
