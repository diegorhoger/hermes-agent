/* Stateful fixture API for the Desktop harness — mirrors the real plugin
 * backend's response shapes (dashboard/state_reader.py). Recorded calls are
 * pushed to window.__HARNESS_CALLS__ for assertions. */

const now = Math.floor(Date.now() / 1000) - 3600

const catalog = [
  { provider: 'nvidia', model: 'llama-3.3-70b-instruct', context_length: 131072,
    capabilities: { tools: 'supported' }, cost_tier: 'free', eligible: true,
    discovery_status: 'discovered', health: 'healthy', updated_at: now },
  { provider: 'nvidia', model: 'deepseek-r1', context_length: 65536,
    capabilities: { tools: 'unsupported' }, cost_tier: 'free', eligible: false,
    discovery_status: 'discovered', health: 'unknown', updated_at: now },
  { provider: 'openrouter', model: 'qwen3-coder:free', context_length: 262144,
    capabilities: { tools: 'supported' }, cost_tier: 'free', eligible: true,
    discovery_status: 'discovered', health: 'unknown', updated_at: now },
]

const profilesSeed = [
  { id: 'rp_1', schema_version: 1, name: 'Nightly builder', description: 'Free-tier batch work',
    ranking_policy: 'coding', providers: ['nvidia'], model_include: [], model_exclude: ['nvidia/deepseek-r1'],
    min_context: 32768, requires_tools: true,
    health: { respect_failures: true, respect_cooldowns: true, require_observed: false },
    task_tags: ['nightly'], fallback_policy: 'refuse', verified_free_only: true,
    created_at: now - 86400, updated_at: now - 3600 },
  { id: 'rp_2', schema_version: 1, name: 'Fast replies', description: '',
    ranking_policy: 'fastest', providers: ['openrouter'], model_include: [], model_exclude: [],
    min_context: 8192, requires_tools: false,
    health: { respect_failures: true, respect_cooldowns: true, require_observed: false },
    task_tags: [], fallback_policy: 'refuse', verified_free_only: true,
    created_at: now - 43200, updated_at: now - 7200 },
]

const synthetic = Array.from({ length: 120 }, (_, i) => ({
  provider: i % 2 === 0 ? 'nvidia' : 'openrouter',
  model: `synthetic/model-${String(i).padStart(3, '0')}`,
  context_length: 32768,
  capabilities: { tools: 'supported' },
  cost_tier: 'free',
  eligible: i % 3 === 0,
  discovery_status: 'discovered',
  health: 'unknown',
  updated_at: now,
}))
const modelsCatalog = [...catalog, ...synthetic]

const PREF_INIT = {
  model_include: [],
  model_exclude: ['nvidia/deepseek-r1'],
  mode: 'unrestricted',
}

function preferenceHash(pref) {
  // Deterministic shape-only hash for optimistic concurrency; not cryptographic.
  const inc = [...pref.model_include].sort().join(',')
  const exc = [...pref.model_exclude].sort().join(',')
  let hash = 0
  const s = `${pref.mode ?? 'unrestricted'}|${inc}|${exc}`
  for (let i = 0; i < s.length; i++) hash = (hash * 31 + s.charCodeAt(i)) >>> 0
  return `hash-${hash.toString(16)}-${s.length}`
}

function makePreferenceState() {
  return {
    model_include: [...PREF_INIT.model_include],
    model_exclude: [...PREF_INIT.model_exclude],
    mode: PREF_INIT.mode,
  }
}

function preferencePairs(list) {
  return new Set(list.map((s) => String(s).trim()).filter(Boolean))
}

function annotateModel(m, pref) {
  const pair = `${m.provider}/${m.model}`
  const inc = preferencePairs(pref.model_include)
  const exc = preferencePairs(pref.model_exclude)
  const mode = pref.mode ?? (inc.size > 0 ? 'allowlist' : 'unrestricted')
  const allowlist = mode === 'allowlist'
  const on = mode === 'none' ? false : allowlist ? (inc.has(pair) && !exc.has(pair)) : !exc.has(pair)
  let note = null
  if (!on) {
    if (mode === 'none' && !exc.has(pair)) note = 'no models enabled (all models are toggled off)'
    else note = exc.has(pair) ? 'disabled by you' : (allowlist ? 'not in the model allowlist' : null)
  }
  return Object.assign({}, m, {
    user_preference: on ? 'on' : 'off',
    preference_note: note,
    allowlist_mode: allowlist,
    blocked_by_profile: null,
  })
}

function preferenceSummary(pref, rows) {
  const inc = preferencePairs(pref.model_include)
  const exc = preferencePairs(pref.model_exclude)
  const mode = pref.mode ?? (inc.size > 0 ? 'allowlist' : 'unrestricted')
  const allowlist = mode === 'allowlist'
  const enabled = rows.filter((r) => r.user_preference === 'on').length
  return {
    available: true,
    mode,
    allowlist_mode: allowlist,
    include_size: inc.size,
    exclude_size: exc.size,
    model_include: [...inc].sort(),
    model_exclude: [...exc].sort(),
    preference_hash: preferenceHash(pref),
    enabled_count: enabled,
    disabled_count: rows.length - enabled,
    blocked_by_profile: 0,
    profile: null,
    restart_note: 'Changes take effect on the next routing decision; no gateway restart is required for inclusion/exclusion changes.',
  }
}

function applyTogglesToPref(pref, toggles) {
  const inc = [...pref.model_include]
  const exc = [...pref.model_exclude]
  let mode = pref.mode ?? (inc.length > 0 ? 'allowlist' : 'unrestricted')
  let allowlistEmptied = false
  const byPair = new Map()
  for (const t of toggles) {
    const pair = `${String(t.provider).trim()}/${String(t.model).trim()}`
    if (!/^[a-z0-9][a-z0-9_-]{0,63}\/[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}$/.test(pair)) {
      throw new Error(`invalid provider/model '${pair}'`)
    }
    byPair.set(pair, Boolean(t.enabled))
  }
  const applyOne = (pair, enabled) => {
    if (enabled) {
      const idx = exc.indexOf(pair)
      if (idx >= 0) exc.splice(idx, 1)
      if (mode === 'allowlist' && !preferencePairs(inc).has(pair)) inc.push(pair)
      else if (mode === 'none') { inc.length = 0; inc.push(pair); mode = 'allowlist' }
    } else if (mode === 'allowlist') {
      const idx = inc.indexOf(pair)
      if (idx >= 0) {
        inc.splice(idx, 1)
        if (preferencePairs(inc).size === 0) { mode = 'none'; allowlistEmptied = true }
      }
    } else if (mode === 'unrestricted') {
      if (!preferencePairs(exc).has(pair)) exc.push(pair)
    }
    // mode === 'none': OFF is a no-op
  }
  for (const [pair, enabled] of byPair) applyOne(pair, enabled)
  return { inc, exc, mode, allowlistEmptied }
}

export function createMockApi() {
  const makeSettingsValues = () => ({
    enabled: true, policy: 'auto', free_only: true, providers: ['nvidia', 'openrouter'],
    cooldown_seconds: 60, state_dir: '', paid_authorized: false, paid_inference: 'disabled',
    enable_chat_router: false, min_context: 8192, requires_tools: true,
    model_include: [...makePreferenceState().model_include],
    model_exclude: [...makePreferenceState().model_exclude],
  })
  const state = {
    profiles: JSON.parse(JSON.stringify(profilesSeed)),
    active: 'rp_1',
    nextId: 100,
    preference: makePreferenceState(),
    settings: {
      values: makeSettingsValues(),
      notes: ['Free-only is mandatory.'],
    },
  }
  // Test hook: simulate an out-of-band writer (another Desktop or web process).
  globalThis.__HARNESS_SET_PREF__ = (patch) => {
    if (patch && typeof patch === 'object') {
      if (Array.isArray(patch.model_include)) state.preference.model_include = [...patch.model_include]
      if (Array.isArray(patch.model_exclude)) state.preference.model_exclude = [...patch.model_exclude]
      if (typeof patch.mode === 'string') state.preference.mode = patch.mode
    }
    return preferenceSummary(state.preference, modelsCatalog.map((m) => annotateModel(m, state.preference)))
  }
  // Assembled exactly like the real backend: the response always reflects the
  // current persisted values (model_include/model_exclude mirror the
  // preference state, as they live in the same plugin settings store).
  const freshSettings = () => ({
    available: true,
    generated_at: Math.floor(Date.now() / 1000),
    editable: true, managed: false,
    values: {
      ...state.settings.values,
      model_include: [...state.preference.model_include],
      model_exclude: [...state.preference.model_exclude],
    },
    notes: [...state.settings.notes],
    schema: { policy: { type: 'enum', options: ['auto', 'coding', 'fastest', 'reliable'] },
              free_only: { type: 'boolean', const: true },
              cooldown_seconds: { type: 'integer', min: 1, max: 86400 },
              providers: { type: 'array', maxItems: 16 } },
  })
  const calls = []
  const record = (path, opts) => calls.push({ path, method: opts?.method ?? 'GET', body: opts?.body ?? null, at: Date.now() })
  const json = (value, status = 200) => ({ status, ok: status < 400, body: value })

  const respond = (path, opts) => {
    const [base, query] = String(path).split('?')
    const q = new URLSearchParams(query ?? '')
    record(path, opts)
    const method = opts?.method ?? 'GET'

    if (base === '/overview') {
      const activeProfile = state.profiles.find((p) => p.id === state.active) ?? null
      return json({
        available: true,
        generated_at: Math.floor(Date.now() / 1000),
        plugin: { enabled: true, policy: 'auto', free_only: true, cooldown_seconds: 60,
                  providers: ['nvidia', 'openrouter'], paid_inference: 'disabled', config_managed: false, config_readable: true },
        virtual_pin_guard: (() => {
          const vpgState = new URLSearchParams(globalThis.location?.search ?? '').get('vpg') ?? 'clear'
          if (vpgState === 'unresolved_pin') {
            return { state: 'unresolved_pin', pins: [{ source: 'config.model.default', detail: 'autorouter/auto-free' }],
                     ts: Math.floor(Date.now() / 1000),
                     detail: "Profile is pinned to the unresolved virtual model 'autorouter/auto-free' while chat routing is disabled. Run /model and select a real model. The configuration was NOT modified; no provider was substituted.",
                     action: "Run /model and select a real model, or re-enable AutoRouter chat routing and restart the gateway. The configuration was NOT modified." }
          }
          return { state: vpgState, pins: [], ts: Math.floor(Date.now() / 1000) }
        })(),
        active_routing_profile: activeProfile ? { id: activeProfile.id, name: activeProfile.name,
          ranking_policy: activeProfile.ranking_policy, providers: activeProfile.providers,
          min_context: activeProfile.min_context, requires_tools: activeProfile.requires_tools,
          updated_at: activeProfile.updated_at } : null,
        routing: { chat_routing_enabled: false, policy: 'auto', min_context: 8192, requires_tools: true,
                   providers: ['nvidia', 'openrouter'], cooldown_seconds: 60, model_include: [], model_exclude: [],
                   last_decision: null },
        counts: { discovered_models: 3, providers: 2, healthy: 1, health_unknown: 2, cooldown: 0, retired: 0,
                  auth_failed: 0, health_invalid: 0, successes: 10, failures: 0, decisions: 4, events: 0 },
        recent_decisions: [], recent_failures: [], unavailable: [],
        unsupported: [],
      })
    }

    if (base === '/providers') {
      return json({
        available: true, generated_at: Math.floor(Date.now() / 1000),
        providers: [
          { name: 'nvidia', configured: true, discovered_models: 2, healthy: 1, health_unknown: 1,
            cooldown: 0, retired: 0, auth_failed: 0, health_invalid: 0, successes: 7, failures: 0,
            last_catalog_refresh: now, last_success_at: now, last_failure_at: null, last_error: null,
            auth: 'configured', free_access_states: ['unknown'], quota_evidence: [] },
          { name: 'openrouter', configured: true, discovered_models: 1, healthy: 0, health_unknown: 1,
            cooldown: 0, retired: 0, auth_failed: 0, health_invalid: 0, successes: 3, failures: 0,
            last_catalog_refresh: now, last_success_at: now, last_failure_at: null, last_error: null,
            auth: 'configured', free_access_states: ['unknown'], quota_evidence: [] },
        ],
        intelligence: { registry: [], models_truncated: false },
        connection_inventory: {
          available: true, mode: 'read_only',
          connections: [
            { id: 'hermes-env:nvidia', provider_id: 'nvidia', label: 'NVIDIA NIM', family: 'llm_adapter',
              authorized: true, presence: 'configured', credential_source: 'hermes_credential_pool',
              inference_authenticated: 'unknown', account_allowance: 'unknown', usable_for_routing: 'ready',
              discovery: 'adapter', health: 'unknown', discovered_model_count: 2,
              readiness: { configured: true, authentication_validated: 'unknown', models_discovered: 2, models_eligible: 1, operationally_usable: 'unknown' } },
            { id: 'hermes-env:openrouter', provider_id: 'openrouter', label: 'OpenRouter', family: 'llm_adapter',
              authorized: true, presence: 'configured', credential_source: 'hermes_credential_pool',
              inference_authenticated: 'unknown', account_allowance: 'unknown', usable_for_routing: 'ready',
              discovery: 'adapter', health: 'unknown', discovered_model_count: 1,
              readiness: { configured: true, authentication_validated: 'unknown', models_discovered: 1, models_eligible: 1, operationally_usable: 'unknown' } },
            { id: 'hermes-env:nous', provider_id: 'nous', label: 'Nous Portal', family: 'llm_adapter',
              authorized: false, presence: 'configured', credential_source: 'hermes_oauth_store',
              inference_authenticated: 'unknown', account_allowance: 'unknown', usable_for_routing: 'not_authorized',
              discovery: 'adapter', health: 'unknown', discovered_model_count: null,
              readiness: { configured: false, authentication_validated: 'unknown', models_discovered: null, models_eligible: null, operationally_usable: 'unknown' } },
            { id: 'hermes-pool:zai', provider_id: 'zai', label: 'zai', family: 'llm_unsupported',
              authorized: false, presence: 'configured', credential_source: 'hermes_credential_pool',
              inference_authenticated: 'unknown', account_allowance: 'unknown', usable_for_routing: 'unsupported',
              discovery: 'unsupported', health: 'unknown', discovered_model_count: null,
              readiness: { configured: false, authentication_validated: 'unknown', models_discovered: null, models_eligible: null, operationally_usable: 'unsupported' } },
          ],
          account_allowance: 'unknown', inference_authentication: 'unverified',
        },
        unavailable: [],
      })
    }

    if (base === '/models') {
      // Mirror the real backend contract (dashboard/state_reader.py):
      // filter -> sort(provider) -> paginate, 50 per page by default.
      const qLower = String(q.get('query') ?? '').trim().toLowerCase()
      const provider = String(q.get('provider') ?? '').trim().toLowerCase()
      const eligibility = String(q.get('eligibility') ?? 'all')
      const prefFilter = String(q.get('preference') ?? 'all')
      const preference = state.preference
      const annotated = modelsCatalog.map((m) => annotateModel(m, preference))
      let filtered = annotated.slice()
      if (provider) {
        filtered = filtered.filter((m) => m.provider.toLowerCase() === provider)
      }
      if (eligibility === 'eligible') {
        filtered = filtered.filter((m) => m.eligible === true)
      } else if (eligibility === 'ineligible') {
        filtered = filtered.filter((m) => m.eligible !== true)
      }
      if (prefFilter === 'on') {
        filtered = filtered.filter((m) => m.user_preference === 'on')
      } else if (prefFilter === 'off') {
        filtered = filtered.filter((m) => m.user_preference === 'off')
      }
      if (qLower) {
        filtered = filtered.filter((m) => `${m.provider} ${m.model}`.toLowerCase().includes(qLower))
      }
      filtered.sort((a, b) => (a.provider + '/' + a.model).localeCompare(b.provider + '/' + b.model))
      const total = filtered.length
      const pageSize = Math.min(Math.max(parseInt(q.get('page_size') ?? '50', 10) || 50, 1), 200)
      const totalPages = total === 0 ? 1 : Math.ceil(total / pageSize)
      const page = Math.min(Math.max(parseInt(q.get('page') ?? '1', 10) || 1, 1), totalPages)
      const models = filtered.slice((page - 1) * pageSize, page * pageSize)
      const summary = preferenceSummary(preference, annotated)
      return json({
        available: true, truncated: false, page, page_size: pageSize,
        total, total_catalog: modelsCatalog.length, total_pages: totalPages,
        models, providers: ['nvidia', 'openrouter'],
        provider_options: ['nvidia', 'nous', 'openrouter'],
        preference: summary,
      })
    }

    if (base === '/models/preference') {
      const preference = state.preference
      const annotated = modelsCatalog.map((m) => annotateModel(m, preference))
      if (method === 'GET') {
        return json(preferenceSummary(preference, annotated))
      }
      if (method === 'POST') {
        const body = opts?.body ?? {}
        const baseHash = String(body.base ?? '')
        if (baseHash !== preferenceHash(preference)) {
          const summary = preferenceSummary(preference, annotated)
          summary.stale = true
          return json({ detail: summary }, 409)
        }
        const toggles = Array.isArray(body.toggles) ? body.toggles : []
        if (body.reset) {
          if (body.reset !== 'unrestricted') return json({ detail: { errors: ['unsupported reset'] } }, 400)
          preference.model_include = []
          preference.model_exclude = []
          preference.mode = 'unrestricted'
          const freshReset = preferenceSummary(preference, modelsCatalog.map((m) => annotateModel(m, preference)))
          freshReset.applied = { changed: true, toggles_applied: 0, mode: 'unrestricted', reset: true }
          return json(freshReset)
        }
        if (toggles.length === 0) {
          return json({ detail: { errors: ['toggles must not be empty'] } }, 400)
        }
        try {
          const { inc, exc, mode, allowlistEmptied } = applyTogglesToPref(preference, toggles)
          preference.model_include = inc
          preference.model_exclude = exc
          preference.mode = mode
          const fresh = preferenceSummary(preference, modelsCatalog.map((m) => annotateModel(m, preference)))
          fresh.applied = { changed: true, toggles_applied: toggles.length, allowlist_emptied: allowlistEmptied, mode }
          return json(fresh)
        } catch (err) {
          return json({ detail: { errors: [String(err.message || err)] } }, 400)
        }
      }
    }

    if (base === '/settings') {
      if (method === 'GET') {
        return json(freshSettings())
      }
      if (method === 'PUT') {
        const body = opts?.body ?? {}
        const updates = body?.updates && typeof body.updates === 'object'
          ? body.updates : null
        if (!updates || Object.keys(updates).length === 0) {
          return json({ detail: { errors: ['updates must be a non-empty object'] } }, 400)
        }
        // Optional test hook: simulate a server-side write failure for one
        // key. Earlier keys in the batch persist (like the real backend);
        // the failing key is not applied; later keys are not attempted.
        const failKey = typeof globalThis !== 'undefined'
          ? globalThis.__HARNESS_SETTINGS_FAIL_KEY__ ?? null : null
        const allowed = ['policy', 'cooldown_seconds', 'min_context', 'requires_tools',
                         'enable_chat_router', 'providers', 'model_include', 'model_exclude']
        const saved = []
        const entries = Object.entries(updates)
        for (let i = 0; i < entries.length; i++) {
          const [key, value] = entries[i]
          if (!allowed.includes(key)) {
            return json({ detail: { errors: [`unknown key '${key}'`] } }, 400)
          }
          if (failKey === key) {
            const remaining = entries.slice(i + 1).map(([k]) => k)
            return json({ detail: {
              message: `Some settings were saved; the rest were not. Saved: ${saved.join(', ') || 'none'}. Failed: ${key} (simulated write failure). Not attempted: ${remaining.join(', ') || 'none'}. Earlier keys were already persisted and stay persisted.`,
              partial: true, saved,
              failed: { [key]: 'simulated write failure' },
              remaining,
            } }, 500)
          }
          if (key === 'model_include' || key === 'model_exclude') {
            state.preference[key] = Array.isArray(value) ? [...value] : []
            state.preference.mode = state.preference.model_include.length > 0 ? 'allowlist' : 'unrestricted'
          } else {
            state.settings.values[key] = value
          }
          saved.push(key)
        }
        return json(freshSettings())
      }
      return json({ detail: { code: 'not_found', message: `unhandled fixture route ${method} ${base}` } }, 404)
    }

    if (base === '/routing-profiles') {
      if (method === 'GET') {
        return json({ schema_version: 1, profiles: state.profiles, active: state.active,
                      ranking_policies: ['auto', 'coding', 'fastest', 'reliable', 'smartest', 'priority'],
                      execution_authority: false })
      }
      if (method === 'POST') {
        const body = opts?.body ?? {}
        if (!body.name?.trim()) {
          return json({ detail: { code: 'profile_invalid', message: 'name must not be empty', fields: { name: 'must not be empty' } } }, 400)
        }
        const profile = {
          id: `rp_${state.nextId++}`, schema_version: 1,
          name: String(body.name).trim(), description: body.description ?? '',
          ranking_policy: body.ranking_policy ?? 'auto',
          providers: Array.isArray(body.providers) ? body.providers : [],
          model_include: Array.isArray(body.model_include) ? body.model_include : [],
          model_exclude: Array.isArray(body.model_exclude) ? body.model_exclude : [],
          min_context: Number(body.min_context ?? 8192), requires_tools: Boolean(body.requires_tools),
          health: body.health ?? { respect_failures: true, respect_cooldowns: true, require_observed: false },
          task_tags: Array.isArray(body.task_tags) ? body.task_tags : [],
          fallback_policy: 'refuse', verified_free_only: true,
          created_at: Math.floor(Date.now() / 1000), updated_at: Math.floor(Date.now() / 1000),
        }
        state.profiles.push(profile)
        return json({ profile }, 201)
      }
    }

    if (base === '/routing-profiles/deactivate' && method === 'POST') {
      state.active = null
      return json({ active: null })
    }

    const profileMatch = base.match(/^\/routing-profiles\/([^/]+)(?:\/(duplicate|preview|activate))?$/)
    if (profileMatch) {
      const [, id, action] = profileMatch
      const profile = state.profiles.find((p) => p.id === id)
      if (!profile) {
        return json({ detail: { code: 'profile_not_found', message: 'Routing profile not found' } }, 404)
      }
      if (!action && method === 'GET') {
        return json({ profile, active: state.active === id })
      }
      if (!action && method === 'PUT') {
        const body = opts?.body ?? {}
        Object.assign(profile, {
          name: body.name ?? profile.name, description: body.description ?? profile.description,
          ranking_policy: body.ranking_policy ?? profile.ranking_policy,
          providers: body.providers ?? profile.providers,
          model_include: body.model_include ?? profile.model_include,
          model_exclude: body.model_exclude ?? profile.model_exclude,
          min_context: body.min_context ?? profile.min_context,
          requires_tools: body.requires_tools ?? profile.requires_tools,
          task_tags: body.task_tags ?? profile.task_tags,
          updated_at: Math.floor(Date.now() / 1000),
        })
        return json({ profile })
      }
      if (!action && method === 'DELETE') {
        state.profiles = state.profiles.filter((p) => p.id !== id)
        const deactivated = state.active === id
        if (deactivated) state.active = null
        return json({ deleted: true, deactivated })
      }
      if (action === 'duplicate' && method === 'POST') {
        const copy = { ...profile, id: `rp_${state.nextId++}`, name: `${profile.name} copy`,
          created_at: Math.floor(Date.now() / 1000), updated_at: Math.floor(Date.now() / 1000) }
        state.profiles.push(copy)
        return json({ profile: copy }, 201)
      }
      if (action === 'preview' && method === 'POST') {
        return json({
          available: true, profile_id: id, generated_at: Math.floor(Date.now() / 1000),
          eligible_count: 1, total_considered: catalog.length,
          chosen: { provider: 'nvidia', model: 'llama-3.3-70b-instruct',
                    context_length: 131072, cost_tier: 'free', tools: 'supported',
                    score: 0.72, health_reason: 'available', circuit_state: 'closed' },
          eligible: [{ provider: 'nvidia', model: 'llama-3.3-70b-instruct', context_length: 131072,
                       tools: 'supported', cost_tier: 'free', score: 0.72, health_reason: 'available' }],
          excluded: [{ provider: 'nvidia', model: 'deepseek-r1', reason_codes: ['tools_unverified_or_unsupported'] }],
          excluded_total: 1, no_match: null, selection_policy_version: 1, execution_authority: false,
        })
      }
      if (action === 'activate' && method === 'POST') {
        state.active = id
        return json({ active: id })
      }
    }

    if (base === '/analytics') {
      return json({ available: true, summary: null, lifetime: null })
    }

    return json({ detail: { code: 'not_found', message: `unhandled fixture route ${method} ${base}` } }, 404)
  }

  // Test hook: force a delay (ms) for fixture responses whose path contains a
  // given substring, so out-of-order / delayed responses can be simulated:
  //   globalThis.__HARNESS_DELAY__ = { 'preference=off': 600 }
  const delayFor = (path) => {
    const hooks = (typeof globalThis !== 'undefined' && globalThis.__HARNESS_DELAY__) || null
    if (!hooks || typeof hooks !== 'object') return 0
    for (const [needle, ms] of Object.entries(hooks)) {
      const value = Number(ms)
      if (needle && Number.isFinite(value) && value > 0 && String(path).includes(needle)) return value
    }
    return 0
  }

  const rest = (path, opts = {}) => {
    return new Promise((resolve, reject) => {
      const wait = delayFor(path)
      const schedule = wait > 0 ? (fn) => setTimeout(fn, wait) : (fn) => queueMicrotask(fn)
      schedule(() => {
        const res = respond(path, opts)
        if (res.status >= 400) {
          // Real ctx.rest rejects with "STATUS: <raw body>"; mirror that shape.
          const err = new Error(`${res.status}: ${JSON.stringify(res.body)}`)
          err.statusCode = res.status
          reject(err)
        } else {
          resolve(res.body)
        }
      })
    })
  }

  return { rest, calls, state }
}
