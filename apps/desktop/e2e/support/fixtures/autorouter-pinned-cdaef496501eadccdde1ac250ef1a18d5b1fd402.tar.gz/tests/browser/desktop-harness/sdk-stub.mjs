/* Minimal REAL @hermes/plugin-sdk replacement for the Desktop harness.
 * Components are real React components implemented with createElement;
 * no mocking of the host beyond this module. Hooks are the real react. */
import React, { useState, createContext, useContext } from 'react'

export const ROUTES_AREA = 'routes'
export const SIDEBAR_NAV_AREA = 'sidebar.nav'
export const PALETTE_AREA = 'command_palette'
export const STATUSBAR_AREAS = { left: 'statusBar.left', right: 'statusBar.right' }
export const host = {
  navigate: (path) => { globalThis.__NAVIGATE__ = path },
  state: {},
}
export const cn = (...args) => args.flat(Infinity).filter(Boolean).join(' ')

const h = React.createElement
const cx = (...args) => args.filter(Boolean).join(' ')

export function Badge({ variant, children }) {
  return h('span', { className: cx('ar-badge', variant && `ar-badge--${variant}`) }, children)
}
export function Button({ variant, size, disabled, onClick, children, ...rest }) {
  return h('button', { type: 'button', ...rest, className: cx('ar-btn', variant && `ar-btn--${variant}`, size && `ar-btn--${size}`), disabled, onClick }, children)
}
export function Codicon({ name, size, className }) {
  return h('i', { 'aria-hidden': 'true', 'data-icon': name, className, style: size ? { fontSize: size } : undefined })
}
export function EmptyState({ title, description, className }) {
  return h('div', { className: cx('ar-empty', className) }, [h('h3', { key: 't' }, title), description ? h('p', { key: 'd' }, description) : null])
}
export function ErrorState({ title, description, className }) {
  return h('div', { role: 'alert', className: cx('ar-error', className) }, [h('h3', { key: 't' }, title), description ? h('p', { key: 'd' }, description) : null])
}

function capitalizeProps(props) { return props }

export function Input(props) {
  const forwarded = capitalizeProps(props)
  return h('input', { ...forwarded, className: cx('ar-input', props.className) })
}
export function Textarea(props) {
  return h('textarea', { ...props, className: cx('ar-textarea', props.className) })
}
export function SearchField(props) {
  // Mirror the real @hermes/plugin-sdk contract: onChange(value: string).
  const rest = { ...props }
  const onChange = typeof props.onChange === 'function' ? props.onChange : undefined
  delete rest.onChange
  return h('input', {
    role: 'searchbox',
    ...rest,
    className: cx('ar-search', props.className),
    onChange: (event) => onChange && onChange(event.target.value),
  })
}

export function SegmentedControl({ options, value, onChange, sizing }) {
  return h('div', { role: 'radiogroup', className: 'ar-segmented' },
    options.map((option) => {
      const id = typeof option === 'string' ? option : option.value ?? option.id
      const label = typeof option === 'string' ? option : (option.label ?? id)
      return h('button', { key: id, type: 'button', role: 'radio', 'aria-checked': String(id === value), 'data-value': id, onClick: () => onChange(id) }, label)
    }))
}

const TabsContext = createContext({ value: null, setValue: () => {} })
export function Tabs({ value, onValueChange, children }) {
  const [internal, setInternal] = useState(value)
  const active = value ?? internal
  const setValue = (v) => { setInternal(v); onValueChange?.(v) }
  return h(TabsContext.Provider, { value: { value: active, setValue } }, children)
}
export function TabsList({ children, className, 'aria-label': ariaLabel }) {
  return h('div', { role: 'tablist', 'aria-label': ariaLabel, className: cx('ar-tabs-list', className) }, children)
}
export function TabsTrigger({ value, children, className }) {
  const ctx = useContext(TabsContext)
  const selected = ctx.value === value
  return h('button', { role: 'tab', type: 'button', 'aria-selected': String(selected), 'aria-controls': `panel-${value}`, 'data-state': selected ? 'active' : 'inactive', className: cx('ar-tabs-trigger', className), onClick: () => ctx.setValue(value) }, children)
}

export function ToggleRow({ label, description, checked, onChange, disabled }) {
  return h('button', { type: 'button', role: 'switch', 'aria-checked': String(!!checked), disabled, onClick: () => onChange(!checked), className: 'ar-toggle' }, [
    h('span', { key: 'l', className: 'ar-toggle-label' }, label),
    description ? h('span', { key: 'd', className: 'ar-toggle-desc' }, description) : null,
  ])
}
