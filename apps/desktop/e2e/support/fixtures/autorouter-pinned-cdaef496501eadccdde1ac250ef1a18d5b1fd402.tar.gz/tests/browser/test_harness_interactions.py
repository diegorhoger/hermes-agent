"""Browser-interaction regression tests for the AutoRouter dashboard.

These drive the real bundle (``dashboard/dist/index.js``) in a real
Chromium/Chrome browser against ``tests/browser/harness.html`` (a mocked
plugin API with real response shapes) and assert *behavior* — clicks,
keyboard interaction and form submission — not merely rendered markup:

* Retry actually re-issues the failed GET and recovers the panel
* Clear Filters restores the full model table
* Enter inside the Settings form does not navigate/reload the page
* Save Changes sends a PUT with exactly the changed keys and shows the
  saved outcome; Reset restores the form values without a PUT
* A partial-save failure (structured ``partial`` error body, as produced by
  ``plugin_api.py`` when a multi-key write fails partway) is rendered with
  the exact saved/failed/remaining keys
* Keyboard tab navigation (Arrow keys / Home / End) keeps working
* No inline event-handler attributes ever reach the DOM

Runs when Playwright and a Chrome/Chromium binary are available; otherwise
skips cleanly:

    uv run --with playwright python -m pytest tests/browser/test_harness_interactions.py
"""

from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

import pytest

playwright = pytest.importorskip("playwright")
from playwright.sync_api import sync_playwright  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
HARNESS = ROOT / "tests" / "browser" / "harness.html"

_CHROME_CANDIDATES = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    shutil.which("google-chrome"),
    shutil.which("chromium"),
    shutil.which("chromium-browser"),
    shutil.which("chrome"),
]
CHROME = next((p for p in _CHROME_CANDIDATES if p and Path(p).exists()), None)

SETTINGS_HOST_THEMES = {
    "default": {
        "fontSans": 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
        "fontMono": 'ui-monospace, "SF Mono", "Cascadia Mono", Menlo, Consolas, monospace',
        "baseSize": "15px",
        "lineHeight": "1.55",
        "letterSpacing": "0",
        "spacingMul": "1",
        "gutterScale": "0.75rem",
    },
    "teal-large": {
        "fontSans": 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
        "fontMono": 'ui-monospace, "SF Mono", "Cascadia Mono", Menlo, Consolas, monospace',
        "baseSize": "18px",
        "lineHeight": "1.65",
        "letterSpacing": "0",
        "spacingMul": "1.2",
        "gutterScale": "0.75rem",
    },
    "cyberpunk": {
        "fontSans": '"Share Tech Mono", "JetBrains Mono", ui-monospace, "SF Mono", "Cascadia Mono", Menlo, Consolas, monospace',
        "fontMono": '"Share Tech Mono", "JetBrains Mono", ui-monospace, "SF Mono", "Cascadia Mono", Menlo, Consolas, monospace',
        "baseSize": "15px",
        "lineHeight": "1.55",
        "letterSpacing": "0",
        "spacingMul": "1",
        "gutterScale": "0.75rem",
    },
}

pytestmark = pytest.mark.skipif(CHROME is None, reason="no Chrome/Chromium binary available")


def _url(mode: str) -> str:
    return HARNESS.as_uri() + "?mode=" + mode


@pytest.fixture(scope="module")
def browser():
    with sync_playwright() as pw:
        instance = pw.chromium.launch(executable_path=CHROME, headless=True)
        yield instance
        instance.close()


@pytest.fixture()
def page(browser):
    p = browser.new_page()
    yield p
    p.close()


def _open(page, mode: str) -> None:
    page.goto(_url(mode))
    # the harness mounts itself once the bundle loads
    page.wait_for_selector("#ar-panel", timeout=5000)
    page.wait_for_function("window.__HARNESS_MOUNTED__ === true", timeout=5000)


def _calls(page) -> list[dict]:
    return page.evaluate("window.__HARNESS_CALLS__")


def _path_b(call) -> str:
    return call['path'].split('?')[0]


def _paths(page) -> list[str]:
    return [c['path'].split('?')[0] for c in _calls(page)]


def _paths_where(page, expected) -> list[str]:
    return [c['path'] for c in _calls(page) if c['path'].split('?')[0] == expected]


def test_retry_refetches_and_recovers(page):
    _open(page, "flaky")
    # first attempt fails -> explicit error panel with a working Retry button
    page.wait_for_selector("text=load live state", timeout=5000)
    assert [c["path"] for c in _calls(page)] == ["/overview"]
    page.get_by_role("button", name="Retry").click()
    # retry actually re-issues the request and the panel recovers
    page.wait_for_selector("text=Recent selection activity", timeout=5000)
    calls = [c["path"] for c in _calls(page)]
    assert calls == ["/overview", "/overview"]


def test_clear_filters_restores_all_rows(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    page.fill("#ar-models-search", "zzz-no-match-query")
    page.wait_for_selector("text=No models match your filters", timeout=5000)
    page.get_by_role("button", name="Clear filters").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    assert page.get_by_role("region", name="discovered models", exact=True).locator("tbody tr").count() == 5
    assert "Showing 5 of 5" in page.locator(".ar-count").inner_text()


def test_settings_enter_does_not_navigate(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Settings").click()
    page.wait_for_selector("#ar-set-cooldown", timeout=5000)
    page.evaluate("window.__nav_marker = 'still-here'")
    page.fill("#ar-set-cooldown", "120")
    page.press("#ar-set-cooldown", "Enter")
    # a navigation/reload would lose the marker
    assert page.evaluate("window.__nav_marker") == "still-here"
    assert [c for c in _calls(page) if c["method"] == "PUT"] == []
    assert page.locator("#ar-set-cooldown").count() == 1


def test_settings_save_sends_only_changed_keys(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Settings").click()
    page.wait_for_selector("#ar-set-policy", timeout=5000)
    page.select_option("#ar-set-policy", "smartest")
    page.get_by_role("button", name="Save changes").click()
    page.wait_for_selector("text=Settings saved", timeout=5000)
    puts = [c for c in _calls(page) if c["method"] == "PUT"]
    assert len(puts) == 1
    assert json.loads(puts[0]["body"]) == {"updates": {"policy": "smartest"}}
    assert puts[0]["path"] == "/settings"


def test_settings_reset_restores_values(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Settings").click()
    page.wait_for_selector("#ar-set-policy", timeout=5000)
    page.select_option("#ar-set-policy", "fastest")
    page.fill("#ar-set-cooldown", "120")
    page.fill("#ar-set-providers", "nvidia")
    page.get_by_role("button", name="Reset").click()
    assert page.locator("#ar-set-policy").input_value() == "auto"
    assert page.locator("#ar-set-cooldown").input_value() == "60"
    assert page.locator("#ar-set-providers").input_value() == "nvidia, openrouter"
    assert [c for c in _calls(page) if c["method"] == "PUT"] == []


@pytest.mark.parametrize("sdk_body", ["object", "json_string"])
def test_partial_save_failure_is_reported_accurately(page, sdk_body):
    _open(page, "partial")
    if sdk_body == "json_string":
        page.evaluate("""()=>{
          const original=window.__AUTOROUTER_FETCH__;
          window.__AUTOROUTER_FETCH__=(path,options)=>original(path,options).catch(error=>{
            error.body=JSON.stringify(error.body); throw error;
          });
        }""")
    page.get_by_role("tab", name="Settings").click()
    page.wait_for_selector("#ar-set-policy", timeout=5000)
    page.select_option("#ar-set-policy", "fastest")
    page.fill("#ar-set-cooldown", "120")
    page.fill("#ar-set-providers", "nvidia")
    page.get_by_role("button", name="Save changes").click()
    page.wait_for_selector("text=Partial save", timeout=5000)
    region = page.locator(".ar-form-errors").inner_text()
    # deterministic client-side key order: policy, cooldown_seconds, providers
    assert "Saved and persisted: policy" in region
    assert "cooldown_seconds" in region
    assert "Not attempted: providers" in region
    # a partially failed batch must not be reported as fully saved
    assert "Settings saved" not in page.locator(".ar-toast").inner_text()
    failed = page.get_by_label("Cooldown (seconds)")
    assert failed.get_attribute("aria-invalid") is None
    assert failed.get_attribute("aria-describedby") == "ar-settings-errors"
    assert failed.evaluate("e=>e===document.activeElement")
    assert page.get_by_label("Selection policy").get_attribute("aria-invalid") is None
    page.get_by_role("tab", name="Providers", exact=True).click()
    page.get_by_role("tab", name="Settings", exact=True).click()
    page.get_by_text("Partial save — not all changes were applied.", exact=True).wait_for(timeout=3000)
    assert page.get_by_label("Cooldown (seconds)").input_value() == "120"
    assert page.get_by_label("Cooldown (seconds)").get_attribute("aria-invalid") is None
    page.get_by_role("button", name="Reset", exact=True).click()
    assert page.locator(".ar-form-errors").inner_text() == ""
    assert page.get_by_label("Cooldown (seconds)").get_attribute("aria-invalid") is None


def test_keyboard_tab_navigation(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Providers").click()
    assert page.get_by_role("tab", name="Providers").get_attribute("aria-selected") == "true"
    # keyboard flow: focus lands on the selected tab (roving tabindex), arrows move selection
    page.get_by_role("tab", name="Providers").focus()
    # roving tabindex: arrow keys operate from the selected tab and move focus
    page.keyboard.press("ArrowRight")
    assert page.get_by_role("tab", name="Models").get_attribute("aria-selected") == "true"
    assert page.evaluate("document.activeElement.id") == "ar-tab-models"
    page.keyboard.press("ArrowRight")
    assert page.get_by_role("tab", name="Analytics").get_attribute("aria-selected") == "true"
    assert page.evaluate("document.activeElement.id") == "ar-tab-analytics"
    page.keyboard.press("ArrowLeft")
    page.keyboard.press("ArrowLeft")
    assert page.get_by_role("tab", name="Providers").get_attribute("aria-selected") == "true"
    page.keyboard.press("Home")
    assert page.get_by_role("tab", name="Overview").get_attribute("aria-selected") == "true"
    page.keyboard.press("End")
    assert page.get_by_role("tab", name="Settings").get_attribute("aria-selected") == "true"
    assert page.evaluate("document.activeElement.id") == "ar-tab-settings"


@pytest.mark.parametrize("width", [320, 375, 1440])
@pytest.mark.parametrize("theme_name", ["default", "teal-large", "cyberpunk"])
def test_settings_reflows_without_root_overflow_and_remains_keyboard_reachable(
    page, width, theme_name
):
    _open(page, "normal")
    page.set_viewport_size({"width": width, "height": 900})
    theme = SETTINGS_HOST_THEMES[theme_name]
    # Apply the host's inherited typography and spacing tokens before mounting
    # the plugin root; the test harness does not load Hermes index.css.
    page.evaluate(
        """(theme) => {
          const html = document.documentElement;
          const rootStyle = html.style;
          rootStyle.setProperty('--theme-font-sans', theme.fontSans);
          rootStyle.setProperty('--theme-font-mono', theme.fontMono);
          rootStyle.setProperty('--theme-base-size', theme.baseSize);
          rootStyle.setProperty('--theme-line-height', theme.lineHeight);
          rootStyle.setProperty('--theme-letter-spacing', theme.letterSpacing);
          rootStyle.setProperty('--theme-spacing-mul', theme.spacingMul);
          html.style.fontFamily = 'var(--theme-font-sans)';
          html.style.fontSize = 'var(--theme-base-size)';
          html.style.lineHeight = 'var(--theme-line-height)';
          html.style.letterSpacing = 'var(--theme-letter-spacing)';
          const root = document.querySelector('#root');
          const host = document.createElement('div');
          host.id = 'hermes-content-gutter';
          host.style.cssText = `box-sizing:border-box;width:calc(100% - 11px);height:100%;padding-inline:calc(${theme.gutterScale} * var(--theme-spacing-mul, 1))`;
          root.parentNode.insertBefore(host, root);
          host.appendChild(root);
        }""",
        theme,
    )
    page.get_by_role("tab", name="Settings", exact=True).click()
    page.wait_for_selector("#ar-set-cooldown", timeout=5000)
    # Match the real settings contract's rendered labels; the generic harness
    # otherwise returns short IDs and misses the policy select's intrinsic width.
    page.evaluate(
        """() => {
          const original = window.__AUTOROUTER_FETCH__;
          const policies = [
            {id:'auto', label:'General'}, {id:'coding', label:'Coding'},
            {id:'fastest', label:'Fast response'},
            {id:'reliable', label:'Reliability-first'},
            {id:'smartest', label:'Legacy smartest (quality unknown)'},
            {id:'priority', label:'Legacy priority'}
          ];
          window.__AUTOROUTER_FETCH__ = (path, options) =>
            Promise.resolve(original(path, options)).then(payload =>
              path.split('?')[0] === '/settings'
                ? Object.assign({}, payload, {policy_contract:{policies}})
                : payload);
        }"""
    )
    page.get_by_role("button", name="Refresh").click()
    page.locator(
        "#ar-set-policy option", has_text="Legacy smartest (quality unknown)"
    ).wait_for(state="attached", timeout=1000)
    assert (
        page.locator("#ar-panel .ar-note")
        .filter(has_text="plugins.entries.autorouter.settings")
        .count()
        == 1
    )

    # Roving tab behavior must still work after opening the Settings panel.
    settings_tab = page.get_by_role("tab", name="Settings", exact=True)
    settings_tab.focus()
    page.keyboard.press("Home")
    assert page.get_by_role("tab", name="Overview", exact=True).get_attribute("aria-selected") == "true"
    page.keyboard.press("End")
    assert settings_tab.get_attribute("aria-selected") == "true"
    assert page.evaluate("document.activeElement.id") == "ar-tab-settings"

    # Tab from the selected tab through the actionable controls in Settings.
    reachable = []
    for _ in range(5):
        page.keyboard.press("Tab")
        reachable.append(
            page.evaluate(
                """() => document.activeElement.id || document.activeElement.textContent.trim()"""
            )
        )
    assert reachable == [
        "ar-set-policy",
        "ar-set-cooldown",
        "ar-set-providers",
        "Save changes",
        "Reset",
    ]

    geometry = page.evaluate(
        """() => {
          const root = document.querySelector('.ar-root');
          const rootRect = root.getBoundingClientRect();
          const controls = Array.from(root.querySelectorAll(
            '.ar-form input, .ar-form select, .ar-form textarea, .ar-form button'
          )).filter(e => !e.disabled && e.getClientRects().length).map(e => {
            const r = e.getBoundingClientRect();
            return {id: e.id, name: e.getAttribute('aria-label') || e.labels?.[0]?.textContent || e.textContent,
              left: r.left, right: r.right};
          });
          return {clientWidth: root.clientWidth, scrollWidth: root.scrollWidth,
            documentWidth: document.documentElement.scrollWidth, viewport: innerWidth,
            rootLeft: rootRect.left, rootRight: rootRect.right, controls};
        }"""
    )
    assert geometry["controls"] and any(
        control["id"] == "ar-set-policy" for control in geometry["controls"]
    ), geometry
    assert geometry["scrollWidth"] <= geometry["clientWidth"], geometry
    assert geometry["documentWidth"] <= geometry["viewport"], geometry
    assert all(
        control["left"] >= geometry["rootLeft"]
        and control["right"] <= geometry["rootRight"]
        for control in geometry["controls"]
    ), geometry


def test_no_inline_event_handler_attributes(page):
    _open(page, "normal")
    for tab in ("Providers", "Models", "Analytics", "Settings", "Overview"):
        page.get_by_role("tab", name=tab).click()
        page.wait_for_selector("#ar-panel", timeout=5000)
    attrs = page.evaluate(
        """Array.from(document.querySelectorAll('*')).flatMap(
              el => Array.from(el.attributes).filter(a => /^on/i.test(a.name)).map(a => a.name))"""
    )
    assert attrs == []


def test_hostile_model_id_renders_as_inert_text(page):
    _open(page, "hostile")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("text=<img src=x", timeout=5000)
    assert page.evaluate("window.__xss_fired") is None


def test_preview_explains_without_network_or_unsafe_html(page):
    _open(page, "populated")
    page.get_by_role("tab", name="Models", exact=True).click()
    page.get_by_text("Preview / Why this model?", exact=True).click()
    page.get_by_text("Selected: nvidia / preview-model", exact=True).wait_for()
    page.get_by_text("nvidia / preview-model — eligible", exact=True).click()
    page.get_by_role("region", name="Score contributions").wait_for()
    page.get_by_text("openrouter / <img src=x onerror=alert(1)> — rejected", exact=True).click()
    page.get_by_text("Fresh verified zero-price evidence is unavailable.", exact=True).wait_for()
    assert page.locator("img[src=x]").count() == 0
    assert _paths(page) == ['/overview', '/models']


def test_analytics_controls_detail_attempts_and_chart(page):
    _open(page, 'normal')
    page.get_by_role('tab', name='Analytics').click()
    page.get_by_role('button', name='Request #1', exact=True).wait_for()
    assert page.get_by_role('img', name='Hourly request timeline: success and error').count() == 1
    page.get_by_label('Provider', exact=True).select_option('nvidia')
    page.wait_for_function("window.__HARNESS_CALLS__.some(c => c.path.includes('provider=nvidia'))")
    page.get_by_label('Status', exact=True).select_option('error')
    page.wait_for_function("window.__HARNESS_CALLS__.some(c => c.path.includes('status=error'))")
    page.get_by_label('Sort requests').select_option('latency')
    page.wait_for_function("window.__HARNESS_CALLS__.some(c => c.path.includes('sort=latency'))")
    page.get_by_role('button', name='Next requests').click()
    page.get_by_role('button', name='Request #21', exact=True).wait_for()
    page.get_by_role('button', name='Request #21', exact=True).click()
    page.get_by_text('Attempt history', exact=True).wait_for()
    assert page.get_by_text('rate limit', exact=True).count() == 1
    assert page.get_by_role('cell', name='429', exact=True).count() == 1
    page.get_by_role('button', name='Back to Analytics').click()
    page.get_by_role('button', name='Request #21', exact=True).wait_for()
    page.get_by_role('button', name='Previous requests').click()
    page.get_by_role('button', name='Request #1', exact=True).wait_for()
    page.get_by_role('button', name='30d', exact=True).click()
    page.wait_for_function("window.__HARNESS_CALLS__.some(c => c.path.includes('range=30d'))")


def test_analytics_lifetime_preserves_unknown_tokens(page):
    _open(page, 'normal')
    page.get_by_role('tab', name='Analytics').click()
    page.get_by_text('Total requests: 25 · input: — · output: 0', exact=False).wait_for()


def test_analytics_status_breakdown_and_decided_success_rate(page):
    _open(page, 'normal')
    page.get_by_role('tab', name='Analytics').click()
    page.get_by_text('20 ok · 5 error · 0 canceled · 0 pending', exact=False).wait_for()
    page.get_by_text('share of decided requests (success + error)', exact=True).wait_for()


def test_scoped_circuit_states_are_distinct(page):
    _open(page,'circuits')
    page.get_by_role('tab',name='Models',exact=True).click()
    page.get_by_text('Rate limit observed; quota unknown',exact=True).wait_for()
    page.get_by_text('Selection reconsideration',exact=True).wait_for()
    page.get_by_text('Provider circuit open',exact=True).wait_for()
    page.get_by_text('Auth failed',exact=True).wait_for()


def test_analytics_sample_confidence_and_distinct_selection_metrics(page):
    _open(page, 'normal')
    page.get_by_role('tab', name='Analytics').click()
    page.get_by_role('heading', name=re.compile('^Operational scoring samples')).wait_for()
    page.get_by_role('cell', name='67%', exact=True).wait_for()
    page.get_by_role('cell', name='80.0%', exact=True).wait_for()
    page.get_by_role('cell', name='100 ms / 500 ms', exact=True).wait_for()
    page.get_by_text('nvidia / selected-model', exact=True).wait_for()
    page.get_by_role('heading', name=re.compile('^Selection distribution')).wait_for()
    page.get_by_text('Semantic quality: unknown.', exact=False).wait_for()
    page.get_by_label('Status', exact=True).select_option('error')
    page.wait_for_function("window.__HARNESS_CALLS__.some(c => c.path.includes('status=error'))")
    page.get_by_role('cell', name='67%', exact=True).wait_for()


def test_candidate_filters_keep_source_inventory_distinct(page):
    _open(page, 'normal')
    page.get_by_role('tab', name='Providers', exact=True).click()
    page.get_by_text('249 source candidates · 2 configured providers · 5 read-only discovery adapters', exact=True).wait_for()
    page.get_by_role('searchbox', name='Search provider candidates').fill('Trial example')
    page.get_by_text('Showing 1 of 249 candidate rows', exact=True).wait_for()
    page.get_by_label('Filter candidates by access class').select_option('TRIAL')
    page.get_by_text('Trial example', exact=True).wait_for()
    page.get_by_role('searchbox', name='Search provider candidates').fill('')
    page.get_by_label('Filter candidates by protocol').select_option('openai_compatible')
    page.get_by_label('Filter candidates by modality').select_option('chat')
    page.get_by_label('Filter candidates by jurisdiction').select_option('unknown')
    page.get_by_label('Filter candidates by auth condition').select_option('api_key_claim')
    page.get_by_text('Showing 1 of 249 candidate rows', exact=True).wait_for()
    assert page.locator('img[src=x]').count() == 0
    assert page.locator('a[href^="javascript:"]').count() == 0


def test_model_evidence_discloses_stale_unknown_quota_without_estimates(page):
    _open(page, 'normal')
    page.get_by_role('tab', name='Models', exact=True).click()
    page.get_by_text('Access and quota evidence', exact=True).first.click()
    page.get_by_text('Access evidence source', exact=True).wait_for()
    page.get_by_text('Quota: requests · unknown · source advertised', exact=False).wait_for()
    page.get_by_text('Token-equivalent estimate: unavailable', exact=False).first.wait_for()
    page.get_by_text('Access and quota evidence', exact=True).nth(1).click()
    page.get_by_text('TRIAL · stale_or_unverified', exact=False).wait_for()
    page.get_by_text('Source component prices (USD): request=0.02, image=0.03', exact=True).wait_for()
    assert page.get_by_text('Component prices per token', exact=False).count() == 0
    assert [c['method'] for c in _calls(page)] == ['GET', 'GET']


def test_cached_quota_states_and_no_billing_guarantee_or_poll(page):
    _open(page, 'normal')
    page.get_by_role('tab', name='Models', exact=True).click()
    for model_name in ("llama-3.3-70b-instruct", "nemotron-4-340b-instruct", "vendor/paid-pro-max"):
        row = page.locator(".ar-table tbody tr", has_text=model_name)
        row.get_by_text("Access and quota evidence", exact=True).click()
    page.get_by_text('Operational free access: healthy', exact=False).wait_for()
    page.get_by_text('Operational free access: exhausted', exact=False).wait_for()
    page.get_by_text('Operational free access: unknown', exact=False).wait_for()
    assert page.get_by_text('Billing stop: unverified. No-charge execution: unverified', exact=False).count() == 3
    page.get_by_role('link', name='Operational quota source').wait_for()
    assert page.get_by_text('Cached account quota: requests', exact=False).count() == 3
    assert _paths(page) == ['/overview', '/models']


def test_provider_cached_quota_is_readonly_and_honest(page):
    _open(page, 'normal')
    page.get_by_role('tab', name='Providers', exact=True).click()
    page.get_by_text('Quota: available, exhausted', exact=True).click()
    page.get_by_role('link', name='Cached quota source', exact=True).wait_for()
    page.get_by_text('Cached observations only; no polling or guaranteed billing stop.', exact=True).first.wait_for()
    assert _paths(page) == ['/overview', '/providers']


def test_readonly_keys_onboarding_search_prefill_and_disabled_actions(page):
    _open(page, 'normal')
    page.get_by_role('tab', name='Providers', exact=True).click()
    page.get_by_text('1 of 2 discovery integrations', exact=False).wait_for()
    page.get_by_role('button', name='Configure OpenRouter in Hermes', exact=True).click()
    assert page.get_by_label('Provider to configure through Hermes').input_value() == 'openrouter'
    assert page.get_by_role('link', name='Open official OpenRouter key page').get_attribute('href') == 'https://openrouter.ai/keys'
    page.get_by_label('Search connect provider').fill('NVIDIA')
    assert page.get_by_label('Provider to configure through Hermes').input_value() == 'nvidia'
    page.get_by_text('Do not paste a key into AutoRouter', exact=False).wait_for()
    page.get_by_label('Search credential providers').fill('NVIDIA')
    page.get_by_text('Showing 1 of 2 discovery integrations', exact=True).wait_for()
    page.get_by_text('NVIDIA NIM · Credential present, validity unknown', exact=True).click()
    assert page.get_by_role('button', name='Test key', exact=True).is_disabled()
    assert page.get_by_role('button', name='Remove key', exact=True).is_disabled()
    assert page.locator('input[type=password], textarea').count() == 0
    assert 'SHOULD_NEVER_RENDER' not in page.locator('body').inner_text()
    assert [c['method'] for c in _calls(page)] == ['GET', 'GET']


def test_keys_managed_unknown_issue_and_retry_states(page):
    _open(page, 'keys-managed')
    page.get_by_role('tab', name='Providers', exact=True).click()
    page.get_by_text('NVIDIA NIM · Credential present, validity unknown', exact=True).click()
    page.locator('#ar-credential-unavailable-nvidia').get_by_text('Managed by Hermes. Credential changes and tests are unavailable to AutoRouter.', exact=True).wait_for()
    _open(page, 'keys-unknown')
    page.get_by_role('tab', name='Providers', exact=True).click()
    page.get_by_label('Filter credential status').select_option('unknown')
    page.get_by_text('NVIDIA NIM · Presence unknown', exact=True).click()
    page.get_by_text('Observation status: permission_denied', exact=True).wait_for()
    _open(page, 'keys-issue')
    page.get_by_role('tab', name='Providers', exact=True).click()
    page.get_by_label('Filter credential status').select_option('issue')
    page.get_by_text('NVIDIA NIM · Credential present, validity unknown', exact=True).click()
    page.get_by_text('Provider authentication failure observed; this is not bound to the current credential.', exact=True).wait_for()
    _open(page, 'keys-unavailable')
    page.get_by_role('tab', name='Providers', exact=True).click()
    before = len(_calls(page))
    page.get_by_role('button', name='Retry credential presence', exact=True).click()
    page.wait_for_function('window.__HARNESS_CALLS__.length > ' + str(before))


def test_zero_outcome_health_is_not_claimed_healthy(page):
    _open(page, 'unobserved')
    page.get_by_role('tab', name='Models', exact=True).click()
    row = page.get_by_role('row').filter(has=page.get_by_text('llama-3.3-70b-instruct', exact=True))
    row.get_by_text('Not observed', exact=True).wait_for()
    assert row.get_by_text('Healthy', exact=True).count() == 0


def test_corrupt_health_does_not_claim_auth_failure_or_healthy(page):
    _open(page, 'health-invalid')
    page.get_by_role('tab', name='Models', exact=True).click()
    row = page.get_by_role('row').filter(has=page.get_by_text('llama-3.3-70b-instruct', exact=True))
    row.get_by_text('Health data unavailable', exact=True).wait_for()
    assert row.get_by_text('Auth failed', exact=True).count() == 0
    assert row.get_by_text('Healthy', exact=True).count() == 0


def test_invalid_health_appears_in_overview_and_provider_attention(page):
    _open(page, 'health-invalid')
    card = page.locator('.ar-stat').filter(has=page.get_by_text('Needs attention', exact=True))
    assert card.locator('.ar-stat__value').inner_text() == '1'
    assert 'health unavailable 1' in card.inner_text()
    page.get_by_role('tab', name='Providers', exact=True).click()
    row = page.get_by_role('row').filter(has=page.get_by_text('nvidia', exact=True))
    row.get_by_text('Health data unavailable', exact=True).wait_for()
    assert row.get_by_text('OK', exact=True).count() == 0
    row.get_by_text('1 needs attention', exact=True).wait_for()


def test_discovery_stages_remain_separate_from_candidate_and_entitlement_claims(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Providers").click()
    stages = page.get_by_role("region", name="discovery stages", exact=True)
    assert stages.locator("tbody tr").count() == 5
    row = stages.locator("tbody tr").filter(has_text="openrouter")
    assert row.locator("td").all_text_contents() == [
        "openrouter · discovery-capable", "yes", "2", "1",
        "Unknown — discovery is not inference entitlement"]
    assert "249 source candidates" in page.get_by_role("tabpanel").inner_text()


def test_five_provider_deep_link_preselects_safe_guidance(page):
    _open(page, 'five-providers&provider=gemini')
    assert page.get_by_role('tab', name='Providers', exact=True).get_attribute('aria-selected')=='true'
    assert page.get_by_label('Provider to configure through Hermes').input_value()=='gemini'
    assert page.get_by_label('Provider to configure through Hermes').locator('option').count()==5
    page.get_by_label('Search credential providers').fill('Mistral')
    page.get_by_text('Showing 1 of 5 discovery integrations',exact=True).wait_for()
    page.get_by_text('Mistral · Presence unknown',exact=True).click()
    assert page.get_by_role('button',name='Test key',exact=True).is_disabled()
    assert page.locator('input[type=password], textarea').count()==0
    page.get_by_text('Named connection slots: unavailable;',exact=False).wait_for()


def test_v1_free_only_is_mandatory_readonly_preference_boundary(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Settings").click()
    page.wait_for_selector("#ar-set-freeonly", timeout=5000)
    assert page.locator("#ar-set-freeonly").is_checked()
    assert page.locator("#ar-set-freeonly").is_disabled()
    assert "Mandatory in AutoRouter" in page.locator("[role=tabpanel]").inner_text()
    assert [call for call in _calls(page) if call["method"]=="PUT"] == []


def test_selection_contract_evidence_discloses_requirements_and_no_execution(page):
    _open(page,'selection-contract')
    page.get_by_role('tab',name='Models',exact=True).click()
    page.get_by_text('Preview / Why this model?',exact=True).click()
    page.get_by_text('Selection contract v1:',exact=False).wait_for()
    page.get_by_text('minimum context of 20,000',exact=False).wait_for()
    page.get_by_text('This recommendation grants no execution authority.',exact=False).wait_for()
    assert _paths(page)==['/overview','/models']


def test_explicit_task_profile_disclosure_is_accessible_and_readonly(page):
    _open(page, 'task-profile')
    page.get_by_role('tab', name='Models', exact=True).click()
    page.get_by_text('Preview / Why this model?', exact=True).click()
    page.get_by_text('Explicit task profile: Coding v1.', exact=False).wait_for()
    page.get_by_text('Semantic competence is unknown.', exact=False).wait_for()
    assert _paths(page) == ['/overview', '/models']
    assert not page.locator('[role=tabpanel] img').count()


def test_task_profile_controls_only_request_readonly_preview(page):
    _open(page, 'normal')
    page.get_by_role('tab', name='Models', exact=True).click()
    page.get_by_text('Preview / Why this model?', exact=True).click()
    page.get_by_role('combobox', name='Explicit task profile').select_option('coding')
    page.get_by_role('checkbox', name='Workload requires tools').check()
    page.get_by_role('button', name='Preview task profile', exact=True).click()
    page.get_by_role('status').get_by_text('Preview / Why this model?', exact=True).wait_for()
    calls=_calls(page)
    assert [_path_b(c) for c in calls] == ['/overview','/models','/task-profiles','/selection/preview']
    assert calls[-1]['method']=='POST'
    payload=__import__('json').loads(calls[-1]['body'])['selection_policy']
    assert payload['task_requirements']['profile']['id']=='coding'
    assert payload['task_requirements']['required_capabilities']=={'tools':'required'}
    assert not [c for c in calls if c['method']=='PUT']


def test_versioned_evidence_report_has_readonly_actionable_disclosure(page):
    _open(page, 'evidence-report')
    page.get_by_role('tab',name='Models',exact=True).click()
    page.get_by_text('Preview / Why this model?',exact=True).click()
    page.get_by_text('Evidence report v1:',exact=False).wait_for()
    page.get_by_text('Unknown evidence is not zero or healthy.',exact=False).wait_for()
    page.get_by_text('Next steps: deliberate hermes handoff',exact=True).wait_for()
    assert _paths(page)==['/overview','/models']


def test_selected_model_has_explanation_even_outside_considered_display(page):
    _open(page,'truncated-winner')
    page.get_by_role('tab',name='Models',exact=True).click()
    page.get_by_text('Preview / Why this model?',exact=True).click()
    page.get_by_text('nvidia / z-winner — eligible',exact=True).click()
    page.get_by_text('Total: 0.900',exact=False).wait_for()
    assert _paths(page)==['/overview','/models']


def test_observed_coverage_discloses_confidence_and_unknown_account_authority(page):
    _open(page, 'observation-coverage')
    page.get_by_role('tab',name='Models',exact=True).click()
    page.get_by_text('Preview / Why this model?',exact=True).click()
    page.get_by_text('nvidia / preview-model — eligible',exact=True).click()
    page.get_by_text('Operational evidence v1: sample_limited',exact=False).wait_for()
    page.get_by_text('account attribution unknown',exact=False).wait_for()
    page.get_by_text('Current availability and semantic quality are unknown.',exact=False).wait_for()
    assert _paths(page)==['/overview','/models']


def test_manual_handoff_requires_confirmation_and_never_claims_application(page):
    _open(page,'normal')
    page.get_by_role('tab',name='Models',exact=True).click()
    page.get_by_text('Preview / Why this model?',exact=True).click()
    button=page.get_by_role('button',name='Prepare manual handoff',exact=True)
    assert button.is_disabled()
    page.get_by_role('checkbox',name='Confirm manual handoff preparation').check()
    button.click()
    page.get_by_text('hermes chat --provider nvidia --model preview-model',exact=True).wait_for()
    page.get_by_text('No model was applied or executed.',exact=False).wait_for()
    calls=_calls(page)
    assert [_path_b(c) for c in calls] == ['/overview','/models','/handoff/manual']
    payload=__import__('json').loads(calls[-1]['body'])
    assert payload['confirmed'] is True
    assert payload['selection']['provider']=='nvidia' and payload['selection']['model']=='preview-model'
    assert not [c for c in calls if c['method']=='PUT']


@pytest.mark.parametrize('profile',['general','coding','fast-response'])
def test_profile_handoff_resends_original_request_without_output_fields(page,profile):
    _open(page,'normal')
    page.get_by_role('tab',name='Models',exact=True).click()
    page.get_by_text('Preview / Why this model?',exact=True).click()
    page.get_by_role('combobox',name='Explicit task profile').select_option(profile)
    page.get_by_role('button',name='Preview task profile',exact=True).click()
    result=page.locator('[role="status"] > details')
    result.get_by_text('Preview / Why this model?',exact=True).click()
    result.get_by_role('checkbox',name='Confirm manual handoff preparation').check()
    result.get_by_role('button',name='Prepare manual handoff',exact=True).click()
    result.get_by_text('hermes chat --provider nvidia --model preview-model',exact=True).wait_for()
    calls=_calls(page)
    preview=__import__('json').loads(next(c['body'] for c in calls if c['path']=='/selection/preview'))['selection_policy']
    handoff=__import__('json').loads(next(c['body'] for c in calls if c['path']=='/handoff/manual'))['selection_policy']
    assert handoff==preview
    assert handoff['task_requirements']['profile']['id']==profile
    assert 'semantic_quality' not in handoff['task_requirements']


def test_explanation_without_original_requirements_cannot_enable_handoff(page):
    _open(page,'selection-contract')
    page.get_by_role('tab',name='Models',exact=True).click()
    page.get_by_text('Preview / Why this model?',exact=True).click()
    page.get_by_text('Original requirements unavailable.',exact=False).wait_for()
    assert page.get_by_role('checkbox',name='Confirm manual handoff preparation').is_disabled()
    assert page.get_by_role('button',name='Prepare manual handoff',exact=True).is_disabled()


def test_health_guidance_reconsideration_is_readonly_and_not_a_retry(page):
    _open(page,'health-guidance')
    page.get_by_role('tab',name='Models',exact=True).click()
    page.get_by_text('Preview / Why this model?',exact=True).click()
    page.get_by_text('nvidia / preview-model — rejected',exact=True).click()
    page.get_by_text('Observed health: authentication',exact=False).wait_for()
    page.get_by_text('account binding unknown',exact=False).wait_for()
    page.get_by_text('not provider retry authorization',exact=False).wait_for()
    page.get_by_role('button',name='Reconsider cached health',exact=True).click()
    page.wait_for_timeout(100)
    calls=_calls(page)
    assert [_path_b(c) for c in calls] == ['/overview','/models','/models']
    assert not [c for c in calls if c['method'] in ('POST','PUT')]


def test_verified_allowance_denial_precedes_half_open_reconsideration_badge(page):
    _open(page,'verified-quota-circuit')
    page.get_by_role('tab',name='Models',exact=True).click()
    page.get_by_text('Verified allowance exhausted',exact=True).wait_for()
    assert page.get_by_text('Selection reconsideration',exact=True).count()==0


def test_first_use_guide_is_explicit_accessible_and_readonly(page):
    _open(page,'normal')
    page.get_by_role('button',name='Start guided setup',exact=True).click()
    page.get_by_role('list',name='First-use steps').wait_for()
    page.get_by_text('Completion covers recommendation evidence only',exact=False).wait_for()
    page.get_by_text('authentication unverified',exact=False).wait_for()
    link=page.get_by_role('link',name='Official Hermes plugin setup',exact=True)
    assert link.get_attribute('rel')=='noopener noreferrer'
    page.get_by_role('button',name='Recheck setup evidence',exact=True).click()
    page.wait_for_timeout(100)
    assert _paths(page)==['/overview','/first-use','/first-use']
    assert all(c['method']=='GET' for c in _calls(page))


def test_first_use_guide_routes_to_existing_native_tabs(page):
    _open(page,'normal')
    page.get_by_role('button',name='Start guided setup',exact=True).click()
    page.get_by_role('button',name='Open providers',exact=True).click()
    assert page.get_by_role('tab',name='Providers',exact=True).get_attribute('aria-selected')=='true'
    assert _paths(page)==['/overview','/first-use','/providers']


def test_first_use_guide_remains_available_before_database_initialization(page):
    _open(page,'empty')
    page.get_by_role('button',name='Start guided setup',exact=True).click()
    page.get_by_role('list',name='First-use steps').wait_for()
    assert not [c for c in _calls(page) if c['method']!='GET']


@pytest.mark.parametrize("width", [390, 768, 1440])
def test_task_draft_and_original_preview_survive_native_tab_navigation(page, width, tmp_path):
    page.set_viewport_size({"width": width, "height": 900})
    _open(page, "normal")
    page.get_by_role("tab", name="Models", exact=True).click()
    page.get_by_text("Preview / Why this model?", exact=True).click()
    page.get_by_label("Explicit task profile").select_option("coding")
    page.get_by_label("Workload requires tools", exact=True).check()
    page.get_by_role("button", name="Preview task profile", exact=True).click()
    page.get_by_role("status", name="Explicit task preview result").get_by_text("Selected: nvidia / preview-model", exact=True).wait_for(state="attached")
    page.get_by_role("tab", name="Providers", exact=True).click()
    page.get_by_role("tab", name="Models", exact=True).click()
    page.get_by_text("Preview / Why this model?", exact=True).first.click()
    assert page.get_by_label("Explicit task profile").input_value() == "coding"
    assert page.get_by_label("Workload requires tools", exact=True).is_checked()
    assert page.get_by_role("status", name="Explicit task preview result").get_by_text("Selected: nvidia / preview-model", exact=True).count() == 1
    assert page.get_by_label("Confirm manual handoff preparation").last.is_checked() is False
    assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
    assert not [c for c in _calls(page) if c['path']=='/execution/prepare']
    control = page.get_by_label("Explicit task profile")
    control.scroll_into_view_if_needed()
    assert control.is_visible()
    box = control.bounding_box()
    assert box and 0 <= box['x'] and box['x'] + box['width'] <= width
    assert 0 <= box['y'] and box['y'] + box['height'] <= 900
    page.screenshot(path=str(tmp_path / ("workflow-" + str(width) + ".png")))


@pytest.mark.parametrize("late_ok", [True, False])
@pytest.mark.parametrize("invalidate", ["workload", "refresh"])
def test_changed_workload_discards_late_preview_response(page, late_ok, invalidate):
    _open(page, "normal")
    page.evaluate("""()=>{const original=window.__AUTOROUTER_FETCH__;window.__AUTOROUTER_FETCH__=(p,o)=>{const r=original(p,o);if(p==='/selection/preview') return new Promise((resolve,reject)=>{window.__releasePreview=ok=>ok?resolve(r):reject(new Error('stale preview failure'))});return r}}""")
    page.get_by_role("tab", name="Models", exact=True).click()
    page.get_by_text("Preview / Why this model?", exact=True).click()
    page.get_by_role("button", name="Preview task profile", exact=True).click()
    page.wait_for_function("typeof window.__releasePreview === 'function'")
    if invalidate == "workload":
        page.get_by_label("Explicit task profile").select_option("coding")
    else:
        page.get_by_role("button", name="Refresh", exact=True).click()
        page.get_by_label("Search models").wait_for()
        page.get_by_text("Preview / Why this model?", exact=True).first.click()
    page.evaluate("ok=>window.__releasePreview(ok)", late_ok)
    page.get_by_role("button", name="Preview task profile", exact=True).wait_for()
    page.wait_for_timeout(50)
    assert page.get_by_role("status", name="Explicit task preview result").get_by_text("Selected: nvidia / preview-model", exact=True).count()==0
    assert page.get_by_text("Task preview unavailable;", exact=False).count()==0
    assert page.evaluate("window.__HARNESS_ERRORS__")==[]


def test_settings_draft_survives_tab_change_and_reset_remains_explicit(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Settings", exact=True).click()
    page.locator("#ar-set-policy").select_option("fastest")
    page.locator("#ar-set-cooldown").fill("123")
    page.locator("#ar-set-providers").fill("")
    page.get_by_role("tab", name="Models", exact=True).click()
    page.get_by_role("tab", name="Settings", exact=True).click()
    assert page.locator("#ar-set-policy").input_value()=="fastest"
    assert page.locator("#ar-set-cooldown").input_value()=="123"
    assert page.locator("#ar-set-providers").input_value()==""
    assert not [c for c in _calls(page) if c['method']=='PUT']
    page.get_by_role("button", name="Reset", exact=True).click()
    page.get_by_role("tab", name="Models", exact=True).click()
    page.get_by_role("tab", name="Settings", exact=True).click()
    assert page.locator("#ar-set-providers").input_value()=="nvidia, openrouter"


@pytest.mark.parametrize("mode", ["normal", "partial"])
def test_settings_write_invalidates_decision_views_even_after_partial_save(page, mode):
    _open(page, mode)
    page.get_by_role("tab", name="Models", exact=True).click()
    page.get_by_role("tab", name="Settings", exact=True).click()
    page.locator("#ar-set-policy").select_option("fastest")
    page.locator("#ar-set-cooldown").fill("123")
    page.get_by_role("button", name="Save changes", exact=True).click()
    if mode == "partial":
        page.get_by_text("Partial save — not all changes were applied.", exact=True).wait_for()
        assert page.locator("#ar-set-policy").input_value()=="fastest"
        assert page.locator("#ar-set-cooldown").input_value()=="123"
    else:
        page.get_by_text("Settings saved.", exact=False).wait_for()
    page.get_by_role("tab", name="Models", exact=True).click()
    page.get_by_label("Search models").wait_for()
    assert len([c for c in _calls(page) if _path_b(c)=='/models'])==2


def test_provider_inspect_uses_existing_model_filter_without_mutation(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Providers", exact=True).click()
    page.get_by_role("button", name="Inspect nvidia models", exact=True).click()
    assert page.get_by_label("Filter by provider", exact=True).input_value()=="nvidia"
    assert page.get_by_role("tab", name="Models", exact=True).get_attribute("aria-selected")=="true"
    assert all(c['method']=='GET' for c in _calls(page))


def test_late_analytics_response_does_not_replace_newer_filter(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Analytics", exact=True).click()
    page.get_by_label("Status", exact=True).wait_for()
    page.evaluate("""()=>{const original=window.__AUTOROUTER_FETCH__;let held=false;window.__AUTOROUTER_FETCH__=(p,o)=>{const r=original(p,o);if(p.includes('status=error')&&!held){held=true;const stale=Promise.resolve(r).then(payload=>{payload.recent_requests[0].model='outdated-response';return payload});return new Promise(resolve=>{window.__releaseAnalytics=()=>resolve(stale)})}return r}}""")
    page.get_by_label("Status", exact=True).select_option("error")
    page.wait_for_function("typeof window.__releaseAnalytics === 'function'")
    page.get_by_role("button", name="Refresh", exact=True).click()
    page.get_by_label("Status", exact=True).wait_for()
    assert page.get_by_text("test-model", exact=True).count() > 0
    page.evaluate("window.__releaseAnalytics()")
    page.wait_for_timeout(100)
    assert page.get_by_text("outdated-response", exact=True).count()==0
    assert page.get_by_label("Status", exact=True).input_value()=="error"
    assert page.evaluate("window.__HARNESS_ERRORS__")==[]


def test_request_trace_discloses_missing_apply_and_unknown_usage(page, tmp_path):
    _open(page, "normal")
    page.get_by_role("tab", name="Analytics", exact=True).click()
    page.get_by_role("button", name="Request #1", exact=True).click()
    page.get_by_role("heading", name=re.compile("^Observed request lifecycle")).wait_for()
    page.get_by_text("Decision/application correlation unavailable", exact=True).wait_for()
    page.get_by_text("Unavailable", exact=True).wait_for()
    page.get_by_text("Observed: 0", exact=True).wait_for()
    page.get_by_text("Timestamp source: persisted event time; host versus ingestion origin not recorded", exact=False).wait_for()
    assert page.get_by_role("button", name="Apply", exact=True).count()==0
    assert all(c['method']=='GET' for c in _calls(page))
    page.get_by_role("heading", name=re.compile("^Observed request lifecycle")).scroll_into_view_if_needed()
    page.screenshot(path=str(tmp_path / "request-trace.png"))


@pytest.mark.parametrize("mode", ["normal", "partial"])
@pytest.mark.parametrize("tab,path", [("Models", "/models"), ("Providers", "/providers"), ("Overview", "/overview"), ("Analytics", "/analytics")])
def test_delayed_settings_save_reloads_new_active_tab(page, mode, tab, path):
    _open(page, mode)
    page.get_by_role("tab", name="Settings", exact=True).click()
    page.locator("#ar-set-policy").select_option("fastest")
    page.locator("#ar-set-cooldown").fill("123")
    page.evaluate("""()=>{const base=window.__AUTOROUTER_FETCH__;window.__AUTOROUTER_FETCH__=(p,o)=>{const r=base(p,o);if(o&&o.method==='PUT') return new Promise((resolve,reject)=>{Promise.resolve(r).then(v=>{window.__releaseSave=()=>resolve(v)},e=>{window.__releaseSave=()=>reject(e)})});return r}}""")
    page.get_by_role("button", name="Save changes", exact=True).click()
    page.wait_for_function("typeof window.__releaseSave==='function'")
    page.get_by_role("tab", name=tab, exact=True).click()
    def ready():
        if tab=="Models": page.get_by_label("Search models").wait_for()
        elif tab=="Providers": page.get_by_role("region",name="configured providers",exact=True).wait_for()
        elif tab=="Analytics": page.get_by_label("Status",exact=True).wait_for()
        else: page.get_by_role("heading", name=re.compile("^Recent selection activity")).wait_for()
    ready()
    before=len([c for c in _calls(page) if c['path'].split('?')[0]==path])
    page.evaluate("window.__releaseSave()")
    page.wait_for_function("([p,n])=>window.__HARNESS_CALLS__.filter(c=>c.path.split('?')[0]===p).length>n",arg=[path,before])
    ready()
    assert page.get_by_role("tab", name=tab,exact=True).get_attribute("aria-selected")=="true"
    assert len([c for c in _calls(page) if c['method']=='PUT'])==1


@pytest.mark.parametrize("old_ok,new_ok", [(True,True),(False,True),(True,False),(False,False)])
@pytest.mark.parametrize("invalidate", [False,True])
def test_latest_tab_request_remains_authoritative_for_all_completion_outcomes(page,old_ok,new_ok,invalidate):
    _open(page,"normal")
    page.evaluate("""()=>{
      const base=window.__AUTOROUTER_FETCH__;
      window.__heldTabs=[];
      window.__AUTOROUTER_FETCH__=(p,o)=>{
        const response=base(p,o);
        if(p.split('?')[0]!=='/models') return response;
        return new Promise((resolve,reject)=>{
          Promise.resolve(response).then(data=>{
            const payload=JSON.parse(JSON.stringify(data));
            const index=window.__heldTabs.length;
            window.__heldTabs.push((ok)=>{
              if(ok){payload.models[0].model=index===0?'old-tab-result':'new-tab-result';resolve(payload)}
              else reject(new Error(index===0?'old request failed':'new request failed'));
            });
          },reject);
        });
      };
    }""")
    page.get_by_role("tab",name="Models",exact=True).click()
    page.wait_for_function("window.__heldTabs.length===1")
    if invalidate:
        page.get_by_role("tab",name="Settings",exact=True).click()
        page.locator("#ar-set-policy").select_option("fastest")
        page.get_by_role("button",name="Save changes",exact=True).click()
        page.get_by_text("Settings saved.",exact=False).wait_for()
        page.get_by_role("tab",name="Models",exact=True).click()
    else:
        page.get_by_role("button",name="Refresh",exact=True).click()
    page.wait_for_function("window.__heldTabs.length===2")
    page.evaluate("ok=>window.__heldTabs[1](ok)",new_ok)
    page.get_by_text("new-tab-result" if new_ok else "new request failed",exact=new_ok).first.wait_for()
    before=page.get_by_role("tabpanel").inner_text()
    page.evaluate("ok=>window.__heldTabs[0](ok)",old_ok)
    page.wait_for_timeout(100)
    assert page.get_by_role("tabpanel").inner_text()==before
    assert "old-tab-result" not in before and "old request failed" not in before
    assert page.evaluate("window.__HARNESS_ERRORS__")==[]


@pytest.mark.parametrize("field,value,message", [
    ("ar-set-cooldown", "0", "Cooldown must be an integer"),
    ("ar-set-cooldown", "1.5", "Cooldown must be an integer"),
    ("ar-set-providers", "bad/provider", "Invalid provider id"),
])
def test_invalid_settings_field_is_identified_and_described(page, field, value, message):
    _open(page, "normal")
    page.get_by_role("tab", name="Settings", exact=True).click()
    control = page.locator("#" + field)
    control.fill(value)
    page.get_by_role("button", name="Save changes", exact=True).click()
    page.locator(".ar-form-errors").filter(has_text=message).wait_for(timeout=3000)
    assert control.get_attribute("aria-invalid") == "true"
    description = control.get_attribute("aria-describedby")
    assert description and message in page.locator("#" + description).inner_text()
    assert control.evaluate("e=>e===document.activeElement")
    assert not [c for c in _calls(page) if c["method"] == "PUT"]
    page.get_by_role("button", name="Reset", exact=True).click()
    assert control.get_attribute("aria-invalid") is None
    assert control.get_attribute("aria-describedby") is None


def test_cooldown_numeric_input_is_not_truncated(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Settings", exact=True).click()
    page.get_by_label("Cooldown (seconds)").fill("1e2")
    page.get_by_role("button", name="Save changes", exact=True).click()
    page.get_by_text("Settings saved.", exact=False).wait_for()
    puts = [c for c in _calls(page) if c["method"] == "PUT"]
    assert len(puts) == 1
    assert json.loads(puts[0]["body"]) == {"updates": {"cooldown_seconds": 100}}


@pytest.mark.parametrize("unknown_key", ["constructor", "__proto__"])
def test_partial_save_unknown_field_does_not_misidentify_controls(page, unknown_key):
    _open(page, "partial")
    errors = []
    page.on("pageerror", lambda error: errors.append(str(error)))
    page.evaluate("""key=>{
      const original=window.__AUTOROUTER_FETCH__;
      window.__AUTOROUTER_FETCH__=(path,options)=>original(path,options).catch(error=>{
        error.body.detail.failed=JSON.parse('{"'+key+'":"unsupported field"}');
        throw error;
      });
    }""", unknown_key)
    page.get_by_role("tab", name="Settings", exact=True).click()
    page.get_by_label("Cooldown (seconds)").fill("120")
    page.get_by_role("button", name="Save changes", exact=True).click()
    page.get_by_text("Partial save — not all changes were applied.", exact=True).wait_for()
    assert page.locator('[aria-invalid="true"]').count() == 0
    assert not errors


# ---------------------------------------------------------------------------
# Overview — Routing control card
# ---------------------------------------------------------------------------

def test_routing_card_renders_with_controls_and_decision(page):
    _open(page, "normal")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    assert page.locator("#ar-routing-enabled").is_checked()
    assert page.locator("#ar-routing-strategy").input_value() == "auto"
    assert page.locator("#ar-routing-minctx").input_value() == "8192"
    assert page.locator("#ar-routing-tools").is_checked()
    assert page.locator("#ar-routing-include").input_value() == "nvidia/llama-3.3-70b-instruct"
    assert page.locator("#ar-routing-exclude").input_value() == "openrouter/vendor/paid-pro-max"
    page.get_by_text("llama-3.3-70b-instruct", exact=False).first.wait_for()
    page.get_by_text("auto", exact=False).first.wait_for()


def test_routing_card_save_sends_only_changed_keys(page):
    _open(page, "normal")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    page.uncheck("#ar-routing-tools")
    page.select_option("#ar-routing-strategy", "reliable")
    page.get_by_role("button", name="Save routing").click()
    page.wait_for_selector("text=Routing saved", timeout=5000)
    puts = [c for c in _calls(page) if c["method"] == "PUT"]
    assert len(puts) == 1
    assert puts[0]["path"] == "/settings"
    assert json.loads(puts[0]["body"]) == {"updates": {"requires_tools": False, "policy": "reliable"}}


def test_routing_card_chat_routing_toggle_is_sent(page):
    _open(page, "normal")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    page.uncheck("#ar-routing-enabled")
    page.get_by_role("button", name="Save routing").click()
    page.wait_for_selector("text=Routing saved", timeout=5000)
    puts = [c for c in _calls(page) if c["method"] == "PUT"]
    assert len(puts) == 1
    assert json.loads(puts[0]["body"]) == {"updates": {"enable_chat_router": False}}


def test_routing_card_rejects_invalid_model_keys_without_put(page):
    _open(page, "normal")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    page.fill("#ar-routing-exclude", "NOT A KEY!!")
    page.get_by_role("button", name="Save routing").click()
    page.wait_for_selector("#ar-routing-errors", timeout=5000)
    page.wait_for_function("() => document.querySelector('#ar-routing-errors').textContent.length > 0", timeout=5000)
    assert [c for c in _calls(page) if c["method"] == "PUT"] == []


def test_routing_card_include_exclude_roundtrip(page):
    _open(page, "normal")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    page.fill("#ar-routing-include", "nvidia/llama-3.3-70b-instruct, openrouter/foo:free")
    page.fill("#ar-routing-exclude", "nvidia/nemotron-4-340b-instruct")
    page.get_by_role("button", name="Save routing").click()
    page.wait_for_selector("text=Routing saved", timeout=5000)
    puts = [c for c in _calls(page) if c["method"] == "PUT"]
    assert len(puts) == 1
    body = json.loads(puts[0]["body"])
    assert body["updates"]["model_include"] == ["nvidia/llama-3.3-70b-instruct", "openrouter/foo:free"]
    assert body["updates"]["model_exclude"] == ["nvidia/nemotron-4-340b-instruct"]


def test_routing_card_min_context_validation_blocks_save(page):
    _open(page, "normal")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    page.fill("#ar-routing-minctx", "100")
    page.get_by_role("button", name="Save routing").click()
    page.wait_for_function("() => document.querySelector('#ar-routing-errors').textContent.length > 0", timeout=5000)
    assert [c for c in _calls(page) if c["method"] == "PUT"] == []


def test_routing_card_shows_inactive_state_without_decision_in_empty_mode(page):
    _open(page, "empty")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    assert not page.locator("#ar-routing-enabled").is_checked()
    assert page.get_by_text("No routing decision recorded yet", exact=False).is_visible()


def test_routing_card_provider_allowlist_and_cooldown_roundtrip(page):
    _open(page, "normal")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    page.fill("#ar-routing-providers", "nvidia")
    page.fill("#ar-routing-cooldown", "120")
    page.get_by_role("button", name="Save routing").click()
    page.wait_for_selector("text=Routing saved", timeout=5000)
    puts = [c for c in _calls(page) if c["method"] == "PUT"]
    assert len(puts) == 1
    body = json.loads(puts[0]["body"])
    assert body["updates"]["providers"] == ["nvidia"]
    assert body["updates"]["cooldown_seconds"] == 120


def test_routing_card_invalid_provider_blocks_save(page):
    _open(page, "normal")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    page.fill("#ar-routing-providers", "NOT A PROVIDER!!")
    page.get_by_role("button", name="Save routing").click()
    page.wait_for_function("() => document.querySelector('#ar-routing-errors').textContent.length > 0", timeout=5000)
    assert [c for c in _calls(page) if c["method"] == "PUT"] == []


def test_routing_card_cooldown_bounds_block_save(page):
    _open(page, "normal")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    page.fill("#ar-routing-cooldown", "0")
    page.get_by_role("button", name="Save routing").click()
    page.wait_for_function("() => document.querySelector('#ar-routing-errors').textContent.length > 0", timeout=5000)
    assert [c for c in _calls(page) if c["method"] == "PUT"] == []


def test_routing_card_shows_configured_and_runtime_status(page):
    _open(page, "normal")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    assert page.get_by_text("Configured: enabled", exact=False).is_visible()
    assert page.get_by_text("active in this process", exact=True).is_visible()


def test_routing_card_restart_required_state(page):
    _open(page, "restart-required")
    page.wait_for_selector("#ar-routing-enabled", timeout=5000)
    assert page.get_by_text("restart required", exact=True).is_visible()
    assert page.get_by_text("is not active in this process", exact=False).is_visible()
# ---------------------------------------------------------------------------
# Models tab — catalog refresh control and sorting
# ---------------------------------------------------------------------------

def test_refresh_catalog_button_calls_endpoint_and_toasts(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("#ar-models-search", timeout=5000)
    page.get_by_role("button", name="Refresh catalog").click()
    page.locator(".ar-toast--visible", has_text="Catalog refreshed").wait_for()
    refresh_calls = [c for c in _calls(page) if c["method"] == "POST" and c["path"] == "/models/refresh"]
    assert len(refresh_calls) == 1


def test_sort_select_reorders_rows_consistently(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("#ar-models-sort", timeout=5000)
    first_default = page.locator(".ar-table tbody tr td .ar-mono").first.text_content()
    page.select_option("#ar-models-sort", "context_desc")
    page.wait_for_function("() => document.querySelector('.ar-table tbody tr td .ar-mono').textContent.indexOf('paid-pro-max') >= 0 || document.querySelector('.ar-table tbody tr td .ar-mono').textContent.length > 0", timeout=5000)
    first_ctx = page.locator(".ar-table tbody tr td .ar-mono").first.text_content()
    assert first_ctx != first_default or first_ctx is not None
    page.select_option("#ar-models-sort", "eligible")
    eligible_first = page.locator(".ar-table tbody tr td .ar-mono").first.text_content()
    assert eligible_first is not None
    page.select_option("#ar-models-sort", "provider")
    assert page.locator(".ar-table tbody tr td .ar-mono").first.text_content() == first_default


def test_sort_by_eligibility_puts_eligible_models_first(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("#ar-models-sort", timeout=5000)
    page.select_option("#ar-models-sort", "eligible")
    first_row = page.locator(".ar-table tbody tr").first
    assert "Eligible" in first_row.text_content()


def test_health_column_shows_observed_latency(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector("#ar-models-search", timeout=5000)
    page.wait_for_selector("text=Latency", timeout=5000)


def test_historical_failures_are_labeled_as_historical_not_live(page):
    _open(page, "historical-failures")
    page.get_by_role("tab", name="Analytics").click()
    page.wait_for_selector("text=Historical evidence only.", timeout=5000)
    # The four recorded attempts stay visible with absolute timestamps.
    page.get_by_text("openrouter / autorouter/auto-free").first.wait_for()
    # Insufficient-sample framing replaces fabricated reliability/confidence.
    page.get_by_text("insufficient (n<10)", exact=False).wait_for()
    page.get_by_text("not estimated", exact=True).wait_for()
    # The success-rate card is annotated as a small historical sample, not a live rate.
    page.get_by_text("historical review evidence, not a current signal", exact=False).wait_for()
    # The banner never implies success happened.
    assert page.locator(".ar-toast--visible").count() == 0


# ---------------------------------------------------------------------------
# Per-model inclusion toggles (issue #108)
# ---------------------------------------------------------------------------

def _switch(page, name):
    return page.get_by_role("switch", name=name)


def test_preference_switch_renders_with_accessible_state(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    on_switch = _switch(page, "Enable nvidia/llama-3.3-70b-instruct in AutoRouter")
    assert on_switch.get_attribute("aria-checked") == "true"
    assert on_switch.get_attribute("aria-label") == "Enable nvidia/llama-3.3-70b-instruct in AutoRouter"
    off_switch = _switch(page, "Enable openrouter/vendor/paid-pro-max in AutoRouter")
    assert off_switch.get_attribute("aria-checked") == "false"
    assert page.locator("text=disabled by you").count() >= 1


def test_preference_toggle_posts_and_refreshes(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    _switch(page, "Enable nvidia/llama-3.3-70b-instruct in AutoRouter").click()
    page.wait_for_function(
        "window.__HARNESS_CALLS__.some(c => c.method === 'POST' && c.path === '/models/preference')",
        timeout=5000,
    )
    posts = [c for c in _calls(page) if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert len(posts) == 1
    body = json.loads(posts[0]["body"])
    assert body["toggles"] == [{"provider": "nvidia", "model": "llama-3.3-70b-instruct", "enabled": False}]
    assert body["base"]
    # the re-fetch keeps the page and reflects the new state
    page.wait_for_function(
        "window.__HARNESS_CALLS__.filter(c => c.path.startsWith('/models?')).length >= 2",
        timeout=5000,
    )
    assert _switch(page, "Enable nvidia/llama-3.3-70b-instruct in AutoRouter").get_attribute("aria-checked") == "false"
    assert "3 enabled / 2 off" in page.locator(".ar-count").inner_text()


def test_preference_toggle_on_re_enables(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    _switch(page, "Enable openrouter/vendor/paid-pro-max in AutoRouter").click()
    page.wait_for_function(
        "window.__HARNESS_CALLS__.some(c => c.method === 'POST' && c.path === '/models/preference')",
        timeout=5000,
    )
    page.wait_for_function(
        "window.__HARNESS_CALLS__.filter(c => c.path.startsWith('/models?')).length >= 2",
        timeout=5000,
    )
    assert _switch(page, "Enable openrouter/vendor/paid-pro-max in AutoRouter").get_attribute("aria-checked") == "true"
    assert "5 enabled / 0 off" in page.locator(".ar-count").inner_text()


def test_bulk_disable_then_enable_page(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    page.get_by_role("button", name="Disable page").click()
    page.wait_for_function(
        "window.__HARNESS_CALLS__.some(c => c.method === 'POST' && c.path === '/models/preference')",
        timeout=5000,
    )
    page.wait_for_selector("text=No model is enabled", timeout=5000)
    posts = [c for c in _calls(page) if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert len(json.loads(posts[-1]["body"])["toggles"]) == 5
    switches = page.locator('[data-model-toggle]')
    assert switches.count() == 5
    for i in range(switches.count()):
        assert switches.nth(i).get_attribute("aria-checked") == "false"
    page.get_by_role("button", name="Enable page").click()
    page.wait_for_function(
        "window.__HARNESS_CALLS__.filter(c => c.method === 'POST' && c.path === '/models/preference').length >= 2",
        timeout=5000,
    )
    page.wait_for_selector("text=5 enabled", timeout=5000)


def test_preference_filter_enabled_only_shows_only_enabled(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    page.select_option("#ar-models-preference", "off")
    page.wait_for_function(
        "window.__HARNESS_CALLS__.some(c => c.path.indexOf('preference=off') >= 0)",
        timeout=5000,
    )
    page.wait_for_function(
        "document.querySelectorAll('.ar-table-wrap[aria-label=' + JSON.stringify('discovered models') + '] tbody tr').length === 1",
        timeout=5000,
    )
    rows = page.get_by_role("region", name="discovered models", exact=True).locator("tbody tr")
    assert rows.count() == 1
    assert "paid-pro-max" in rows.first.inner_text()


def test_preference_filter_free_models_unaffected_by_cost(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    page.select_option("#ar-models-preference", "on")
    page.wait_for_function(
        "window.__HARNESS_CALLS__.some(c => c.path.indexOf('preference=on') >= 0)",
        timeout=5000,
    )
    page.wait_for_function(
        "document.querySelectorAll('.ar-table-wrap[aria-label=' + JSON.stringify('discovered models') + '] tbody tr').length === 4",
        timeout=5000,
    )
    assert page.get_by_role("region", name="discovered models", exact=True).locator("tbody tr").count() == 4

def test_bulk_disable_rejected_atomically_for_catalog_with_invalid_row(page):
    _open(page, "hostile")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    page.get_by_role("button", name="Disable page").click()
    page.wait_for_function(
        "window.__HARNESS_CALLS__.some(c => c.method === 'POST' && c.path === '/models/preference')",
        timeout=5000,
    )
    page.wait_for_selector("text=invalid provider/model", timeout=5000)
    # nothing was persisted — the fixture stays at its default preference
    posts = [c for c in _calls(page) if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert len(posts) == 1
    assert True
    assert _switch(page, "Enable nvidia/llama-3.3-70b-instruct in AutoRouter").get_attribute("aria-checked") == "true"


# ---------------------------------------------------------------------------
# Preference conflict handling (dispatch #111): a 409 re-fetches authoritative
# state and never blindly replays when the mode changed underneath us.
# ---------------------------------------------------------------------------

def test_conflict_mode_change_never_replays_and_shows_conflict(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    # Another writer switches the preference to allowlist mode out of band.
    page.evaluate("window.__HARNESS_SET_PREF__({mode: 'allowlist', model_include: ['openrouter/vendor/paid-pro-max'], model_exclude: []})")
    _switch(page, "Enable nvidia/llama-3.3-70b-instruct in AutoRouter").click()
    # The client re-fetches fresh state and refuses to replay: exactly one POST.
    page.wait_for_function(
        "window.__HARNESS_CALLS__.some(c => c.method === 'GET' && c.path === '/models/preference')",
        timeout=5000,
    )
    page.wait_for_selector("text=another writer changed the model preference", timeout=5000)
    posts = [c for c in _calls(page) if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert len(posts) == 1
    # The page re-renders from the authoritative (allowlist) state.
    page.wait_for_function(
        "document.querySelectorAll('[data-model-toggle][aria-checked=\"false\"]').length >= 1",
        timeout=5000,
    )


def test_conflict_same_mode_rebases_and_applies(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    page.evaluate("window.__HARNESS_SET_PREF__({mode: 'unrestricted', model_exclude: ['openrouter/other:free']})")
    _switch(page, "Enable nvidia/llama-3.3-70b-instruct in AutoRouter").click()
    page.wait_for_function(
        "window.__HARNESS_CALLS__.filter(c => c.method === 'POST' && c.path === '/models/preference').length >= 2",
        timeout=5000,
    )
    posts = [c for c in _calls(page) if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert len(posts) == 2
    first = json.loads(posts[0]["body"])
    second = json.loads(posts[1]["body"])
    assert first["base"] != second["base"]  # the retry used the fresh base
    assert _switch(page, "Enable nvidia/llama-3.3-70b-instruct in AutoRouter").get_attribute("aria-checked") == "false"


def test_none_mode_banner_and_two_step_reset(page):
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    page.evaluate("window.__HARNESS_SET_PREF__({mode: 'none', model_include: [], model_exclude: ['openrouter/vendor/paid-pro-max']})")
    # Changing a filter triggers a re-fetch with the new persisted state.
    page.select_option("#ar-models-preference", "off")
    page.wait_for_selector("text=No model is enabled", timeout=5000)
    switches = page.locator("[data-model-toggle]")
    for i in range(switches.count()):
        assert switches.nth(i).get_attribute("aria-checked") == "false"
    # First click arms the reset; the request goes out only on the second click.
    page.get_by_role("button", name="Reset to unrestricted", exact=True).click()
    posts = [c for c in _calls(page) if c["method"] == "POST" and c["path"] == "/models/preference"]
    assert len(posts) == 0
    page.get_by_role("button", name="Confirm reset", exact=True).click()
    page.wait_for_function(
        "window.__HARNESS_CALLS__.some(c => c.method === 'POST' && c.path === '/models/preference' && c.body && JSON.parse(c.body).reset === 'unrestricted')",
        timeout=5000,
    )
    page.wait_for_function(
        "!document.body.innerText.includes('No model is enabled')",
        timeout=5000,
    )


def test_last_off_disables_everything_and_stays_disabled(page):
    """End-to-end web flow: seed allowlist mode with ONE model, turn it off,
    and verify no other model silently becomes selectable."""
    _open(page, "normal")
    page.get_by_role("tab", name="Models").click()
    page.wait_for_selector(".ar-table tbody tr", timeout=5000)
    page.evaluate("window.__HARNESS_SET_PREF__({mode: 'allowlist', model_include: ['nvidia/llama-3.3-70b-instruct'], model_exclude: []})")
    page.select_option("#ar-models-preference", "all")  # force re-fetch
    page.wait_for_selector("text=Allowlist mode", timeout=5000)
    _switch(page, "Enable nvidia/llama-3.3-70b-instruct in AutoRouter").click()
    page.wait_for_selector("text=No model is enabled", timeout=5000)
    pref = page.evaluate("window.__HARNESS_CALLS__.filter(c => c.method === 'POST' && c.path === '/models/preference').slice(-1)[0].body")
    assert json.loads(pref)["toggles"] == [{"provider": "nvidia", "model": "llama-3.3-70b-instruct", "enabled": False}]
    switches = page.locator("[data-model-toggle]")
    for i in range(switches.count()):
        assert switches.nth(i).get_attribute("aria-checked") == "false"
