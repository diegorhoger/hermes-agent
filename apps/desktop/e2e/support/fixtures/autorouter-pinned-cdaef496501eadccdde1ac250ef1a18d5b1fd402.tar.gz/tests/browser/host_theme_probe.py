"""Opt-in visual acceptance against an isolated real Hermes web dashboard.

This changes only the supplied temporary dashboard's theme/policy preferences.
It requires an explicit fixture root and verifies the plugin state path is there.
Never point it at an operator's Hermes instance. No provider/inference requests.
"""
import argparse
import json
import os
import hashlib
import importlib.util
import sys
import time
from pathlib import Path
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright

THEMES = ['Hermes Teal', 'Hermes Teal (Large)', 'Nous Blue', 'Midnight', 'Ember', 'Mono', 'Cyberpunk', 'Rosé']

STYLE_PROBE = '''()=>{
 let root=document.querySelector('.ar-root'),shell=root.querySelector('.ar-shell'),input=root.querySelector('.ar-input');
 input.focus();
 let rs=getComputedStyle(root),ss=getComputedStyle(shell),is=getComputedStyle(input),fs=getComputedStyle(root.querySelector('.ar-footer'));
 let probe=document.body.appendChild(document.createElement('div'));
 probe.style.cssText='color:var(--midground);background:var(--background-base);border:1px solid var(--color-border);outline-color:var(--color-ring,var(--midground))';
 let p=getComputedStyle(probe);
 let expected={foreground:p.color,background:p.backgroundColor,border:p.borderColor,focus:p.outlineColor};
 probe.style.color='color-mix(in srgb,var(--color-muted-foreground,var(--color-text-secondary,var(--midground))) 25%,var(--midground-base,var(--midground)))';
 expected.muted=getComputedStyle(probe).color;
 probe.remove();
 function rgb(color){let c=document.createElement('canvas');c.width=c.height=1;let x=c.getContext('2d');x.fillStyle=color;x.fillRect(0,0,1,1);return Array.from(x.getImageData(0,0,1,1).data);}
 function contrast(color,bg){let c=rgb(color),b=rgb(bg),a=c[3]/255;function lum(v){return v.slice(0,3).map(x=>x/255).map(x=>x<=0.04045?x/12.92:((x+0.055)/1.055)**2.4).reduce((s,x,i)=>s+x*[0.2126,0.7152,0.0722][i],0)}let front=c.slice(0,3).map((v,i)=>v*a+b[i]*(1-a));let pair=[lum(front),lum(b)].sort((a,b)=>a-b);return(pair[1]+0.05)/(pair[0]+0.05);}
 return {contrast:{text:contrast(rs.color,ss.backgroundColor),muted:contrast(fs.color,ss.backgroundColor)},mounted:root===window.__themeMountedNode,foreground:rs.color,background:ss.backgroundColor,
 border:is.borderTopColor,focus:is.outlineColor,muted:fs.color,font:rs.fontFamily,fontSize:rs.fontSize,
 radius:getComputedStyle(root.querySelector('.ar-note')).borderRadius,padding:ss.padding,
 expected,selected:root.querySelector('[role=tab][aria-selected=true]').textContent,
 query:root.querySelector('[aria-label="Search provider candidates"]').value,
 width:innerWidth,documentWidth:document.documentElement.scrollWidth};
}'''


def run(base, fixture_root, output, *, host_sha=None, artifact=None, synthetic_workflow=False):
    assert urlsplit(base).hostname in ('127.0.0.1', 'localhost'), 'isolated loopback dashboard required'
    output.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=os.environ.get('PRIVATE_BROWSER_EXECUTABLE', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'), headless=True)
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        errors, external, requests = [], [], []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('request', lambda r: requests.append({'method': r.method, 'path': urlsplit(r.url).path}) if '/api/plugins/autorouter/' in r.url else None)
        def net(route):
            if route.request.url.startswith(base) or route.request.url.startswith('data:'):
                route.continue_()
            else:
                external.append(urlsplit(route.request.url).scheme + '://' + urlsplit(route.request.url).netloc + urlsplit(route.request.url).path)
                route.abort()
        page.route('**/*', net)
        page.goto(base + '/autorouter', wait_until='networkidle')
        # Use the sanctioned SDK fetch helper; never extract a host session token.
        settings = page.evaluate("window.__HERMES_PLUGIN_SDK__.fetchJSON('/api/plugins/autorouter/settings')")
        assert Path(settings['values']['state_dir']).resolve().is_relative_to(fixture_root.resolve())
        if page.get_by_role('button', name='No thanks', exact=True).count():
            page.get_by_role('button', name='No thanks', exact=True).click()
        artifact_record = None
        if artifact is not None:
            assert artifact.resolve().is_relative_to(fixture_root.resolve())
            spec = importlib.util.spec_from_file_location('_package_verifier', Path(__file__).resolve().parents[2] / 'tools/build_package.py')
            verifier = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(verifier)
            content = artifact.read_bytes()
            manifest = verifier.verify(content)
            deployed = fixture_root / 'profile/plugins/autorouter'
            for record in manifest['files']:
                assert hashlib.sha256((deployed / record['path']).read_bytes()).hexdigest() == record['sha256']
            artifact_record = dict(source_sha=manifest['source_sha'],tree_sha=manifest['tree_sha'],sha256=hashlib.sha256(content).hexdigest())
        api_checks = {}
        for endpoint in ('overview','providers','models','analytics','settings','connections','first-use','task-profiles','execution-capabilities'):
            path = '/api/plugins/autorouter/' + endpoint
            with page.expect_response(lambda response: urlsplit(response.url).path == path and response.request.method == 'GET') as observed:
                body = page.evaluate('(path)=>window.__HERMES_PLUGIN_SDK__.fetchJSON(path)', path)
            assert observed.value.status == 200 and isinstance(body, dict)
            api_checks[endpoint] = observed.value.status
        anonymous = pw.request.new_context()
        denied = {}
        for method, path in (('GET','overview'),('PUT','settings'),('POST','selection/preview')):
            response = anonymous.fetch(base + '/api/plugins/autorouter/' + path, method=method, data={} if method != 'GET' else None)
            assert response.status == 401
            denied[method + ' ' + path] = response.status
        anonymous.dispose()
        page.get_by_role('tab', name='Providers', exact=True).click()
        page.get_by_label('Search provider candidates').fill('NVIDIA')
        page.evaluate("window.__themeMountedNode=document.querySelector('.ar-root')")
        def switch(label):
            page.get_by_role('button', name='Switch theme', exact=True).click()
            box = page.get_by_role('listbox', name='Theme', exact=True)
            box.get_by_role('option').filter(has=page.get_by_text(label, exact=True)).click()
            page.wait_for_function('(label)=>document.querySelector("[aria-label=\\"Switch theme\\"]").title.includes(label)', arg=label)
            page.evaluate('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))')
        matrix, tabs = [], []
        for label in THEMES:
            switch(label)
            result = page.evaluate(STYLE_PROBE)
            assert result['mounted'] and result['selected'].strip() == 'Providers' and result['query'] == 'NVIDIA'
            assert result['documentWidth'] <= result['width']
            assert result['contrast']['text'] >= 4.5 and result['contrast']['muted'] >= 4.5, (label, result['contrast'])
            for key in ('foreground', 'background', 'border', 'focus', 'muted'):
                assert result[key] == result['expected'][key], (label, key, result)
            page.screenshot(path=str(output / ('host-plugin-' + label.lower().replace(' ', '-').replace('(', '').replace(')', '') + '.png')))
            matrix.append(dict(theme=label, **result))
            for width in (390, 768, 1440):
                page.set_viewport_size({'width': width, 'height': 1000})
                for tab in ('Overview', 'Providers', 'Models', 'Analytics', 'Settings'):
                    page.get_by_role('tab', name=tab, exact=True).click()
                    page.wait_for_function("!document.querySelector('.ar-panel .ar-sk-row')")
                    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'), (label, width, tab)
                    tabs.append({'theme': label, 'width': width, 'tab': tab})
                if label in ('Hermes Teal', 'Nous Blue'):
                    page.screenshot(path=str(output / ('host-settings-' + label.lower().replace(' ', '-') + '-' + str(width) + '.png')))
            page.get_by_role('tab', name='Providers', exact=True).click()
            page.get_by_label('Search provider candidates').fill('NVIDIA')
        assert len({row['background'] for row in matrix}) > 2
        assert matrix[0]['fontSize'] != matrix[1]['fontSize']
        switch('Hermes Teal')
        before = page.evaluate(STYLE_PROBE)
        schemes = []
        for scheme in ('light', 'dark'):
            page.emulate_media(color_scheme=scheme)
            after = page.evaluate(STYLE_PROBE)
            assert after['foreground'] == before['foreground'] and after['background'] == before['background']
            schemes.append({'scheme': scheme, 'unchanged_named_host_theme': True})
        page.get_by_role('button', name='Switch theme', exact=True).click()
        options = page.get_by_role('listbox', name='Theme', exact=True).get_by_role('option').all_text_contents()
        page.keyboard.press('Escape')
        assert not any(text.strip().lower() == 'system' for text in options)
        native = []
        for label in ('Hermes Teal', 'Nous Blue'):
            # Keep the switching observation separate from native-page navigation.
            page.goto(base + '/autorouter', wait_until='networkidle')
            switch(label)
            for route in ('/config', '/system'):
                response = page.goto(base + route, wait_until='networkidle')
                assert response.status == 200
                name = label.lower().replace(' ', '-') + route.replace('/', '-')
                page.screenshot(path=str(output / ('host-native-' + name + '.png')))
                native.append({'theme': label, 'route': route, 'status': response.status})
        page.goto(base + '/autorouter', wait_until='networkidle')
        switch('Hermes Teal')
        page.get_by_role('tab', name='Settings', exact=True).click()
        page.get_by_role('tab', name='Settings', exact=True).focus()
        page.keyboard.press('Home')
        assert page.get_by_role('tab', name='Overview', exact=True).get_attribute('aria-selected') == 'true'
        page.get_by_role('tab', name='Settings', exact=True).click()
        original = page.get_by_label('Selection policy').input_value()
        changed = 'reliable' if original != 'reliable' else 'auto'
        for value in (changed, original):
            page.get_by_label('Selection policy').select_option(value)
            with page.expect_response(lambda r: '/api/plugins/autorouter/settings' in r.url and r.request.method == 'PUT') as saved:
                page.get_by_role('button', name='Save changes', exact=True).click()
            assert saved.value.status == 200
        # Deliberate one-response transport fixture; recovery uses the actual API.
        page.route(base + '/api/plugins/autorouter/models*', lambda route: route.fulfill(
            status=503, content_type='application/json', body='{"detail":"Synthetic isolated transport error"}'), times=1)
        page.get_by_role('tab', name='Models', exact=True).click()
        page.wait_for_function("document.querySelector('.ar-panel .ar-empty') || document.querySelector('.ar-panel .ar-error')")
        if page.locator('.ar-panel .ar-error').count() == 0:
            page.get_by_role('button', name='Refresh', exact=True).click()
        page.get_by_role('button', name='Retry', exact=True).wait_for()
        page.screenshot(path=str(output / 'host-simulated-transport-error.png'))
        page.get_by_role('button', name='Retry', exact=True).click()
        page.get_by_text('Catalog is empty', exact=True).wait_for()
        page.emulate_media(reduced_motion='reduce')
        assert page.locator('.ar-toast').evaluate('(e)=>getComputedStyle(e).transitionDuration') == '0s'
        handoff = None
        if synthetic_workflow:
            assert artifact_record is not None, 'verified deployed artifact required for fixture writes'
            deployed = fixture_root / 'profile/plugins/autorouter'
            spec = importlib.util.spec_from_file_location('_acceptance_plugin', deployed / '__init__.py', submodule_search_locations=[str(deployed)])
            module = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = module
            spec.loader.exec_module(module)
            state_spec = importlib.util.spec_from_file_location(spec.name + '.state', deployed / 'state.py')
            state_module = importlib.util.module_from_spec(state_spec)
            sys.modules[state_spec.name] = state_module
            state_spec.loader.exec_module(state_module)
            store = state_module.StateStore(Path(settings['values']['state_dir']))
            stamp = time.time()
            model = 'fixture/browser-free'
            cap = dict(provider='openrouter',model=model,context_window=32000,tools='supported',cost_tier='free',discovery_status='discovered',metadata_source='controlled-test-fixture',retrieved_at=stamp,expires_at=stamp+3600)
            store.upsert_catalog('openrouter',model,32000,{'tools':True},'free')
            store.upsert_capability('openrouter',model,json.dumps(cap),metadata_source=cap['metadata_source'],retrieved_at=stamp,expires_at=stamp+3600)
            page.get_by_role('button', name='Refresh', exact=True).click()
            page.get_by_text('Preview / Why this model?',exact=True).first.click()
            page.get_by_label('Explicit task profile').select_option('coding')
            page.get_by_label('Workload requires tools',exact=True).check()
            page.get_by_role('button',name='Preview task profile',exact=True).click()
            page.get_by_role('status',name='Explicit task preview result').get_by_text('Selected: openrouter / '+model,exact=True).wait_for(state='attached')
            page.get_by_text('Preview / Why this model?',exact=True).last.click()
            page.get_by_label('Confirm manual handoff preparation').last.check()
            with page.expect_response(lambda response: urlsplit(response.url).path.endswith('/handoff/manual') and response.request.method=='POST') as observed:
                page.get_by_role('button',name='Prepare manual handoff',exact=True).last.click()
            receipt = observed.value.json()
            assert observed.value.status == 200 and receipt['state']=='manual_handoff_pending'
            assert receipt['applied'] is False and receipt['executed'] is False
            handoff = dict(state=receipt['state'],applied=False,executed=False,synthetic_model_proof=True,live_entitlement=False)
            page.screenshot(path=str(output / 'host-synthetic-manual-handoff.png'))
        assert not errors, errors
        assert all(r['method'] == 'GET' or (r['method'] == 'PUT' and r['path'].endswith('/settings')) or (r['method']=='POST' and r['path'].endswith(('/selection/preview','/handoff/manual'))) for r in requests)
        report = dict(host=host_sha or 'unknown; explicit host pin required for acceptance',artifact=artifact_record,authenticated_api=api_checks,unauthenticated_denials=denied,synthetic_handoff=handoff,
            themes=matrix, native_pages=native, tabs=tabs, os_scheme_checks=schemes,
            system_theme='UNSUPPORTED_BY_PINNED_HOST: eight named themes; System Sans/Serif/Mono are font choices',
            settings_round_trip={'original': original, 'changed': changed, 'restored': original},
            error_recovery='one explicitly simulated 503, followed by actual API empty-state recovery',
            errors=errors, blocked_external_font_urls=sorted(set(external)), plugin_requests=requests)
        (output / 'actual-host-theme-report.json').write_text(json.dumps(report, indent=2))
        browser.close()
        return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', required=True)
    parser.add_argument('--fixture-root', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--host-sha')
    parser.add_argument('--artifact',type=Path)
    parser.add_argument('--synthetic-workflow',action='store_true')
    args = parser.parse_args()
    result = run(args.base.rstrip('/'), args.fixture_root, args.output,host_sha=args.host_sha,artifact=args.artifact,synthetic_workflow=args.synthetic_workflow)
    print(json.dumps({'themes': len(result['themes']), 'native_pages': len(result['native_pages']),
                      'tab_checks': len(result['tabs']), 'errors': result['errors']}))
