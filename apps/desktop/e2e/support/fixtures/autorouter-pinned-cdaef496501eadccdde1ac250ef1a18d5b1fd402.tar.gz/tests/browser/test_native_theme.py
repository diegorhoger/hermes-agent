"""Offline token-inheritance checks; actual host evidence is a separate probe."""
import pytest
pytest.importorskip('playwright')
from playwright.sync_api import sync_playwright
from .test_harness_interactions import CHROME, _url

pytestmark = pytest.mark.skipif(CHROME is None, reason='no Chrome/Chromium binary')

PALETTES = [
    ('teal', '#041c1c', '#ffe6cb'),
    ('light', '#E8F2FD', '#0053FD'),
    ('mono', '#111111', '#eeeeee'),
]


def test_host_token_changes_update_mounted_ui_without_api_or_remount():
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=CHROME, headless=True)
        page = browser.new_page(viewport={'width': 1280, 'height': 900})
        page.goto(_url('normal'))
        page.get_by_role('tab', name='Models', exact=True).click()
        page.add_style_tag(content='html{font-family:var(--theme-font-sans);font-size:var(--theme-base-size)}')
        page.evaluate("window.__mountedThemeNode=document.querySelector('.ar-root');window.__nativeProbe=document.body.appendChild(document.createElement('div'));window.__nativeProbe.style.cssText='color:var(--midground);background:var(--background-base);border:1px solid var(--color-border)' ")
        previous = None
        for name, bg, fg in PALETTES:
            page.evaluate('''([bg,fg])=>{let r=document.documentElement.style; for(let[k,v]of Object.entries({'--background-base':bg,'--midground-base':fg,'--midground':fg,'--color-border':fg,'--color-muted-foreground':fg,'--color-ring':fg,'--color-input':fg,'--theme-font-sans':'system-ui','--theme-base-size':'16px','--theme-radius':'0.5rem','--theme-spacing-mul':'1'}))r.setProperty(k,v)}''', [bg, fg])
            page.get_by_label('Search models').focus()
            result = page.evaluate('''()=>{let node=document.querySelector('.ar-root'),r=getComputedStyle(node),s=getComputedStyle(node.querySelector('.ar-shell')),i=getComputedStyle(document.activeElement),p=getComputedStyle(window.__nativeProbe);return {mounted:node===window.__mountedThemeNode,fg:r.color,bg:s.backgroundColor,focus:i.outlineColor,hostFg:p.color,hostBg:p.backgroundColor,hostBorder:p.borderColor,calls:window.__HARNESS_CALLS__.length}}''')
            assert result['mounted'] and result['fg'] == result['hostFg']
            assert result['bg'] == result['hostBg'] and result['focus'] == result['hostBorder']
            assert result['calls'] == 2
            if previous:
                assert result['bg'] != previous['bg'] and result['fg'] != previous['fg']
            previous = result
        browser.close()


@pytest.mark.parametrize('width', [390, 768, 1440])
def test_native_surface_keeps_keyboard_focus_and_viewport(width):
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=CHROME, headless=True)
        page = browser.new_page(viewport={'width': width, 'height': 900})
        page.goto(_url('normal'))
        for name in ('Overview', 'Providers', 'Models', 'Analytics', 'Settings'):
            page.get_by_role('tab', name=name, exact=True).click()
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
        page.get_by_role('tab', name='Settings', exact=True).focus()
        page.keyboard.press('Home')
        assert page.get_by_role('tab', name='Overview', exact=True).get_attribute('aria-selected') == 'true'
        page.emulate_media(reduced_motion='reduce')
        assert page.locator('.ar-toast').evaluate('(e)=>getComputedStyle(e).transitionDuration') == '0s'
        browser.close()


@pytest.mark.parametrize('mode,label', [('normal', 'Plugin enabled'), ('empty', 'Plugin disabled')])
def test_header_status_has_text_and_no_duplicate_product_brand(mode, label):
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=CHROME, headless=True)
        page = browser.new_page()
        page.goto(_url(mode))
        page.locator('.ar-header').get_by_text(label, exact=False).wait_for()
        assert page.locator('.ar-logo, .ar-title').count() == 0
        browser.close()
