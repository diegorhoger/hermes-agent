/* Harness entry: mount the Desktop plugin against the fixture API. */
import React from 'react'
import { createRoot } from 'react-dom/client'
import plugin from '../../../desktop/plugin.js'
import { createMockApi } from './mock-api.mjs'

const { rest, calls, state } = createMockApi()
globalThis.__HARNESS_CALLS__ = calls
globalThis.__HARNESS_STATE__ = state
globalThis.__HARNESS_MOUNTED__ = false

const contributions = []
const ctx = {
  source: 'plugin:autorouter',
  register: (c) => { contributions.push({ ...c, id: `autorouter:${c.id}` }) },
  registerMany: (cs) => cs.map((c) => contributions.push({ ...c, id: `autorouter:${c.id}` })),
  onDispose: () => {},
  onEvent: () => () => {},
  storage: { get: (_k, fallback) => fallback, set: () => {}, remove: () => {} },
  rest,
  socket: () => () => {},
  runAction: () => ({ ok: true }),
  listActions: () => [],
  os: {},
  pet: {},
  files: {},
  i18n: { register: () => {}, t: (s) => s, onLocaleChange: () => {} },
  preview: {},
}

plugin.register(ctx)
globalThis.__CONTRIBUTIONS__ = contributions.map((c) => ({ area: c.area, title: c.title, id: c.id, has_render: typeof c.render === 'function' }))

const page = contributions.find((c) => c.area === 'routes')
const root = createRoot(document.getElementById('root'))
root.render(React.createElement(page.render))
globalThis.__HARNESS_MOUNTED__ = true
