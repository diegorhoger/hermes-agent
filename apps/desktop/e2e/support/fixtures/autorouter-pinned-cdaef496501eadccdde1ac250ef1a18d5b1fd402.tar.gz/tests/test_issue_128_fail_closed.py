"""Issue #128 regression: unreadable routing authorization/settings after
consumer registration must fail closed, never widen.

The native routing consumer reads Hermes configuration per attempt. These
tests pin the contract that a configuration read failure or malformed shape
grants NOTHING: no providers, no unrestricted preference, no host client
construction, no outbound provider request. A structurally valid file that
deliberately omits settings remains a valid omission and keeps the
documented manufacturing defaults.
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from pathlib import Path

import pytest

os.environ.setdefault("HERMES_DISABLE_LAZY_INSTALLS", "1")

from autorouter.autorouter_core.integration import native_routing  # noqa: E402
from autorouter.autorouter_core.integration import _route_resolution  # noqa: E402
from autorouter.autorouter_core.storage import state as state_mod  # noqa: E402

_HERMES_IMPORTABLE = False
try:
    import hermes_cli.config  # noqa: E402
    import hermes_cli.middleware  # noqa: E402
    import hermes_cli.plugins  # noqa: E402

    _HERMES_IMPORTABLE = True
except Exception:
    pass

requires_hermes = pytest.mark.skipif(not _HERMES_IMPORTABLE,
                                     reason="Hermes v0.23.2 not importable")


def _settings(**overrides):
    base = {
        "enabled": True,
        "enable_chat_router": False,
        "enable_native_routing": True,
        "policy": "auto",
        "min_context": 8192,
        "cooldown_seconds": 60,
        "requires_tools": True,
        "free_only": True,
        "providers": ["nvidia", "openrouter"],
        "model_include": [],
        "model_exclude": [],
    }
    base.update(overrides)
    return base


def _seed_catalog(store, rows):
    now = 1.0
    expiry = 9999999999.0
    for p, m, ctx, caps, tier in rows:
        store.upsert_catalog(p, m, context_length=ctx, capabilities=caps, cost_tier=tier)
        store.upsert_capability(
            p, m,
            json.dumps({
                "provider": p, "model": m,
                "field_evidence": {
                    "context_window": {"metadata_source": "provider",
                                       "retrieved_at": now, "expires_at": expiry},
                    "tools": {"metadata_source": "provider",
                              "retrieved_at": now, "expires_at": expiry},
                    "cost_tier": {"metadata_source": "provider",
                                  "retrieved_at": now, "expires_at": expiry},
                },
                "context_window": ctx, "tools": caps["tools"],
                "cost_tier": tier, "source": "provider",
            }),
            metadata_source="provider", retrieved_at=now, expires_at=expiry,
        )


@pytest.fixture
def store_dir(tmp_path):
    store = state_mod.StateStore(tmp_path / "store")
    _seed_catalog(store, [
        ("nvidia", "nvidia-free", 131072, {"tools": "supported"}, "free"),
        ("openrouter", "qwen/qwen3-coder:free", 262144, {"tools": "supported"}, "free"),
    ])
    return tmp_path / "store"


def _patch_valid(monkeypatch, **settings):
    import hermes_cli.config as _hcfg

    merged = _settings(**settings)
    monkeypatch.setattr(_hcfg, "load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": merged}}}})
    return merged


def _patch_broken_after(monkeypatch, valid, calls_before_break):
    """First ``calls_before_break`` reads return the valid config; afterwards
    every read raises, modelling a configuration that breaks at attempt time."""
    import hermes_cli.config as _hcfg

    state = {"calls": 0}

    def _loader():
        state["calls"] += 1
        if state["calls"] <= calls_before_break:
            return {"plugins": {"entries": {"autorouter": {"settings": valid}}}}
        raise OSError("configuration disappeared")

    monkeypatch.setattr(_hcfg, "load_config_readonly", _loader)
    return state


def _forbid_network(monkeypatch):
    import socket

    def _boom(*args, **kwargs):
        raise AssertionError("network access is forbidden on this path")

    monkeypatch.setattr(socket, "socket", _boom)


def _consumer_route(store_dir, **metadata):
    return native_routing.resolve_consumer_route(
        metadata={"session_id": metadata.pop("session_id", "s-128"),
                  "platform": "desktop", **metadata},
        store_dir=store_dir,
    )


# --------------------------------------------------------------- RED specs

@requires_hermes
def test_valid_registration_then_config_read_failure_refuses(monkeypatch, store_dir):
    """Valid at register time; read breaks at attempt time: no route."""
    imported = _patch_valid(monkeypatch, requires_tools=True)
    # precondition: valid config routes
    first = _consumer_route(store_dir, session_id="s-128a")
    assert first["status"] == "route"
    _patch_broken_after(monkeypatch, imported, 0)
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128b")
    assert out["status"] == "refuse"
    assert out["provider"] is None and out["model"] is None
    assert _route_resolution.authorized_providers() == []
    assert _route_resolution.routing_settings() is None


@requires_hermes
def test_config_read_failure_fires_before_any_engine_call(monkeypatch, store_dir):
    """No authorization grant means the resolution engine is never reached."""
    import autorouter.autorouter_core.integration._route_resolution as rr

    imported = _patch_valid(monkeypatch, requires_tools=True)
    calls = []

    def _spy(*args, **kwargs):
        calls.append((args, kwargs))
        return {"provider": "nvidia", "model": "nvidia-free", "error": None,
                "policy": "auto", "at": 1.0, "profile_id": None, "profile_name": None}

    _patch_broken_after(monkeypatch, imported, 0)
    monkeypatch.setattr(rr, "resolve_route_detailed", _spy)
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128c")
    assert out["status"] == "refuse"
    assert calls == []


@requires_hermes
def test_config_returning_malformed_object_refuses(monkeypatch, store_dir):
    import hermes_cli.config as _hcfg

    monkeypatch.setattr(_hcfg, "load_config_readonly", lambda: ["plugins", "entries"])
    _forbid_network(monkeypatch)
    assert _route_resolution.routing_settings() is None
    assert _route_resolution.authorized_providers() == []
    out = _consumer_route(store_dir, session_id="s-128d")
    assert out["status"] == "refuse"
    assert out["provider"] is None and out["model"] is None


@requires_hermes
def test_config_returning_failed_read_dict_refuses(monkeypatch, store_dir):
    """Hermes serves a FailedConfigRead (default-merge marked with read_error)
    on a corrupt file; it must not be read as a valid empty config."""
    import hermes_cli.config as _hcfg
    from hermes_cli.config_read_errors import FailedConfigRead

    _forbid_network(monkeypatch)
    monkeypatch.setattr(_hcfg, "load_config_readonly",
                        lambda: FailedConfigRead({"plugins": {"entries": {"autorouter": {"settings": _settings(requires_tools=True)}}}},
                                               error=ValueError("YAML broke")))
    assert _route_resolution.routing_settings() is None
    assert _route_resolution.authorized_providers() == []
    out = _consumer_route(store_dir, session_id="s-128e")
    assert out["status"] == "refuse"
    assert out["provider"] is None


@requires_hermes
def test_unreadable_providers_key_grants_nothing(monkeypatch, store_dir):
    _forbid_network(monkeypatch)
    for bad in ("nvidia", 123, 1.5, ["nvidia", "no-such-provider"], ["nvidia", "NVIDIA"], [""]):
        _patch_valid(monkeypatch, providers=bad, requires_tools=True)
        assert _route_resolution.authorized_providers() == [], bad


@requires_hermes
def test_omitted_providers_key_keeps_documented_defaults(monkeypatch, store_dir):
    """A structurally valid file that simply omits providers is a valid
    omission: the documented manufacturing defaults apply (regression guard)."""
    import hermes_cli.config as _hcfg

    settings = _settings(requires_tools=True)
    settings.pop("providers")
    monkeypatch.setattr(_hcfg, "load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": settings}}}})
    assert _route_resolution.authorized_providers() == ["nvidia", "openrouter"]
    out = _consumer_route(store_dir, session_id="s-128f")
    assert out["status"] == "route"


@requires_hermes
def test_unreadable_restrictive_preference_never_widens(monkeypatch, store_dir):
    """model_preference was restrictive; the read now breaks: refuse, never unrestricted."""
    imported = _patch_valid(monkeypatch, model_preference={"mode": "none"})
    first = _consumer_route(store_dir, session_id="s-128g")
    assert first["status"] == "refuse"
    _patch_broken_after(monkeypatch, imported, 0)
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128h")
    assert out["status"] == "refuse"


@requires_hermes
def test_legacy_restrictive_preference_list_unparseable_fails_closed(monkeypatch, store_dir):
    """Legacy model_include that is not a clean list used to evaluate as an
    empty allowlist -> unrestricted; now unreadable means refused."""
    _patch_valid(monkeypatch, model_include="nvidia/nvidia-free")
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128i")
    assert out["status"] == "refuse"


@requires_hermes
def test_malformed_model_preference_object_refuses(monkeypatch, store_dir):
    _patch_valid(monkeypatch, model_preference={"mode": "banana", "include": ["!"]})
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128j")
    assert out["status"] == "refuse"


@requires_hermes
def test_configuration_disappears_after_consumer_registration(monkeypatch, store_dir):
    imported = _patch_valid(monkeypatch, requires_tools=True)
    first = _consumer_route(store_dir, session_id="s-128k")
    assert first["status"] == "route"
    # configuration disappears: every read now raises
    import hermes_cli.config as _hcfg

    def _loader():
        raise FileNotFoundError("config.yaml vanished")

    monkeypatch.setattr(_hcfg, "load_config_readonly", _loader)
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128l")
    assert out["status"] == "refuse"


@requires_hermes
def _config_for(root_settings, cfg):
    return {"plugins": {"entries": {"autorouter": {"settings": cfg}}}}


def test_concurrent_sessions_during_configuration_invalidation(monkeypatch, store_dir):
    """Attempt-scoped, deterministic invalidation.

    Each worker reads the configuration exclusively from its own arm of the
    loader (selected by thread name), which makes the expected outcome for
    every attempt deterministic regardless of thread scheduling. Repeating
    the scenario 25 times proves stability."""
    import hermes_cli.config as _hcfg

    valid = _settings(requires_tools=True)
    broken = OSError("configuration unreadable mid-swap")
    per_worker = {
        "worker-valid": ("snapshot", _config_for(valid, valid)),
        "worker-broken": ("error", broken),
    }
    barrier = threading.Barrier(3)

    def _loader():
        kind, payload = per_worker[threading.current_thread().name]
        if kind == "error":
            raise payload
        return payload

    monkeypatch.setattr(_hcfg, "load_config_readonly", _loader)
    _forbid_network(monkeypatch)

    def _worker(flag, sid, results):
        barrier.wait(timeout=5)
        results[sid] = _consumer_route(store_dir, session_id=sid)

    for _ in range(25):
        results = {}
        threads = [
            threading.Thread(target=_worker, args=(False, "s-128m-valid", results), name="worker-valid"),
            threading.Thread(target=_worker, args=(True, "s-128n-broken", results), name="worker-broken"),
        ]
        for t in threads:
            t.start()
        barrier.wait(timeout=5)
        for t in threads:
            t.join()
        assert results["s-128m-valid"]["status"] == "route"
        assert results["s-128n-broken"]["status"] == "refuse"

    # after the config is readable again the refused session routes again —
    # per-attempt revalidation works in both directions
    import hermes_cli.config as _hcfg

    monkeypatch.setattr(_hcfg, "load_config_readonly",
                        lambda: _config_for(valid, valid))
    out = _consumer_route(store_dir, session_id="s-128o-recovered")
    assert out["status"] == "route"


@requires_hermes
def test_thread_local_attempt_isolation_stress(monkeypatch, store_dir):
    """50 interleaved pairs of attempts, half readable and half broken;
    no cross-contamination between attempts."""
    import hermes_cli.config as _hcfg

    valid = _settings(requires_tools=True)
    broken = OSError("configuration unreadable mid-swap")
    states = {"iter": 0}

    def _loader():
        states["iter"] += 1
        # alternate strictly deterministically: even attempts read, odd fail
        if states["iter"] % 2 == 0:
            return _config_for(valid, valid)
        raise broken

    monkeypatch.setattr(_hcfg, "load_config_readonly", _loader)
    _forbid_network(monkeypatch)

    outcomes = []
    for i in range(50):
        out = _consumer_route(store_dir, session_id=f"s-128-stress-{i}")
        outcomes.append(out["status"])
    # strictly alternating loader: even iter -> route, odd -> refuse. Any
    # anomaly (double read in one attempt that flips the parity) fails here.
    assert outcomes == ["refuse" if (i + 1) % 2 else "route" for i in range(50)]


@requires_hermes
def test_refusal_carries_no_provider_and_no_model(monkeypatch, store_dir):
    _patch_broken_after(monkeypatch, _settings(requires_tools=True), 0)
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128p")
    assert out["status"] == "refuse"
    assert out["provider"] is None
    assert out["model"] is None
    receipt = out.get("receipt") or {}
    assert receipt.get("route") is None


@requires_hermes
def test_valid_config_consumer_still_routes_after_reload(monkeypatch, store_dir):
    """Sanity: the failure gates do not stick — a repaired config routes."""
    imported = _patch_valid(monkeypatch, requires_tools=True)
    _patch_broken_after(monkeypatch, imported, 1)
    out1 = _consumer_route(store_dir, session_id="s-128q")
    assert out1["status"] == "route"
    out2 = _consumer_route(store_dir, session_id="s-128r")
    assert out2["status"] == "refuse"


@requires_hermes
def test_plugin_revoked_after_registration_refuses_both_modes(monkeypatch, store_dir):
    """enabled: true -> enabled: false at attempt time revocation: REFUSE."""
    valid = _settings(requires_tools=True, enable_native_routing=True, enable_chat_router=True)
    monkeypatch.setattr("hermes_cli.config.load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": valid}}}})
    first = _consumer_route(store_dir, session_id="s-128-revoke-1", selection_mode="manual",
                            requested_model="autorouter/auto-free")
    assert first["status"] != "passthrough"

    revoked = dict(valid, enabled=False)
    monkeypatch.setattr("hermes_cli.config.load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": revoked}}}})
    _forbid_network(monkeypatch)
    for sid, meta in (("s-128-revoke-b", {}), ("s-128-revoke-a",
                                               {"selection_mode": "manual",
                                                "requested_model": "autorouter/auto-free"})):
        out = _consumer_route(store_dir, session_id=sid, **meta)
        assert out["status"] == "refuse"
        assert out["provider"] is None and out["model"] is None


@requires_hermes
def test_plugin_restored_after_revocation_routes_again(monkeypatch, store_dir):
    enabled_cfg = _settings(requires_tools=True)
    monkeypatch.setattr("hermes_cli.config.load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": enabled_cfg}}}})
    assert _consumer_route(store_dir, session_id="s-128-restore-1")["status"] == "route"

    revoked = dict(enabled_cfg, enabled=False)
    monkeypatch.setattr("hermes_cli.config.load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": revoked}}}})
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128-restore-2")
    assert out["status"] == "refuse"

    monkeypatch.setattr("hermes_cli.config.load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": enabled_cfg}}}})
    out = _consumer_route(store_dir, session_id="s-128-restore-3")
    assert out["status"] == "route"


@requires_hermes
def test_initial_disabled_never_registers_and_never_routes():
    """Disabled at load: registration must not occur (documented default)."""
    class _Ctx:
        def __init__(self):
            self.middleware = {}

        def register_middleware(self, kind, callback):
            self.middleware[kind] = callback

    ctx = _Ctx()
    out = native_routing.register_if_supported(
        ctx, settings=_settings(enable_native_routing=False, enable_chat_router=False, enabled=False))
    assert out["registered"] is False
    assert ctx.middleware == {}


@requires_hermes
def test_configuration_snapshot_cannot_widen_preference_mid_attempt(monkeypatch, store_dir):
    """R4: one attempt, one verified snapshot. A mid-attempt valid->valid
    change (unrestrictive permissive config becomes default) must not widen."""
    restrictive = _settings(requires_tools=True, model_preference={"mode": "none"})
    permissive = _settings(requires_tools=True)  # no preference: unrestricted legacy default
    seq = iter([restrictive, permissive, permissive, permissive])

    def _loader():
        return {"plugins": {"entries": {"autorouter": {"settings": next(seq)}}}}

    monkeypatch.setattr("hermes_cli.config.load_config_readonly", _loader)
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128-r4-1")
    assert out["status"] == "refuse"
    assert out["provider"] is None and out["model"] is None


@requires_hermes
def test_configuration_snapshot_cannot_widen_authorization_mid_attempt(monkeypatch, store_dir):
    restrictive = _settings(requires_tools=True, providers=["nvidia"])
    permissive = _settings(requires_tools=True, providers=["nvidia", "openrouter"])
    seq = iter([restrictive, permissive, permissive])

    def _loader():
        return {"plugins": {"entries": {"autorouter": {"settings": next(seq)}}}}

    monkeypatch.setattr("hermes_cli.config.load_config_readonly", _loader)
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128-r4-2")
    assert out["status"] in ("refuse", "route")
    if out["status"] == "route":
        # if the attempt routed, it must honor snapshot 1's restrictive
        # authorization, never snapshot 2's wider one.
        assert out["provider"] == "nvidia"


@requires_hermes
def test_configuration_snapshot_cannot_engage_after_flag_turned_off(monkeypatch, store_dir):
    disengaged = _settings(requires_tools=True, enable_native_routing=False)
    engaged = _settings(requires_tools=True, enable_native_routing=True)
    seq = iter([disengaged, engaged, engaged])

    def _loader():
        return {"plugins": {"entries": {"autorouter": {"settings": next(seq)}}}}

    monkeypatch.setattr("hermes_cli.config.load_config_readonly", _loader)
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-128-r4-3")
    # snapshot 1 has the mode off; consumer must stay on passthrough and
    # never ride on snapshot 2's engaged flag.
    assert out["status"] == "passthrough"


@requires_hermes
def test_primary_enabled_non_true_values_refuse_after_registration(monkeypatch, store_dir):
    """R5: post-registration, ANY non-True primary enabled must refuse."""
    valid = _settings(requires_tools=True, enable_native_routing=True, enable_chat_router=True)
    monkeypatch.setattr("hermes_cli.config.load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": valid}}}})
    assert _consumer_route(store_dir, session_id="s-134-r5-seed")["status"] == "route"

    _forbid_network(monkeypatch)
    for bad in (False, None, 0, "false", "true", 1, ["true"]):
        revoked = dict(valid, enabled=bad)
        monkeypatch.setattr("hermes_cli.config.load_config_readonly",
                            lambda cfg=revoked: {"plugins": {"entries": {"autorouter": {"settings": cfg}}}})
        for sid, meta in (("s-134-r5-b", {}),
                          ("s-134-r5-a",
                           {"selection_mode": "manual", "requested_model": "autorouter/auto-free"})):
            out = _consumer_route(store_dir, session_id=f"{sid}-{bad!r}", **meta)
            assert out["status"] == "refuse", (bad, meta, out)
            assert out["provider"] is None and out["model"] is None


@requires_hermes
def test_missing_primary_enabled_key_refuses(monkeypatch, store_dir):
    valid = _settings(requires_tools=True, enable_native_routing=True, enable_chat_router=True)
    monkeypatch.setattr("hermes_cli.config.load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": valid}}}})
    assert _consumer_route(store_dir, session_id="s-134-miss-seed")["status"] == "route"

    missing = _settings(requires_tools=True, enable_native_routing=True, enable_chat_router=True)
    missing.pop("enabled")
    monkeypatch.setattr("hermes_cli.config.load_config_readonly",
                        lambda: {"plugins": {"entries": {"autorouter": {"settings": missing}}}})
    _forbid_network(monkeypatch)
    for sid, meta in (("s-134-missing-b", {}),
                      ("s-134-missing-a", {"selection_mode": "manual",
                                           "requested_model": "autorouter/auto-free"})):
        out = _consumer_route(store_dir, session_id=sid, **meta)
        assert out["status"] == "refuse"
        assert out["provider"] is None and out["model"] is None


@requires_hermes
def test_r5_never_registered_default_still_passes_through():
    class _Ctx:
        def __init__(self):
            self.middleware = {}

        def register_middleware(self, kind, callback):
            self.middleware[kind] = callback

    ctx = _Ctx()
    out = native_routing.register_if_supported(
        ctx, settings=_settings(enable_native_routing=False, enable_chat_router=False, enabled=False))
    assert out["registered"] is False
    assert ctx.middleware == {}


@requires_hermes
def test_r6_raw_model_mode_unrestricted_cannot_override_preference_none(monkeypatch, store_dir):
    """R6: mode=none in canonical preference + raw model_mode=unrestricted."""
    cfg = _settings(requires_tools=True,
                    model_preference={"mode": "none", "include": [], "exclude": []})
    cfg["model_mode"] = "unrestricted"
    _patch_valid(monkeypatch, **cfg)
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-134-r6-1")
    assert out["status"] == "refuse"
    assert out["provider"] is None and out["model"] is None


@requires_hermes
def test_r6_raw_model_include_pairs_empty_cannot_override_allowlist(monkeypatch, store_dir):
    cfg = _settings(requires_tools=True,
                    model_preference={"mode": "allowlist", "include": ["nvidia/nvidia-free"],
                                      "exclude": []})
    cfg["model_include_pairs"] = []
    cfg["model_mode"] = "unrestricted"
    _patch_valid(monkeypatch, **cfg)
    out = _consumer_route(store_dir, session_id="s-134-r6-2")
    assert out["status"] == "route"
    assert (out["provider"], out["model"]) == ("nvidia", "nvidia-free")


@requires_hermes
def test_r6_raw_model_exclude_pairs_empty_cannot_override_exclusion(monkeypatch, store_dir):
    cfg = _settings(requires_tools=True,
                    model_preference={"mode": "unrestricted", "include": [],
                                      "exclude": ["nvidia/nvidia-free"]})
    cfg["model_exclude_pairs"] = []
    cfg["model_mode"] = "allowlist"
    cfg["model_include_pairs"] = [("nvidia", "nvidia-free")]
    _patch_valid(monkeypatch, **cfg)
    out = _consumer_route(store_dir, session_id="s-134-r6-3")
    # Canonical exclusion of nvidia-free survives the raw override; the
    # remaining eligible free model routes instead (never nvidia-free).
    assert out["status"] == "route"
    assert (out["provider"], out["model"]) == ("openrouter", "qwen/qwen3-coder:free")


@requires_hermes
def test_r6_raw_internal_keys_do_not_override_derived_restrictions(monkeypatch, store_dir):
    cfg = _settings(requires_tools=True,
                    model_preference={"mode": "none", "include": [], "exclude": []})
    cfg["min_context"] = 2048          # would widen context floor to 2048
    cfg["requires_tools"] = False      # would drop tools requirement
    cfg["cooldown_seconds"] = 3600
    cfg["policy"] = "yolo"             # would pass through raw policy
    cfg["model_mode"] = "unrestricted"
    cfg["model_include_pairs"] = [("nvidia", "nvidia-free")]
    cfg["model_exclude_pairs"] = []
    _patch_valid(monkeypatch, **cfg)
    _forbid_network(monkeypatch)
    out = _consumer_route(store_dir, session_id="s-134-r6-4")
    assert out["status"] == "refuse"
    assert out["provider"] is None and out["model"] is None
