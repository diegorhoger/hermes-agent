"""Launch-claim traceability and regression coverage, not a shipped-feature badge."""
import copy
import importlib.util
import json
from pathlib import Path

import pytest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('claim_checker',ROOT/'tools/check_product_claims.py')
checker=importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)


def contract():
    return json.loads(checker.CONTRACT.read_text())


def test_all_24_commitments_resolve_to_actual_paths_and_test_functions():
    data=contract()
    errors,proofs=checker.validate(data)
    assert errors==[]
    assert proofs and len(data['claims'])==24
    doc=(ROOT/'docs/internal/product/claims-v1.md').read_text()
    for claim in data['claims']:
        assert f"## {claim['id']} — {claim['title']}" in doc
        assert claim['website']['quote'] in doc
        assert claim['proofs'][0] in doc
        assert claim['limitation'] in doc


@pytest.mark.parametrize('mutation', ['missing_claim','duplicate','missing_proof','missing_path','missing_gate','unsafe_path','unowned'])
def test_missing_or_invalid_acceptance_coverage_fails(mutation):
    data=contract()
    if mutation=='missing_claim':data['claims'].pop()
    elif mutation=='duplicate':data['claims'][1]['id']=data['claims'][0]['id']
    elif mutation=='missing_proof':data['claims'][0]['proofs']=['tests/test_preview.py::test_not_real']
    elif mutation=='missing_path':data['claims'][0]['implementation']=['not_real.py']
    elif mutation=='missing_gate':data['claims'][0]['release_gate']=''
    elif mutation=='unsafe_path':data['claims'][0]['implementation']=['../README.md']
    else:data['claims'][0]['owner_issue']='https://untrusted.invalid/issue'
    assert checker.validate(data)[0]


def test_website_source_changes_are_detected(tmp_path):
    data=contract()
    # No substitute local source is allowed to certify the frozen quotation.
    assert checker.validate(data,website=tmp_path)[0]


def test_mapping_success_is_not_release_readiness(capsys):
    assert checker.main(['--release'])==2
    output=json.loads(capsys.readouterr().out)
    assert output['mapping']=='PASS'
    assert output['proof_execution']=='NOT_EXECUTED'
    assert output['release']=='BLOCKED'
    assert not output['independent_release_acceptance']
    assert 'AC-C13' in output['incomplete_claims']


def test_free_first_mismatch_and_host_apply_gap_are_not_silently_redefined():
    claims={c['id']:c for c in contract()['claims']}
    assert claims['AC-C13']['state']=='blocked'
    assert 'paid' in claims['AC-C13']['limitation']
    assert claims['AC-C22']['state']=='blocked'
    assert 'apply/use' in claims['AC-C22']['limitation']


@pytest.mark.parametrize("kind,expected,exit_code", [("pass","PASS",0),("skip","INCOMPLETE",1),("failure","FAIL",1),("error","FAIL",1),("missing","FAIL",1),("empty","FAIL",1),("deselected","FAIL",1),("parameter_missing","FAIL",1)])
def test_fresh_proof_execution_requires_real_results_without_skips(monkeypatch, capsys, kind, expected, exit_code):
    from types import SimpleNamespace
    def fake_run(command, **kwargs):
        proofs=checker.validate(contract())[1]
        nodes=[proof+'[case]' for proof in proofs]+[proofs[-1]+'[second-case]']
        if '--collect-only' in command:
            assert 'PYTEST_ADDOPTS' not in kwargs['env']
            return SimpleNamespace(returncode=0,stdout='\n'.join(nodes))
        report=Path(next(value.split('=',1)[1] for value in command if value.startswith('--junitxml=')))
        if kind!='missing':
            tag={"skip":"<skipped/>","failure":"<failure/>","error":"<error/>"}.get(kind,"")
            selected=nodes[:1] if kind=='deselected' else nodes[:-1] if kind=='parameter_missing' else nodes
            cases='' if kind=='empty' else ''.join('<testcase classname="'+node.split('::')[0][:-3].replace('/','.')+'" name="'+node.split('::')[1]+'">'+tag+'</testcase>' for node in selected)
            report.write_text('<testsuites><testsuite>'+cases+'</testsuite></testsuites>')
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(checker.subprocess,'run',fake_run)
    assert checker.main(['--run-proofs'])==exit_code
    result=json.loads(capsys.readouterr().out)
    assert result['proof_execution']==expected
    assert result['release']=='BLOCKED' and not result['independent_release_acceptance']
