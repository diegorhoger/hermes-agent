# Quick start

A practical first-run path. Every step is reversible.

1. **Open AutoRouter.** Run `hermes dashboard`, select the **AutoRouter** tab. If it is missing, run `hermes plugins enable autorouter` and restart.
2. **Check provider availability.** Open **Providers** and read the presence labels. `Credential present, validity unknown` means Hermes has an observed process credential or OAuth state — it says nothing about pertinence or entitlement. `Credential not observed` means no evidence — presence is never inferred.
3. **Refresh the catalog.** On **Models**, press **Refresh catalog**. The count updates per provider (e.g. `nvidia 83 · openrouter 447 · nous 0`). If it fails, see [troubleshooting](troubleshooting.md).
4. **Inspect eligible models.** Use the **Eligibility: Eligible only** filter and read the ineligibility reasons shown for every other row. Everything you see is computed from the stored evidence — nothing is invented.
5. **Configure routing rules.** Set policy, free-only restriction, minimum context, tool requirement, allowlist, model include/exclude and cooldown on the Overview or Settings tabs. Remember: settings apply on the next plugin load, not immediately.
6. **Enable chat routing (optional).** Only if you want chats to route through `autorouter/auto-free`: enable `enable_chat_router: true`, restart, then pick **AutoRouter** in `/model`.
7. **Watch it select.** Send a chat. The **Analytics** tab records what was attempted — successes, failures and historical small-sample evidence are kept verbatim.
8. **Refusals are the product.** If the catalog is empty or no model qualifies, you get a clear refusal *before* any network request — never a paid model, never a silently substituted one. With routing disabled, be aware the host may attempt to send the literal virtual identifier upstream; fix any unresolved-pin warning immediately.

## Suggested first session

```text
hermes plugins enable autorouter
# edit <HERMES_HOME>/config.yaml: authorized providers, enabled: true
restart the gateway
hermes dashboard            → AutoRouter tab
Providers                   → confirm presence labels
Models → Refresh catalog    → confirm counts
Settings                    → policy auto, min_context 8192, free-only on
/model → AutoRouter         → (enable_chat_router: true first)
```

If anything looks off, every UI label is truthful about what is *not* known — prefer the label over the assumption.
