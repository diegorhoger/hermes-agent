# Troubleshooting

Reproducible diagnostics, in order. No credentials required or requested anywhere here.

## Plugin not visible in dashboard

1. `hermes plugins enable autorouter` — adds `autorouter` to `plugins.enabled`; then **restart Hermes/dashboard**.
2. Confirm the extracted plugin is at `<HERMES_HOME>/plugins/autorouter/plugin.yaml`.

Then reload `/autorouter`. If Hermes reports plugin load errors, see Hermes logs.

## Dashboard unavailable / empty tab

- Confirm the profile you are using is the one with the plugin: `HERMES_HOME` matters.
- The tab is mounted only when `plugins.enabled` contains `autorouter` — by design.
- Core plugin unaffected by dashboard outages; check `hermes dashboard` logs.

## Provider not detected

- **Presence label `Credential not observed`** — authorize in Hermes (NVIDIA/OpenRouter need no key for catalog discovery; Nous Portal needs `hermes auth nous`-style sign-in handled by Hermes).
- **OpenRouter models present but ineligible** — zero price unverifiable; that is expected, not a bug.
- **Nous after sign-in → 0 rows** — entitlement is UNKNOWN by design without host quota authority; nothing is invented.

## Refresh catalog fails

- Verify outbound network and proxy rules for the provider endpoints (catalogs are GET-only and read-only).
- Partial success publishes partial evidence; the rest retains prior provenance.
- Repeated failure → check provider status; no retry is performed by you beyond refresh.

## No eligible models

- Relax `min_context` (e.g. 8192 → 4096) and/or `requires_tools: false`.
- Widen `providers` if authorized providers were excluded by accident.
- Check the exact ineligibility rule per row — it is always specific.
- Confirm health is not auth-failed on the provider side (re-authorize in Hermes).

## Refusal on `/model` or in chat

By design, when nothing eligible exists. Inspect the Models tab for reasons; there is no override that admits unpaid/verified models without evidence.

## Virtual model unresolved (`autorouter/auto-free`)

1. Enable `enable_chat_router: true` and restart — or better, set a real model as `model: default` with `/model`.
2. If chat routing was disabled, the dashboard shows a red warning while the pin remains — fix the pin, restart, confirm the banner cleared.
3. With the adapter absent, stock Hermes may forward the literal `autorouter/auto-free` to your endpoint. The guard can detect and report that pin but cannot block the request — fix it before your next chat; do not rely on the warning as protection.

## Adapter not activated

With `enable_chat_router: true`, a healthy Hermes logs the adapter activation. If Hermes v0.23.x changed internal bindings, the adapter logs a failure at plugin load and interposition stays inert — visible in the dashboard as "restart_required/unknown". Chat routing then does nothing (safe); open an issue with the Hermes version and the plugin-load log.

## Settings did not fully apply

Settings apply one key at a time. Partial batch saves persist earlier keys only; the dashboard reports exactly which keys were saved and which were not. Re-issue with the failing key corrected.

## Status and verification commands

```sh
python3 -m pytest -q                  # unit evidence for your checkout
python3 -m pytest tests/browser       # UI harness evidence
```

These verify the repository you built from, not your installed deployment — for that, run the checklist in [installation.md](installation.md).
