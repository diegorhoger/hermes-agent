# Installation

Everything below is copy-and-paste working shell. Replace `main` with any ref/SHA you want to build. No step touches `~/.hermes` unless you explicitly point production at it.

The validation workflow uses an **isolated** profile (`$HOME/.hermes-autorouter`); your everyday Hermes profile is never touched.

## 1. Clone and pin the source

```sh
export WORK="$(mktemp -d)"
git clone https://github.com/diegorhoger/autorouter.git "$WORK/autorouter"
cd "$WORK/autorouter"
git checkout origin/main          # or: git checkout <sha>
sha=$(git rev-parse HEAD)
echo "building $sha"
```

## 2. Build the package

```sh
mkdir -p "$WORK/dist"
python3 tools/build_package.py --repo . --revision "$sha" --output "$WORK/dist"
```

Prints the artifact path, SHA-256, source/tree IDs and file count. The build is deterministic: same revision twice → identical bytes.

## 3. Locate and verify the artifact

```sh
artifact="$WORK/dist/autorouter-0.2.0-${sha:0:12}.zip"
(cd "$WORK/dist" && shasum -a 256 -c "$artifact.sha256")
```

`shasum` prints `autorouter-….zip: OK` (Linux: use `sha256sum -c`).

Every file inside is integrity-pinned and the manifest pins `source_sha` to your checkout:

```sh
python3 - "$artifact" <<'EOF'
import hashlib, json, sys, zipfile
z = zipfile.ZipFile(sys.argv[1])
m = json.loads(z.read("autorouter/PACKAGE-MANIFEST.json"))
bad = [e["path"] for e in m["files"]
       if hashlib.sha256(z.read("autorouter/" + e["path"])).hexdigest() != e["sha256"]]
print("source_sha:", m["source_sha"], "\nfiles:", len(m["files"]), "\nmismatches:", bad or "none")
assert not bad
EOF
```

`source_sha` must equal `git rev-parse HEAD` printed earlier.

## 4. Install into an isolated profile

```sh
export HERMES_HOME="${HERMES_HOME:-$HOME/.hermes-autorouter}"
install_dir="$HERMES_HOME/plugins"
mkdir -p "$install_dir"
# never overwrite silently: preserve whatever is already there
if [ -e "$install_dir/autorouter" ]; then
  mv "$install_dir/autorouter" "$install_dir/autorouter.bak.$(date +%Y%m%d%H%M%S)"
  echo "existing install preserved as $install_dir/autorouter.bak.*"
fi
python3 -m zipfile -e "$artifact" "$install_dir/"
```

## 5. Enable and configure

```sh
hermes plugins enable autorouter
```

This only appends `autorouter` to `plugins.enabled`. Restart the gateway so the plugin loads. Then authorize an existing provider:

```yaml
# $HERMES_HOME/config.yaml
plugins:
  entries:
    autorouter:
      settings:
        enabled: true
        providers: [nvidia]          # or openrouter
        free_only: true
        cooldown_seconds: 60
```

Restart the gateway again (settings are not hot-applied).

## 6. Open the dashboard

```sh
hermes dashboard
```

The plugin mounts `/autorouter`; the tab and its API appear only for the profile it was enabled in. If Hermes prints a port other than 9119 territory, use it.

## 7. Smoke test

```text
AutoRouter tab → Settings / Overview lists the plugin as enabled
Models → Refresh catalog → non-zero count
Providers → presence labels render
autorouter_select → eligible model or clear refusal
```

## Uninstall / rollback

```sh
hermes plugins disable autorouter
# keep a copy of the current plugin first
mv "$install_dir/autorouter" "$install_dir/autorouter.removed.$(date +%Y%m%d%H%M%S)"
# full removal of the extracted plugin only — state data survives:
rm -rf "$install_dir/autorouter"
# rollback to previous install, if any:
mv "$install_dir"/autorouter.removed.* "$install_dir/autorouter"
```

`plugin-data/autorouter/autorouter.db` is never touched by uninstall. If you want to erase recorded evidence too, delete that directory deliberately — it is irreversible.

## Upgrading

See [upgrading](upgrading.md). Never downgrade the SQLite schema; move forward with the exact artifact you verified, or roll back by restoring the previous plugin directory.

## Production note

None of these commands targets `~/.hermes`. To use your real profile, drop `HERMES_HOME` from the environment first (`unset HERMES_HOME`) and review what the plugin's opt-in process does — but start with the isolated profile until you are satisfied.
