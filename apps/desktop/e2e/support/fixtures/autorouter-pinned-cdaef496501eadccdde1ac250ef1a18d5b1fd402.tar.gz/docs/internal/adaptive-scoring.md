# Operational scoring and Analytics

Eligibility precedes scoring. Unknown, paid, stale or restricted access proof, insufficient context, unsupported required tools, explicit exhaustion, retirement, authentication failure and selection-time circuit state remain hard gates. Better statistics cannot authorize a denied model. AutoRouter does not replay requests, switch executing providers, schedule probes or claim protection of direct Hermes requests.

## Observations and attribution

Ranking reads the existing telemetry request and attempt tables. For each provider/model/authorized credential scope it reads at most the newest 64 request rows through `idx_requests_scoring(provider, model, key_scope, created_at, id)`, then at most 17 indexed attempt rows per request. A sample requires a stable request identity, terminal success/error, a finite original completion time no later than the evaluation time, and one through 16 attempts all attributed to that same provider and model. Pending, canceled, no-ID, missing-attempt, cross-provider/model and oversized-attempt histories do not calibrate ranking. General Analytics retains its existing observed-callback accounting; it is not relabeled as independent scoring evidence.

Connection references use the existing telemetry scope hash, not the circuit-breaker hash. A missing or changed observed scope during a pending request permanently clears that request to unknown scope. Later callbacks cannot restore a specific account attribution. Completed requests are immutable. A specific authorized scope never borrows another account's observations; unknown scope only uses unknown-scope rows. Raw connection references, credentials, prompts, responses and provider errors are not returned or added to telemetry by this change.

Old databases without the additive index or telemetry tables produce unavailable statistics and a neutral prior. Preview uses the same read-only state facade and calculations as selection, without initialization, migration, decision writes or network I/O. The dashboard Models preview also exposes that reader contract through its already-open read-only connection; both normal and dashboard readers share one bounded SQL helper and canonical legacy-health lookup. Non-neutral scoped SQLite/API regressions verify complete preview parity. Zero observed outcomes remain labeled Not observed, rather than Healthy. Invalid stored health is a generic denial, never synthesized authentication failure; Models reports health data unavailable and overview counts it separately from healthy/auth/cooldown states. Read-only legacy health error bodies use the existing migration allowlist: unrecognized values become legacy_error in model/overview output without rewriting old storage. Designated legacy request/attempt error summaries, reasons and categories use the existing telemetry category allowlist; unrecognized bodies are withheld and unknown category groups coalesce into the existing Other bucket without changing counts. Normal plugin initialization adds the index transactionally without changing the existing schema version or table layout. No telemetry pipeline is duplicated.

## Bounded calculations

For an outcome of age `a`, the evidence weight is `2 ** (-a / 604800)`: a seven-day half-life. Reliability is the decayed Beta posterior `(2 + weighted_successes) / (4 + weighted_successes + weighted_failures)`. The Beta(2,2) prior gives a cold start 0.5. One fresh success gives 0.6; 60 successes and four errors give 62/68, approximately 0.912. Old evidence decays back toward 0.5. The raw sample count and fractional effective sample count are both reported.

Latency uses only finite nonnegative observed durations. In chronological order, an EWMA with alpha 0.3 accumulates age-weighted latency and age-weighted normalization; their ratio is the latency estimate. Raw speed is `1 / (1 + latency_ewma_ms / 1000)`. It is shrunk toward neutral 0.5 by latency confidence `effective_latency_samples / (effective_latency_samples + 5)`. Reliability confidence uses the same denominator with outcome samples. Confidence is a documented evidence-weight indicator, not a statistical confidence interval or provider uptime claim. Missing latency stays null. Reported p50/p95 use nearest-rank actual durations in the bounded sample, not modeled timings or token estimates.

Observation time and staleness are explicit. The most recent sample becomes stale after one half-life; original ages are never refreshed by reading or ranking. The EWMA is an estimate from provider-observed durations; it does not claim end-to-end timing across native Hermes retries.

## Policy weights

These stable weights apply to reliability, speed, semantic quality, cooldown eligibility and verified tools respectively:

| Policy | Reliability | Speed | Semantic quality | Cooldown | Tools |
| --- | ---: | ---: | ---: | ---: | ---: |
| auto | .35 | .25 | .25 | .15 | 0 |
| fastest | .20 | .60 | .10 | .10 | 0 |
| reliable | .60 | .20 | .10 | .10 | 0 |
| smartest | .30 | .10 | .50 | .10 | 0 |
| coding | .30 | 0 | .40 | .10 | .20 |
| priority | .50 | 0 | .20 | .30 | 0 |

No independently validated semantic evaluation is available, so semantic quality is explicitly UNKNOWN and contributes a neutral 0.5. Context capacity remains an eligibility constraint and contributes no quality ranking. This intentionally changes older behavior that favored larger context windows as a quality proxy. Ties remain deterministic by provider and model. Preview exposes the exact factor values, weights, contributions, source, samples, confidence and decay used in selection.

## Analytics presentation

Existing request counts, token observations, filters, detail views and time-series metrics remain intact. Current scoring evidence for up to 25 displayed models shows bounded sample count, effective sample count, confidence, posterior reliability, latency EWMA and freshness. It uses unknown credential scope because the dashboard has no authorized account enumeration interface. These current scoring samples are independent of the selected range/status filters, and are labeled accordingly.

Selection distribution comes from recorded selection decisions, separately labeled as choices rather than executions, with at most 100 groups and an explicit truncation flag. It respects the time/provider filter; request status cannot filter a selection decision. Hourly request buckets add observed latency p50/p95 and sample counts. Missing evidence stays unavailable; no dollars, savings, inferred tokens or semantic quality are invented. All new reads use the existing read-only dashboard boundary and sanitized text rendering.

## Verification

Run `python -m pytest -q -rs tests/test_adaptive_scoring.py tests/test_preview.py tests/browser/test_harness_interactions.py`, then the complete suite. Fixtures cover the prior, robust versus small samples, frozen-clock decay and EWMA math, stale/future/malformed observations, identity and account isolation, cross-provider/model retry rejection, actual telemetry-to-ranking, indexed bounds, missing/legacy databases, paid-model denial despite excellent samples, exact preview parity and unchanged database bytes, scope changes, API accounting and browser sample/confidence presentation. No real provider credential or inference call is needed.
