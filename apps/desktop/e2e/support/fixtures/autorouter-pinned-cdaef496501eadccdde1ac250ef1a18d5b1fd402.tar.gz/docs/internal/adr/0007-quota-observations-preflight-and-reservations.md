---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Versioned multi-window observations and four preflight policies merged; host producer blocked and spending reservations deferred."
---

# ADR-0007: Quota observations, preflight policies and reservations are distinct

Quota is modeled per sanctioned connection/model/shared scope and window, with dimension, units/currency, provenance, confidence and original observation/expiry. Prefer allowance may tolerate unknown if all hard gates pass; require fresh account allowance rejects missing/stale/unknown; avoid verified exhaustion excludes only genuinely exhausted matching scope; require no-charge guarantee denies without an independently enforceable billing boundary. Unlike units are never aggregated into invented free tokens.

## Consequences and limits

Cached quota and persisted refresh leases are observations/polling coordination, not spending reservations. Atomic local reservation/settlement requires an execution owner and a separate future security program. Unknown is neither healthy nor exhausted, and 429 alone is not proof of consumed account allowance.

## Evidence and ownership

[#10](https://github.com/diegorhoger/autorouter/issues/10); [#13](https://github.com/diegorhoger/autorouter/issues/13); [#41](https://github.com/diegorhoger/autorouter/issues/41); [#42](https://github.com/diegorhoger/autorouter/issues/42); [#54](https://github.com/diegorhoger/autorouter/issues/54). Code anchors: `free_access.py`, `quota.py`, `health.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
