# milestone-03 — five-provider discovery and capability evidence

Review dependency: [milestone-01 / #38](https://github.com/diegorhoger/autorouter/issues/38).
The discovery, claims and plugin-side quota implementations are merged into
main through PR #69. Private Hermes extension tests do not establish standard-host
authority. Discovery/evidence maps to claim IDs C01/C02/C03 without promoting
partial claims or implying live entitlement.

## Source contract

Official references were checked on 7 November 2026. They describe API contracts,
not the entitlement, remaining quota or price of an operator's account.

| ID | Catalog path and source | Fields admitted from this path | Deliberately unknown | Proof level |
|---|---|---|---|---|
| `nvidia` | Native Hermes profile model IDs; [NVIDIA NIM API reference](https://docs.api.nvidia.com/nim/reference/models-1) | Successful list of identifiers and original discovery age | Context/tools/pricing not established by identifier listing | Native profile contract + offline fixtures; no live account certification |
| `openrouter` | Native Hermes profile IDs plus [official model-properties API](https://openrouter.ai/docs/api/api-reference/models/list-all-models-and-their-properties) | Explicit context, supported parameters, every supplied price component and original per-field evidence | Account entitlement, quota and hard billing stop | Actual isolated Hermes loader/profile/tool path with synthetic catalog transport; dated public observation is separate evidence |
| `groq` | Fixed `https://api.groq.com/openai/v1/models`; [API reference](https://console.groq.com/docs/api-reference) | Identifier and explicit inactive status | No context/tools/price inferred from model names or external price tables | Fixed adapter + malformed/HTTP/transport fixtures |
| `gemini` | Fixed `https://generativelanguage.googleapis.com/v1beta/models`; [models API](https://ai.google.dev/api/models) | Identifier, native `inputTokenLimit`, bounded pagination | Generation-method presence does not establish tools; price remains unknown | Fixed adapter + pagination/partial/HTTP fixtures |
| `mistral` | Fixed `https://api.mistral.ai/v1/models`; [models API](https://docs.mistral.ai/api/endpoint/models) | Identifier, explicit `max_context_length`, function-calling and archived state | Missing capabilities and catalog pricing remain unknown | Fixed adapter + partial/archive/HTTP fixtures |

No new independently reliable model-specific zero-price source was established
for NVIDIA/Groq/Gemini/Mistral. Those catalogs therefore do not gain free-only
eligibility. Promotional credit and the word “free” in a model name are not proof.
The public OpenRouter transport now shares the existing redirect-refusing,
10-second, two-MiB read boundary. Catalog normalization rejects malformed roots,
IDs, duplicates and oversized collections rather than silently calling a partial
result complete. No authenticated destination is taken from a catalog row.
Native NVIDIA/OpenRouter transport remains owned by the pinned Hermes profile;
this PR does not certify arbitrary/custom profile implementations.

## Discovery lifecycle and public presentation

The API's `intelligence.discovery_states` has one record for each of the five
fixed discovery IDs. It separates `discovery_capable`, `configured`, catalog row
count, observed discovered row count and `eligible_model_count` from
`operationally_usable: unknown`. Counts explicitly use the displayed model
snapshot (maximum 500 rows). The Providers registry presentation shows
these stages independently of the 249 unverified, inactive source candidates.
Configuration means operator selection, not a credential/authentication verdict;
that readiness contract belongs to milestone-09.

Successful native list observations are marked `discovered`. A static fallback
on native transport failure is marked `candidate`; it cannot satisfy verified
eligibility or refresh prior field proof. Complete successful catalogs, including
an empty catalog, tombstone absent cached IDs as `removed`, unavailable, unknown
cost and unsupported tools. Failed/malformed catalogs do not claim removal and
retain original evidence ages. Tombstones remain visible for auditability and
are not counted as discovered models. Partial metadata retains each independent
field's original source/expiry; it cannot extend a price proof's lifetime.

## Executable acceptance

- `tests/test_discovery_conformance.py`: bounded OpenRouter transport delegation,
  malformed/partial catalogs, native empty-list revocation, failed native static
  fallback candidate handling, unchanged field ages, invalid identifiers and
  the five-stage public contract.
- `tests/test_provider_adapters.py`: fixed origins, auth only in headers,
  native pagination, missing credentials, 401/403/429/5xx, transport failure,
  oversized responses, inactive/removed models and no inferred free pricing.
- `tests/test_verified_metadata.py`, `tests/test_access_evidence.py`,
  `tests/test_evidence_gate.py`: independent field freshness and hard cost gates.
- `tests/integration/test_acceptance_gates.py`: actual clean archived Hermes
  `PluginManager`, actual native OpenRouter profile and registered tool functions
  exercise refresh -> persisted capability evidence -> eligible recommendation.
  Only catalog responses are synthetic; no live credentials, provider calls or
  inference are used. Strict no-charge and original-expiry checks still deny.

The isolated host acceptance proves the supported plugin workflow for that
fixture, not real-world account entitlement, end-to-end inference or launch
acceptance for every account. Final release must retain independently reviewed
exact-HEAD evidence, execute milestone-14's clean installation and obtain any separately
authorized live-provider acceptance. This issue does not close those gates.
