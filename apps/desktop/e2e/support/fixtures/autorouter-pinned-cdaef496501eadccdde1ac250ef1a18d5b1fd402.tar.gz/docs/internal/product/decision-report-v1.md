# Decision evidence report v1

Every canonical evaluated decision now includes `evidence_report`. Router selection,
read-only preview, tools and dashboard return the same projection of the same
eligibility and scoring result. The report does not evaluate eligibility again,
fetch credentials, discover providers, run inference or grant execution authority.

## Contract

- `schema_version: 1`; unsupported requested report versions reject explicitly.
- Generated time, canonical policy/version, explicit task/profile version, applied
  requirements, selected provider/model or null, no-match/contract error.
- Candidate eligibility, original authored rejection codes/text and deterministic
  next-action codes; total/eligible counts and truncation.
- Named hard-check groups and source-attributed price/context/tools proof, with
  original retrieval/expiry and fresh/expired/unknown state. `not_rejected` means
  the canonical check did not reject; it is not independent proof of an unknown fact.
- Active-connection observation authority versus unknown, observed health/circuit
  diagnostics, quota state and bounded sanitized windows. A cached allowance does
  not establish current credential authority or enforce provider billing.
- Existing score factors/contributions, sample/effective counts, confidence, latency
  measurement timestamps and boundary. Operational measures are not semantic quality.
- Explicit unknown semantic quality, limitations and `execution_authority: false`.

The report is additive; existing decision fields and policy/profile aliases are
preserved. `decision_report.build(decision, schema_version=1)` projects an already
evaluated result. It has no store/network/credential dependency. The optional
`selection_requirements` uses the canonical public contract, including masked
opaque constraints. No account IDs, scope hashes, prompts, completions or raw errors
are projected. Unknown source labels and non-allowlisted/query-bearing URLs are not
copied; public catalog/quota sources are allowlisted. Unsafe/oversized identity
strings are explicitly redacted in the report, never used as execution targets.

Candidates are limited to the existing canonical display maximum of 500; ranking
still considers the full snapshot. If the canonical winner lies outside the
alphabetical display window, one existing report/UI slot is reserved for its full
evidence; the requested display bound is preserved. Quota windows are limited to 32. Field/factor
names are fixed; numeric measurements must be finite. The website-parity fixture
is explicitly synthetic and cannot establish live entitlement.

## No match, missing and corrupt state

An evaluated empty catalog is `no_match` with absent evidence, not a healthy result.
A missing/unreadable database produces a separate unavailable report in Models;
POST preview returns 503 with that report rather than an apparently successful
recommendation. Reads never initialize or repair a database. Authenticated preview
still performs no discovery, network, credential resolution or decision write.

Next actions are authored suggestions: refresh public metadata deliberately,
review requirements, configure credentials in Hermes, wait for cooldown/verified
quota refresh, obtain supported host authority or choose another model. They do not
perform those actions. A successful recommendation directs a deliberate Hermes
handoff; Apply/Use remains #45's responsibility.

## Dependencies and evidence

The explicit-profile (#60), canonical-policy (#53), discovery (#57), scoped-quota
(#36/#58) and evidence-report (#61) implementations are merged into main through
#69. Cached quota observations and unknown active scope remain distinct. This
integration does not supply a sanctioned standard-host quota producer, current
account authority or live entitlement.

Tests cover exact tool/API/selection/preview parity, absent/corrupt SQLite, stale or
revoked price, unsupported tools, health/cooldown, exhausted quota and unknown scope,
version rejection, deterministic/bounded serialization and privacy. Browser controls
use safe text rendering; actual isolated Hermes tests assert identical reports for
registered tools and preview using synthetic public evidence. No live provider or
production entitlement is established by these fixtures.
