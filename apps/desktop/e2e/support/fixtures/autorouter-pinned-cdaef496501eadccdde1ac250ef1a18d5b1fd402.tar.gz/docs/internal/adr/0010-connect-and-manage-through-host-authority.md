---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Read-only onboarding and truthful readiness merged; secure host credential lifecycle remains unavailable."
---

# ADR-0010: Connect and Manage Providers through secure host authority

Adopt coverage strips, searchable provider groups, named connection slots, model scopes, readiness explanations and provider-preselected onboarding flows. Choose provider, configure via host, validate if authorized, discover, check eligibility, recommend and apply are distinct steps; saving a key is not successful authentication. Connection objects and sanitized metadata require host ownership, not a second encrypted vault.

## Consequences and limits

Unavailable management operations must name the missing host capability and offer a truthful supported setup/handoff. Forms, disabled buttons or mocked receipts cannot count as working lifecycle management. Tests must cover permissions, isolation, stale/failed state, accessibility and secret-free output.

## Evidence and ownership

[#17](https://github.com/diegorhoger/autorouter/issues/17); [#18](https://github.com/diegorhoger/autorouter/issues/18); [#39](https://github.com/diegorhoger/autorouter/issues/39); [#46](https://github.com/diegorhoger/autorouter/issues/46); [#49](https://github.com/diegorhoger/autorouter/issues/49). Code anchors: `connections.py`, `dashboard/state_reader.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
