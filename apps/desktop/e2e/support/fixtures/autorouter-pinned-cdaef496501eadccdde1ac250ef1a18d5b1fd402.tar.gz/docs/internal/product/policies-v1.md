# AutoRouter V1 policy contract

`policies.contract()` is schema version 1. Tools and preview return this same
contract; Settings exposes it and renders policy labels from it. The portable
`tests/fixtures/policies-v1.json` is the website parity fixture, checked against
actual engine, tool, API and dashboard-reader behavior. Website deployment and
copy changes belong to milestone-15; this fixture does not claim the website is updated.

| Product preference | Policy ID | Task label | Meaning |
|---|---|---|---|
| General | `auto` | general | Existing balanced operational weights |
| Coding | `coding` | coding | Existing operational/tool-capability preference |
| Fast response | `fastest` | general | Higher weight for observed, confidence-adjusted speed |
| Reliability-first | `reliable` | general | Higher weight for observed, prior-adjusted reliability |

`general`, `fast-response`, and `reliability-first` are accepted aliases. The old
website name `free-first` maps to General, **not paid fallback**. Old `smartest`
and `priority` configuration IDs remain readable/selectable for compatibility;
Settings labels them as legacy. `smartest` has no verified semantic-quality
benchmark: semantic quality remains UNKNOWN for every policy. Explicit task
requirements/profiles are owned by milestone-06; these names do not manufacture coding
quality or reasoning-capability evidence.

Every V1 preference first applies the same hard constraints: fresh verified zero
price, required tools/context, configured provider, health/cooldown/concurrency,
and known quota exhaustion. `free_only=false` and `paid_authorized=true` never
relax these constraints. Settings now shows free-only as required and rejects a
new false setting; legacy configuration can still load safely. No preference
spends credits, retries execution, switches an active Hermes task or guarantees
provider billing. Strict no-charge guarantee remains unavailable and denies all
selection without an independently enforceable host/provider contract.

Unknown policies reject instead of silently becoming General. Missing/stale cost
proof rejects even a model whose name says “free.” Ranking ties sort by provider
then model. No match returns no recommendation and explicit rejection evidence;
it must not trigger paid or cross-provider execution fallback. Tool selection
returns the evidence from its **same** evaluation, rather than a second preview
that might disagree with selection.

## Integrated dependencies and authority

Claims (#52), canonical policy (#53), scoped storage/quota (#36/#58), discovery
(#57) and explicit profiles (#60) are merged into main through #69. Their original
candidate/review states are historical, not current landing blockers. Source
inclusion does not establish standard-host credential authority, website parity,
independent exact-artifact acceptance or release permission.

## Amended selection-policy request v1

`selection_policy.py` adds a separate version-1 request envelope, preserving the
existing version-1 ranking metadata, IDs and aliases. The portable JSON fixture
and tool schema define six required fields:

- `schema_version: 1` — unsupported versions reject, with a bounded error code.
- `hard_eligibility` — mandatory verified-free-only, required/forbidden verified
  tool capability, minimum context, authorized providers, explicit model exclusions,
  observed local concurrency limit and health/cooldown rules. Requiring observed
  health also requires an explicit maximum observation age. Unknown hard facts deny.
- `preferences` — an existing ranking policy; hard gates precede score weights.
- `task_requirements` — version, explicit label, capability and context requirements.
  Requirements compose; contradictory tools requirements reject. Coding is a label,
  not evidence of competence. The explicit profile catalog is provided by #43; no classifier is authorized.
- `connection_restrictions` — provider, opaque connection constraint, required
  authority, allowed model pairs and optional shared quota scope. References are
  constraints, not grants. An explicit connection/shared-scope ID requires provider
  identity. The public decision masks opaque IDs rather than exporting them.
- `quota_policy` — one of #41's four preflight modes, subordinate to cost eligibility.

Use `Router.preview(selection_policy=...)`, `Router.select(selection_policy=...,
return_decision=True)`, `autorouter_select`'s `selection_policy` argument, or the
host-authenticated `POST /api/plugins/autorouter/selection/preview` with
`{"selection_policy": ...}`. The dashboard endpoint is read-only: no discovery,
credential resolution, settings update, decision write or inference. Its result
uses the same evaluator as selection/tools. Corrupt or missing state returns an
unavailable response; malformed input returns authored errors without echoing it.

### Authority and executor independence

Adapter-owned `SelectionContext` and `ConnectionContext` bind an observation to
current opaque profile/session/request, provider, connection, model/shared scope,
permission and original time/expiry. They are internal typed context, not public
request JSON. A matching opaque ID, a cached allowance or legacy
`credential_scopes` map cannot construct that authority. Missing, revoked, expired,
future-version or different-session context denies hard connection requirements.
Contexts convey authorized **observation**, never permission to execute or apply.

No production context producer is fabricated. Standard Hermes v0.23.0 lacks the
required active-scope contract. A separately accepted adapter must supply the
current typed context through trusted internal state; #45 owns Apply/Use receipts.
No Hermes dependency is imported by this pure contract module.

### Integrated quota boundary

A trusted pure evaluator may be supplied internally using the existing #58 shape:
`evaluate_policy(snapshot, provider, model, scope, now, quota_policy=...)` returns
`quota_policy_version: 1`, matching policy, allowed/state/preference and a
version-1 allowance with provider, canonical account scope and bounded windows.
The integrated router uses the existing #58 evaluator by default. Adversarial
fixtures can supply synthetic source-attributed responses; these are not live
host quota or an independent quota engine.

The selection boundary checks result version, provider/scope binding and freshness
using existing metadata/quota helpers. It preserves supported sources, original
ages/expiry and explicit unsupported-window uncertainty; it does not convert units
or combine currencies. Opaque/account context is removed from public evidence.

- Prefer mode uses a separately explained fresh-allowance ranking preference only
  when supported fresh evidence and current context exist; unknown is not positive.
- Require-fresh mode denies absent, stale, mismatched or incompatible authority/data.
- Avoid-exhaustion retains existing verified-exhaustion rejection; 429/timeout alone
  does not establish exhausted quota. Health/cooldown gates still apply separately.
- Require-no-charge remains denied: no inspected enforceable billing boundary exists.

Without the evaluator/context, normal best-effort quota modes retain UNKNOWN while
strict modes deny. After independently accepted #36/#58 merges, connect their pure
cached evaluator through the approved adapter and rerun integration acceptance;
real active connection authority remains an external host gate. No authenticated
request, spending controller, reservation, retry/failover or gateway is introduced.

Fixtures are explicitly synthetic. Website parity data is updated here in
AutoRouter only; the website is unchanged. Existing configurations and false legacy
paid/free flags cannot relax verified-free-only eligibility.

## Explicit profile extension

The dependent milestone-06 implementation adds an optional versioned `profile` declaration
to `task_requirements`; see [task profiles v1](task-profiles-v1.md). Existing v1
requests without this field retain the policy-contract behavior documented above.
