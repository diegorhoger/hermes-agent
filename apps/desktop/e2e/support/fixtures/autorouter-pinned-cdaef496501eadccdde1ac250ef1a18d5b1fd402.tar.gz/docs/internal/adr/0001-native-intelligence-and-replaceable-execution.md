---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Native intelligence and manual execution adapter merged; standard-host context-bound Apply/Restore unavailable."
---

# ADR-0001: Hermes-native intelligence with replaceable execution

AutoRouter V1 remains a Hermes-native model-intelligence product, with discovery, evidence, policy, selection, explanations and outcomes kept separate from execution authority. A versioned execution adapter declares capabilities, validates an eligible target in sanctioned context and performs deliberate apply only when the host confirms it. A manual handoff is pending, not applied. This preserves the small native trust surface while allowing a separately authorized future gateway to reuse the same engine rather than making V1 depend on a proxy.

## Consequences and limits

Previously the implementation avoided a gateway; the new owner decision permits a future gateway direction, not gateway implementation in V1. A host adapter cannot promise execution, streaming, retries or spending enforcement merely because it can recommend a model.

## Evidence and ownership

[#37](https://github.com/diegorhoger/autorouter/issues/37); [#45](https://github.com/diegorhoger/autorouter/issues/45); [#54](https://github.com/diegorhoger/autorouter/issues/54). Code anchors: `README.md`, `integration.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
