# Quota evidence and credit estimates

`quota_evidence` is an optional list in existing capability JSON; no SQLite schema change is needed. Each record describes one provider/model/account/shared pool and one dimension: `input_tokens`, `output_tokens`, `aggregate_tokens`, `requests`, or `credits`. Requests per minute/day use `dimension=requests` and `window=minute|day`; tokens per minute use `aggregate_tokens` and `minute`. Windows also include `month`, `one_time`, and `unknown`. Separate input/output caps are separate records; shared pools share the same opaque `shared_scope`, and must not be summed as independent allowance.

The contract retains limit/remaining as exact decimal strings, currency denomination, reset timestamp/timezone, rollover, grant expiry, signup/KYC restrictions, source URL/type/issuer, source-of-truth flag, observation/expiry timestamps, confidence, spendability and original scope. Unknown numeric fields remain null. `source=advertised` describes a claim; `provider_api|mapped_headers` describes an observation; `configured|estimated|unknown` remain distinct. Never put raw credentials in an account or shared scope. These are plugin metadata identifiers, not credential storage.

`quota.normalize_quota` allowlists fields and validates amounts and timezone. `quota.quota_status` reports remaining allowance only for a fresh source-attributed account observation. Expired grants report `expired`; passed reset timestamps report unknown until reobserved. It never assumes rollover or replenishes balances. One-time grants cannot become recurring monthly quotas. No automatic daily-to-monthly extrapolation is performed. Source-claim fixtures from issue #10 remain unverified examples, including the FreeModel.dev and AgentRouter dollar claims; they are not shipped as production quota evidence.

`quota.estimate_credit_tokens` requires fresh verified model-level input/output prices per token, a fresh account-observed spendable balance in the same currency, and an explicit workload mix with its source. It returns `kind=estimate`, exact input assumptions, source ages and:

`floor(balance / (input_share * input_price_per_token + (1-input_share) * output_price_per_token))`

Exact rational arithmetic over decimal inputs floors the resulting whole token count. Missing/conflicting/stale data, unsupported extra charges or a zero denominator return unknown, never zero or infinity. The total is a workload projection, not a promised token allowance or separately spendable input/output cap. A current zero balance can project zero; absent balances cannot. Promotions do not establish free-only eligibility. This module performs no billing, provider polling, inference, host credential mutation or automatic selection activation.

Partial metadata refresh replaces only matching quota source/scope/dimension/window records and preserves independent limits and original ages. The typed capability resolver preserves normalized quota evidence. Existing SQLite capability JSON persistence works without migration; the selector still requires its existing zero-price/capability proof.

Run: `python -m pytest -q tests/test_quota.py` and the complete regression suite. The tests use temporary SQLite and deterministic fixtures; no credential is required.


## Standard-host authority gap (issue #41)

Read-only inspection on 9 November 2026 of installed Hermes commit
`2bd378ed1b8d6bf2192cb26e0a55ff3091e6bd19` establishes a boundary, not a
compatibility claim for every Hermes version. Its
`hermes_cli.plugin_provider_requests.credentialed_provider_request` validates
installed-plugin identity, declared authentication and allowed origins, and returns
no credential. Its signature has no selected credential-scope, profile/request or
attempt binding. `agent.account_usage.fetch_account_usage` accepts an `api_key`
and an `identity_id` cache label; that label is not credential-use authorization.
AutoRouter must not supply a raw key or infer the active account to bridge this gap.

The smallest requested host extension should reuse those host-owned mechanisms:

1. Hermes supplies an unforgeable plugin/profile/request-attempt binding to the
   actual selected credential. An opaque identifier alone grants no authority.
2. A permission-checked operation accepts only a named, allowlisted quota source
   (initially supported OpenRouter key limits), with host-owned authentication,
   endpoint validation, no redirects, bounded timeout/rate/concurrency and redacted
   failures. It must deny cross-plugin/profile/attempt or expired bindings.
3. The sanitized response includes provider, authorized opaque scope, source,
   original observation time, expiry and separately typed quota windows. Unsupported
   providers/windows remain unknown. Dollar credits never imply free requests.
4. Consent and capability denial cause no provider call. No plugin-selectable
   arbitrary URL, credential export, account switch, request replay or billing
   enforcement is introduced.

Host acceptance must exercise two selected accounts with different balances,
forged and stale bindings, profile/plugin/attempt mismatch, capability denial,
concurrent requests, expiry/reset, 401/403/429/timeouts and secret-bearing errors.
It must prove exact selected-account authorization without exposing the key.
Synthetic plugin callbacks prove consumer behavior only; private patched Hermes
attribution does not prove this standard-host producer exists. NVIDIA remains
unknown until a supported source is established.

Until that extension is sanctioned and tested, the account-bound collection gate
is `BLOCKED_EXTERNAL_HOST_CONTRACT`. Cached evidence is not a spending reservation
or a no-charge guarantee. Strict no-charge selection remains denied without an
independently enforceable boundary. This document requests a contract; it does not
implement or authorize a Hermes patch.
