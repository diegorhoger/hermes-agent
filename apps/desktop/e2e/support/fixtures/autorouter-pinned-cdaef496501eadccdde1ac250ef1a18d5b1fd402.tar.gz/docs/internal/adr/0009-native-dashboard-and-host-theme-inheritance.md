---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Native five-tab dashboard merged for named themes; OS-system mode externally blocked; SDK recovery repair PR #72 awaits acceptance."
---

# ADR-0009: One native five-tab dashboard inherits the host

AutoRouter extends the existing Hermes Overview, Providers, Models, Analytics and Settings surfaces, using real host theme tokens, scoped styles, safe text-only DOM rendering, host authentication and sanctioned settings writes. A separate dashboard/theme engine would duplicate state and weaken native integration. New provider-management and first-run workflows belong in these surfaces.

## Consequences and limits

Desktop system-theme support is not proof of a web-dashboard OS-theme bridge. Supported named-theme inheritance and unsupported OS-system acceptance must be reported separately; no synthetic browser fixture is presented as actual host-theme certification.

## Evidence and ownership

[#18](https://github.com/diegorhoger/autorouter/issues/18); [#26](https://github.com/diegorhoger/autorouter/issues/26); [#39](https://github.com/diegorhoger/autorouter/issues/39); [#46](https://github.com/diegorhoger/autorouter/issues/46); [#49](https://github.com/diegorhoger/autorouter/issues/49). Code anchors: `dashboard/manifest.json`, `dashboard/dist/style.css`, `dashboard/dist/index.js`, `dashboard/plugin_api.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
