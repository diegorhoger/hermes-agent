# Hermes selection handoff v1

AutoRouter owns recommendation evidence. Hermes owns credentials, account selection and
execution. This versioned adapter provides validated manual handoff; it does not
apply a model or execute a request.

## Verified host contracts and limit

Read-only installed-source inspection pinned Hermes
`2bd378ed1b8d6bf2192cb26e0a55ff3091e6bd19` (v0.23.0 checkout). `PluginContext` in
`hermes_cli/plugins.py` exposes profile metadata, plugin-local config, commands,
hooks and messaging; `plugin_session.py` exposes calling session metadata. These
are not a context-bound model-apply/restore receipt API. This is a bounded finding
for these interfaces/revision, not a permanent claim about every Hermes version.

`hermes_cli/model_switch.py: switch_model` resolves credentials and returns
credential-bearing internal runtime data. It is not used by this plugin.
`web_server_config.py: _apply_model_assignment_sync` implements profile-default
configuration changes for `/api/model/set`. Those writes are not confirmation that
an intended current session/request adopted the model, nor a sanctioned plugin
receipt/restore contract. AutoRouter does not call them or mutate shared defaults.

The installed and pinned isolated Hermes `_parser.py` accept the supported manual
syntax `hermes chat --provider PROVIDER --model MODEL`. Isolated tests parse these
arguments with the actual host parser; parsing is not execution or proof of an
actual request target. No production imports, calls, restarts or settings changes
were performed during this compatibility inspection.

## Capability and receipt contract

`execution_adapter.capabilities()` declares schema v1, `selection_handoff: true`.
Host-confirmed apply/restore, execution, streaming, retry and spending enforcement
are separately false. No inferred API grant or generic authenticated HTTP proxy.

`ManualHermesAdapter.validate_target(selection, context, ...)` accepts only a v1
provider/model/time selection, validates fixed provider IDs and safe model IDs,
rejects future or 120-second-old decisions, checks any supplied typed internal
context against the current context, and revalidates the **current canonical
recommendation** using `Router.preview()`. A changed ranking requires selecting
again; a stale/paid/unknown/rejected target cannot produce a command. Preview does
not discover, read credentials, write decisions, initialize or repair the DB.

`ExecutionContext` is an adapter-owned opaque profile/session/agent/request binding,
not public JSON or permission. Missing context is unknown. Mismatched contexts and
schema versions deny; no private host identity attributes or inferred account IDs.
A bound validation receipt does not bind a subsequently launched CLI session.

`handoff(..., confirmed=True)` prepares argv and shell-quoted display text only
after validation. Without explicit confirmation it returns recommendation evidence
and no command. No subprocess, provider call, global config write or agent mutation
occurs. Exact account/connection/model-scope requirements and require-fresh-account
allowance cannot be preserved by this manual CLI, so the handoff refuses them
rather than dropping those requirements. The owner must run any steps in the
intended Hermes profile; this command does not choose a profile or pooled account.

Receipts distinguish `recommendation`, `validation_failed`, `unavailable_evidence`
and `manual_handoff_pending`. They always report `applied/restored/executed: false`,
`actual_request_target: unobserved`, and no execution authority. `apply()` and
`restore()` return explicit unavailable receipts. No apply/restore-confirmed state
is manufactured; those require an independently authorized future host adapter.

## Tools and dashboard

`autorouter_status` exposes adapter capabilities. `autorouter_select` accepts an
optional `handoff: {confirmed: boolean}` and returns a separate handoff receipt,
using the same original requirements and canonical evaluator. Old calls keep their
existing selection meaning. A no-match never becomes a handoff.

Host-authenticated dashboard routes provide `GET /execution-capabilities` and
`POST /handoff/manual`. The latter refuses disabled plugins and unknown request
fields, and reads only existing SQLite through the read-only store. Client JSON
cannot supply context authority. Models → Preview requires an explicit confirmation
checkbox before preparing copyable manual steps and discloses that no model was
applied/executed. Profile previews retain the original validated request in their
local UI closure; handoff resends that request unchanged, not the public explanation
object with output-only fields or masked constraints. If original requirements are
unavailable, the UI refuses preparation and requires a new explicit preview. Invalid or lost opaque constraints fail closed, not silently
relaxed. There is no native Apply or Restore button claiming unsupported authority.

## Removal of unsupported legacy mutation

`integration.apply_to_agent()` now returns false without inspecting or changing the
agent. Its previous `_fallback_chain` assignment was a private, unsanctioned host
mutation and is intentionally disabled. The legacy `build_fallback_chain()` helper
remains a bounded read-only recommendation list; it does not install fallback,
record decisions, discover, execute or replay requests. Existing optional callers
must use deliberate manual handoff until a sanctioned adapter is accepted.

## Acceptance and external blocker

Unit tests cover confirmation, revalidation, versions, stale/future selections,
no-match, paid/unknown/expired proof, safe argv, exception redaction, context
isolation, disabled/missing state, and zero private-agent access. SQLite/API/tool
parity and browser controls are tested. Actual isolated Hermes loads the plugin,
prepares a handoff and parses its arguments without transport or config mutation.

**BLOCKED_NATIVE_CONTEXT_BOUND_APPLY_RESTORE:** actual intended-request targeting,
permission revocation at apply, failed host apply, host-confirmed previous selection
and restore cannot be accepted without a supported host contract. Parser/observer
fixtures are not substitutes for those gates. #50 owns subsequent decision-to-request
correlation; no success is inferred from matching model names. #39/#49 can reuse
these truthful capabilities/receipt states. #45 is closed for bounded adapter delivery; native acceptance remains blocked.

The #62/#61/#60/#53 plugin dependencies are merged through #69. Their source
inclusion does not establish missing host execution authority.
No #36/#58 duplication, Hermes patch, credential vault, gateway, paid inference,
retry/replay, production changes or release.
