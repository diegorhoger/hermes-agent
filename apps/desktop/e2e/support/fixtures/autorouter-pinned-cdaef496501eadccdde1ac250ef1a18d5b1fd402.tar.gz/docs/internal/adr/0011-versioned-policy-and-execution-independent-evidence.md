---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Execution-independent canonical policy, explicit profiles and evidence report merged; host authority remains separate."
---

# ADR-0011: Versioned policies separate requirements and authority

Policy contracts separate hard eligibility, ranked preferences, explicit task suitability and sanctioned credential/connection restrictions. The intelligence engine emits the same sanitized versioned selection/evidence meaning to tools, preview, dashboard, website fixtures and future execution adapters. Unknown/invalid values and missing authority yield explicit rejection or uncertainty rather than a hidden fallback.

## Consequences and limits

An executor cannot relax hard gates or invent account identity. Schema negotiation, deterministic ties/no-match, freshness and capability denial must be tested. Adapter capabilities and apply receipts remain [#45](https://github.com/diegorhoger/autorouter/issues/45); quota-policy modes remain coordinated with [#41](https://github.com/diegorhoger/autorouter/issues/41).

## Evidence and ownership

[#38](https://github.com/diegorhoger/autorouter/issues/38); [#41](https://github.com/diegorhoger/autorouter/issues/41); [#42](https://github.com/diegorhoger/autorouter/issues/42); [#43](https://github.com/diegorhoger/autorouter/issues/43); [#44](https://github.com/diegorhoger/autorouter/issues/44); [#45](https://github.com/diegorhoger/autorouter/issues/45). Code anchors: `router.py`, `tools.py`, `eligibility.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
