# AutoRouter virtual model — deactivation boundary

**Date:** 2026-11-13
**Scope:** `autorouter/auto-free` when chat routing is **disabled**
**Applies to:** the dashboard deactivation toggle, a gateway started with
`enable_chat_router: false`, and a failed adapter load.

## Exact boundary

Hermes has no sanctioned plugin interception point that can block or rewrite
a model request when the AutoRouter chat-router adapter is not interposed.
When the adapter is absent (flag off, plugin removed, loader failure,
`disable()` called, or a Hermes upgrade moved a patched binding and the
plugin logged the failure) the plugin cannot see, stop or rewrite the
next outbound chat request. **No part of this document or the implementation
claims otherwise.**

When `enable_chat_router: true` and the adapter interposed correctly, the
adapter fails closed *before any network execution*: the virtual marker is
resolved to an eligible real free route, or the request is refused. The
marker never reaches a provider.

When the adapter is disabled or failed, a profile whose persisted config pins
`model`/`model.default` to `autorouter/auto-free` would have the host send
that string verbatim to the configured endpoint. That is the unsafe condition
this work addresses.

## What the plugin does (implemented)

`virtual_pin_guard.py`, invoked from the plugin's `register()` (gateway
start/restart path) and synchronously by the dashboard settings save when
`enable_chat_router` transitions to `false`, and from nowhere else:

1. Detect unresolved virtual pins in `config.model` (flat string) and
   `config.model.default` (nested `model:` section) — read-only.
2. Detect `HERMES_INFERENCE_MODEL=autorouter/auto-free` (advisory; env pins
   are never rewritten).
3. Log a **critical**, actionable message: the profile is pinned to an
   unresolvable virtual model; the next chat would send the marker
   upstream verbatim; the user must run `/model` and select a real model,
   or re-enable AutoRouter chat routing and restart.
4. Persist a durable marker in the plugin's own store (`meta` key
   `virtual_pin_guard`). The dashboard renders it as a red banner with the
   same fix instructions. Healthy outcomes (`clear` / `routing_active`) are
   persisted too, so a stale banner disappears once the user fixes the pin.
5. **Preserve the existing configuration unchanged, byte for byte.** The
   guard never calls the host config writer. It never replaces the pinned
   provider/model, and it never carries over (or rips out) the stale
   `base_url`, `api_mode`, or credential context from the virtual-model
   configuration.

Property of the guard: it **never selects, enables or authorizes any
provider, never rewrites configuration, and never blocks a host request.**
It reports; it does not route and it does not repair.

## Why the guard is warning-only

Earlier revisions of this module restored a "previous route" inferred from
the profile's own `decisions`/`requests` tables. That path was removed:

- Those rows are **usage history, not configuration snapshots.** A selected
  model was never necessarily the configured default; a recorded request does
  not prove the request succeeded; and nothing proves the historical route is
  still appropriate, authorized or safe for future use.
- Restoring `model.default` + `model.provider` while retaining the pinned
  virtual configuration's `base_url`, `api_mode` and credential context could
  bind a real model id to the wrong endpoint or the wrong credential scope.
- Silent substitution is exactly the failure shape this guard exists to
  prevent.

Historical rows remain useful for diagnostics, but they carry no authority
to rewrite configuration. Restoration would require a **complete,
separately authorized, authoritative configuration snapshot** — model,
provider, endpoint and credential scope, with provenance and explicit user
authorization — which this plugin does not have and does not attempt to
reconstruct. If such a snapshot ever becomes available through a sanctioned
host path, automatic restoration could be reconsidered deliberately; it is
not implemented, and it is not approximated from history.

**No "previously configured route" is ever reconstructed, guessed or
inferred. With no authoritative snapshot, the correct action is always a
loud warning plus an untouched configuration.**

## What requires a sanctioned host-side guard

Anything that must happen *before* the provider wire request — refusing the
marker in the provider path, rewriting it in-flight, or forcing a fallback —
cannot be done by this plugin when the adapter is off. A correct guard
belongs in Hermes itself. Recommended shape (not implemented here; no host
patches, no production changes):

- In `resolve_startup_model_route` (and the equivalent picker-time and
  session-create paths), reject or refuse a pinned model id equal to
  `autorouter/auto-free` when the AutoRouter adapter is absent or disabled,
  with a clear error message *before any request is built*.
- Equivalently: config-load-time validation flagging `autorouter/auto-free`
  (or provider `autorouter`) as a pinned value when the chat-router
  integration is off, pointing the operator at `/model`.
- A `/model` picker affordance marking the virtual entry unavailable when
  routing is disabled.

## Operational notes

- The guard outcome is persisted in the plugin store (`meta` key
  `virtual_pin_guard`) and rendered by the dashboard Overview. The payload
  contains only the pin sources and advisory text — never endpoint values,
  credential material or other config content.
- The guard runs in any process that loads the plugin (gateway, dashboard),
  which makes restarted-gateway deactivation safe too.
- Failing safe means **refusing to choose**, never silently substituting.
- If the guard cannot run (config unreadable, store corrupt) it degrades to
  a conservative report; the plugin never fails its own load because of it.
- The guard performs no network activity. It reads the host config
  read-only (same mechanism the rest of the plugin uses) and never calls
  the host config writer.
