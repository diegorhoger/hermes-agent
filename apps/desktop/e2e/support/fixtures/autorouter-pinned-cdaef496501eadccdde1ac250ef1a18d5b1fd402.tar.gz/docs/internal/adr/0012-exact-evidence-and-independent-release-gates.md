---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Deterministic builder and isolated lifecycle merged; exact-artifact acceptance and release authorization remain separate gates."
---

# ADR-0012: Exact-revision evidence and independent release gates

Each bounded issue produces an exact-HEAD tested PR for independent review. Local source approval, synthetic tests, real isolated-host evidence, actual provider results, GitHub checks, merge acceptance and release authorization are different facts. Owner-controlled publication, production installation, repository visibility and paid usage require their own authority. Epic [#37](https://github.com/diegorhoger/autorouter/issues/37) cannot be complete while a mandatory user journey is blocked or unaccepted.

## Consequences and limits

Keep immutable history and explicit missing evidence. Do not sum overlapping suites, call unexecuted checks passed, treat candidate data as working integrations, or close host-dependent issues on a private extension. ADRs record accepted decisions, not automatically implemented behavior.

## Evidence and ownership

[#37](https://github.com/diegorhoger/autorouter/issues/37); [#38](https://github.com/diegorhoger/autorouter/issues/38); [#41](https://github.com/diegorhoger/autorouter/issues/41); [#51](https://github.com/diegorhoger/autorouter/issues/51); [#55](https://github.com/diegorhoger/autorouter/issues/55). Code anchors: `RELEASE.md`, `README.md`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
