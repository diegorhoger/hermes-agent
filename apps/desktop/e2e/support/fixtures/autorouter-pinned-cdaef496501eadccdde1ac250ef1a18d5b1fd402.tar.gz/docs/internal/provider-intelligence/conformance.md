# Provider conformance and isolated Hermes acceptance

The offline regression suite is authoritative for fixture behavior. It does not certify a provider's current pricing, credentials, available allowance, uptime, or live inference. No production deployment or release is part of this gate. Provider-epic acceptance covers its actual PIR child deliverables and credential/UX consumers; the separate #13 default-host operational blocker is recorded without adding it as a new epic dependency. The matrix below must be refreshed on the final main commit.

## Inventory accounting

The pinned source contains 249 rows and 249 stable canonical candidate IDs. There are 248 nonempty distinct source IDs and one explicitly unidentified row. The structural kinds are 198 provider entries, 24 gateways, 10 specialized services, nine plans, five deprecated entries and three regional variants. These counts describe source-derived entities, not verified companies or working integrations. A verified unique-vendor count is unknown: the source is not an independently verified corporate-identity database. The 51 non-provider-kind rows remain countable separately, without collapsing their credential, region or protocol differences.

Every source candidate remains unverified and inactive in the shipped registry. In particular, native NVIDIA and Gemini entries are distinct from their g4f gateway variants. Candidate names, signup credit claims and zero-looking model names do not establish free eligibility. See the [registry contract](registry.md) for regeneration and source preservation.

## Discovery support and eligibility

The five implemented discovery IDs are listed below. They are metadata adapters, not five new inference gateways or a claim that credentials work on a particular account. Defaults authorize NVIDIA/OpenRouter only; new adapters require explicit operator configuration. The candidate registry itself remains inactive.

| Provider ID | Discovery implementation | Fresh capability/price proof supplied by that implementation |
| --- | --- | --- |
| `nvidia` | Existing sanctioned Hermes provider profile model catalog | Identifiers only; context, tools and zero price remain unknown unless independently established |
| `openrouter` | Existing Hermes model catalog plus allowlisted public OpenRouter metadata | Explicit supported parameters, context and all supplied price components; verified zero price requires fresh model-specific evidence |
| `groq` | Fixed official read-only models endpoint | Identifiers; context/tools/price remain unknown |
| `gemini` | Fixed official native models endpoint with bounded pagination | Input context limit; generation methods do not prove tool support; price remains unknown |
| `mistral` | Fixed official read-only models endpoint | Explicit context/function-calling and archived status; price remains unknown |

See [adapter endpoints, official sources and error taxonomy](adapters.md). None performs inference. New-adapter absence, authentication failures, rate limiting, provider failures, redirects, malformed/oversized pages, removed models and stale independent prices have deterministic offline fixtures. Complete catalog removal revokes old eligibility; failed refreshes retain original evidence ages. Unsupported catalog-only, experimental gateway and source-deprecated records never acquire an adapter through their names or URL claims.

No selectable models or verified account credentials are seeded by the repository. A current count of usable accounts or successfully executed models is **not measured** by offline tests and cannot be inferred from candidate counts. A separate unauthenticated public metadata observation on 2026-11-06 at 05:50:57 UTC (02:50:57 São Paulo), using main `667813f19aa1586c65de7e714f2cb973e7724e3f`, normalized 454 OpenRouter rows: 16 had verified zero component prices at that observation, and 13 also supplied tools and context of at least 8192. The [dated observation](observed-openrouter-2026-11-06.json) preserves the original source/observation/expiry, zero-price proof and raw-response SHA-256; it is not seeded into plugin state. Only the zero-price subset is serialized; 454 is the captured full-response count, not an account inventory.

`tests/test_public_catalog_observation.py` replays those 13 metadata-eligible rows at the capture time, proves every row becomes ineligible after its original expiry, and confirms strict no-charge selection has no choice. Credential validity, account allowance and actual inference remain UNMEASURED; the observation read no provider credentials, performed no inference and changed no production state. These are dated public-metadata counts, not a continuing availability or billing guarantee.

Credential inventory supports two host-managed environment slots (`nvidia`, `openrouter`), constant masked placeholders and explicit unverified presence. Credential CRUD, account enumeration, reveal/export and credential validation remain unavailable. The optional account-quota collector uses only an explicitly opted-in OpenRouter metadata GET with an independently supplied sanctioned opaque scope. Default host scope is unknown; there is no automatic quota polling or invented account count. See [credential limitations](credential-contract.md), [descriptive quota contract](quotas.md), and [operational observations](free-access.md).


## Essential external host-attribution blocker (#13)

Code and offline fixtures for scoped operational observations are delivered, but the default inspected host does not supply a sanctioned opaque account/credential reference. At Hermes `b200f5bc60e31588ba2cb60e288029c4a54ba5fa`, the actual dispatch sites are `agent/turn_api_request.py:81` (pre), `agent/turn_response_intake.py:77` (post), and `agent/api_request_hooks.py:177` (error). Their payloads include stable request/provider/model/timing fields, but no `credential_scope`, `key_scope` or account reference. The native error payload also does not forward Retry-After; its parser is exercised only when trusted metadata is explicitly supplied by a supported producer.

Consequently, native account-specific quota refresh, per-account attribution of observed failures and matching account-scoped ranking remain UNKNOWN by default. Read-only credential presence cannot establish identity, validity, account count or entitlement. Manually supplying a guessed hash, deriving an identity from a raw key, patching Hermes, rewriting credentials or declaring free access would violate the product boundary. A future sanctioned host interface, or an explicitly authorized supported producer of matching opaque references, is required to complete this essential operational acceptance. Issue #13 is now closed for bounded plugin delivery; open #41 retains the external host acceptance blocker. It is a separate roadmap acceptance item, not an added required child of provider epic #6; the overall backlog mission remains incomplete while that host acceptance is blocked. The optional explicit-scope API and its mocks do not prove default-host account attribution.

## Reproducible offline gate

Run from the extracted plugin source with the project's test dependencies installed in an isolated virtual environment:

```sh
python provider_registry.py --check
python -m pytest -q -rs
```

The default suite explicitly skips the nine real-host tests unless `AUTOROUTER_HERMES_SOURCE` names a clean, unpacked Hermes git archive. A skip is not a passing host test. The browser tests also require their documented browser/runtime dependencies; report their actual result separately when unavailable.

## Real Hermes, without a production installation

Use a supported Hermes commit and its declared Python dependencies in a separate virtual environment. Create a clean source archive; do not point tests at a live checkout, credential directory, or production Hermes home:

```sh
git -C /path/to/hermes-source archive --format=tar HEAD -o /tmp/hermes-acceptance.tar
mkdir -p /tmp/hermes-acceptance-source
tar -xf /tmp/hermes-acceptance.tar -C /tmp/hermes-acceptance-source
AUTOROUTER_HERMES_SOURCE=/tmp/hermes-acceptance-source /path/to/isolated-venv/bin/python -m pytest -q -rs tests/integration
```

The fixture rejects a source containing `.git` or a root `.env`. Each test stages the current plugin into a new temporary `HERMES_HOME`, writes only synthetic plugin settings there, uses an empty bundled-plugin directory, disables project plugins and starts a separate interpreter with an allowlisted environment and disposable user home. No inherited credentials or live user plugin configuration are supplied. An audit hook rejects access to the user's live `.hermes` directory and denies DNS, connection, datagram-send and listener-binding operations before they execute; child-process creation is denied to prevent escaping that boundary. No Hermes source edits, host patches or real credential checks are needed.

The four loader tests use the actual `PluginManager` and its registration ledger. They verify plugin-default disabled behavior, explicit enablement, the three observer hooks (including the telemetry-only `api_request_error` observer), expected tools, no transform/failover hook, and host-level disabled behavior. Hermes' internal tool-override-policy bookkeeping is excluded from behavioral registrations. The four constructor cases each construct an actual `AIAgent` across plugin-setting and host-allowlist combinations; none is a placeholder assertion. The final probe bounds construction time. All subprocesses have a 35-second deadline.

Hermes may attempt network access during its own constructor even with AutoRouter disabled. Those attempts are blocked and counted; passing these tests means offline construction and plugin loading work with network disabled. It does not mean native Hermes never attempts networking or that an actual provider request succeeded. Missing third-party dependencies are reported by module name as explicit skips; host API incompatibilities and assertion failures are failures.

The initial repaired fixture was executed against Hermes `b200f5bc60e31588ba2cb60e288029c4a54ba5fa`: all nine tests passed. The isolated interpreter used Python 3.14.5 with `ruamel.yaml`, `python-dotenv`, `requests`, `rich`, `httpx[socks]`, `openai`, `tenacity`, `jinja2`, `psutil`, `tiktoken`, `croniter`, `prompt_toolkit`, `fire`, PyYAML and pytest. Dependencies were installed only under `/tmp/autorouter-host-venv`. This is an offline host-lifecycle result, not live-provider or production-dashboard acceptance.

## Regression evidence to retain at final acceptance

| Boundary | Existing executable evidence |
| --- | --- |
| Lossless candidate count, variants, gateway separation, source redaction | `tests/test_provider_registry.py` |
| Dated public metadata eligibility and original-expiry replay without no-charge/account claims | `tests/test_public_catalog_observation.py` |
| Explicit null, trial/credit/paid/stale proof, partial-refresh ages and scoped restrictions | `tests/test_access_evidence.py`, `tests/test_evidence_gate.py`, `tests/test_verified_metadata.py` |
| Free-only hard gates and missing/corrupt state | `tests/test_eligibility.py`, `tests/test_safety.py`, `tests/test_router.py` |
| Constant masked credential metadata and unavailable credential actions | `tests/test_connections.py` |
| SQLite migration rollback, lifecycle idempotency and secret-free telemetry | `tests/test_telemetry.py`, `tests/test_p4_repairs.py` |
| Dashboard read-only queries, safe rendering, five tabs and browser interactions | `tests/test_dashboard_api.py`, `tests/test_dashboard_state_reader.py`, `tests/browser/` |
| Fixed provider catalogs, removed models, malformed data and no inferred free access | `tests/test_provider_adapters.py` |
| Advertised versus observed quotas, credit math, expiry/reset, shared dimensions and UNKNOWNs | `tests/test_quota.py` |
| Account isolation, opt-in metadata lease, stale/conflicting allowance, strict no-charge denial | `tests/test_free_access.py` |
| Provider/model/account circuits, Retry-After, half-open recovery and scope-safe migration | `tests/test_scoped_health.py` |
| Zero-side-effect routing preview, complete non-neutral/scoped Models API parity and legacy error privacy | `tests/test_preview.py`, `tests/test_dashboard_scoring_parity.py` |
| Native host token bridge, scoped flat CSS, mounted theme switching and five-tab responsive behavior | `tests/test_native_theme_contract.py`, `tests/browser/test_native_theme.py`; actual-host `tests/browser/host_theme_probe.py` |
| Actual plugin loading and bounded agent construction, all network blocked | `tests/integration/` with explicit clean Hermes source |

The final gate records the merged adapter, quota, selection/circuit and dashboard-specific commands and support counts, with #13's unsupported native account attribution stated explicitly. Provider epic completion follows its actual required PIR children; the separate operational roadmap blocker must not be silently reported as completed.

## Delivery and review evidence snapshot

Current-state clarification (9 November 2026): main is
`918207b7b7e42aec32ab417e6cb14d4894e56579`; conformance PR #28 merged at
`9dca52877872c41bfd3efc7bbe2e46cf809f5dcd`. The following matrix is the preserved
historical pre-#28 snapshot, not current open/merge status. Current V1 tracking is
[#37](https://github.com/diegorhoger/autorouter/issues/37), and #41 retains the
standard-host account/quota acceptance gap despite bounded #13 closure.

The authoritative live tracker is [epic #6](https://github.com/diegorhoger/autorouter/issues/6). This is an acceptance-evidence snapshot through product main `787039e5fa185f3261adfa443a82b90fc2d2a0fd`, not a second live progress tracker. Short commit labels below link to full immutable commit IDs. Feature review approvals were performed by agents separate from their implementation; they are engineering review records, not author self-approval.

| Issue / integration | Acceptance state at this snapshot | Implementation | Merge evidence |
| --- | --- | --- | --- |
| [#6 Provider epic](https://github.com/diegorhoger/autorouter/issues/6) | TESTING: final required PIR child conformance review pending; #13 is a separate open roadmap blocker | Child PRs below | Remains open |
| [#7 Registry](https://github.com/diegorhoger/autorouter/issues/7) | DONE | [PR #19](https://github.com/diegorhoger/autorouter/pull/19) | [fa10c96](https://github.com/diegorhoger/autorouter/commit/fa10c96b407cd2f4bf9ee2bd89bd48ce9797a3c3) |
| [#8 Access evidence](https://github.com/diegorhoger/autorouter/issues/8) | DONE with independently reviewed follow-up repairs | [PR #21](https://github.com/diegorhoger/autorouter/pull/21), [PR #22](https://github.com/diegorhoger/autorouter/pull/22) | [9e85f4c](https://github.com/diegorhoger/autorouter/commit/9e85f4c11efb9ab9dc080be6d9c15ffb389bebd4), [b247d34](https://github.com/diegorhoger/autorouter/commit/b247d34a1975d86b542eea1c6b561f2539441395) |
| [#9 Discovery adapters](https://github.com/diegorhoger/autorouter/issues/9) | DONE | [PR #25](https://github.com/diegorhoger/autorouter/pull/25) | [edaf7e2](https://github.com/diegorhoger/autorouter/commit/edaf7e2e407968124cc232b4ed7f39d99811f83e) |
| [#10 Quota descriptions / estimates](https://github.com/diegorhoger/autorouter/issues/10) | DONE | [PR #24](https://github.com/diegorhoger/autorouter/pull/24) | [886bc73](https://github.com/diegorhoger/autorouter/commit/886bc73cd7c6aeedcae1c2adb16bb044390dfbf0) |
| [#11 Provider/model dashboard](https://github.com/diegorhoger/autorouter/issues/11) | DONE | [PR #30](https://github.com/diegorhoger/autorouter/pull/30) | [03a5a19](https://github.com/diegorhoger/autorouter/commit/03a5a19d84a8ef9f23f684714982906dfefedec4) |
| [#12 Conformance](https://github.com/diegorhoger/autorouter/issues/12) | REVIEW_REQUIRED; offline conformance passed, final independent exact-HEAD review pending | [Draft PR #28](https://github.com/diegorhoger/autorouter/pull/28) | Not merged; no final acceptance claimed |
| [#13 Operational account observations](https://github.com/diegorhoger/autorouter/issues/13) | BLOCKED: code merged, default host supplies no sanctioned account reference | [PR #29](https://github.com/diegorhoger/autorouter/pull/29) | [cc28e93](https://github.com/diegorhoger/autorouter/commit/cc28e936e30f16e662f791970727fcab3eb074ab); issue remains open |
| [#14 Preview](https://github.com/diegorhoger/autorouter/issues/14) | DONE | [PR #23](https://github.com/diegorhoger/autorouter/pull/23) | [64a8fc1](https://github.com/diegorhoger/autorouter/commit/64a8fc13c4d1be65593929cd2c926505835a188c) |
| [#15 Scoped resilience](https://github.com/diegorhoger/autorouter/issues/15) | DONE for supported observation / selection-time interfaces | [PR #27](https://github.com/diegorhoger/autorouter/pull/27) | [c1b50ca](https://github.com/diegorhoger/autorouter/commit/c1b50ca6a4f0cab6aee2b36019b0f85f4a28a1eb) |
| [#16 Adaptive ranking](https://github.com/diegorhoger/autorouter/issues/16) | DONE after independently reviewed API parity, typed-health and legacy privacy repairs | [PR #31](https://github.com/diegorhoger/autorouter/pull/31), [PR #33](https://github.com/diegorhoger/autorouter/pull/33) | [667813f](https://github.com/diegorhoger/autorouter/commit/667813f19aa1586c65de7e714f2cb973e7724e3f), [aa73a85](https://github.com/diegorhoger/autorouter/commit/aa73a851e9fbd52eff4b8b0d576238f8645f9130) |
| [#17 Credential contract](https://github.com/diegorhoger/autorouter/issues/17) | DONE using explicitly permitted read-only fallback | [PR #20](https://github.com/diegorhoger/autorouter/pull/20) | [9a78a6c](https://github.com/diegorhoger/autorouter/commit/9a78a6c08d9d237a473da2fc8ea6a25203981de5) |
| [#18 Host-managed Keys UX](https://github.com/diegorhoger/autorouter/issues/18) | DONE using the read-only host-managed contract | [PR #32](https://github.com/diegorhoger/autorouter/pull/32) | [b1806c7](https://github.com/diegorhoger/autorouter/commit/b1806c767dc990b1fa8bb0e687428e73803b5851) |
| [#26 Native theme compatibility](https://github.com/diegorhoger/autorouter/issues/26) | BLOCKED_HOST_SYSTEM_THEME: code and all eight supported presets accepted; unavailable OS-system-mode step remains open | [PR #34](https://github.com/diegorhoger/autorouter/pull/34) | [787039e](https://github.com/diegorhoger/autorouter/commit/787039e5fa185f3261adfa443a82b90fc2d2a0fd) |
| Existing telemetry integration | MERGED | [PR #5](https://github.com/diegorhoger/autorouter/pull/5) | [6b14132](https://github.com/diegorhoger/autorouter/commit/6b14132f3ba2c58394adbcb19cb3c4f98ff5f794) |

Historical exact-HEAD gates below are preserved for traceability and are not substitutes for the final current-main suite:

| PR / reviewed HEAD | Independent final verdict and executed historical gate |
| --- | --- |
| #19 [20d7ff4](https://github.com/diegorhoger/autorouter/commit/20d7ff49df3b099f07ca0adf856851841da21223) | Approved/merged in the verified handoff; registry conformance re-executed in the current suite |
| #20 [7810b84](https://github.com/diegorhoger/autorouter/commit/7810b84ce09730fc0697bf6350e637b9c3caadae) | APPROVED; 238 passed / 9 unavailable-runtime skips |
| #5 [db6badc](https://github.com/diegorhoger/autorouter/commit/db6badcd74b57088abdf2c6f4348c77a5d6c864e) | APPROVED after privacy/migration/lifecycle repairs; 344 passed / 9 unavailable-runtime skips |
| #22 [82be286](https://github.com/diegorhoger/autorouter/commit/82be28692d8569caf1619a44c6b42a7f1e5c03c4) | APPROVED after scope-preservation/null-roundtrip repair; 266 passed / 9 unavailable-runtime skips |
| #23 [cbdc0ec](https://github.com/diegorhoger/autorouter/commit/cbdc0ecf31000abc1297f4ff244529dc45e918e3) | [APPROVED](https://github.com/diegorhoger/autorouter/pull/23#issuecomment-6671889004); 363 passed / 9 unavailable-runtime skips |
| #25 [a8d16c4](https://github.com/diegorhoger/autorouter/commit/a8d16c425a5f725a03f477daccf3e1ba5dad7140) | APPROVED; 387 passed / 9 unavailable-runtime skips |
| #24 [f4b16ac](https://github.com/diegorhoger/autorouter/commit/f4b16accf2023fb3fccf64baac616f32506f166a) | APPROVED after malformed/contradictory quota and grant/reset expiry repairs; 457 passed / 9 unavailable-runtime skips |
| #27 [f6384f7](https://github.com/diegorhoger/autorouter/commit/f6384f798d252a8e172bf54ec3500df5eaee2dca) | [APPROVED](https://github.com/diegorhoger/autorouter/pull/27#issuecomment-6673566635); 486 passed / 9 unavailable-runtime skips |
| #29 [702b672](https://github.com/diegorhoger/autorouter/commit/702b6722ac63a36935f9bacf5a87fa7a09c39fcb) | [CODE APPROVED](https://github.com/diegorhoger/autorouter/pull/29#issuecomment-6677817944); 519 passed / 9 unavailable-runtime skips; default-host account acceptance remains blocked |
| #30 [34a5441](https://github.com/diegorhoger/autorouter/commit/34a544146b57748a2bd3702286bdaeb8625bd381) | APPROVED; 529 passed / 9 unavailable-runtime skips |
| #31 [ff6b585](https://github.com/diegorhoger/autorouter/commit/ff6b5854b3b0880d9e1df05d6681fd2341463e90) | [Final APPROVED](https://github.com/diegorhoger/autorouter/pull/31#issuecomment-6677994396); 546 passed / 9 unavailable-runtime skips |
| #32 [b1b134b](https://github.com/diegorhoger/autorouter/commit/b1b134b6770bc1b3cbbe741d9f11f5359030e7ff) | Independent APPROVED reported by the orchestrator; 550 passed / 9 unavailable-runtime skips, plus actual isolated host API/UX and unauthenticated-denial evidence |
| #33 [33ff436](https://github.com/diegorhoger/autorouter/commit/33ff43653a56d1d3382022d0e339b018687c04c7) | [Independent APPROVED](https://github.com/diegorhoger/autorouter/pull/33#issuecomment-6687062581); 570 passed / 9 unavailable-runtime skips; API/Router parity and legacy privacy corrections |
| #34 [1c9eaca](https://github.com/diegorhoger/autorouter/commit/1c9eaca8cc19f2c91aba89150c50088dc0d2d1ea) | [Independent CODE APPROVED](https://github.com/diegorhoger/autorouter/pull/34#issuecomment-6687279641); 578 passed / 9 unavailable-runtime skips plus actual-host eight-theme acceptance; OS-system mode unavailable |

### Final all-features execution

On the conformance branch integrating product main `787039e5fa185f3261adfa443a82b90fc2d2a0fd`, the following commands executed successfully:

```sh
AUTOROUTER_HERMES_SOURCE=/tmp/autorouter-hermes-source /tmp/autorouter-host-venv/bin/python -m pytest -q
/tmp/autorouter-host-venv/bin/python provider_registry.py --check
```

Result: **590 passed, zero failed, zero skipped**, one existing third-party Starlette/httpx deprecation warning, 36.98 seconds. All nine real isolated Hermes lifecycle gates executed, along with actual SQLite/ASGI/non-neutral preview/scoped privacy, Chromium fixture, migration rollback, dated-public-catalog replay and native-token contract checks. The registry command reported **249 unverified candidate rows; no activation or eligibility changes**. The separate real-dashboard 120-check matrix below is additional runtime evidence, not added to the pytest count.

These are executed results, not historical isolated-runtime skips or an assertion of live provider inference. Final exact submitted HEAD/review/merge evidence is recorded in PR #28 and the authoritative epic tracker. This document's issue-state table is a pre-merge acceptance snapshot, not a competing live status tracker. Supported-boundary PIR conformance can complete while the separately documented default-host account attribution and OS-system-theme acceptance remain open; neither missing capability is claimed implemented or passed.

### Actual isolated dashboard acceptance

Separate integration review ran the exact PR #34 source against the real Hermes b200 dashboard, matching shipped web assets and authenticated SDK/API, with synthetic configuration and an empty temporary plugin database. All eight installed named presets passed mounted-node/filter preservation and computed host-token inheritance. The matrix covered eight themes × three widths (390/768/1440) × five tabs = 120 checks; four native Config/System comparisons, actual keyboard focus, allowed policy save/restore, empty/error states and 503 recovery passed. Text/secondary contrast minima were 5.07/4.72. A separate non-neutral temporary telemetry fixture selected beta with ten samples identically through the actual Models API and canonical Router preview; the read-only comparison left DB bytes unchanged. The original empty DB and temporary config were restored afterward. These were not mocked API/HTML tests and were not live provider or account evidence.

`BLOCKED_HOST_SYSTEM_THEME` remains: pinned Hermes offers named presets, not an OS-system-theme mode. OS light/dark emulation under a named preset leaves host and plugin unchanged and cannot pass the requested system-mode acceptance. The bridge remains pure inherited CSS variables; no host patch or duplicate theme engine is introduced. Issue #26 therefore stays open for that precise host capability, while its implemented supported-preset compatibility is merged.

The independent runtime records are `FINAL-INTEGRATION-EVIDENCE.md`, `actual-host-scoring-parity.json`, `fixture-restored.json`, screenshots and the final actual-host theme report in the explicit disposable dashboard evidence directory. No raw operator configuration, credentials or request contents were used. Authenticated plugin reads worked and unauthenticated plugin API access returned 401. The test dashboard is temporary acceptance infrastructure, not a production deployment or a new listener shipped by the plugin.


## Compatibility and migration note

The registry and access evidence use existing capability JSON. Telemetry adds schema v2 through a transactional migration; scoped health upgrades state to schema v3 with hashed references and bounded provider/model/account circuits. Both migrations have rollback fixtures; legacy catalog, health and capability records remain readable. Dashboard reads remain read-only and do not perform migrations. Back up plugin state before upgrading; do not rewrite operator credentials or enable the plugin as part of acceptance. Disabled-by-default selection and the prohibition on execution-level provider switching, replay and postcommit retry remain in force.
