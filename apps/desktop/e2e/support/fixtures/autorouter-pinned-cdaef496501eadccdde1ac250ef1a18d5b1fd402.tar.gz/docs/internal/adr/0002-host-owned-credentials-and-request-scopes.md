---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Scoped plugin consumer and presence interfaces merged; sanctioned standard-host selected-account/quota producer unavailable."
---

# ADR-0002: Host-owned credentials and authoritative request scopes

Hermes initially owns credential storage, selection, authorization and lifecycle. AutoRouter consumes sanctioned presence and sanitized opaque request/attempt-bound identity; neither a raw-key hash nor a previous observation becomes current-account authority. A narrow host-mediated quota operation must authorize the requesting plugin and actual selected credential for the profile/request/attempt, not merely accept a supplied opaque ID. This avoids a second vault and cross-account credential-use escalation.

## Consequences and limits

Actual add/update/disable/remove/validate controls require a verified secure host authority, explicit consent and truthful host receipts. Missing authority stays unavailable with official setup guidance. No secret capture, reveal/export shortcut, automatic rotation or inferred account equivalence is authorized.

## Evidence and ownership

[#17](https://github.com/diegorhoger/autorouter/issues/17); [#18](https://github.com/diegorhoger/autorouter/issues/18); [#13](https://github.com/diegorhoger/autorouter/issues/13); [#41](https://github.com/diegorhoger/autorouter/issues/41); [#46](https://github.com/diegorhoger/autorouter/issues/46). Code anchors: `connections.py`, `runtime.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
