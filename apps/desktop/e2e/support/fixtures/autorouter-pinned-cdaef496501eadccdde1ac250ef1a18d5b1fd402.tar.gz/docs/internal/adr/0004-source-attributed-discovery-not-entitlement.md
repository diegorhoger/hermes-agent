---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Five-provider discovery conformance merged; catalog evidence is not live provider entitlement."
---

# ADR-0004: Source-attributed discovery is not entitlement

The 249-record registry is an unverified inactive candidate inventory, not 249 working provider integrations. The operational metadata adapters are NVIDIA, OpenRouter, Groq, Gemini and Mistral; native host provider support may differ. Candidate, configured/present, discovered, eligible and operationally usable states must not collapse into a connected badge. Unknown capabilities/prices remain unknown, with source identity and original freshness retained.

## Consequences and limits

Catalog success is not inference entitlement. Static fallback information must not become fresh provider discovery, and removed/revoked/expired records must not retain current access authority. Full live-provider and release-path acceptance remain separate gates.

## Evidence and ownership

[#7](https://github.com/diegorhoger/autorouter/issues/7); [#8](https://github.com/diegorhoger/autorouter/issues/8); [#9](https://github.com/diegorhoger/autorouter/issues/9); [#12](https://github.com/diegorhoger/autorouter/issues/12); [#40](https://github.com/diegorhoger/autorouter/issues/40); [#46](https://github.com/diegorhoger/autorouter/issues/46). Code anchors: `provider_registry.py`, `adapters.py`, `metadata.py`, `discovery.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
