# AutoRouter architectural decisions

This register records consequential decisions and a separate backlog, requested in [#55](https://github.com/diegorhoger/autorouter/issues/55). It is not a new implementation roadmap or competing V1 epic. [Epic #37](https://github.com/diegorhoger/autorouter/issues/37) and its approved issues remain authoritative.

**Status vocabulary:** ADR `accepted` means the owner approved the direction/boundary. The separate implementation column says whether code is merged, candidate, private, pending or externally blocked. It does not imply independent code approval, merge, standard-host support or release. Historical decisions are retrospective records written on 7 November 2026, not fabricated decision dates. Newly approved competitive amendments are identified explicitly.

| ADR | Decision | Implementation / acceptance |
|---|---|---|
| [ADR-0001](0001-native-intelligence-and-replaceable-execution.md) | Hermes-native intelligence with replaceable execution | Native intelligence and manual execution adapter merged; standard-host context-bound Apply/Restore unavailable. |
| [ADR-0002](0002-host-owned-credentials-and-request-scopes.md) | Host-owned credentials and authoritative request scopes | Scoped plugin consumer and presence interfaces merged; sanctioned standard-host selected-account/quota producer unavailable. |
| [ADR-0003](0003-mandatory-free-only-and-billing-uncertainty.md) | Mandatory verified-free-only before ranking | Mandatory verified-free-only canonical policy merged; no paid fallback or enforceable no-charge guarantee. |
| [ADR-0004](0004-source-attributed-discovery-not-entitlement.md) | Source-attributed discovery is not entitlement | Five-provider discovery conformance merged; catalog evidence is not live provider entitlement. |
| [ADR-0005](0005-observed-ranking-not-semantic-benchmarks.md) | Observed operational ranking without invented competence | Observed ranking and explicit task profiles merged; semantic competence remains unknown. |
| [ADR-0006](0006-profile-storage-and-nondestructive-migration.md) | Profile-scoped SQLite and nondestructive legacy migration | Profile-scoped storage and nondestructive migrations merged; rollback requires a matching compatible snapshot. |
| [ADR-0007](0007-quota-observations-preflight-and-reservations.md) | Quota observations, preflight policies and reservations are distinct | Versioned multi-window observations and four preflight policies merged; host producer blocked and spending reservations deferred. |
| [ADR-0008](0008-no-unsafe-replay-or-unowned-enforcement.md) | No replay or enforcement without execution authority | Accepted boundary; automatic replay/fallback remains inactive and unauthorized. |
| [ADR-0009](0009-native-dashboard-and-host-theme-inheritance.md) | One native five-tab dashboard inherits the host | Native five-tab dashboard merged for named themes; OS-system mode externally blocked; SDK recovery repair PR #72 awaits acceptance. |
| [ADR-0010](0010-connect-and-manage-through-host-authority.md) | Connect and Manage Providers through secure host authority | Read-only onboarding and truthful readiness merged; secure host credential lifecycle remains unavailable. |
| [ADR-0011](0011-versioned-policy-and-execution-independent-evidence.md) | Versioned policies separate requirements and authority | Execution-independent canonical policy, explicit profiles and evidence report merged; host authority remains separate. |
| [ADR-0012](0012-exact-evidence-and-independent-release-gates.md) | Exact-revision evidence and independent release gates | Deterministic builder and isolated lifecycle merged; exact-artifact acceptance and release authorization remain separate gates. |
| [ADR-0013](0013-autorouter-brand-and-compatible-package-identity.md) | AutoRouter brand with compatible repository and plugin identity | AutoRouter branding with compatible autorouter plugin/package identity preserved; rename or public release not authorized. |
| [ADR-0014](0014-native-hermes-model-toggles.md) | Native Hermes model toggles without a second UI framework | UX architecture approved; implementation pending [#108](https://github.com/diegorhoger/autorouter/issues/108) and independent acceptance. |
| [ADR-0015](0015-native-hermes-autorouter-picker.md) | Capability-gated AutoRouter selection in the native Hermes chat model picker | Owner-approved direction; actual picker registration and host-side route resolution pending issue [#116](https://github.com/diegorhoger/autorouter/issues/116); live Hermes unsupported. |
| [ADR-0016](0016-dynamic-hermes-provider-coverage.md) | Dynamic Hermes-backed provider capability coverage | **P0 owner priority**; implementation tracked in [#119](https://github.com/diegorhoger/autorouter/issues/119); no runtime support or live acceptance claimed. |

- [Decision backlog](backlog.md): unresolved contract questions, owner and release/authority gates.
- [Delivery history](delivery-history.md): verified merged work, current candidates, private/live evidence and remaining blockers.
- [Domain glossary](../glossary.md): connection, scope, credential authority, allowance observation, reservation and confirmed apply.

Implementation status checked against accepted main `918207b7b7e42aec32ab417e6cb14d4894e56579` on 9 November 2026. Decision approval dates and boundaries are unchanged. See the [delivery history](delivery-history.md) for exact merge receipts; open repair PRs are not merged acceptance.

## Recording a decision

Add the next sequential ADR, update index.json and this table, and link the existing issue/PR and evidence. Preserve old records; supersede rather than silently rewrite a reversed decision. Add proposed decisions to the backlog until authorized. Record source revision and evidence type; never store keys, prompts, completions or account balances. A future implementation or public release still needs its normal independent/owner gate.

Check local links/index/frontmatter using `python tools/check_adrs.py`. The check validates documentation consistency, not feature acceptance or remote URL availability.
