# Operational observation coverage v1

Issue #48 adds evidence coverage around the existing operational scorer. Beta
posterior, bounded reads, decay, EWMA, weights and deterministic ranking remain
unchanged. Historical observations are not current availability, account access or
semantic task competence.

## Shared contract

Every scored candidate includes `score.coverage`, schema version 1. The same
coverage appears under `evidence_report.candidates[].ranking.coverage`, selection,
preview, registered tools and dashboard API. Models → Preview displays the source,
sample/effective count, confidence, age/staleness boundary, attribution and latency
measurement boundary beside the unchanged factor contributions.

- `unavailable`: observation storage/source is unavailable; samples and confidence
  are null, never fabricated zero counts.
- `cold_start`: the bounded store read succeeded but no valid final observations
  were available. Neutral ranking priors are not measured reliability.
- `sample_limited`: fewer than 64 recent valid observations, with existing decayed
  effective count and confidence. A single success cannot establish reliability.
- `bounded_sample`: 64 valid observations in the bounded read. This is capped
  evidence, not full-population coverage or semantic certification.
- `stale`: last valid outcome is at least seven days old. Historical estimates
  continue decaying toward priors; no current healthy/available claim is made.

Original outcome/latency timestamps are retained. `stale_after` is last outcome
plus the existing seven-day decay half-life, explicitly a **display staleness
boundary**, not a provider TTL or an invented expiry/revocation event. Latency age
is independently based on the last actual latency observation. Missing or invalid
latency is unknown, not zero milliseconds. #43 continues to suppress unusable speed
evidence for Fast response while preserving independent reliability observations.

Measurements describe host-reported final-request elapsed latency, including
supported homogeneous retries and both success/error terminal outcomes. They are
not token-normalized benchmarks, pure provider processing time or time-to-first-token
unless a separate metric explicitly says so. No prompts/completions are read.

## Attribution and existing ingestion

The existing indexed SQLite reader matches exact provider/model/scope, reads at
most 64 final requests and excludes missing request identity, pending/cancelled
requests, missing attempts, more than 16 attempts, and attempts spanning models or
providers. Existing final-callback deduplication and scope invalidation remain.
No new observer pipeline or independent ranking engine is introduced.

Coverage distinguishes current typed `authorized_observation`, legacy configured
scope and `unknown`. A caller-supplied label cannot grant current authority;
canonical evaluation revalidates the internal context. Opaque scope values, account
identifiers and hashes are not emitted by coverage. Legacy configured scope does
not prove a currently selected account. Unknown-scoped metrics cannot claim
known-account performance, even when historical outcomes exist.

Standard Hermes does not yet supply the complete sanctioned active-scope producer.
The #36 structured-scope consumer and #58 quota integration are merged through #69.
Real account-bound acceptance remains blocked until a sanctioned host producer
and current-context authority are accepted.
Public/unknown-scope coverage and synthetic authorized-context tests remain useful
and independently testable without claiming the blocker is solved.

## Acceptance evidence and limits

Fixtures cover cold start, one-off success, cap, decay/staleness, future/invalid
samples, missing callbacks, cross-provider attempts, multi-account reads, revoked
and mismatched sessions, and refusal of caller-asserted scope authority. Existing
SQLite/API parity tests compare complete decisions, including coverage. Browser
tests use labeled expandable evidence. Actual isolated Hermes loads the plugin
and calls its registered observers with synthetic success/error lifecycle events;
registered-tool/preview parity is checked afterward. Those are real host/plugin
integration tests with synthetic callbacks, not actual provider requests, live
credential attribution, inferred savings or semantic benchmarks.

No Hermes, production, credential, autorouter-web, Apply/Use, gateway or release changes.
The #61/#60/#53 and #36/#58/#57 plugin dependencies are merged through #69. Issue
#48 is closed for bounded source delivery; that is not live account-bound acceptance.
