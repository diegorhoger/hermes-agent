# Architectural decision backlog

Approved direction and undecided implementation details must not be conflated. All items below reuse existing ownership; no competing epic or implicit gateway implementation is created.

| Item | Direction / state | Owner | Required decision/evidence |
|---|---|---|---|
| Host credential lifecycle authority | Direction accepted; host contract unresolved | [#46](https://github.com/diegorhoger/autorouter/issues/46), [#39](https://github.com/diegorhoger/autorouter/issues/39) | Verified secure host intake/validation/lifecycle API, declared permissions, isolation, revocation and real receipts. No independent vault. |
| Active request/attempt scope | Plugin consumer merged; native host blocked | [#13](https://github.com/diegorhoger/autorouter/issues/13), [#41](https://github.com/diegorhoger/autorouter/issues/41), PR [#36](https://github.com/diegorhoger/autorouter/issues/36) | Sanctioned producer plus authorized quota operation on standard host; no private pool or last-observed-account authority. |
| Quota windows and preflight policy serialization | Multi-window/four-policy consumer merged; host authority blocked | [#41](https://github.com/diegorhoger/autorouter/issues/41), [#42](https://github.com/diegorhoger/autorouter/issues/42) | Units/windows/confidence/expiry, policy-version fixtures, A/B isolation and unknown/exhaustion/no-charge semantics. |
| Connection restrictions in canonical policy | Canonical contract merged via PR [#53](https://github.com/diegorhoger/autorouter/pull/53); actual host authority unresolved | [#42](https://github.com/diegorhoger/autorouter/issues/42) | Keep hard eligibility, preferences, task profile and connection restrictions independent of executor. |
| ExecutionAdapter target/context/receipts | Manual adapter merged; native context-bound host Apply/Restore unresolved | [#45](https://github.com/diegorhoger/autorouter/issues/45), [#44](https://github.com/diegorhoger/autorouter/issues/44), [#50](https://github.com/diegorhoger/autorouter/issues/50) | Capability declaration, context revalidation, confirmation, failed/restore receipt and intended request observation. Manual handoff cannot claim applied. |
| Explicit task requirements | Explicit profiles merged through #60/#69; semantic competence unknown | [#43](https://github.com/diegorhoger/autorouter/issues/43) | Evidence-backed requirements and uncertainty; coding label is not quality proof. |
| Automatic task classification | Deferred; no implementation dispatch | [#54](https://github.com/diegorhoger/autorouter/issues/54) | Optional privacy-preserving classifier, explicit separate scope and tests; keyword match is not competence. |
| Optional gateway and local credential service | Deferred/design only, outside V1 | [#54](https://github.com/diegorhoger/autorouter/issues/54) | Separate security/operational program, credential ownership, protocol and commitment safety; reuse intelligence plane. |
| Atomic local allowance reservations | Future execution-owner gate | [#54](https://github.com/diegorhoger/autorouter/issues/54) | Concurrency-safe reserve/settle/cancel with enforceable ownership. Refresh leases and quota snapshots are not reservations. |
| Native web OS-system theme | External host gap | [#26](https://github.com/diegorhoger/autorouter/issues/26), [#49](https://github.com/diegorhoger/autorouter/issues/49) | Actual web theme/OS bridge; Desktop support alone is insufficient. No second theme engine. |
| Reproducible release / public access | Prepare-only; owner approval outstanding | [#51](https://github.com/diegorhoger/autorouter/issues/51) | Exact artifact/lifecycle/checksum/license acceptance; no public visibility/release/deployment before approval. |
| External performance evidence | Explicitly deferred, outside V1 | [#35](https://github.com/diegorhoger/autorouter/issues/35) | Provisional docs candidate PR [#71](https://github.com/diegorhoger/autorouter/pull/71); runtime remains deferred; no benchmark/evaluator duplication. |

## Amendment record

Amendment decisions derive from the review approved by the product owner on 7 November 2026. No external project is a source for this register's decisions; implementation status above was checked against the recorded issue set only.

Accepted amendments are recorded in [#41](https://github.com/diegorhoger/autorouter/issues/41)/#42/#45/#46 and the explicit-profile clarification in [#43](https://github.com/diegorhoger/autorouter/issues/43). Existing candidates must be reassessed against the amended criteria before being counted accepted. The initial reconciliation pause is historical. Merged implementation status above was checked on 9 November 2026; no future gateway or classifier work is authorized.
