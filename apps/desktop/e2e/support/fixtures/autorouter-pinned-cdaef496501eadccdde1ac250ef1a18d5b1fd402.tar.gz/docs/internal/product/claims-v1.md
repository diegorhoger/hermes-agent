# AutoRouter V1 launch-claim acceptance contract

Contract version 1; related to #38 and Epic #37. This freezes 24 atomic commitments from the website at `5937c182da6d857daea4437399cf3de68705969f`. Each quotation maps to an actual surface, executable regression proof, limitation and owner. Repeated wording can describe distinct user requirements; these IDs do not add new promises.

**This is acceptance infrastructure, not a declaration that V1 is shipped.** `supported` means the stated bounded behavior has a regression proof, not independent release approval. `partial` and `blocked` are release blockers, including implementable work assigned to approved child issues. Synthetic tests do not prove live provider access.

The machine-readable source is [claims-v1.json](claims-v1.json). When website-source access is separately authorized, run `python tools/check_product_claims.py --website-checkout <checkout> --run-proofs`; IDs, links, test functions, source quotations and pinned source digests are checked. Without `--run-proofs`, tests are NOT_EXECUTED. `--release` additionally requires fresh proof execution, matching website source, all claims supported, and explicit independent release acceptance. It intentionally fails on current gaps.

At the frozen website revision, Free-first permits a paid-tag fictional fallback, while the engine rejects paid/unknown costs. C13 records this mismatch; neither the promise nor the production hard gate is silently weakened. The website is read-only in this issue.

## Current website source note

Read-only inspection of current `autorouter-web` commit
[`d7522cd7742e453eddaab091475b7d58caf1845d`](https://github.com/diegorhoger/autorouter-web/commit/d7522cd7742e453eddaab091475b7d58caf1845d)
shows that the demo removed the fictional paid-model examples and now uses a
source-linked catalog ([`recommendations.ts`](https://github.com/diegorhoger/autorouter-web/blob/d7522cd7742e453eddaab091475b7d58caf1845d/src/data/recommendations.ts),
[`RecommendationDemo.tsx`](https://github.com/diegorhoger/autorouter-web/blob/d7522cd7742e453eddaab091475b7d58caf1845d/src/components/RecommendationDemo.tsx)).
However, Free-first still chooses `eligible[0]` without a verified-cost/free-only
eligibility gate; the demo has no live health weighting and labels its observations
as sample/unknown. Thus the precise frozen fictional-paid-example mismatch is no
longer present in this source revision, but canonical website-to-plugin fixture
parity remains unverified. C13's frozen quote, state, and no-charge limitation are
unchanged; #42 stays open, and release remains BLOCKED. This source inspection did
not run a shared fixture or establish deployed-website behavior.


## Candidate evidence update

Implementation descriptions and executable proof links now reflect the combined
private candidate, including explicit profiles, versioned reports, guidance,
request traces and packaging. Frozen website quotes/digests, claim IDs, owners,
all supported/partial/blocked dispositions and release gates are unchanged.
This update corrects stale descriptions; it does not mark any partial promise
complete or substitute manual handoff for native Apply/Use.

The historical authenticated browser/artifact evidence was recorded at
`bb9c40c56e764812e287408b39ad2d211c136ae6`, artifact SHA-256
`5dadf9957a2098aea6de758583e03265aa34110e64b5b7ede81ecb00fd233257`,
with patched Hermes `3a5f88e`: nine authenticated routes, three unauthenticated
denials, eight themes and synthetic preview/manual handoff without execution.
This is bounded private evidence; formal source/artifact approval, native
execution, authoritative selected-account quotas and broader release gates
remain outstanding. The current proof run and exact revision are recorded in
Epic #37; historical artifact evidence is not relabeled as a new artifact.

Run `python tools/check_product_claims.py --run-proofs` in the guarded isolated
environment to execute the listed proofs. Without separately authorized website
source verification, website status stays NOT_VERIFIED and release stays BLOCKED.
No autorouter-web repository access or modification is part of this update.

## AC-C01 — Discover candidates

- Source: `src/App.tsx` — “Explore candidate AI models across supported providers.”
- Owner: https://github.com/diegorhoger/autorouter/issues/40
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `discovery.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_discovery_conformance.py::test_complete_native_empty_catalog_revokes_absent_models`, `tests/test_discovery.py::test_discover_all_persists_and_lkg`.
- Limit/failure condition: Five-provider discovery is integrated and locally validated; catalog evidence is not live entitlement and independent release acceptance remains pending.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C02 — Model discovery

- Source: `src/App.tsx` — “Model discovery”
- Owner: https://github.com/diegorhoger/autorouter/issues/40
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `adapters.py`, `provider_intelligence.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_discovery_conformance.py::test_stages_never_promote_registry_candidates_or_entitlement`, `tests/test_provider_registry.py::test_unknowns_and_claims_never_become_eligibility`.
- Limit/failure condition: Registry candidates remain distinct from six discovery integrations and verified eligible models; candidate presence is not entitlement.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C03 — Capability checking

- Source: `src/App.tsx` — “Evaluate available evidence about capabilities, eligibility, and provider health.”
- Owner: https://github.com/diegorhoger/autorouter/issues/40
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `metadata.py`, `task_profiles.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_task_profiles_v1.py::test_profiles_preserve_hard_gates`, `tests/test_verified_metadata.py::test_persistence_and_selection`.
- Limit/failure condition: Fresh source-attributed capability gates and explicit profiles are implemented; missing/stale proof denies requirements and live entitlement remains unverified.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C04 — Source-backed cost

- Source: `src/App.tsx` — “capability, cost, and reliability information”
- Owner: https://github.com/diegorhoger/autorouter/issues/42
- State: **supported**; evidence: `automated_synthetic`.
- Path/API/UI: `eligibility.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_eligibility.py::test_cost_allowed`.
- Limit/failure condition: Paid/unknown cost is rejected; zero-price metadata is not a billing hard stop.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C05 — Health observations

- Source: `src/App.tsx` — “Health and availability evidence”
- Owner: https://github.com/diegorhoger/autorouter/issues/47
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `health.py`, `health_guidance.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_health_guidance_v1.py::test_failure_categories_and_boundaries_have_original_provenance`, `tests/test_scoped_health.py::test_rate_limit_scope_and_reason`.
- Limit/failure condition: Scoped observed failure guidance is implemented; historical observations and local cooldowns do not guarantee current availability or provider recovery.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C06 — Quota uncertainty

- Source: `src/App.tsx` — “Unknown quota or billing information stays unknown.”
- Owner: https://github.com/diegorhoger/autorouter/issues/41
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `free_access.py`, `selection_policy.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_quota_policies_v1.py::test_router_uses_integrated_versioned_quota_evaluator_without_callers_injecting_one`, `tests/test_free_access.py::test_exhaustion_staleness_and_strict_guarantee`.
- Limit/failure condition: Account caches and all four quota policies are composed locally with synthetic authority; standard-Hermes selected-account quota collection and formal acceptance remain blocked.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C07 — Free-access limits

- Source: `src/App.tsx` — “Published free pricing does not guarantee unlimited free access.”
- Owner: https://github.com/diegorhoger/autorouter/issues/41
- State: **supported**; evidence: `automated_synthetic`.
- Path/API/UI: `free_access.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_free_access.py::test_exhaustion_staleness_and_strict_guarantee`.
- Limit/failure condition: No unlimited-access or provider hard-stop guarantee is offered.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C08 — Explicit constraints

- Source: `src/App.tsx` — “Recommend suitable models based on your policies and constraints.”
- Owner: https://github.com/diegorhoger/autorouter/issues/42
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `router.py`, `selection_policy.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_selection_policy_v1.py::test_requirements_compose_before_ranking_and_keep_semantic_quality_unknown`, `tests/test_preview.py::test_pure_deterministic_and_all_rejections`.
- Limit/failure condition: Versioned hard constraints, ranked preferences and explicit task profiles share the canonical evaluator; independent acceptance and sanctioned execution authority remain separate.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C09 — User control

- Source: `src/App.tsx` — “Recommendations follow explicit constraints; users remain in control.”
- Owner: https://github.com/diegorhoger/autorouter/issues/45
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `tools.py`, `execution_adapter.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_execution_adapter_v1.py::test_tool_api_and_adapter_agree_without_database_writes_from_handoff`, `tests/test_preview.py::test_preview_matches_selection_without_writes_network_or_credentials`.
- Limit/failure condition: Intentional preview and validated manual handoff work through the authenticated private dashboard; manual preparation does not perform native Apply/Use.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C10 — General task

- Source: `src/components/RecommendationDemo.tsx` — “General”
- Owner: https://github.com/diegorhoger/autorouter/issues/43
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `scoring.py`, `task_profiles.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_task_profiles_v1.py::test_portable_profile_contract`, `tests/test_adaptive_scoring.py::test_semantic_quality_is_unknown_and_context_does_not_rank`.
- Limit/failure condition: General v1 is implemented with balanced operational preferences and verified hard gates; semantic task competence stays unknown and formal acceptance is pending.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C11 — Coding task

- Source: `src/components/RecommendationDemo.tsx` — “Coding”
- Owner: https://github.com/diegorhoger/autorouter/issues/43
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `scoring.py`, `task_profiles.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_task_profiles_v1.py::test_coding_tools_only_when_workload_explicitly_requires_them`, `tests/test_adaptive_scoring.py::test_semantic_quality_is_unknown_and_context_does_not_rank`.
- Limit/failure condition: Coding v1 requires tools only for an explicitly tool-requiring workload; the label is not evidence of coding competence or inference entitlement.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C12 — Fast task

- Source: `src/components/RecommendationDemo.tsx` — “Fast response”
- Owner: https://github.com/diegorhoger/autorouter/issues/43
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `scoring.py`, `task_profiles.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_task_profiles_v1.py::test_fast_and_general_rank_differently_for_evidenced_tradeoff`, `tests/test_adaptive_scoring.py::test_cold_start_prior_and_sample_confidence`.
- Limit/failure condition: Fast response v1 uses confidence-aware observed latency; missing/stale measurements and semantic quality remain unknown, with no speed or answer-quality guarantee.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C13 — Free-first vocabulary

- Source: `src/components/RecommendationDemo.tsx` — “Free-first”
- Owner: https://github.com/diegorhoger/autorouter/issues/42
- State: **blocked**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `eligibility.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_eligibility.py::test_cost_allowed`.
- Limit/failure condition: Website preference can choose a paid-tag fictional example; engine mandatory free-only cannot. Resolve in milestone-05/milestone-15.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C14 — Reliability-first vocabulary

- Source: `src/components/RecommendationDemo.tsx` — “Reliability-first”
- Owner: https://github.com/diegorhoger/autorouter/issues/42
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `scoring.py`, `policies.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_policies_v1.py::test_same_fixture_has_identical_engine_tool_api_dashboard_decision`, `tests/test_adaptive_scoring.py::test_observed_telemetry_changes_ranking_and_preview_is_identical`.
- Limit/failure condition: Canonical reliability preferences rank only eligible verified-free models; fictional website examples and independent release acceptance remain unresolved.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C15 — Tool requirement

- Source: `src/components/RecommendationDemo.tsx` — “tool calling required”
- Owner: https://github.com/diegorhoger/autorouter/issues/42
- State: **supported**; evidence: `automated_synthetic`.
- Path/API/UI: `eligibility.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_eligibility.py::test_is_eligible_requires_tools`.
- Limit/failure condition: Required tool capability must be verified; unknown is rejected.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C16 — Explain recommendation

- Source: `src/App.tsx` — “See the reasoning and the important uncertainties behind the recommendation.”
- Owner: https://github.com/diegorhoger/autorouter/issues/44
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `router.py`, `decision_report.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_decision_report_v1.py::test_selected_evidence_survives_alphabetical_display_truncation`, `tests/test_preview.py::test_pure_deterministic_and_all_rejections`.
- Limit/failure condition: Versioned winner evidence, source/expiry, hard gates and next actions are implemented; explanations disclose unknowns and grant no execution or account authority.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C17 — Explain alternatives

- Source: `src/components/RecommendationDemo.tsx` — “Why other examples were left out”
- Owner: https://github.com/diegorhoger/autorouter/issues/44
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `router.py`, `decision_report.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_decision_report_v1.py::test_report_is_bounded_deterministic_and_no_match_is_not_paid_fallback`, `tests/test_preview.py::test_pure_deterministic_and_all_rejections`.
- Limit/failure condition: Bounded rejected-alternative reports preserve hard-gate reasons and provenance; omitted display rows and unsupported evidence remain explicit limitations.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C18 — Show unknowns

- Source: `src/App.tsx` — “See why a model was recommended and what remains unknown.”
- Owner: https://github.com/diegorhoger/autorouter/issues/44
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `scoring.py`, `decision_report.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_decision_report_v1.py::test_unavailable_observations_are_not_reported_as_zero_samples`, `tests/test_adaptive_scoring.py::test_semantic_quality_is_unknown_and_context_does_not_rank`.
- Limit/failure condition: Reports and native dashboard preserve unknown evidence separately from zero; semantic quality and unsupported host authority remain unknown.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C19 — No match

- Source: `src/components/RecommendationDemo.tsx` — “No eligible example”
- Owner: https://github.com/diegorhoger/autorouter/issues/44
- State: **supported**; evidence: `automated_synthetic`.
- Path/API/UI: `router.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_preview.py::test_empty_and_malformed_evidence_do_not_discover`.
- Limit/failure condition: No eligible candidate means no recommendation; no paid fallback.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C20 — Observed reliability

- Source: `src/App.tsx` — “reliability information”
- Owner: https://github.com/diegorhoger/autorouter/issues/48
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `scoring.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_observation_coverage_v1.py::test_coverage_counts_confidence_and_limit_are_exact`, `tests/test_adaptive_scoring.py::test_decay_ewma_and_staleness_under_frozen_clock`.
- Limit/failure condition: Bounded observed coverage, confidence, freshness and scoped ranking are implemented; observations are not semantic benchmarks or current-account authority.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C21 — Hermes-native installation

- Source: `src/App.tsx` — “native Hermes Agent plugin”
- Owner: https://github.com/diegorhoger/autorouter/issues/51
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `plugin.yaml`, `tools/build_package.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/integration/test_package_lifecycle.py::test_verified_package_lifecycle_preserves_profile_data`, `tests/test_dashboard_manifest.py::test_manifest_parses_and_is_complete`.
- Limit/failure condition: A reproducible private artifact and isolated install/upgrade/snapshot-rollback/remove/restore checks exist; standard-host compatibility, formal exact-artifact and release acceptance remain pending.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C22 — Reduced switching friction

- Source: `src/App.tsx` — “Less model juggling.”
- Owner: https://github.com/diegorhoger/autorouter/issues/45
- State: **blocked**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `integration.py`, `execution_adapter.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_execution_adapter_v1.py::test_capability_contract_never_grants_unsupported_authority`, `tests/test_preview.py::test_preview_matches_selection_without_writes_network_or_credentials`.
- Limit/failure condition: Validated manual handoff does not supply sanctioned native apply/use/restore or executed-request targeting; the private fallback-chain helper remains inactive.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C23 — Outcome guidance

- Source: `src/App.tsx` — “AutoRouter does not guarantee uninterrupted inference or automatic recovery from every provider failure.”
- Owner: https://github.com/diegorhoger/autorouter/issues/50
- State: **partial**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `telemetry.py`, `request_trace.py`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_request_trace_v1.py::test_trace_does_not_serialize_identity_content_or_infer_target`, `tests/test_scoped_health.py::test_explicit_observer_scope_groups_telemetry_without_secret`.
- Limit/failure condition: Actionable health guidance and versioned request/attempt traces are implemented; decision-to-native-apply-to-request correlation remains unavailable without a sanctioned host producer.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

## AC-C24 — Verified release instructions

- Source: `src/App.tsx` — “Installation instructions coming from the verified release”
- Owner: https://github.com/diegorhoger/autorouter/issues/51
- State: **blocked**; evidence: `partial_automated_or_external_dependency`.
- Path/API/UI: `RELEASE.md`; Hermes plugin tools / native dashboard; see implementation path.
- Environment: isolated temporary SQLite / no live provider entitlement asserted.
- Executable proof: `tests/test_package_v1.py::test_repeatable_manifest_and_exact_member_inventory`, `tests/test_dashboard_manifest.py::test_manifest_parses_and_is_complete`.
- Limit/failure condition: Private build and recovery instructions are tested; exact-artifact independent release acceptance and public publication are not authorized, and native execution gates remain blocked.
- Release gate: Independent exact-HEAD acceptance, referenced owner issue and real isolated Hermes release journey; blocked/partial claims cannot pass release.

The proof runner reads pytest results and refuses PASS on skipped, failed, empty
or missing reports, even if pytest exits zero. A required isolated-host proof
without its environment is INCOMPLETE, never a release-ready result.
