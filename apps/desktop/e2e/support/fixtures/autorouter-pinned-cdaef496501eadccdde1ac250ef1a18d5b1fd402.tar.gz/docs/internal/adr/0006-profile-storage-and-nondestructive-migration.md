---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Profile-scoped storage and nondestructive migrations merged; rollback requires a matching compatible snapshot."
---

# ADR-0006: Profile-scoped SQLite and nondestructive legacy migration

Plugin state belongs in the active Hermes profile plugin-data directory with explicit overrides preserved. Migrating an owned canonical legacy database uses a consistent SQLite backup including committed WAL data, preserves the original, rejects linked/foreign sources and never overwrites an existing destination. Retaining a legacy source is preferable to silently importing another profile or losing rollback evidence.

## Consequences and limits

A backup is not live replication: legacy writers must be stopped for a planned migration. Code rollback must account for the changed default data location. Approval of the architecture or local source does not make PR [#36](https://github.com/diegorhoger/autorouter/issues/36) merged.

## Evidence and ownership

[#13](https://github.com/diegorhoger/autorouter/issues/13); [#41](https://github.com/diegorhoger/autorouter/issues/41); [#51](https://github.com/diegorhoger/autorouter/issues/51). Code anchors: `state_dir.py`, `state.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
