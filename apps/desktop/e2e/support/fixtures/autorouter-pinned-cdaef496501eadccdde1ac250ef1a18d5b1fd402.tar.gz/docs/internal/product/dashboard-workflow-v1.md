# Native dashboard workflow v1

The existing five Hermes tabs share navigation intent without acquiring execution
or credential authority. Overview starts first-use guidance. Providers can open
Models with a provider filter. Models keeps the explicitly chosen task and tools
requirement while the user inspects other tabs. Its read-only preview retains the
original validated request for manual handoff revalidation; confirmations are
never retained or submitted automatically. Analytics remains observed history,
not proof that a recommendation was applied or executed.

## State and recovery

Unsaved Settings policy, cooldown and provider fields survive tab navigation,
including an explicitly empty provider input. Reset deliberately restores saved
values. Save uses the existing sanctioned settings API. A successful save clears
the draft and invalidates Overview, Providers, Models and Analytics caches.
Partial saves also invalidate those views because some values already persisted;
the draft and existing partial-save report remain available for correction.
Settings take effect on plugin reload, not as an implicit live runtime change.

Invalid numeric/provider input identifies and focuses the affected field with a
programmatic link to its authored error. Cooldown validation checks the complete
numeric value as an integer; it never truncates fractional or exponential input.
Partial-save reports and failed-field descriptions survive tab navigation alongside
the draft. Reset or another save clears obsolete error state; successfully saved
fields are not marked invalid. These semantics do not certify a screen reader's
actual spoken announcements.


A task or workload change clears its previous explicit preview. Refreshing Models
also clears it. Returning to the tab preserves task choices but a reconstructed
manual-handoff confirmation starts unchecked. A late preview response for an old
workload cannot populate the current result. Per-tab request generations prevent
late responses, including errors, from replacing a newer read or invalidating its
loading state. No background polling, provider request or automatic retry is added.

## Integration and acceptance limits

This branch includes accepted main through #65, including merged #36, #57,
#58 and #59 plugin functionality. No duplicate provider adapters or quota
implementation is introduced. Plugin integration does not establish live entitlement. Native context-bound Apply/Restore,
trusted selected-account authority and provider response-header contracts remain
unavailable; manual handoff does not satisfy those gates.

Browser regressions cover task/Settings persistence, partial saves, provider
navigation, late responses and 390/768/1440px. Existing tests retain no-match,
unknown/corrupt state, stale quota, safe settings, keyboard tab behavior, native
CSS token inheritance and no-remount theme behavior. These are offline browser
contract tests; the guarded suite separately exercises actual isolated Hermes
with synthetic observations. They are not live-provider or combined authenticated
Hermes-browser acceptance. Issue #49 remains open until its complete acceptance
matrix, including supported host behavior, is independently established.

The host’s supported named theme presets continue to inherit through CSS tokens.
This work adds neither a theme engine nor an unsupported OS-system-theme mode.

## Mainline integration regressions

Browser checks exercise all four old/new success/error completion combinations,
including Settings invalidation while a Models read is in flight. The newest
read remains authoritative. Late task-preview success and error are discarded
after workload changes or forced Models refresh. Responsive checks assert actual
control visibility, viewport bounds and document overflow at 390, 768 and 1440px;
screenshots are supplemental. Partial-save checks preserve unsaved corrections.
Public release remains unapproved and automatic paid inference remains disabled.
