---
status: accepted
recorded: 2026-11-17
authority: owner-approved P0 expansion of provider compatibility
implementation: "Pending issue #119: host-backed provider registry, multi-provider discovery and truthful UI statuses. This ADR and its draft PR do not implement runtime support, credential management, free entitlement or live deployment."
---

# ADR-0016: Dynamic Hermes-backed provider capability coverage

## Context and observed limitation

AutoRouter currently recognizes six implemented discovery-provider IDs in `autorouter_core/providers/connections.py`: NVIDIA NIM, OpenRouter, Groq, Gemini, Mistral and Nous Portal. The module's fixed `PROVIDERS` membership determines whether authorization IDs are accepted; a host-known provider outside the six is rendered as `family: llm_unsupported`, and `validate_provider()` rejects it as `unsupported_provider`. The `valid_provider_list()` check rejects an entire list with any unsupported or invalid ID. `autorouter_core/discovery/adapters.py` has another fixed set of discovery implementations. Tests currently prove rejection of `zai`, illustrating the artificial limitation rather than proving that its Hermes API cannot be used.

AutoRouter separately preserves a 249-row candidate research registry. Those source claims contain gateways, plans, specialized services and unverified providers; they are **not** verified usable chat providers or authorities for credentials, pricing, free tiers or endpoints.

The owner requires this limitation to become the **number-one implementation priority**. Existing Hermes-native picker work and issues #41/#104/#116 remain independent, and their safety prerequisites may not be bypassed.

## Decision

Make the currently trusted **Hermes provider registry/capability contract** the authoritative source of which provider identities and supported protocols AutoRouter can discover. AutoRouter may retain protocol-specific, safely bounded discovery adapters and evidence normalization, but may not equate absence from a static six-ID allowlist with lack of Hermes support.

**Provider recognition must not grant permission.** A provider can be discovered and visible without (a) an operator allowlist authorization, (b) a working credential, (c) inference capability, (d) verified-free price, or (e) authoritative quota/allowance. Each property has its own independent, evidence-bearing state. Only models that pass the strict existing mandatory free-only, user authorization, task requirement and profile constraints can be routed.

A compatible Hermes-integrated provider means one for which the exact host version supplies an authoritative provider identity and a supported inference/runtime route. The phrase **support all providers** is an extensible integration goal, not permission to pretend arbitrary third-party API keys, plans, non-chat modalities, model lists or unsupported HTTP protocols are executable or free. When host functionality or metadata is unavailable, state it truthfully.

## Architecture and ownership

1. **Provider capability discovery:** Obtain bounded, validated provider rows through supported Hermes-host APIs, including identity, aliases, protocol, catalog metadata support, runtime support, tools/context metadata quality and credential-presence state. Preserve source/version/provenance and detect unavailable host capability. Never read arbitrary provider endpoints from an untrusted registry row.
2. **Authorization as a separate gate:** Current configured operator allowlist stays explicit. Preserve meaningful empty lists. Invalid, duplicate, ambiguous or conflicted IDs must fail closed with actionable per-provider diagnostics. Host additions do not grant automatic authorization or change default settings.
3. **Credentials remain host-owned:** Hermes chooses credentials; AutoRouter receives non-secret provider/capability/presence metadata through sanctioned interfaces. Credential existence or successful HTTP response never proves free allowance. The proposed host scope/quota extension tracked by issue #41 is independently required for scoped quota facts.
4. **Metadata and inference are different:** Prefer host-supplied model catalogs where trustworthy, then fixed-origin, documented protocol adapters. Validate model IDs, aliases, pricing evidence, context, tool support, freshness and provenance. A catalog or credential alone does not establish an executable route.
5. **Provider-specific quota remains separate:** Provider models can appear and be operationally supported even when authoritative account quota is UNKNOWN. Only supported, documented quota sources may populate scoped allowance evidence. Never invent free entitlement for a provider or route unknown-cost/paid models under `free_only:true`.
6. **Compatibility and lifecycle:** Handle Hermes version changes, provider unload/removal, OAuth/pool updates, stale caches and unsupported hosts without widening access. No host runtime monkeypatch, credential vault, automatic network probing or unapproved live configuration changes.
7. **UI status taxonomy:** Report independently: host-known, configured/present, authentication verified/unverified, catalog available, runtime available, free verified/unknown/ineligible, quota verified/unknown, and authorized/not authorized. Replace generic `llm_unsupported` with a truthful explanation where supported by host facts. Do not turn unknown capability into success.

## Decision diagram

```text
Hermes authoritative provider registry
           |
           v
Host-backed capability inventory (visible, untrusted for spending)
           |
           +--> credential presence: present / absent / unknown
           +--> inference runtime: supported / unsupported / unknown
           +--> model catalog: available / unavailable / unknown
           +--> pricing/free proof: verified-free / ineligible / unknown
           +--> quota scope: scoped verified / unknown
           |
           v
Explicit operator provider authorization
           |
           v
Canonical eligibility / profile and preference restrictions
           |
           +--> verified eligible free model: may route
           +--> unknown, paid, unauthorized, unsupported: refuse
```

## Rollout and independent acceptance

Track implementation in [issue #119](https://github.com/diegorhoger/autorouter/issues/119).

- **Slice A: host-backed dynamic registry and schema.** Enumerate canonical IDs and capabilities without secrets, alias collisions or automatic authorizations; previous six integrations remain correct.
- **Slice B: catalog and routing integration.** Reuse sanctioned host catalog/runtime interfaces; add fixed-origin protocol-specific adapters only when required and independently justified. Distinguish discovery support from inference and verified-free selection.
- **Slice C: Providers and Settings UI.** Show separate status axes and actionable explanations, support operator opt-in for newly recognized host providers through validated versioned settings, and preserve cross-process/stale-write controls.
- **Slice D: integration and acceptance.** Test with an actual, disposable Hermes-host runtime containing a provider outside the original six, a localhost-only physical model mock, and no live credentials. Assert an unauthorized provider is excluded, an unknown-cost model is excluded, and a verified-free explicitly authorized compatible model can be routed. Preserve all six existing adapters, zero outbound on refusal, profile narrowing, model `none` and rollback.

Required negative tests: malformed IDs, alias collision, mixed invalid authorization list, host registry unavailable, plugin unload/update, account-scope ambiguity, missing credential, unavailable catalog, timeout, unknown free price, provider mismatch, stale catalog/permissions, missing task capabilities, and untrusted endpoint injection. Each proposed implementation PR must show exact-head results and independent review, with accurate skips and no fabricated host acceptance.

This ADR is an **architectural decision and P0 prioritization**, not proof that all 249 candidate research records are supported or that any newly visible provider may perform paid/unknown-cost inference. No live installation, user session or default model is modified by this document.

## Relationships

- [ADR-0003](0003-mandatory-free-only-and-billing-uncertainty.md): strict free-only proof.
- [ADR-0010](0010-connect-and-manage-through-host-authority.md): credential authority.
- [ADR-0011](0011-versioned-policy-and-execution-independent-evidence.md): independent policy and evidence contracts.
- [ADR-0015](0015-native-hermes-autorouter-picker.md): Hermes picker integration, distinct from provider coverage.
- [Issue #119](https://github.com/diegorhoger/autorouter/issues/119): P0 provider coverage implementation.
- [Issue #41](https://github.com/diegorhoger/autorouter/issues/41): host-owned scope/quota authority.
- [Issue #104](https://github.com/diegorhoger/autorouter/issues/104): ordinary-session routing.
- [Issue #116](https://github.com/diegorhoger/autorouter/issues/116): native AutoRouter picker.
