# Provider and model intelligence

The existing Providers and Models tabs display stored evidence without fetching
provider APIs or changing credentials. All five dashboard tabs and host SDK/auth
integration remain intact.

Providers keeps configured/previously discovered integrations separate from the
249-row source candidate registry. Registry totals distinguish source candidates,
configured provider IDs, the five read-only discovery adapters, and verified
eligible models/providers in the displayed snapshot. Verified counts explicitly
cover the displayed model snapshot (at most 500 rows), not a universal provider
catalog or an assertion of operational inference support. The read-only credential
inventory remains a separate two-slot NVIDIA/OpenRouter contract.

Search candidates by name/ID and filter access classification, protocol, modality,
jurisdiction and auth hints. Unknown facts remain unknown. Source classifications
are always labeled unverified; experimental/deprecated source inventory labels do
not establish model pricing. Candidate links retain source provenance and cannot
activate integrations or authorize free selection.

Models uses routing preview's actual eligibility result and stable rejection codes,
including configured-provider exclusions and cached operational quota denials.
Expand **Access and quota evidence** for access classes, per-component price
metadata, evidence source/type/issuer, original observation and expiry, auth/region
restrictions, and nullable payment/KYC policies. Quotas distinguish advertised facts
from cached account observations and show dimensions, units, windows, reset and
source ages. Missing allowances/reset values remain unknown. Account references
are hashed or omitted; no raw keys, account enumeration or credential validation
is introduced.

Token-equivalent estimates remain unavailable without an explicit workload mix and
verified spendable credit/pricing. No monthly allowances, infinite token estimates,
usage, savings or billing guarantees are invented. Cached operational access shows
healthy/exhausted/unknown states supplied by the existing free-access contract;
a zero model price never claims no-charge execution or a provider hard billing
stop. Reading the dashboard never starts a quota poll.

Tables scroll within narrow viewports. Filter inputs, native disclosure controls,
status text, external links and retry flows remain keyboard accessible. Stored
strings use text nodes; source URLs require HTTPS and reject credential-bearing
URLs. The offline Chromium harness covers filters, unknown/stale/trial/verified
states, cached healthy/exhausted/unknown quotas, XSS attempts and GET-only reads.
It is mocked API evidence, not actual Hermes host visual acceptance.

The inspected default Hermes callbacks do not expose a sanctioned credential scope
for operational quota attribution. Actual host account allowance therefore remains
unknown (`BLOCKED_HOST_CREDENTIAL_SCOPE`, Issue #13). Explicitly scoped snapshots
and synthetic fixtures demonstrate the supported contract without inventing a host
account identity or closing that external blocker.
