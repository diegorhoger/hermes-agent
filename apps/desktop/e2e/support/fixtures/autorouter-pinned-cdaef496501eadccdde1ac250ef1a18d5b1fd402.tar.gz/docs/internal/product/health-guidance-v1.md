# Observed health and recovery guidance v1

AutoRouter explains past observations and local selection restrictions. It does not
probe providers, retry execution, reset circuits or establish live availability.
Schema-v1 `health_guidance` is produced beside canonical eligibility and appears in
selection, preview, tools, the evidence report and Models UI.

## Categories and scope

Authentication, rate limit, concurrency, temporary provider service, transport,
model unavailable, verified quota exhaustion, observed success and unknown/invalid
are separate authored explanations. Raw errors, prompts, account IDs and credential
material are never projected.

Existing health circuit rows remain the source: credential authentication failures
apply to that observed credential scope; rate/transport constraints to the matching
connection/model scope; provider-service restrictions to the provider; retired
model evidence to the provider/model. Shared provider/model observations are not
misrepresented as failures of another credential. Active-account binding is shown
only when the existing typed context validates; otherwise it is unknown. The
plugin-side #36 integration is merged; a sanctioned standard-host selected-account
producer remains externally gated.

An HTTP 429 or stored `quota_exhausted` hint is reported as rate limiting, not
verified allowance exhaustion. Only the canonical matching quota gate can produce
verified-quota guidance. Its original source/observed time/expiry are retained.
No inferred balances, reset periods, units or account identity are introduced.

## Original times, confidence and expiration

Circuit observations expose their original event time, age and local
reconsideration deadline. Store schema v4 adds nullable `event_observed_at`, separate
from circuit maintenance `updated_at`. New callback writes record actual event time;
legacy-denial migration preserves a known original failure time. Existing unlabelled
v3 circuits retain unknown event provenance, rather than guessing from maintenance
time. Read-only diagnostics never migrate; the writer upgrade is transactional. Model retirement has no fabricated expiry. A closed
circuit updated by a successful observation is described as recovery/past success,
not a freshly renewed failure. Any unrecovered failure takes priority over a closed
recovery record, including failures below the circuit-opening threshold. Fallback
success uses its success timestamp; quota exhaustion uses evidence from the gate
that actually denied, never an unrelated health timestamp. Invalid/future timestamps do not become supported
recent evidence.

Confidence denotes a local observed event, not a calibrated probability or provider
availability guarantee. The seven-day display-staleness boundary reuses the
existing operational decay horizon and is explicitly not a provider TTL. Older
observations are stale, missing observations unknown and corrupt evidence unavailable.

`provider_retry_after` is always null: existing stored cooldowns do not preserve an
independently trusted provider-header provenance contract. `local_reconsider_at`
explains the existing selector restriction, never authorization to retry an API
request. Circuit open/half-open/closed transitions and ordinary eligibility rules
are unchanged. Reconsideration reads cached state only; half-open does not mean
that a live probe ran or succeeded.

## Honest default and summary labels

Previously, a default zero-valued health row could be labeled available merely
because the row dictionary was nonempty. The diagnostic reason is now unknown
until an actual successful observation exists, and half-open/past-failure states
are not promoted to observed-available health. The selection-availability boolean
still means no local hard denial; unknown health alone does not add a new gate.
Explicit require-observed-health constraints remain conservative.

The legacy `healthy` summary key is retained for compatibility but counts only
recent successful observations, without later failure/half-open restrictions.
`health_unknown` separately counts otherwise selectable rows without that evidence.
UI labels say recent observed successes/current health unknown, not live healthy.
Model badges similarly distinguish historical success/failure, stale evidence,
local cooldown and verified allowance exhaustion; a raw quota hint cannot produce
a verified exhausted badge. Existing tests expecting unobserved rows as healthy
were corrected to assert unknown rather than preserving the original defect.

## Manual recovery flow

Each failure includes controlled next-action codes: review credentials in Hermes,
wait for local cooldown, inspect connectivity, refresh catalog/choose a replacement,
or obtain authoritative quota evidence. No action executes automatically.

Models → Preview offers **Reconsider cached health**, which reloads the read-only
Models snapshot. No provider request, execution retry or circuit reset occurs.
Guidance may suggest deliberately invoking the existing `autorouter_refresh` tool
for public catalog evidence; that refresh does not test credentials, quota or live
provider availability. Apply/Use capability receipts remain #45's boundary.

## Acceptance and dependencies

Tests cover failure categories and original times, account A/B isolation, provider
and model boundaries, unknown/corrupt/stale/future evidence, 429 versus real quota,
local cooldown and half-open/recovery semantics, summary defaults, redaction,
SQLite/API/tool parity, read-only browser reconsideration and actual isolated
Hermes observer callbacks. Synthetic callback/catalog fixtures are not live provider
or active-account acceptance.

Depends on #63/#62/#61/#60/#53; no dependency is merged or silently copied. #36/#58
and #57 remain separate integration gates. Standard-host account attribution and
trusted response-header provenance remain external blockers. No inference,
credentials, Hermes changes, gateway, replay, production changes or release.

The combined private candidate uses schema v5 to include the separate scoped-attempt
column as well as the v4 health event timestamp. See [combined candidate](combined-candidate-v1.md).
