---
status: accepted
recorded: 2026-11-16
authority: owner-approved requirement to expose AutoRouter in the actual Hermes chat model picker
implementation: "Consumer MODE A landed in PR #118 (AutoRouter side); the host virtual-provider/picker/resolver seam landed on the development fork stacked on feat/pre-inference-route (upstream #156277; issue #116). Verified in an isolated disposable host (row absent without the gate; physical route resolved when gated; virtual identifier never on the wire). Awaiting upstream merge, a supported host release and explicit operator authorization: no live acceptance implied."
---

# ADR-0015: Capability-gated AutoRouter selection in the native Hermes chat model picker

## Context and evidence

The owner observed in the real Hermes Desktop model picker that available models appear under Nous Portal and NVIDIA NIM but there is **no AutoRouter Auto option**. At the same time the AutoRouter Overview reports **Plugin Enabled** and **Chat Routing Inactive**. The enabled management console, model catalog and ranking policy do not constitute a host model-picker registration or active route interception.

AutoRouter documents an experimental virtual identifier `autorouter/auto-free` that requires an enabled chat adapter. With `enable_chat_router: false`, or where the host lacks a supported resolver, a literal virtual model can be sent to the normal provider by stock Hermes. The installed v0.23.1 host does not support the proposed native ordinary-session pre-inference route (upstream [Hermes PR #156277](https://github.com/NousResearch/hermes-agent/pull/156277)); consent-gated scope/quota producers remain upstream work ([PR #156606](https://github.com/NousResearch/hermes-agent/pull/156606)). The requested visible picker integration is separate from automatic interception of every ordinary chat (AutoRouter [#104](https://github.com/diegorhoger/autorouter/issues/104)).

Evidence types: owner-provided live Desktop screenshots and Overview readout (2026-11-16), existing repository documentation/installed-host reports, and merged AutoRouter unit/isolated-host integration reports. The picker feature is **not** currently proven implemented.

## Decision

Provide a first-class **AutoRouter · Auto (Free)** entry in the **actual Hermes chat model selector**, implemented through an explicitly supported, host-owned picker registration and route-resolution contract. The label is a user-visible routing *mode*, not a provider-hosted model and not a promise of live free quota. Hermes remains authoritative for picker rendering, session selection, provider/client construction and credential handling.

A selectable entry must be shown **only if** a supported runtime exposes both (1) a valid picker registration/selection interface and (2) an enabled, functioning virtual-to-physical model resolver for that selection. The plugin's enabled status, a populated catalog, a configured ranking policy, or existence of the virtual identifier alone is **insufficient**. On unsupported/disabled/unregistered/failed adapters, hide it or show a truthful **non-interactive** unsupported state if the host SDK provides that representation. Never add a decorative clickable row.

Selection must deliberately opt the conversation into AutoRouter; **explicit physical model picks always override this mode**. Switching back to a named model must be reversible. Define and test behavior across chat creation, resume, per-session state, plugin reload/restart, profile defaults and potential stale or missing routing bindings. Do not silently change the user's global Hermes default or reuse a previous session's binding for a different session.

Resolve a selected AutoRouter mode into a **physical provider and model before inference-client construction**, honoring the canonical verified-free-only policy, provider authorization, model preference `none`/allowlist/unrestricted states, profile narrowing, minimum context, tool requirements and host credential authority. An unresolved virtual name, absent resolver, malformed decision, ineligible candidate or authorization failure must refuse **before outbound provider requests**. No virtual model name may reach an external provider. Preserve zero paid fallback and never infer account quota from model pricing, credential presence or response success.

## Ownership and integration boundaries

- Reuse Hermes-native Desktop controls and SDK contracts; do not introduce a second frontend framework, host monkeypatch, or an AutoRouter-owned parallel picker.
- Inspect the actual Hermes picker and plugin API. If a supported registration interface is absent, propose the **smallest opt-in host extension** on the authorized Hermes fork; reuse #156277's routing seam where appropriate, but do not assume that seam alone creates a selectable picker item. Keep distinct upstream work in a focused PR if needed.
- Preserve stock Hermes behavior with no registered consumer, on unsupported versions, or with feature flags off.
- Host-owned capability/version negotiation must be truthful. Do not claim a fake "Auto" model is actionable while `enable_chat_router` is false or a native resolver is unavailable.
- Never expose host secrets, accept an unverified free-access claim, route paid/unknown-cost inference, or authorize unsafe replay/fallback.
- Existing ADR-0014 model-management toggles and their merged acceptance remain independent of this new chat-selector feature.

## Implementation and acceptance

The delivery issue is [#116](https://github.com/diegorhoger/autorouter/issues/116). Required verification:

1. Actual Hermes model-picker UI: supported-and-enabled shows **AutoRouter · Auto (Free)**; unsupported/disabled/failed states contain **no actionable** virtual item. Test keyboard, focus, screen-reader semantics, narrow widths, feedback, and error states.
2. End-to-end isolated host: choosing AutoRouter in the real picker leads to pre-client resolution of a verified-free physical model, and a localhost mock receives only the physical provider/model (never `autorouter/auto-free`).
3. Explicit physical picks, normal `/model`, new chats, resume, multi-session isolation, setting/profile changes and switching back remain deterministic and reversible.
4. No eligible model, explicit preference `none`, stale state, unsupported host, invalid route or consumer failure result in refusal and **zero outbound provider calls**.
5. Capability changes, plugin reload, host downgrade and feature deactivation cannot leave a visually actionable but nonfunctional route.
6. Isolated test evidence is **not** operational release acceptance. A supported Hermes release, explicit operator opt-in and authorized live UI/ordinary-session test are required before claiming production availability.

This decision approves the **user experience and safety boundary**, not host changes, a merge, deployment, paid inference or activation on the live v0.23.1 gateway. Coding-agent contributions must use focused PRs and independent ChatGPT review.

## Relationships

- [ADR-0003](0003-mandatory-free-only-and-billing-uncertainty.md) — verified free-only hard gate.
- [ADR-0008](0008-no-unsafe-replay-or-unowned-enforcement.md) — no unauthorized execution fallback.
- [ADR-0009](0009-native-dashboard-and-host-theme-inheritance.md) — native host UI conventions.
- [ADR-0014](0014-native-hermes-model-toggles.md) — management toggles, not chat picker registration.
- AutoRouter [#104](https://github.com/diegorhoger/autorouter/issues/104) — ordinary-session routing.
- AutoRouter [#41](https://github.com/diegorhoger/autorouter/issues/41) — authoritative account-scope/quota evidence.
- Hermes [PR #156277](https://github.com/NousResearch/hermes-agent/pull/156277) and [PR #156606](https://github.com/NousResearch/hermes-agent/pull/156606) — proposed host capabilities.
