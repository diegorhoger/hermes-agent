---
status: accepted
recorded: 2026-11-07
authority: owner-approved AutoRouter mission; retrospective naming context
implementation: "AutoRouter branding with compatible autorouter plugin/package identity preserved; rename or public release not authorized."
---

# ADR-0013: AutoRouter brand with compatible repository and plugin identity

The product is AutoRouter, formerly AutoRouter, with the promise “Know which AI model to use, and why,” the brand “AutoRouter. Exhale.” under the AutoRouter name. Product-facing naming does not automatically rename repository URLs, installed plugin IDs, configuration keys, tool names or state paths: those changes have compatibility and migration consequences and belong in independently reviewed release packaging.

## Consequences and limits

Preserve the website's established direction and clearly explain the AutoRouter repository transition. No domain deployment, repository visibility change or untested installation command follows from adopting the name. Do not break existing users by silently replacing the plugin identity or storage path during unrelated feature work.

## Evidence and ownership

[Epic #37](https://github.com/diegorhoger/autorouter/issues/37), [release #51](https://github.com/diegorhoger/autorouter/issues/51), [ADR register #55](https://github.com/diegorhoger/autorouter/issues/55). Current code anchors: `plugin.yaml`, `README.md`, `RELEASE.md`. See [delivery history](delivery-history.md); accepted product direction is separate from release acceptance.
