# Hermes pre-inference routing contract (issue #104)

Status: **implemented on the AutoRouter side; blocked on one host extension.**
Hermes v0.23.1 (`3b421578588243f920886e6fe79a6faa87ea026e`) has no sanctioned
pre-inference selection seam, so ordinary sessions are **not** auto-routed and
`plugin.yaml` / the live install ship `enable_native_routing: false`. Nothing
here monkey-patches the host; the extension is a proposal, not an applied patch.

## What the host lacks today (verified 2026-11-15, once)

Plugin-visible seams and why they are insufficient:

| Seam | Kind | Why it cannot select a route |
| --- | --- | --- |
| `llm_request` middleware (`apply_llm_request_middleware`) | rewrites the request payload | client is already built; can only touch payload keys (e.g. `model`), never provider/base_url/credentials |
| `llm_execution` middleware | wraps execution in-process | would make AutoRouter responsible for provider clients and credentials; selection latency lands inside the retry loop |
| `pre_api_request` / `on_session_open` / `pre_llm_call` | observers | return values ignored; cannot influence execution |
| `hermes_cli.model_switch` / `resolve_startup_model_route` | selection machinery | not a plugin seam; AutoRouter's opt-in compatibility adapter interposes here, it is not a host contract |

`hermes plugins capabilities` reports **no** plugin-held capabilities, and no
`pre_inference_route` middleware kind, hook or call site exists
(`hermes_cli/middleware.py` `VALID_MIDDLEWARE` has only `tool_request`,
`tool_execution`, `llm_request`, `llm_execution`).

## Minimal host extension (the entire ask)

Three host changes, all optional, all backward compatible; roughly 120 lines
plus tests, best sent as two upstream PRs:

1. `hermes_cli/middleware.py`
   - Add `PRE_INFERENCE_ROUTE_MIDDLEWARE = "pre_inference_route"` to
     `VALID_MIDDLEWARE` (and the name export).
   - Add `apply_pre_inference_route_middleware(metadata, **context) -> PreInferenceRouteResult`:
     invoke `pre_inference_route` middleware with **non-secret** metadata;
     first non-`None` route wins; validate the result shape (provider/model
     `^[a-z0-9][a-z0-9-]{0,63}$` / model ≤ 199 chars, no key-like fragments);
     malformed results are dropped fail-closed.
   - Metadata passed to callbacks (nothing else):
     `{session_id, task_id, turn_id, platform, hermes_profile, requested_model,
     requested_provider, explicit_model: bool}`.
2. One call site before client construction
   - `resolve_startup_model_route` (session create) **and** the agent-init
     path used for direct agent construction: after the requested route is
     known but **before** the provider client is built, if the plugin
     `autorouter` opted in (`plugins.entries.autorouter.settings.enable_native_routing`
     via `load_config_readonly`), invoke the middleware.
   - Route: validate provider against the same registry the `/model` switch
     pipeline accepts, commit through the same `apply_model_selection` path,
     bind to this session only. Never mutate global config, other sessions, or
     `model.default`.
   - Refusal: abort session start with the plugin's reason; **no provider
     request is issued** (identical fail-closed contract as the virtual model).
   - Opt-out semantics: absent flag or absent consumer ⇒ byte-identical
     behavior to stock Hermes.
3. Receipt
   - The middleware callback's return already carries the sanitized receipt;
     the host does not need to persist it — AutoRouter writes its own decision
     ledger (`decisions` table) exactly as it does for the virtual model.

## AutoRouter consumer (implemented, host-independent)

`autorouter_core/integration/native_routing.py`, wired in `register()`:

- `detect_host_native_routing()` — read-only probe; reports `supported: false`
  on v0.23.1 with the reason string. `autorouter_status` exposes it as
  `native_routing` so the gap is visible in the dashboard/tools, not implied.
- `resolve_consumer_route(metadata=...)` — never raises, never opens a socket.
  Statuses: `passthrough` (opt-in off — host proceeds untouched), `route`
  (selected), `refuse` (fail-closed; the host must stop before network).
- Per-session binding: first route for `session_id` writes a non-reversible
  binding (`meta` key `native_route_binding:<sha256(session_id)[:24]>`)
  `{profile_id, profile_name, provider, model, bound_at}`. Resumed sessions
  re-derive under the bound profile — never under the operator's current
  default — and a missing/corrupt bound profile refuses rather than widening
  to any default. Bindings are first-route-wins (`INSERT OR IGNORE`).
  Global-policy routes (no user-created default profile) stay unpinned and
  follow the current default on resume — a documented, deliberate policy.
- Refusal before network is absolute: no eligible free verified model,
  missing catalog, corrupt/missing bound profile, missing `session_id`, or
  `metadata` that is not an object ⇒ `refuse`. There is no paid/unknown-cost
  fallback anywhere in the path; eligibility gates are identical to the
  virtual model (`_route_resolution.resolve_route_detailed`).
- Receipt: `{schema_version, plugin: "autorouter", decision, route, route_profile,
  policy, session (12-hex sha256 of session_id), evidence_ts, refusal?}` with
  key-like-fragment redaction as a second line of defense.

## Acceptance for issue #104 (host present, flag on)

1. New ordinary chat session follows the operator-selected profile with zero
   configuration changes (global default untouched).
2. Session A bound to profile A, session B bound to profile B; changing the
   default in between does not rewrite existing sessions.
3. Resumed sessions follow the bound profile; deleting the bound profile
   refuses instead of substituting.
4. Zero provider requests on refusal (asserted with a localhost mock that
   records connections).
5. `enable_native_routing: false` ⇒ stock behavior, byte for byte.
6. `/model` explicit pick is never overridden by the consumer.

## What remains external

- Upstream authorship/review of the two PRs (I do not hold write authority on
  `NousResearch/hermes-agent`; nothing was forked or pushed there).
- Real-host end-to-end acceptance with the user's Desktop opting in.

## Acceptance repro (dispatch 131, issue #126)

`tests/integration/test_native_consumer.py` exercises the real host flow on a
disposable combined archive — it never mutates the live install:

1. Build a pristine Hermes v0.23.2 (`ae2a81ccc00e9b7c06301523e5bb09608397149c`) archive.
2. Cherry-pick onto it, in order: `96aa7df96427812a88ebc923ade584580caa9e3e`
   (upstream seam #156277 host extension), then the picker stack from fork
   PR #1 (base `feat/pre-inference-route`, head `eda82804c5237827cdfb003f8795a92ba38f7457`):
   `bdf8a5756f27879a545fb538ed8f7db69f6e78a6`,
   `e1e3c31aab37af4e25d3e229473a65190c406ed2`,
   `941adc09f8a4bb1aeb6d44a637ed15c1d264524b`,
   `eda82804c5237827cdfb003f8795a92ba38f7457`;
   the feature files must be byte-identical to the fork branch.
3. Point the tests at the result:
   `AUTOROUTER_HERMES_SOURCE=<combined archive> python3 -m pytest tests/integration/test_native_consumer.py`
4. Stock v0.23.2 (no seam) validates the fail-closed unsupported-host path:
   `AUTOROUTER_HERMES_VANILLA_SOURCE=<v0.23.2 archive>`.

The suite requires no network. The out-of-six `mockinfra` provider is a
localhost-only fixture; all price evidence is test-only and quota stays
UNKNOWN.
