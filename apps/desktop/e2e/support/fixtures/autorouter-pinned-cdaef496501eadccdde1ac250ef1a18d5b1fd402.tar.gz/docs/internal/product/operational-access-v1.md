# milestone-04 — operational access acceptance boundary

Related to #41 and #13. This is an integration acceptance wrapper around PR #36,
not another quota engine. Plugin integration through #36/#58/#69 is merged.
A sanctioned standard-host producer remains unavailable. Issue #13 is closed for
its bounded delivery; that closure does not establish full account-bound collection
or close #41. No Hermes publication or modification is authorized.

## Executable evidence

`tests/test_operational_access_acceptance.py` exercises the actual consumer,
persistent cache and evaluator with synthetic sanitized facts:

- A available / B exhausted remain isolated; unknown cannot borrow either state.
- Expiry preserves original timestamps and never fabricates reset allowance.
- 401/403/429/5xx/timeout-equivalent invalidation affects only its observed scope,
  remains unavailable rather than invented exhaustion, and retains original facts.
- An unextended host with no scope/quota API never polls or infers a current
  identity, even if a previous scope is supplied as an observation.
- A wrong-scope result is rejected without account reassignment.

The existing PR #36 structured-scope, refresh/concurrency, migration and health
suites remain the authoritative attempt attribution and storage regressions.
Synthetic sanitized facts cannot prove that standard Hermes produces authorized
identity. Private exact-source host integration must be reported separately.
No raw key is read or hashed here; hashes of opaque references are not credential
hashes or proofs of account equivalence.

## Standard-host blocker

Read-only source audit of installed Hermes
`2bd378ed1b8d6bf2192cb26e0a55ff3091e6bd19` (reported v0.23.0) found ordinary
request hooks but no sanctioned `llm.credential_scope` producer or scope-bound
`quota_fetch` operation. Its provider request helper supports Codex/plugin OAuth,
not exact selected OpenRouter API-key authorization. The OpenRouter usage
collector resolves a runtime credential; its cache identity_id is not authority
to select a credential for an attempt. Native current-account acceptance is
therefore **BLOCKED_EXTERNAL**, not DONE.

Without that producer, quota and associated dashboard state remain UNKNOWN.
A previous observation must not become current-account authority. Reading a
private pool, blindly accepting an opaque ID, or independently resolving an env
key would not repair the authorization gap. NVIDIA and other unsupported quota
sources remain UNKNOWN. Metadata pricing and USD credits are not free allowance
or a guaranteed provider billing hard stop.

## Smallest external dependency and release gate

A separately authorized host contract must bind provider/profile/request/attempt
identity to the actual selected credential and enforce plugin consent/declarations
for a narrow fixed-endpoint quota operation. It must bound latency, frequency and
response size, refuse redirects, sanitize failures/results and preserve original
observation/expiry while retaining secrets in the host. The private extension
exercises this proposed behavior; it is not standard-host availability.

A separate dashboard also needs a sanctioned current-scope context before it can
claim current-account allowance; telemetry cannot supply that authority.
Independent review of PR #36 and this exact dependent HEAD, an accepted host
contract, and isolated real-host producer acceptance remain required. Plugin-side
safe degradation and cached facts are reviewable; no native quota completion,
release, production change or execution fallback is claimed.

## Approved quota-window and preflight amendment

`free_access.connection_allowance` projects a version-1, maximum-32-window view
without mutating or renewing stored observations. Each supported window retains
its dimension, units/currency, source, confidence, scope and original times.
Unsupported sources/windows stay descriptive UNKNOWN; unlike windows are not
summed. The current inspected operational source supports only OpenRouter's
observed daily free-request counter. Additional provider windows are not invented.

`free_access.evaluate_policy` distinguishes:

- `prefer_available_allowance`: unknown may remain eligible under all other hard
  rules; only genuinely fresh available evidence sets the preference signal.
- `require_fresh_account_allowance`: unknown, stale, unavailable, duplicate or
  unsupported required-window evidence denies this requirement.
- `avoid_verified_exhaustion`: genuinely exhausted matching scope is excluded,
  while unknown never becomes invented exhaustion.
- `require_no_charge_guarantee`: denied; no inspected source establishes an
  independently enforceable billing boundary.

The explicit `autorouter_refresh` include-quota option accepts these policy IDs
and returns cached preflight evidence. It neither fetches keys nor executes,
reserves spending or applies a model. The default remains cached-only. Selection
contract integration and adapter-produced active connection authority are the
separate #42/#45 acceptance dependency: a caller-provided scope or last observed
account is not permission to use a credential. Native current-account completion
remains BLOCKED_EXTERNAL until a sanctioned host producer exists.

## Mainline integration boundaries

Router uses this versioned evaluator by default; an explicitly unavailable
evaluator remains unavailable. Only validated host-owned selection context can
associate account allowance. Caller-supplied scopes do not create authority.

Dashboard storage lookup is read-only. Before enabled-runtime initialization,
profile-owned legacy diagnostics read the legacy database directly. Only enabled
runtime initialization uses sanctioned plugin storage and snapshots migration.
Stop legacy writers before initialization; later legacy writes are not mirrored.
Disabled registration and read-only endpoints never publish a migrated copy.
Rollback needs a matching prior schema/database backup; replacing plugin files
alone does not prove database downgrade safety.
