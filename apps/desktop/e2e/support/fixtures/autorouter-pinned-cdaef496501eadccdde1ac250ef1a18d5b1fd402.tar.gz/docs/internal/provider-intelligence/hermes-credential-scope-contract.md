# Hermes Host Credential-Scope Contract (Upstream Proposal)

## Purpose

AutoRouter (AutoRouter V1) consumes an **opaque credential scope** from Hermes to isolate quota
observations by active account. Hermes currently does not expose this capability to plugins.
This document specifies the minimal contract needed.

## Required Hermes Capability: `llm.credential_scope`

### Hook field

When Hermes fires `pre_api_request` / `post_api_request` / `api_request_error` hooks,
it must optionally include a `credential_scope` field in the hook payload:

```python
credential_scope: dict | str | None
```

**Structured form (preferred):**
```json
{
  "provider_id": "openrouter",
  "credential_scope_id": "<32-char lowercase hex>",
  "identity_status": "known"
}
```

**String form (legacy):**
```
"openrouter:<32-char hex>"
```

**Unknown form:**
```
null  (or omitted)
```

### Validation rules (AutoRouter side)
- `provider_id` must match the hook's `provider` field
- `credential_scope_id` must be exactly 32 lowercase hex characters
- `identity_status` must be `"known"`
- If any field is missing or invalid, the scope is treated as unknown (empty string)
- No raw credentials, key fragments, or account identifiers may appear in the scope

### Capability declaration

Hermes plugin manifest must declare:
```yaml
capabilities:
  - llm.credential_scope
```

Without this capability, AutoRouter treats all scopes as unknown and never borrows
another account's quota state.

## Required Hermes Capability: `ctx.quota_fetch`

### Method signature

```python
ctx.quota_fetch(
    provider_id: str,           # e.g. "openrouter"
    credential_scope_id: str,    # 32-char hex from credential_scope
    quota_source: str,          # e.g. "official_key_limits"
) -> dict
```

### Response contract

**Success:**
```json
{
  "status": "ok",
  "provider_id": "openrouter",
  "credential_scope_id": "<32-char hex>",
  "quota_source": "official_key_limits",
  "observed_at": <unix timestamp float>,
  "expires_at": <unix timestamp float>,
  "limit": <int >= 0>,
  "remaining": <int >= 0>,
  "used": <int >= 0>
}
```
Constraints: `remaining + used == limit`, `observed_at <= now < expires_at <= observed_at + TTL`

**Failure:** Any exception or non-`ok` status is treated as unavailable (fail-closed).

### Boundaries
- Collection timeout: 2 seconds (including failure)
- No credential resolution or account enumeration
- No raw key access
- Fail-closed: missing/timeout/unauthorized → unknown state, not fabricated balance

## Hermes Plugin Manifest Capability

The following capability must be added to Hermes' known capability set:
```
llm.credential_scope
```

Currently Hermes reports:
```
known: gateway.platform_actions, llm.agent_id_override, llm.model_override,
       llm.profile_override, llm.provider_override, llm.side_question,
       llm.task_override, tools.override
```

## Why this is needed

Without `llm.credential_scope`:
- AutoRouter cannot distinguish Account A (available) from Account B (exhausted)
- All quota observations are attributed to an unknown scope
- `Require fresh account allowance` policy always fails
- `Avoid verified exhaustion` cannot exclude genuinely exhausted connections

## AutoRouter-side status

All AutoRouter-side implementation is complete:
- `credential_scope.py`: decodes host observations, validates structure, rejects invalid/unknown
- `scope_quota.py`: consumes quota observations, validates response, persists with lease
- `free_access.py`: canonical scope, refresh leasing, TTL enforcement
- Tests: 133 passed (credential scope, scope quota refresh, quota policies, scoped health)
- Fail-closed: unknown scope → no quota observation, no borrowing

## What is missing (Hermes-side)

1. Hook payload must include `credential_scope` field for active account identity
2. Plugin capability `llm.credential_scope` must be registered in Hermes
3. `ctx.quota_fetch` method must be provided to plugins with sanctioned account access
4. No raw credential access — only opaque 32-char hex scope IDs

## Upstream action required

File an upstream issue/PR against `NousResearch/hermes-agent` requesting:
1. Add `llm.credential_scope` to `VALID_CAPABILITIES` / plugin capability set
2. Include `credential_scope` in hook payloads (`pre_api_request`, `post_api_request`, `api_request_error`)
3. Provide `ctx.quota_fetch` method on plugin context for sanctioned quota observation
4. Ensure no raw credentials are exposed — only opaque scope IDs

## Issue #41 closure condition

Issue #41 can be closed when Hermes provides the above contract and AutoRouter's
integration tests pass against a real (non-mocked) Hermes host with sanctioned producer.
Until then, #41 remains open with this precise dependency.
