# Explicit task profiles v1

AutoRouter recommends eligible models and explains the evidence. Hermes retains execution
authority. Profiles do not establish semantic competence, account entitlement or a
no-charge billing boundary. No prompt inspection or automatic classification occurs.

| Profile | Hard requirements | Operational preference | Unsupported claim |
| --- | --- | --- | --- |
| General | Fresh verified-free price, verified context at least 8192, existing health gates, explicit user constraints | Existing balanced General | Universal suitability |
| Coding | Same; verified tool support only when the declared workload requires tools | Balanced General; no implicit tool or coding-quality bonus | Coding competence |
| Fast response | Same hard gates | Existing confidence-aware Fast response weights using observed latency | Semantic quality or unmeasured speed |

8192 is the existing selection minimum, not a task-quality threshold. Profiles do
not manufacture distinct hard requirements merely to create different outcomes.
A tool-requiring Coding workload can eliminate a model accepted by General;
Fast response can rank a faster measured model ahead of a more reliable model.
Absent relevant evidence, deterministic ties are appropriate.

## Contract and public surfaces

Select an explicit profile using the backward-compatible optional field
`selection_policy.task_requirements.profile = {"schema_version": 1, "id": "coding"}`.
The surrounding #53 v1 contract remains mandatory. The task label must match the
profile ID. `preferences.policy` must match the profile's documented preference
(aliases resolving to the same canonical preference are supported); conflicting
explicit declarations reject rather than silently override. Older task declarations
without `profile` and legacy ranking aliases retain their existing behavior.

`task_profiles.request(id, configured_providers, requires_tools=False)` constructs
a validated public-evidence request template. Explicit tools/context requirements
compose through the existing hard evaluator; they never relax pricing, connection,
quota, exclusion, concurrency, health or cooldown constraints. The default quota
mode is avoid-verified-exhaustion. Other quota modes and connection restrictions
can be supplied through the existing envelope; no #58 evaluator is duplicated.

Profiles are discoverable through `autorouter_status` and the host-authenticated
read-only `GET /api/plugins/autorouter/task-profiles`. The latter also provides
validated preview templates for configured providers. Tools accept the envelope
through `autorouter_select`. For explicit profiles only, the tool defaults its
workload-tools requirement to false; an explicit caller requirement always applies.
Legacy tool calls preserve their previous default.

Router selection/preview, tool responses and dashboard POST `/selection/preview`
share one canonical evaluator. Models → Preview provides a labeled profile selector,
a workload-tools checkbox and an explicit read-only preview button. This does not
change persisted settings, apply a model, discover providers or invoke inference.
The result discloses profile version, constraints, source/freshness, unavailable
properties and semantic quality unknown. Requests with invalid profile IDs,
versions, fields or conflicts reject with bounded authored codes and no fallback.

## Evidence and freshness

Capability/context/price proof uses each field's original independent source,
retrieval time and expiry. Missing/stale required proof denies. No timestamp is
refreshed by selecting a profile. Catalog discovery is distinct from eligibility
and real account entitlement, following the merged five-provider discovery evidence contract.

Fast response reuses the existing bounded, decayed final-request observations,
EWMA and confidence-aware scoring. An additive `last_latency_observed_at` field
tracks the actual last latency measurement separately from other outcomes. A newer
outcome without latency cannot renew old speed evidence. Missing, future, untrusted
source or seven-day-old latency has no measured speed claim or positive confidence;
independent reliability observations are retained. Original evidence dates remain
visible in outcome summaries. Neutral ranking priors are not measured benchmarks.

## Dependencies and acceptance

The policy (#53), discovery (#57), explicit-profile (#60) and subsequent integration
changes are merged into main through #69. The original branch dependencies are
historical provenance, not current unmerged gates. Repository-local integrated
acceptance does not establish live provider entitlement or standard-host authority.

Public task evidence evaluation does not depend on #36's private host extension.
Standard-host connection authority and strict account quota/no-charge capabilities
remain unknown or denied as required by #53. #45 owns Apply/Use. Gateway #54 remains
deferred. No Hermes, production, credentials or website changes are included.

The portable `tests/fixtures/task-profiles-v1.json` is synthetic parity data, not
provider entitlement. Unit/SQLite/API/browser and actual isolated Hermes plugin tests
exercise declared profiles without live providers, inference or raw credentials.
