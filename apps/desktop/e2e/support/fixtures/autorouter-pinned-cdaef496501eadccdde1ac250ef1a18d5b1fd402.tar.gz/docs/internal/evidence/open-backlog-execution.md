# Open backlog execution ledger

Baseline: `918207b7b7e42aec32ab417e6cb14d4894e56579`; zero open PRs and 16 open issues discovered from live GitHub on 9 November 2026. Principal retains acceptance, closure and merge authority. No issue closure or release is implied.

## Execution order

### #26 — UI: Native Hermes dashboard parity, minimal design, and live theme inheritance

Created: 2026-11-06T00:36:21Z

Status: **PARTIAL — BLOCKED_HOST_VISUAL_E2E for OS-system-theme only**.

Requirements: native five-tab UI, host token/typography inheritance, flat scoped styling, accessible keyboard/focus/contrast, reduced motion, responsive layouts, authentication/permissions, live named themes and OS-system theme.

Existing merged implementation: native token bridge and dashboard workflows through PRs #66/#69. Current main tree exactly matches reviewed integration tree `ca51fc67c989d126bfd5fa1f6f73b967119d7ce2`; checked with Git, not inferred from ancestry.

Evidence reused: authenticated artifact-backed pinned Hermes `3a5f88ece685f16082369504ee263fbc12a41cc8`, source `ce9c60087c07cec60bed742e184ab2aab7396c14`, artifact SHA256 `0cf66351ab1882eff88844392c43b04dcab1a53deb389964d23cf01b5ef9f8c7`. Receipt contains eight named themes, 120 tab/viewport checks, zero JS errors, authentication denials, settings roundtrip and process teardown. Host assets pinned separately; private patched scope is not standard-host authority. Existing guarded browser checks include visibility/bounds/overflow at 390/768/1440, keyboard and no-remount theme inheritance. Historical full suite 1319 passed; no new execution of that suite claimed here.

Verification this dispatch: loaded actual GUI JSON and asserted theme/tab/error fields; compared exact main and tested-source trees. No plugin visual defect reproduced; no code changed.

External gate: pinned Hermes exposes eight named presets but no OS-system mode/Desktop bridge. Required interface: native web theme state supporting OS preference changes, exposed to plugin CSS tokens without remount. Acceptance: emulate OS light/dark while host System mode selected and verify all five tabs inherit tokens. Do not fabricate a plugin theme engine.

Disposition: keep open; principal may accept completed named-theme scope. Next authority: sanctioned upstream web-theme support or explicit acceptance-criteria amendment.

### #35 — Future model-performance evidence interoperability

Created: 2026-11-06T16:31:49Z

Status: **DOCS CANDIDATE SUBMITTED; runtime integration remains deferred**.

Requirements: one provisional versioned interoperability document, ownership/data flow, independent evaluation provenance, digest verification, null/zero semantics, quarantine, canonical hard-gate precedence, opt-in and rollback; no runtime integration.

Work: wrote an interop-evidence proposal on an independent branch from accepted main. Read-only GitHub inspection of the external evidence-program issues informed ownership. That proposal has since been removed from the current tree (dispatch 92 scope gate); its content remains in Git history. No adopted wire API or completed future evaluator is claimed; external component mapping remains explicitly unverified.

Submitted: [PR #71](https://github.com/diegorhoger/autorouter/pull/71), exact HEAD `9f40c0757ebb04d272f4578052bda0147177acd8`, base `918207b7b7e42aec32ab417e6cb14d4894e56579`, mergeable, one Markdown file.

Verification: `python tools/check_adrs.py` PASS; `git diff --check` PASS. No runtime test rerun necessary for documentation-only change. Remaining gate: principal documentation acceptance/merge; later runtime activation requires separate authority. Issue remains open.

### #37 — EPIC: AutoRouter V1 — fulfill the landing-page model-decision journey

Created: 2026-11-07T16:15:28Z

Status: **PARTIAL — parent acceptance tracker; release/host gates remain open**.

Requirements: 24 traced commitments; real-host end-to-end journey; honest unknown/error handling; native dashboard/auth; independently accepted artifact and separate release authority.

Work: read current epic and issue #38, reconciled accepted main through PR #69 and live child states. Existing modules implement discovery/check/select/explain, manual handoff, observations and packaging. Native context-bound apply/use and authoritative account/quota/request linkage remain external; website mismatch and public-release authority unresolved. No epic feature branch or speculative implementation created.

Evidence: accepted main `918207b7b7e42aec32ab417e6cb14d4894e56579`; claims run documented under #38. Historical exact-source artifact-backed suite 1319 passed and authenticated GUI receipt remain provenance-bound to ce9c600; main tree equality verified under #26. No suite rerun claimed. Principal owns child acceptance/closure; do not infer full completion from merged PRs or closed bounded children.

Disposition: epic remains open. Tracking corrected in GitHub without closing or changing product requirements. Next authority: native host interfaces, website decision and separately approved release acceptance.

### #38 — milestone-01 [P0] Product-to-code acceptance contract and frozen launch claims

Created: 2026-11-07T16:16:17Z

Status: **LOCAL CONTRACT VERIFIED; WEBSITE/RELEASE ACCEPTANCE PENDING**.

Requirements: all 24 frozen claim IDs/quotations/digests/owners, executable proof references, truthful supported/partial/blocked states and explicit gates; filter-resistant proof execution.

Existing merged implementation: PR #52 plus #69 checker repair and current implementation mapping. Work: read full issue, executed actual checker against accepted-main runtime in a disposable pinned host environment; no claims promoted, quotations rewritten or website accessed.

Command: pinned private-baseline Python `autorouter-v1-delivery/evidence/backlog-main-verification/run_claim_proofs.py`, which invokes staged `tools/check_product_claims.py --run-proofs`. Result: mapping PASS, 24 claims, 35 proof functions, **110 cases passed; zero failed/errors/skipped/missing**, 20.72s. Regression tests retained for missing/deselected/parameter/skipped/error/empty proof outcomes. WEBSITE_SOURCE NOT_VERIFIED; release BLOCKED; independent_release_acceptance false. Log is private evidence outside Git; executable checker and references are in merged main.

Remaining: independent claim acceptance and actual authorized website-source verification; fictional paid preference mismatch remains explicitly blocked. No new implementation PR needed. Issue remains open pending principal disposition; website modifications/public release not authorized.

### #39 — milestone-02 [P0] Hermes-native guided activation and first-use journey

Created: 2026-11-07T16:16:19Z

Status: **PLUGIN IMPLEMENTATION VERIFIED; principal acceptance pending**.

Requirements: explicit activation/provider setup, presence versus authentication, deliberate refresh, canonical recommendation and supported manual handoff; disabled/missing/invalid/stale/no-match/partial states; clean real-host/browser and accessibility.

Existing merged implementation: #65's first_use.py, GET /first-use, native guide controls, strict provider-list validation; #63 manual handoff. Work: inspected full issue and tests, ran first-use/inventory/onboarding/discovery/browser/registered-host cases. No missing runtime defect reproduced. Fresh authenticated pinned Hermes browser with exact ce9c600 artifact (identical accepted-main tree) exercised Start guided setup, unavailable authentication, catalog-refresh-required, read-only recheck and keyboard Open providers. All plugin calls GET, zero JS errors; owned server stopped and port closed. No implicit activation, provider request, settings write or inference.

Evidence: pinned Python `evidence/backlog-main-verification/run.py tests/test_first_use_v1.py tests/test_connections.py tests/test_onboarding_v1.py tests/test_discovery.py tests/test_discovery_conformance.py tests/test_verified_metadata.py tests/browser/test_harness_interactions.py tests/integration/test_acceptance_gates.py`: **224 passed, zero failed/skipped**, 51.79s. Browser and actual-host tests are included subsets, not extra passes. Supplemental `gui_first_use.py` probe exit 0, receipt under first-use-browser/acceptance, teardown verifies closed port. Invalid keys are represented through synthetic presence/failure evidence, not real credential probes.

Remaining: principal acceptance; native current-session Apply/Restore and credential/account authority remain separate host gaps. Guide correctly offers validated manual handoff, not native execution readiness. No new implementation PR or closure required from agent.

### #40 — milestone-03 [P0] Five-provider discovery and capability-evidence conformance

Created: 2026-11-07T16:16:20Z

Status: **FIVE-ADAPTER LOCAL CONFORMANCE VERIFIED; live entitlement unverified**.

Requirements: exactly five operational discovery integrations, sourced fields/TTL, partial/failure/empty semantics, revocation, conservative unknowns and one actual isolated-host discovery→eligibility→recommendation path.

Existing merged implementation: #57 adapters/discovery evidence and #69 complete/partial five-provider registered-host flow. Per-provider source/field/gap matrix is `docs/internal/provider-intelligence/discovery-conformance.md`; official source checks there are dated 7 November, not represented as a new live-provider observation. Work: read complete issue and matrix; verified existing runtime paths and executed current tests. No runtime gap reproduced; corrected stale dependency introduction only.

Evidence: shared 224-case first-use/discovery run above; additional disjoint invocation `run.py tests/test_provider_adapters.py tests/test_access_evidence.py tests/test_evidence_gate.py`: **65 passed, zero failed/skipped**, 0.84s. Covers fixed endpoints, header-only auth, bounded pagination, malformed/partial/empty catalogs, 401/403/429/5xx/timeouts, field expiry and revocation. Actual PluginManager/registered-tool tests use synthetic transport for all five providers, select only source-backed free OpenRouter proof, keep other costs/capabilities unknown and strict no-charge denied. The 249 offline candidates remain unverified, not connected integrations.

Remaining: principal source/evidence acceptance and any separately authorized live entitlement/release proof. No provider inference or real credentials used. Existing source already merged; no duplicate feature PR or issue closure.

### #41 — milestone-04 [P0] Active credential identity and operational free-access acceptance (#13)

Created: 2026-11-07T16:16:22Z

Status: **LOCAL CONSUMER VERIFIED — BLOCKED_EXTERNAL_HOST_CONTRACT**.

Requirements: isolated account/connection/model/shared windows, immutable attribution, original freshness and migration, safe concurrent refresh, four explicit policies, unknown standard-host authority and no raw credential handling or billing guarantee.

Existing merged implementation: PRs #36/#53/#58 and integration #69; versioned evaluator, scoped cache, refresh leasing and canonical selection remain in main. No replacement quota engine is needed.

Executed: guarded `run.py tests/test_quota.py tests/test_quota_policies_v1.py tests/test_scope_quota_refresh.py tests/test_selection_policy_v1.py`: **301 passed, 0 failed/skipped** (1.91s). Covers contradictory exhaustion, all four policies, incompatible windows, account/model isolation, original expiry and 20 concurrent callbacks. These are synthetic consumer tests, not proof of host authorization or live entitlement.

Host inspection: installed Hermes `2bd378ed1b8d6bf2192cb26e0a55ff3091e6bd19` provider-request helper checks plugin declaration/origin but has no selected-attempt binding; account-usage helper accepts a raw API key and cache identity label. Neither is an authorized scoped producer for this plugin. Private attribution hooks do not close this gap.

Change: precise extension requirements and adversarial host acceptance added to `docs/provider-intelligence/quotas.md` in the ledger PR. No runtime defect reproduced, host modified, provider contacted or credential accessed. Unknown remains unknown; strict no-charge remains denied.

Disposition: keep #41 open. GitHub currently reports #13 closed for its bounded delivery; that does not establish host authority. Next authority: sanctioned host-owned, consented selected-credential quota producer; principal accepts plugin-side evidence separately. Continue independent #42.

### #42 — milestone-05 [P0] Canonical free-only, task and reliability policy semantics

Created: 2026-11-07T16:16:28Z

Status: **PLUGIN CONTRACT VERIFIED — external website parity not verified**.

Requirements: versioned execution-independent hard gates/preferences/task/connection restrictions; identical canonical tool/preview/dashboard/manual evidence; deterministic invalid/no-match handling; four quota modes; no paid fallback or fabricated authority.

Existing merged implementation: PR #53 with final adversarial exhaustion repair, integrated through #69. `selection_policy.py` validates versioned requirements; `router.evaluate_snapshot` supplies the canonical decision; tool and dashboard preview consume that contract. Website parity fixtures are repository-local, not proof of deployed website behavior.

Executed: the #41 invocation's 301 passing cases includes `tests/test_selection_policy_v1.py`, covering version errors, hard-gate composition, contradictory evaluator evidence, account/model/shared-window isolation and all four policies; not counted again. Additional guarded `run.py tests/test_preview.py tests/test_dashboard_api.py tests/test_router.py`: **49 passed, 0 failed/skipped** (1.91s). Actual isolated Hermes registered-tool gate `tests/integration/test_acceptance_gates.py::test_real_hermes_registered_tools_share_policy_contract_and_deny_missing_authority`: **1 passed, 0 failed/skipped** (1.75s); schema parity and missing-authority denial verified with synthetic callbacks and zero network attempts.

Related #41 scope/health invocation: `run.py tests/test_structured_credential_scope.py tests/test_scoped_health.py`: **52 passed, 0 failed/skipped** (1.30s), including immutable retry attribution, redacted attempt API, migration rollback and unknown/mismatched scope. These are consumer tests, not an authorized live credential producer.

No reproducible repository-local parity defect found; no speculative runtime change or feature PR created. The guarded first-use/browser and claims checks above remain separate evidence. Actual website parity is outside authorized repository scope and remains unverified; host-owned identity/Apply authority remains unavailable. Principal acceptance and any website coordination are still required; keep issue open.

### #43 — milestone-06 [P0] Explicit task-aware model suitability profiles

Created: 2026-11-07T16:17:11Z

Status: **PLUGIN PROFILE CONTRACT VERIFIED — principal acceptance pending**.

Requirements: explicit General/Coding/Fast response v1, verified capability requirements, deterministic ranking/no-match, provenance, unknown semantic quality and no classifier.

Merged implementation: #60, canonical #53 and integrated #69. Read `task_profiles.py` and its complete contract: Coding does not invent competence or require tools unless explicitly requested; Fast response uses fresh confidence-aware observations; user hard gates are never relaxed.

Executed guarded `run.py tests/test_task_profiles_v1.py tests/test_decision_report_v1.py`: **107 passed, 0 failed/skipped** (1.26s), including profile-policy composition, missing capability rejection, measured ranking differences, original latency age and tool/API/SQLite preview parity. This combined run is shared with #44, not counted twice. Six focused browser cases passed (3.23s): explicit-profile disclosure, read-only preview controls, report disclosure and parametrized three-profile handoff request preservation. Browser transport is a synthetic harness, not live-provider evidence. The preceding actual isolated Hermes policy gate exercises all three profiles and exact tool/preview report equality with unchanged database bytes.

Change: corrected stale unmerged #53/#57 dependency claims in `docs/product/task-profiles-v1.md`; both are integrated into accepted main. No runtime defect reproduced. Semantic quality and live entitlement remain unknown; host Apply authority is external. Principal accepts this bounded implementation; no issue closure implied.

### #44 — milestone-07 [P0] Versioned complete explainable recommendation evidence report

Created: 2026-11-07T16:17:12Z

Status: **CANONICAL REPORT VERIFIED — principal acceptance pending**.

Requirements: one bounded versioned report across selection/tool/preview/UI; chosen/rejected evidence, source/freshness, hard gates, measured uncertainty, unknown account, no-match and safe next steps; read-only preview.

Merged implementation: #61 with #60/#53 and integration #69. Report projects the canonical result instead of re-evaluating it, sanitizes identifiers/source labels, preserves unknown metrics, bounds candidate/window output and retains winner evidence under truncation.

Executed: shared 107-case profile/report run and six-case focused browser run recorded under #43; no duplicate count. Tests include corrupt/missing SQLite without repair, unavailable evidence, expired/revoked price, tool/context denial, circuit/cooldown, four quota modes, account privacy, unsupported schema, deterministic bounded serialization and truncation. Actual isolated Hermes gate recorded under #42 compares registered tool and preview evidence reports, including measured callbacks and unknown execution/account authority; synthetic callbacks are explicitly labeled.

Change: corrected obsolete dependency paragraphs in `docs/product/decision-report-v1.md`. No runtime contradiction reproduced. Unavailable authority remains disclosed, not fabricated. Principal acceptance remains separate from source/test evidence.

### #47 — milestone-10 [P1] Actionable observed provider health and failure recovery guidance

Created: 2026-11-07T16:17:19Z

Status: **OBSERVED HEALTH GUIDANCE VERIFIED — active-account authority externally gated**.

Requirements: separate authentication/rate-limit/quota/service/transport/model categories, provenance and original times, scoped recovery/half-open, account isolation, no invented retry-after or execution retry.

Merged implementation: #64 and integration #69; read `health_guidance.py` and its contract. Typed original circuit event time is separate from maintenance time; matching quota evidence alone can establish exhaustion. HTTP 429 is rate limiting, not allowance proof. Provider retry-after remains null without trusted provenance.

Executed guarded `run.py tests/test_health_guidance_v1.py`: **34 passed, 0 failed/skipped** (0.57s), covering scoped category distinctions, A/B isolation, invalid/stale provenance, unknown v3 events, atomic migrations, recovered versus unrecovered precedence and exact denying quota timestamps. Prior #41 scoped-health run is reused without recounting. Two focused browser cases passed (1.05s): cached reconsideration is read-only/no retry and verified allowance denial overrides half-open display. Actual isolated Hermes policy gate also checks synthetic 401 guidance with unknown account and no automatic retry.

Change: corrected stale wording that conflated merged #36 plugin work with absent standard-host authority. No host patch or runtime defect identified. Host-selected account binding remains `BLOCKED_EXTERNAL_HOST_CONTRACT`; principal acceptance of completed observed-health behavior is separate.

### #49 — milestone-12 [P1] Complete five-tab native Hermes dashboard workflows

Created: 2026-11-07T16:17:58Z

Status: **BOUNDED REPAIR SUBMITTED — full host acceptance remains partial**.

Requirements: five-tab onboarding/provider/task/evidence/manual-action/Analytics/Settings flow, state recovery, stale asynchronous protection, accessibility, responsive layouts and native themes. Native Apply/Restore is unavailable without sanctioned host support.

Merged implementation: #66/#69 workflow state, scoped native CSS and manual handoff. Current-main browser harness: **71 passed, 0 failed/skipped** (19.93s). Reused exact-tree authenticated artifact receipt covers eight themes, 120 tab/viewport checks and explicit synthetic manual handoff; this is not real provider execution or OS-system mode.

Concrete defect: native Hermes `ApiError.body` contains JSON text, but dashboard error normalization returned it unchanged, preventing structured partial-save rendering/cache invalidation. A focused regression reproduced it: **1 failed, 1 passed** before repair. An isolated branch from main decodes that body, retains legacy/object handling and adds the adversarial case. No host changes.

Submitted [PR #72](https://github.com/diegorhoger/autorouter/pull/72), exact HEAD `5a7bcdc8ecd7d31c8075aed26580693bc33a1e81`, tree `2b6accf7045ad91115a3b0a3c1e9fa5a89edfb02`, base `918207b7b7e42aec32ab417e6cb14d4894e56579`, two files, mergeable. Focused browser **72 passed** (26.93s). Full guarded repair suite **1320 passed plus 5 subtests, 0 failed/errors/skipped** (80.74s), including 72 browser cases, 23 isolated Hermes tests and package lifecycle; these subsets are not extra totals. Five Ruff findings match unchanged main; no new lint findings. ADR/JS syntax/diff checks pass.

Two exact-commit package builds match SHA256 `5c8c16b3d291689c4c09aa6a31bac555a89ad6588bfe21ea98bbedb409281ccd`, 91 payload files. Actual pinned Hermes authenticated browser verified this package: Settings draft survives Analytics navigation, one explicitly simulated partial failure genuinely persists policy only, failed cooldown draft remains, retry succeeds, original settings restored, zero JS errors and owned server/port stopped. Probe locator/routing/wait issues were corrected before final PASS; those failed probes are not acceptance passes. This fresh receipt covers empty Analytics, not a live provider request. No claim of standard-host credential authority or real screen-reader testing.

Remaining: principal exact-HEAD review/merge; supported native context-bound Apply/Restore; actual assistive-technology acceptance and any live provider acceptance require their own safe authorized evidence. Keep issue open. OS-system theme remains #26's specific host gap.

### #50 — milestone-13 [P1] Trustworthy usage/analytics and decision-to-request traceability

Created: 2026-11-07T16:18:00Z

Status: **LOCAL REQUEST TRACE VERIFIED — BLOCKED_EXTERNAL_HOST_CONTRACT for decision-to-request linkage**.

Requirements: sanitized session/task/turn request lifecycle, immutable attempts/scope, callback/terminal idempotency, cancellation, partial retry coverage, missing versus zero metrics, bounded read-only Analytics and legitimate decision/apply correlation only.

Merged implementation: #67/#69 request trace and cancellation repair. Read `docs/product/request-trace-v1.md` and regression cases. Guarded current-main `run.py tests/test_request_trace_v1.py`: **23 passed, 0 failed/skipped** (0.37s). Covers cross-session/context contradictions, immutable attempts, changed account, out-of-order callbacks, terminal idempotency, cancellation without health/quota accounting, unavailable metrics, bounded reads and redaction. Browser trace disclosure passed in the 71-case main harness and 72-case repair harness; reused, not counted again.

Actual isolated Hermes registered callbacks demonstrate synthetic success/error requests with unknown decision/apply receipts; the #42 gate asserts unavailable end-to-end correlation and missing usage, rather than guessing from timestamps or model names. This does not satisfy the issue's real decision-to-execution linkage acceptance.

No local trace defect reproduced; no new runtime implementation. Required host contract: sanctioned context-bound decision/apply receipt carried unchanged into the actual request/attempt hooks, scoped to profile/session/task/turn, with stale/mismatched/replayed receipt denial. Acceptance must prove one authorized success and failure with genuine linkage, account changes/cancellation and redaction. Until available, `END_TO_END_CORRELATION: UNAVAILABLE`; no plugin-side fabricated authority or live execution. Principal acceptance remains separate; keep issue open and continue #51.

### #51 — milestone-14 [P0 RELEASE] Reproducible installable Hermes plugin and release acceptance

Created: 2026-11-07T16:18:03Z

Status: **PRIVATE PACKAGE PREPARED — independent artifact/release acceptance pending**.

Requirements: exact latest-main package, deterministic source/tree/member identity, secret/license disclosure, adversarial archive rejection, disabled-by-default clean host install/enable/discovery/free selection/dashboard, upgrade, compatible-snapshot rollback, removal/restoration and accurate release restrictions.

Existing merged implementation: #68/#69 builder and lifecycle. Built accepted main `918207b7b7e42aec32ab417e6cb14d4894e56579` twice from an isolated detached checkout. Both `autorouter-0.2.0-918207b7b7e4.zip` archives match SHA256 `5687794d20f8a41cccbaf3659ecc87cdf1267d28e458f140f21e6d5425d207f0`, tree `ca51fc67c989d126bfd5fa1f6f73b967119d7ce2`, 91 payload files plus manifest. Verified every member against committed Git bytes, hashes/sizes, ZIP integrity and builder forbidden-path/secret checks. LICENSE/NOTICE present; no third-party runtime vendored. Pinned environment direct dependencies FastAPI 0.162.0, Pydantic 2.14.3 and PyYAML 6.0.3 disclose MIT; not an audit of all host transitive dependencies.

Executed exact-main `run_main_package.py tests/test_package_v1.py tests/integration/test_package_lifecycle.py tests/integration/test_acceptance_gates.py`: **48 passed, 0 failed/errors/skipped**, retained receipt invocation 19.44s. Earlier identical 48-case invocation was not added to totals. The isolated lifecycle actually loads package paths and tests explicit opt-in, upgrade v4→v5, matching v4 snapshot before rollback, removal preserving data and restoration. Five-provider transport is synthetic; native Apply remains unavailable. Reused identical-tree named-theme/manual-handoff GUI evidence is labeled separately from this new main-manifest identity. No full suite rerun for a manifest-only identity change.

Owner-approved private handoff: `~/Downloads/AutoRouter-main-918207b-handoff`, ZIP, manifest/inventory, checksum/source/blob receipt, retained JUnit/log and acceptance limitations. Exact repair #72 package is separate at `~/Downloads/AutoRouter-PR72-5a7bcdc-handoff`; source `5a7bcdc8ecd7d31c8075aed26580693bc33a1e81`, SHA256 `5c8c16b3d291689c4c09aa6a31bac555a89ad6588bfe21ea98bbedb409281ccd`. Its full 1320-test guarded run and authenticated SDK recovery do not approve main's distinct artifact automatically.

Recomputed historical `7122f8e` SHA256 `0642be5637e1e48a68bc62bb46157b672b60966d844b10e018c2edec0ffb57a3` and `ce9c600` SHA256 `0cf66351ab1882eff88844392c43b04dcab1a53deb389964d23cf01b5ef9f8c7`; both unchanged. No release/tag/upload/public visibility or production install. Required next authority: independent exact-artifact acceptance, principal candidate merges, then integration rebuild/reacceptance as source changes; host/website/product release gates remain blocked. Keep #51 open.

### #54 — [FUTURE / DESIGN-ONLY] Optional gateway and credential-authority acceptance gates

Created: 2026-11-07T16:41:25Z

Status: **DESIGN-ONLY CANDIDATE SUBMITTED — runtime remains DEFERRED outside V1**.

Requirements: document future reuse/credential/execution/reservation/stream/replay/authentication/SSRF/resource/operations/rollback gates without implementing a gateway, vault, OAuth, classifier or spending controller.

Work: one acceptance matrix in `docs/architecture/future-gateway-acceptance-gates.md`, with accountable decision owners, adversarial evidence and explicit stop/authorization conditions. Existing ADR boundaries retained. No runtime or new V1 dependency.

Submitted [PR #73](https://github.com/diegorhoger/autorouter/pull/73), exact HEAD `0214b59d5ca8ef77dabd02f31f8f1ac18c4e89ad`, base `918207b7b7e42aec32ab417e6cb14d4894e56579`, one file, mergeable. ADR checker and diff whitespace checks pass; runtime tests not rerun for prose-only changes. Principal documentation acceptance pending. Any future runtime dispatch requires separate owner/security/operational authority; this issue does not block V1.

### #55 — [DOCS] Architectural decision register and approved decision backlog

Created: 2026-11-07T16:41:40Z

Status: **ADR RECONCILIATION CANDIDATE SUBMITTED — principal acceptance pending**.

Requirements: stable 13-decision index, accepted-direction versus implementation/review/merge distinctions, backlog/glossary, truthful delivery history, links, retrospective provenance, actual merged state and explicit unknown/deferred host work.

Existing implementation: merged #56 register and checker. Updated only implementation/status metadata, corresponding index/table/backlog and current delivery receipt; approved decisions and dates unchanged. All 17 merge SHAs (#36/#52/#53/#56–#69) were fetched from GitHub and verified as ancestors of current main. Original 7 November candidate/baseline reports remain clearly dated historical records. Current bounded closure of #13/#45/#46/#48 is distinguished from unfulfilled host acceptance. Glossary definitions remain accurate and unchanged.

Submitted [PR #74](https://github.com/diegorhoger/autorouter/pull/74), exact HEAD `55b7ce04033a5f6a44568154a3683af48d058142`, base `918207b7b7e42aec32ab417e6cb14d4894e56579`, 17 documentation files. `tools/check_adrs.py` PASS; guarded `run_adrs.py tests/test_adr_links.py`: **5 passed plus 5 subtests, 0 failed/skipped** (0.14s); whitespace checks pass. A subsequent status-only historical-closure clarification also passed ADR/diff checks. No new architecture decision or runtime behavior.

Related ledger PR corrects stale product-document dependency descriptions; it does not promote host support. Principal exact-HEAD review/merge required; no automatic closure or release.

## Execution receipt — 9 November 2026

- All 16 original open issues have been processed oldest-first. No original issue was closed by this execution. Source-ready or locally verified is not issue acceptance.
- Initial open PRs: 0. New independent candidates: #70 ledger/documentation, #71 provisional interop, #72 native SDK recovery, #73 deferred gateway gates, #74 ADR reconciliation. All target accepted main directly; no hidden dependency on another candidate. Principal may land accepted docs independently; #72 requires its exact-HEAD review. Rebuild/reaccept integrated package after accepted source changes; no source approval transfers automatically.
- Main remains `918207b7b7e42aec32ab417e6cb14d4894e56579`; no self-merges, issue closures, host/production changes, public release, tags or visibility changes. Original artifacts remain immutable.
- Repair-HEAD claims checker executed: **24 claims, 35 proof functions, 110 cases passed, 0 failed/errors/skipped/missing** (8.76s). Website source NOT_VERIFIED, independent release acceptance false, release BLOCKED. No claim states promoted.
- Full guarded checkpoint for #72: **1320 passed plus 5 subtests, 0 failed/errors/skipped**, 80.74s. Browser 72 and isolated Hermes 23 are included subsets, not additional totals. Independent focused runs elsewhere are not summed into this suite.
- Lint: same five existing main browser-file findings (F401, four E701); no new findings. JS syntax via pinned Playwright Node PASS; ADR/diff checks PASS. No broad automatic formatter changes; formatting limited to the bounded edits.
- Host gates: standard-host selected-account authority/consent, authorized scoped quota producer, context-bound Apply/Restore and decision→actual-request linkage. OS-system theme is separately unavailable. NVIDIA quota unknown; live entitlement unverified. No plugin-side fabricated authority.
- Owner gates: exact-HEAD candidate acceptance/merges, independent new-artifact acceptance, authorized assistive-technology/live-provider evidence where required, website/source verification and separate release/production authorization. #35/#54 runtime remains deferred. Remaining original issues require principal acceptance or these specific external gates, not another speculative implementation campaign.

Final disposition: **REPOSITORY-LOCAL EXECUTION CANDIDATES SUBMITTED; PRINCIPAL AND EXTERNAL ACCEPTANCE OUTSTANDING**. Full V1 is not complete or release-ready.
