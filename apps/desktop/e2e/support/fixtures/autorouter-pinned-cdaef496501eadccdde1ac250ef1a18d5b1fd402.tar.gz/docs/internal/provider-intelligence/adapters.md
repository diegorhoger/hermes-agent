# Read-only discovery adapters (PIR-3)

Three additional adapters run only when their canonical provider ID is explicitly
included in the plugin's authorized `providers` list. Defaults remain NVIDIA and
OpenRouter. Catalog presence does not activate providers, verify credentials for
inference, establish account allowance, or prove free execution.

| ID | Official read-only catalog | Credential header | Normalized evidence |
| --- | --- | --- | --- |
| `groq` | `https://api.groq.com/openai/v1/models` | Bearer | Model identifiers; tool/context/price remain unknown |
| `gemini` | `https://generativelanguage.googleapis.com/v1beta/models` | `x-goog-api-key` | Native `models/` identifiers, `inputTokenLimit`; generation methods do not establish tools |
| `mistral` | `https://api.mistral.ai/v1/models` | Bearer | Identifiers, `max_context_length`, explicit `capabilities.function_calling`, archived status |

Sources inspected on 2026-11-05:

- [Groq API reference, Models](https://console.groq.com/docs/api-reference).
- [Gemini models API and pagination](https://ai.google.dev/api/models).
- [Gemini authentication](https://ai.google.dev/api).
- [Mistral models API](https://docs.mistral.ai/api/endpoint/models).

The adapter contract is `adapters.fetch_catalog(provider, api_key, now=None)`,
returning model-ID keyed capability metadata. `normalize(provider, payload, now)`
is pure. Model-specific evidence uses the existing metadata merge and capability
JSON persistence. Price is omitted from supplied fields: independent original
price proof can survive only until its original expiry; a catalog never renews it.
No new adapter currently supplies zero-price proof. Missing model pricing stays
unknown unless separately established by existing fresh model-specific evidence.

Credentials use existing Hermes profile environment declarations and dotenv
reader; when no profile exists, fixed declared environment names are used:
`GROQ_API_KEY`, `GEMINI_API_KEY`/`GOOGLE_API_KEY`, and `MISTRAL_API_KEY`.
Only credential values needed for the catalog GET are held in memory. They are
never put into a URL, capability row, response, error classification, or log.
These adapters add metadata discovery, not a new host inference integration.

Network destinations are fixed official endpoints. Custom profile URLs and
candidate registry URLs cannot redirect catalog requests. Redirects are rejected
so authorization headers never follow another origin. Requests have a ten-second
timeout, two-MiB response limit, 1000-model limit and ten-page Gemini limit; repeated
pagination tokens, duplicate/malformed identifiers and credential-like IDs fail
closed. Provider errors are fixed classifications (`authentication`,
`rate_limited`, `provider_unavailable`, `http_error`, `transport_error`), without
provider error bodies. No inference requests, active validation or account polling
are performed.

A complete successful catalog revokes absent models by persisting unknown cost
and unsupported tools. Failed or malformed refreshes preserve last-known-good
rows and their original verification ages. Native Gemini and OpenAI-shaped
Groq/Mistral response formats are normalized separately. Existing NVIDIA and
OpenRouter behavior is retained.

Run the offline adapter fixtures with:

```sh
python -m pytest -q tests/test_provider_adapters.py
```

The fixtures cover successful native/compatible catalogs, credentials absent,
401/403/429/5xx, timeout, redirect denial, malformed/oversized responses, removed
models, missing pricing, sanitized logs/storage, and bounded pagination. No actual
credentials or external inference are needed.
