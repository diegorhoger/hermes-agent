# PR #5 repair verification

The Analytics reader now counts and sums the complete selected range in SQL. Provider/status filters apply consistently to summary, breakdowns, errors, timeline and requests. Request sorting uses an allowlist, and LIMIT/OFFSET execute in SQLite. Latency statistics use all valid observations with nearest-rank `ceil(n*p)-1`; no sample cap or approximation is used. Exact percentile computation retains valid latency values in memory.

Request finalization takes a SQLite write lock and guards the pending-to-terminal update. The row, hourly counters and lifetime counters commit together exactly once. First terminal status and tokens are immutable, including under concurrent calls.

Hook correlation uses the host's `api_request_id` stored in SQLite, without a process-global map. Confirmed host fields were read from `agent/turn_api_request.py`, `agent/turn_response_intake.py`, `agent/api_request_hooks.py`, and `agent/conversation_loop.py` in the installed Hermes source; no host files were changed. Distinct host IDs are distinct request observations; no task/turn-based guessing combines concurrent calls. Same-ID retryable failures stay pending until a post callback, explicit exhaustion (`retry_count >= max_retries`), or cleanup. Unobserved completions older than one hour are canceled in bounded batches of 1,000 on pre callbacks. Without an ID, pre callbacks create no orphan; terminal callbacks are independent observations and cannot be deduplicated across unknown identities. Telemetry does not require a Router instance. Attempt history is recorded per ordinal and remains available in request detail.

Analytics exposes range, provider/status filters, SQL-backed request sorting/pagination, request-detail navigation, complete recorded attempt history and a graphical hourly success/error timeline with a table for exact values. Existing plugin registration, disabled-by-default behavior, free-only routing and schema version remain unchanged.

Regression tests cover 5,105 requests for each supported range, offsets beyond the former cap, filtered totals/timeline, nearest-rank small samples, terminal duplicates and reversed statuses, concurrent finalization, missing/interleaved IDs, retries/exhaustion/cleanup, Router absence, full attempt detail, and browser controls/navigation/chart rendering.

Reproduce using Python with pytest, FastAPI, httpx, PyYAML and Playwright installed, plus Chrome:

```sh
python -m pytest -q -rs
python -m pytest -q -rs tests/browser
```

Nine optional Hermes integration tests require runtime imports unavailable in the test environment: acceptance gates at lines 127/139/163/173; constructor matrix at 64/73/82/91; probe agent at 26. These skips are not passing integration results. No merge, release, production installation or Hermes source modification was performed.

Actual repair run (isolated `/tmp/autorouter-metadata-venv/bin/python`): full `-m pytest -q -rs` → **214 passed, 0 failed, 9 skipped**, one third-party Starlette/httpx deprecation warning; separate `-m pytest -q -rs tests/browser` → **10 passed, 0 failed, 0 skipped**. Post-hook regression also verifies success without retry_count retains all earlier retry attempts.

## Current-main integration verification

Reconciled against registry main `fa10c96b407cd2f4bf9ee2bd89bd48ce9797a3c3` without dropping metadata provenance/expiry gates or registry entries. The metadata reopen regression now checks the current schema version. Schema creation and the v1-to-v2 upgrade run in one explicit SQLite transaction; individual complete DDL statements avoid `executescript`'s implicit commit. An injected failure after creating all telemetry tables verifies rollback leaves version 1, original catalog timestamps/data, and no partial telemetry tables; the retry then upgrades successfully.

Executed in the isolated dependency-equipped test environment:

- `/tmp/autorouter-metadata-venv/bin/python -m pytest -q -rs`: 279 passed, 9 skipped, one third-party Starlette/httpx deprecation warning.
- `/tmp/autorouter-metadata-venv/bin/python -m pytest -q -rs tests/browser`: 10 passed using installed Chrome against the mocked dashboard API harness.

The nine skips still require the supported Hermes runtime; browser harness results do not establish live-host acceptance. No production deployment or host modification was performed.

After credential contract PR #20 merged, reconciled against `main@9a78a6c08d9d237a473da2fc8ea6a25203981de5`; the same complete suite reports **310 passed, 9 skipped**, one unchanged third-party warning. Credential API changes merged without conflicts. These supersede the intermediate counts above.

Independent review found provider error text could reach SQLite and grouping labels bypassed output scrubbing. Persistence now drops arbitrary error bodies/reasons in favor of allowlisted categories, hashes opaque request/task/turn/session correlation identifiers, constrains telemetry labels, and preserves lookup by the host request ID without storing it. Every SQL grouping label is scrubbed on read. Lifetime usage nulls remain unavailable in the browser; observed zeros remain zero. Unknown-prefix credential sentinel tests cover SQLite dumps and summary/detail API payloads; another test seeds untrusted grouping labels directly; a real Chrome test covers unknown-vs-zero lifetime display.

After integrating evidence PR #21 (`main@9e85f4c11efb9ab9dc080be6d9c15ffb389bebd4`), the complete suite reports **338 passed, 9 skipped**, one unchanged third-party warning. The suite includes 11 browser interaction tests.

A further independent review caught duplicate terminal callbacks incrementing Router health despite request finalization being idempotent. SQLite attempt insertion now returns whether a new ordinal was accepted, and runtime health only consumes those accepted observations. Concurrent repeated callbacks after terminal success leave one health success and no failure/auth poisoning; repeated pending retry ordinal is counted once while the next genuine retry ordinal is retained. Full suite after this fix: **340 passed, 9 skipped**, unchanged third-party warning.
