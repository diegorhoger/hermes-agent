# Issue #104 — host extension: sanctioned pre-inference routing seam

Status: **host patch ready for upstream review; NOT applied to the installed Hermes.**
Hermes v0.23.1 (`3b421578588243f920886e6fe79a6faa87ea026e`) has no pre-inference
selection seam, so ordinary sessions are **not** auto-routed on the stock host.
This directory is the exact, minimal, backward-compatible extension that adds one.

- Contract the patch implements: `docs/internal/hermes-native-routing-contract.md`
- Consumer half (already implemented, issue #104): `autorouter_core/integration/native_routing.py`
- Host-side test (ships inside the patch): `tests/hermes_cli/test_pre_inference_route_host.py`

## Contents

`patches/hermes-agent-3b421578-pre-inference-route.patch` — applies cleanly to a
Hermes checkout at `3b421578588243f920886e6fe79a6faa87ea026e`. Three files:

1. `hermes_cli/middleware.py`
   - New `PRE_INFERENCE_ROUTE_MIDDLEWARE = "pre_inference_route"` in `VALID_MIDDLEWARE`.
   - New `PreInferenceRouteResult` dataclass and
     `apply_pre_inference_route_middleware(metadata, **context)`:
     - Invokes registered `pre_inference_route` middleware consumers with **non-secret**
       metadata only; key-like fragments in any string value are replaced with
       `"[redacted]"` before delivery (second line of defense — the consumer is a
       contract violation if it emits credentials in the first place).
     - `route` results are validated: provider must match `^[a-z0-9][a-z0-9-]{0,63}$`,
       model ≤ 199 chars and must not contain key-like material. Malformed results are
       dropped; if consumers ran but none produced a valid result, the outcome is a
       fail-closed `refuse` (no provider request is issued).
     - `passthrough` tells the caller to proceed exactly as if no consumer existed.
     - Returns `None` when no `pre_inference_route` consumer is registered — stock
       behavior, byte-identical to pre-extension Hermes.
     - Consumers that raise, or produce no usable result at all, yield a fail-closed
       `refuse` — never `None`, never a stock route. The only provable opt-out is an
       explicit `passthrough`. Callback exceptions are isolated by the delivery layer
       and surface here as empty results, which is exactly why empty results refuse.
     - Route results are validated defensively: provider `^[a-z0-9][a-z0-9-]{0,63}$`,
       model ≤ 199 chars, no control characters, no key-like material; `reason` capped
       at 500 chars and redacted; `receipt` bounded to 32 items with strings ≤ 500
       chars and key-like fragments redacted. Metadata delivered to consumers is
       bounded and sanitized the same way.
2. `tui_gateway/agent_factory.py`
   - `_make_agent` runs one `has_middleware("pre_inference_route")` probe before the
     provider client is built.
     - Explicit per-session model/provider picks are **never** rewritten — they return
       before any consumer interaction.
     - Otherwise the consumer is invoked with non-secret, bounded metadata
       `{session_id, platform, hermes_profile, requested_model, requested_provider, explicit_model: false}`
       (control characters stripped; lengths clamped: 256/64/128/199/64).
     - `route` → the session pins `{"model": …, "provider": …}` through the normal
       `resolve_runtime_provider` path (the host alone resolves credentials; the consumer
       never sees them).
     - `refuse` → `RuntimeError` before `AIAgent` is constructed; zero provider requests.
     - `passthrough` → stock path unchanged.
     - Registered consumer raises, returns nothing usable, or the capability probe
       itself fails → `RuntimeError` before provider construction. An AutoRouter failure
       is **never** widened into a stock (potentially paid or unknown-cost) request.
     - No registered consumer → stock behavior, byte-identical.
3. `tests/hermes_cli/test_pre_inference_route_host.py`
   - Ready-to-run against this patch (28 hermetic tests + 1 optional end-to-end test
     gated on `AUTOROUTER_SOURCE=/path/to/autorouter` checkout).

## Verification performed (2026-11-15, scratch clone of the exact installed revision)

Environment: `uv sync --all-groups` of a pristine copy of the installed host source;
no changes to `/Users/prometheos/.hermes/hermes-agent` or the live install.

- `tests/hermes_cli/test_pre_inference_route_host.py` — **28 passed, 1 skipped**
  (the `AUTOROUTER_SOURCE` end-to-end case was then run with
  `AUTOROUTER_SOURCE=<this repo with the dispatch-108 consumer repairs>` — **1 passed**).
- `tests/hermes_cli/test_plugins_middleware_chain.py` + `tests/hermes_cli/test_plugins.py` +
  `tests/hermes_cli/test_dashboard_auth_middleware.py` — **120 passed** with the patch applied
  (host regressions clean).
- Static check: the live processes running `3b421578588243f920886e6fe79a6faa87ea026e` do
  **not** contain this extension; the live host reports
  `detect_host_native_routing() == {supported: false, …}` and registers nothing.

## What this does NOT do

- Does **not** patch the installed Hermes host or the released Desktop app.
- Does **not** make ordinary sessions auto-routed on the live system. Acceptance
  (issue #104, items 1–6) requires this patch (or an equivalent upstream merge) plus
  the operator's `enable_native_routing: true`, and a fresh Desktop/gateway process.
- Does **not** persist its own receipt store — the AutoRouter consumer writes its
  decision ledger exactly as for the virtual-model path.

## Applying and reviewing upstream

```bash
# against NousResearch/hermes-agent @ 3b421578588243f920886e6fe79a6faa87ea026e
git apply patches/hermes-agent-3b421578-pre-inference-route.patch
python -m pytest tests/hermes_cli/test_pre_inference_route_host.py -q
# optional cross-repository proof:
AUTOROUTER_SOURCE=/path/to/autorouter python -m pytest \
    tests/hermes_cli/test_pre_inference_route_host.py::test_real_autorouter_consumer_end_to_end -q
```

Two review notes for upstream authors:

- The single TUI/Desktop call site covers ordinary Desktop/TUI sessions. The messaging
  gateway (`gateway/run.py` → agent construction) and the CLI (`hermes_cli/cli_init_mixin.py`)
  deliberately reuse the same helper shape before their own client construction; landing
  only this patch routes ordinary Desktop/TUI sessions. Follow-up patches can replicate the
  `_pre_inference_route_override` call in those two sites unchanged.
- Refusal aborts agent construction. Callers surface `RuntimeError` as a session-start
  failure with the consumer's reason; no provider request, no fallback model, no telemetry.
