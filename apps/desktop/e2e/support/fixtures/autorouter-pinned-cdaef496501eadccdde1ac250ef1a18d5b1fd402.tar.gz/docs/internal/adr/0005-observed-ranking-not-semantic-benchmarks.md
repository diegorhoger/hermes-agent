---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Observed ranking and explicit task profiles merged; semantic competence remains unknown."
---

# ADR-0005: Observed operational ranking without invented competence

AutoRouter ranks eligible models using observed, bounded, source-aware reliability/latency evidence with conservative priors, sample coverage, decay and uncertainty. Operational observations are not independent semantic task-quality evaluations. Explicit General, Coding and Fast response profiles declare verified requirements and limitations; a Coding label or keyword match cannot establish model competence.

## Consequences and limits

Automatic task classification is optional future work, not V1 authority. External evaluation-evidence interoperability remains deferred in [#35](https://github.com/diegorhoger/autorouter/issues/35); no evaluator, benchmark engine or self-confirming learning is added to AutoRouter.

## Evidence and ownership

[#14](https://github.com/diegorhoger/autorouter/issues/14); [#16](https://github.com/diegorhoger/autorouter/issues/16); [#35](https://github.com/diegorhoger/autorouter/issues/35); [#43](https://github.com/diegorhoger/autorouter/issues/43); [#44](https://github.com/diegorhoger/autorouter/issues/44); [#48](https://github.com/diegorhoger/autorouter/issues/48); [#54](https://github.com/diegorhoger/autorouter/issues/54). Code anchors: `scoring.py`, `telemetry.py`, `router.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
