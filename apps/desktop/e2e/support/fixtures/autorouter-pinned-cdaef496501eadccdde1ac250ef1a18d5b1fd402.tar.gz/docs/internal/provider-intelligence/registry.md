# the registry candidate registry

This offline registry preserves the 249 source rows from [the approved source commit](https://github.com/diegorhoger/autorouter/blob/e683ebd293e4eed1c95c52036aaefd9281488054/docs/provider-intelligence/source-provider-catalog-2026-11.csv). It is a candidate inventory, not 249 operational integrations. It does not import or execute provider code, fetch URLs, inspect environment variables, create models, touch SQLite, register hooks, or alter selection. NVIDIA/OpenRouter discovery and verified free-only eligibility remain authoritative and unchanged.

## Shipped artifacts and regeneration

- `data/provider_registry/source-2026-11.csv`: exact original data, SHA-256 `15f4b936e6a3368273451855ef8ff90c83d6f99c00bf1ada9ee4ca5408a160c2`.
- `data/provider_registry/registry-v1.json`: deterministic version 1 normalized snapshot.
- `provider_registry.py`: standard-library importer, validator, loader and exact-match lookup.

From the plugin directory:

```sh
python provider_registry.py          # regenerate the JSON snapshot
python provider_registry.py --check  # byte-for-byte validation; does not write
python -m pytest -q -rs tests/test_provider_registry.py
```

No source branch merge is required. The importer reads the shipped pinned CSV and writes only its versioned JSON snapshot. Updating the inventory requires an explicit source checksum/version change and review. Regeneration has no wall-clock timestamps, network dependency or locale dependence. The source capture date has month precision (`2026-11`); verification and expiration remain null.

## Identity and lookup

Each source row is one candidate entity. No display entities are deduplicated in the registry. Canonical IDs have the form `pir-<original numeric index, minimum 3 digits>-<original provider ID>`. These are registry identities, not runtime provider IDs. The original index, original provider ID and every original CSV field are retained under `source_claim`.

Source row 141 has an empty original provider ID. It remains empty in `source_claim`, null in `source_provider_id`, and has the explicit registry identity `pir-141-unidentified`; its name `NaN.Builders` remains searchable. An existing source index must never be reassigned. Reordering CSV rows does not change normalized ordering or IDs. Duplicate indexes are rejected rather than dropped. Distinct rows with the same provider ID or name remain distinct canonical entities, and alias lookup returns **all** matches rather than choosing an arbitrary winner.

`find_candidates(query)` matches a canonical ID, original provider ID, name, or alias case-insensitively and returns a list. Plans and regions keep their own identities. Optional `related_source_provider_id` associates source variants without merging them or asserting interchangeable credentials. It is an association, not a provider hierarchy. g4f gateways remain separate from native NVIDIA/Gemini. No native `ollama` source ID exists in this inventory, so g4f-Ollama is not silently aliased to Ollama Cloud. Naga AI and Naga.ac remain separate even where source notes mention the same domain.

## Claims, structure and unknowns

`variant_kind` distinguishes provider, plan, region, gateway, specialized and deprecated source entries. Structural annotations use explicit source IDs/descriptions and never assert working compatibility. Regional endpoints and plan requirements remain in the original notes; the importer does not construct endpoints or infer account entitlements.

`protocol_hint`, `auth_hint` and `modalities` are unverified source-description hints, not capability evidence. Unstated fields remain null/empty. In particular, 1min.AI is proprietary chat, Runway is async video, and Jina/Mixedbread/Voyage specialized products are not promoted to chat models. Unknown products are never assumed to be OpenAI chat. No source-reported context, model list, tool support, price, token estimate or quota becomes operational metadata: the normalized fields remain null. Advertised credits, RPM, trials and free-model names stay raw claims only. Security/privacy/account/region caveats remain intact in `source_claim.notes`.

Every entry has `verification_state=unverified_source_claim`, `trust_state=unverified`, `active=false`, `operationally_integrated=false`, and `autorouter_default_eligible=false`. These flags describe the imported registry records; existing configured adapters are unaffected. g4f and explicitly experimental claims are flagged experimental. All five rows marked deprecated in the source remain deprecated and inactive. This includes CLOVA Studio because the source marks it deprecated when describing its legacy endpoint; the registry preserves that conservative source status rather than claiming to have independently verified deprecation.

## Input safety

The importer validates exact headers, row shape, bounded strings, indexes, IDs, known source classifications and unverified/inactive source flags. It rejects common credential-shaped text and URLs with user information using sanitized errors without echoing values. Public URL evidence accepts HTTP(S) DNS links only, excluding IP literals, local hostnames, malformed DNS labels, credentials, queries, fragments and nonstandard ports. Trailing prose punctuation is trimmed only in normalized URL evidence; raw non-secret source values remain lossless. Evidence links are never treated as API base URLs or fetched, so validation is not a claim of endpoint ownership or safety. A secret-shaped record aborts ingestion before any snapshot is written.

Missing or malformed non-secret URLs are counted in `rejected_url_count`, with no usable URL produced. Unknown metadata is not fabricated to fill gaps. The loader validates the pinned source checksum and exact snapshot bytes before returning records.

the scoped-access contract evidence, new discovery adapters, quotas, and UI changes are outside this PR. No candidate is activated by importing or searching this registry.

## the registry verification run

Executed with `/tmp/autorouter-metadata-venv/bin/python`:

- `-m pytest -q -rs tests/test_provider_registry.py`: **35 passed**, no failures/skips.
- `-m pytest -q -rs`: **207 passed, 0 failed, 9 skipped**; one third-party Starlette/httpx deprecation warning. The full run includes existing browser, dashboard, discovery, SQLite, fail-closed metadata and selection tests.
- `python3 provider_registry.py --check`: passes with 249 rows.
- `git diff --check`: passes.

Skipped tests (unexecuted, not passing): `tests/integration/test_acceptance_gates.py:127,139,163,173` require unavailable `hermes_cli.plugins`; `tests/integration/test_constructor_matrix.py:64,73,82,91` and `tests/integration/test_probe_agent.py:26` require unavailable `hermes_cli`/`run_agent` runtime dependencies in the test environment. No live-provider or inference validation was attempted.
