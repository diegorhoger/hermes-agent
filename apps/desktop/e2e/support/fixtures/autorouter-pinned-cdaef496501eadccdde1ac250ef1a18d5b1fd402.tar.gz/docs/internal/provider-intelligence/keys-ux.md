# Host-managed provider credential experience

The existing Providers tab offers a compact credential coverage strip, searchable
and collapsible provider groups, status filters, and one **Connect provider**
disclosure. Unconfigured chips open the guidance with that provider selected.
Search the picker, open the official key issuance page, configure through Hermes
setup/auth, then refresh presence metadata. Do not enter secrets into AutoRouter.

The denominator is exactly the two slots supported by the reviewed credential
contract: NVIDIA NIM and OpenRouter. It is neither the 249 source candidates nor
the five read-only discovery adapters. Presence is process-environment-only and
unverified. Authorization, credential presence, provider-level authentication
observations, unknown activation and unavailable validation are separate facts.
No account/key count, last validation time or current-key quota is invented.
Provider/model quota observations remain in their existing evidence sections;
they are not attributed to the current credential.

Hermes exposes no supported credential mutation or validation interface to this
plugin. Add/replace/remove/enable/disable/test controls are disabled with explicit
adjacent explanations, including managed configuration. No credential input,
reveal, export, import, custom endpoint, budget cap editor or self-owned vault is
introduced. The placeholder is constant, not derived from a key. Corrupt or absent
SQLite state does not prevent the independent read-only presence contract from
being displayed; unavailable presence has a working retry action.

## References and provenance

The interaction patterns were inspected in a local reference build of an
unrelated provider-management UI. Its implementation, its vault, gateway,
credential reveal and inference testing are not imported.

Official issuance links checked on 2026-11-06:

- [NVIDIA API keys](https://build.nvidia.com/settings/api-keys), linked by
  [NVIDIA's authentication documentation](https://docs.nvidia.com/nemo/retriever/latest/extraction/api-keys/).
- [OpenRouter API keys](https://openrouter.ai/keys), linked by
  [OpenRouter's authentication documentation](https://openrouter.ai/docs/api_reference/authentication).

The backend exposes fixed provenance and auth prerequisites, not a URL inferred
from arbitrary candidate data. Links require HTTPS in the frontend. Issuance
happens at the provider and configuration happens in Hermes, never through an
AutoRouter lifecycle API. The existing unavailable-operation endpoints continue
to deny writes and tests, and host authentication/consent remain in force.
