# AutoRouter decision language

AutoRouter helps a user choose an eligible model from evidence and understand what can be done with that choice.

## Language

**Connection**:
An authorized relationship with a provider, potentially associated with a distinct credential and access scope. A provider name alone does not identify a connection.
_Avoid_: account, key, connected badge as interchangeable names

**Credential authority**:
The owner responsible for a credential's custody, authorized use and lifecycle. Possession of an opaque reference is not authority to use that credential.
_Avoid_: key visibility as permission

**Opaque scope**:
A reference supplied by an authorized producer to distinguish a particular provider/connection context. It does not by itself establish billing-account identity or equivalence.
_Avoid_: account identity inferred from a key hash

**Allowance observation**:
A source-attributed statement about remaining quota in a particular dimension, scope, window and time. An observation is neither a reservation nor a no-charge guarantee.
_Avoid_: guaranteed free balance

**Allowance reservation**:
An execution owner's temporary, enforceable claim on local allowance for an intended operation. It is distinct from observing provider quota.
_Avoid_: refresh lease as spending reservation

**Intelligence plane**:
The discovery, evidence, eligibility, ranking and explanation responsibilities that determine a recommendation. A recommendation does not itself execute a request.
_Avoid_: inference gateway as synonym

**Execution adapter**:
An integration boundary whose declared authority determines which target-validation, application or execution operations it can perform.
_Avoid_: automatic router as assumed execution authority

**Confirmed apply**:
A host-confirmed change to the intended user context after deliberate authorization and validation. Instructions or a recommendation alone are a handoff, not confirmed application.
_Avoid_: applied for copyable instructions

**Verified-free-only**:
A hard eligibility requirement admitting only models with adequate fresh evidence of zero pricing for the supported request. It does not establish unlimited allowance or an enforceable no-charge guarantee.
_Avoid_: Free-first when it implies paid fallback
