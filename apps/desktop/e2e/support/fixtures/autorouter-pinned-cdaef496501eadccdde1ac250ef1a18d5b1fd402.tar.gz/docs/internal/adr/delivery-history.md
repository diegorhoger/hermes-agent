# Delivery history and evidence ledger

Recorded retrospectively on 7 November 2026 from live GitHub PR/issue state, local exact-source receipts and prior owner decisions. This is a bounded verified project history, not a claim to reconstruct undocumented decisions or certify every historical check. Architectural reasoning lives in the ADRs; PRs and receipts remain authoritative for implementation. No account IDs, balances, keys, prompts or completions are included.

## Current merged status — verified 9 November 2026

GitHub reports current main `918207b7b7e42aec32ab417e6cb14d4894e56579`, tree
`ca51fc67c989d126bfd5fa1f6f73b967119d7ce2`. The historical unmerged labels below
are dated receipts, not the current landing state. All 17 merge commits in this
update were fetched from GitHub and verified as ancestors of current main.
Merge records establish source inclusion, not formal approval or release readiness.

| PR | Exact merge SHA | GitHub merged at (UTC) |
| --- | --- | --- |
| [#36](https://github.com/diegorhoger/autorouter/pull/36) | `675907aeb1800cd31152fb325b69adb7aef4100f` | 2026-11-08T17:05:37Z |
| [#52](https://github.com/diegorhoger/autorouter/pull/52) | `830bee4df7e00e597516a24dddc8048aabed09e2` | 2026-11-08T17:06:00Z |
| [#53](https://github.com/diegorhoger/autorouter/pull/53) | `08a6fd6620a6c568c1464eb75be68695df157c79` | 2026-11-08T17:06:08Z |
| [#56](https://github.com/diegorhoger/autorouter/pull/56) | `83e112f5c00141739f75c130a88ed916a6a7e9f2` | 2026-11-08T17:06:14Z |
| [#57](https://github.com/diegorhoger/autorouter/pull/57) | `7af5bbe04a519829f0d97202591341c7ba8a3d81` | 2026-11-08T17:24:58Z |
| [#58](https://github.com/diegorhoger/autorouter/pull/58) | `725797beef1a4ac443dc36051f591f8fe8e2b73c` | 2026-11-08T17:41:24Z |
| [#59](https://github.com/diegorhoger/autorouter/pull/59) | `cf5f2d7e73e251676de8895787ef424c8c5d5f8d` | 2026-11-08T17:31:05Z |
| [#60](https://github.com/diegorhoger/autorouter/pull/60) | `9b8754f463aabf61cfb9178d585b7e8ba88acbd2` | 2026-11-08T17:46:33Z |
| [#61](https://github.com/diegorhoger/autorouter/pull/61) | `34d13d775182da268938c60120775989facc6dfe` | 2026-11-08T18:07:38Z |
| [#62](https://github.com/diegorhoger/autorouter/pull/62) | `942fc24eb3902395cc8ca36bd9bee6a28d95f8c2` | 2026-11-08T19:03:29Z |
| [#63](https://github.com/diegorhoger/autorouter/pull/63) | `b3fe469888ad0c61f577a7594806621fe1135961` | 2026-11-08T20:04:00Z |
| [#64](https://github.com/diegorhoger/autorouter/pull/64) | `45cfb6eac4d7411fc62caefadc3541148210838f` | 2026-11-08T20:18:54Z |
| [#65](https://github.com/diegorhoger/autorouter/pull/65) | `734d3ad972ddb7365610d88189e4fdf39ce48ff2` | 2026-11-08T20:42:45Z |
| [#66](https://github.com/diegorhoger/autorouter/pull/66) | `da74022664bd8feef902aa8dbe0e09c2f6375785` | 2026-11-08T21:00:40Z |
| [#67](https://github.com/diegorhoger/autorouter/pull/67) | `56d24a10cfc59516a876f5902b47b6d8d6a54ae4` | 2026-11-08T21:22:20Z |
| [#68](https://github.com/diegorhoger/autorouter/pull/68) | `e9e716c3e3d9582be6c6bbf0ed7bae8764c709f0` | 2026-11-08T22:30:06Z |
| [#69](https://github.com/diegorhoger/autorouter/pull/69) | `918207b7b7e42aec32ab417e6cb14d4894e56579` | 2026-11-09T02:56:56Z |

Current private candidates, each based independently on that main:

- [#70](https://github.com/diegorhoger/autorouter/pull/70): backlog execution evidence and bounded documentation corrections.
- [#71](https://github.com/diegorhoger/autorouter/pull/71): provisional #35 interoperability document, HEAD `9f40c0757ebb04d272f4578052bda0147177acd8`; runtime deferred.
- [#72](https://github.com/diegorhoger/autorouter/pull/72): native SDK partial-save recovery, HEAD `5a7bcdc8ecd7d31c8075aed26580693bc33a1e81`; full guarded 1320 tests plus five subtests passed, zero failures/skips. Exact-package authenticated Settings recovery passed using one explicitly simulated failure; no provider execution.

Exact-source main package `autorouter-0.2.0-918207b7b7e4.zip` has SHA256
`5687794d20f8a41cccbaf3659ecc87cdf1267d28e458f140f21e6d5425d207f0`;
91 payload files match all committed blobs and two deterministic builds.
It does not inherit the original PR #69 artifact's independent integrity acceptance.
The original `7122f8e` artifact and later `ce9c600` integration artifact remain
separate immutable identities; no historical approval is transferred to a rebuild.

Actual named-theme/viewport acceptance reused the `ce9c600` source tree, which is
identical to main's tree, on pinned private Hermes `3a5f88e`. New main packaging
has its own source manifest. Standard-host selected credential authority, authorized
quota collection, context-bound Apply/Restore and decision-to-request linkage
remain externally blocked; live entitlement is unverified. Website source remains
unverified and release remains blocked. Principal retains issue/merge/release authority. GitHub reports #13, #45, #46
and #48 closed for bounded delivery; none of those closure states proves the
remaining host-dependent acceptance criteria. The dated snapshots below are
retained for provenance, not current issue status.

## Historical application baseline — 7 November 2026

Verified remote application `main`: `9dca52877872c41bfd3efc7bbe2e46cf809f5dcd`. Website `main`: `5937c182da6d857daea4437399cf3de68705969f`. Repository rename/public access and release were not performed. AutoRouter is the product name; AutoRouter remains the repository/plugin identity until a reviewed packaging decision changes it.

| PR | Implemented increment | Exact merge SHA |
|---|---|---|
| [#1](https://github.com/diegorhoger/autorouter/pull/1) | feat: keyword-only record_outcome and regression test | `aa5e05df43bc11a8e88f29cf50177bf14acfd2d1` |
| [#2](https://github.com/diegorhoger/autorouter/pull/2) | feat: plugin-only free model selection and test portability | `63b5415383f5d14d56b79b8d830830e34964047d` |
| [#3](https://github.com/diegorhoger/autorouter/pull/3) | feat: five-tab AutoRouter management console (dashboard plugin) | `7d835b34deff42a44d6f754740e759326e7fcce0` |
| [#4](https://github.com/diegorhoger/autorouter/pull/4) | fix: verified model metadata and catalog persistence | `9c03c705b631217da83a0f186427a470990c6ffd` |
| [#19](https://github.com/diegorhoger/autorouter/pull/19) | feat: the registry provider candidate registry (249 source rows) | `fa10c96b407cd2f4bf9ee2bd89bd48ce9797a3c3` |
| [#20](https://github.com/diegorhoger/autorouter/pull/20) | feat: the connection contract read-only provider credential capability contract | `9a78a6c08d9d237a473da2fc8ea6a25203981de5` |
| [#21](https://github.com/diegorhoger/autorouter/pull/21) | feat: the scoped-access contract scoped model access and free-tier evidence | `9e85f4c11efb9ab9dc080be6d9c15ffb389bebd4` |
| [#22](https://github.com/diegorhoger/autorouter/pull/22) | fix: preserve scoped access restrictions across public price refreshes | `b247d34a1975d86b542eea1c6b561f2539441395` |
| [#5](https://github.com/diegorhoger/autorouter/pull/5) | feat: P4 telemetry and Analytics dashboard | `6b14132f3ba2c58394adbcb19cb3c4f98ff5f794` |
| [#23](https://github.com/diegorhoger/autorouter/pull/23) | feat: deterministic read-only routing preview and explanations | `64a8fc13c4d1be65593929cd2c926505835a188c` |
| [#25](https://github.com/diegorhoger/autorouter/pull/25) | feat: PIR-3 read-only Groq Gemini and Mistral discovery | `edaf7e2e407968124cc232b4ed7f39d99811f83e` |
| [#24](https://github.com/diegorhoger/autorouter/pull/24) | feat: provenance-backed quota metadata and exact credit projections | `886bc73cd7c6aeedcae1c2adb16bb044390dfbf0` |
| [#27](https://github.com/diegorhoger/autorouter/pull/27) | feat: scoped health and selection-only circuit breakers | `c1b50ca6a4f0cab6aee2b36019b0f85f4a28a1eb` |
| [#29](https://github.com/diegorhoger/autorouter/pull/29) | feat: cached scoped free-access observations and honest no-charge selection | `cc28e936e30f16e662f791970727fcab3eb074ab` |
| [#30](https://github.com/diegorhoger/autorouter/pull/30) | feat: PIR-5 provider candidate and model evidence dashboard | `03a5a19d84a8ef9f23f684714982906dfefedec4` |
| [#31](https://github.com/diegorhoger/autorouter/pull/31) | feat: sample-aware operational ranking and evidence-backed Analytics | `667813f19aa1586c65de7e714f2cb973e7724e3f` |
| [#32](https://github.com/diegorhoger/autorouter/pull/32) | feat: PIR-8 host-managed provider Keys onboarding UX | `b1806c767dc990b1fa8bb0e687428e73803b5851` |
| [#33](https://github.com/diegorhoger/autorouter/pull/33) | fix: preserve observed ranking parity in read-only dashboard previews | `aa73a851e9fbd52eff4b8b0d576238f8645f9130` |
| [#34](https://github.com/diegorhoger/autorouter/pull/34) | feat: native Hermes theme inheritance and flat dashboard integration | `787039e5fa185f3261adfa443a82b90fc2d2a0fd` |
| [#28](https://github.com/diegorhoger/autorouter/pull/28) | test: real isolated Hermes conformance and honest acceptance gates | `9dca52877872c41bfd3efc7bbe2e46cf809f5dcd` |

All listed merge commits were verified as ancestors of this baseline. This establishes merged source, not current live-provider entitlement or independent V1 acceptance. Existing [#26](https://github.com/diegorhoger/autorouter/issues/26) remains open for unsupported host OS-system-theme acceptance despite merged named-theme work. [#13](https://github.com/diegorhoger/autorouter/issues/13) remains open. [#35](https://github.com/diegorhoger/autorouter/issues/35) remains deferred.

## Preserved private development and live evidence

- Approved source baselines preserved: Hermes `3a5f88ece685f16082369504ee263fbc12a41cc8`; AutoRouter `63a187730c1a5cd45f4a9fc326b10d359923c83f`. Everyday installation was not replaced by the private validation work.
- Private quota extension: Hermes `db5b14b32eefb7a7081966227e2c58bb153c2269`; initial AutoRouter extension `f7b35f14bfe74163e9c2d0e892d64d1540436f6d`. Synthetic local validation recorded 64 cross-repository, 626 AutoRouter and 135 targeted Hermes passes, separately scoped and overlapping rather than summed.
- Bounded real-provider campaign: 11 provider calls, including one explicit OpenRouter free-variant inference reporting USD cost 0 and 25 completion tokens, no retries/failover. This is one observed result, not unlimited/free entitlement or a hard billing guarantee. Other provider quota gaps and an observed Groq HTTP 403 were retained honestly; no post-inference balance delta was measured. No live requests were rerun for the current planning amendment.
- Actual isolated dashboard: five tabs, six API checks, no JavaScript errors and unauthorized HTTP 401. Provider counts and bounded catalog/request details reconciled; a separate dashboard lacked sanctioned current-scope authority and did not display current-account quota as known.
- Read-only installed source update: Hermes reported v0.23.0 at `2bd378ed1b8d6bf2192cb26e0a55ff3091e6bd19`. Required native credential-scope/quota interfaces were absent in the bounded source audit; existing provider-request/account-usage interfaces and separate Desktop/web theme paths did not remove that gap. This audit did not restart or modify services.
- Credential environment-variable normalization was local-only; values were preserved and no credential file was committed or copied into product artifacts. No private balances or credential fingerprints are recorded here.

The earlier credential-scope upstream experiment [Hermes PR #150317](https://github.com/NousResearch/hermes-agent/pull/150317) is verified CLOSED and unmerged at `3a5f88ece685f16082369504ee263fbc12a41cc8`. It is not an accepted upstream capability. No new Hermes publication is authorized.

## Historical review and paused candidates — 7 November 2026

| Work | Exact source | Evidence / current state |
|---|---|---|
| [PR #36](https://github.com/diegorhoger/autorouter/pull/36), [#13](https://github.com/diegorhoger/autorouter/issues/13)/#41 | `62c327d6d455670457bafafb271cd4341db93b89` | Repaired persisted quota refresh gate and restored preview read-count assertion. Separate local independent review APPROVED source; independently ran 641 regression and 65 private-host integration cases, zero failures/skips. Draft/open; no merge, no formal GitHub review or standard-host completion implied. |
| [PR #52](https://github.com/diegorhoger/autorouter/pull/52), [#38](https://github.com/diegorhoger/autorouter/issues/38) | `64c6ca1702da705af0da1c3d933879267f067ea1` | 24 frozen website claim mappings, 11 contract tests, 26 mapped proof cases, 601 full regression passes. Unmerged/review required; release gate remains blocked. |
| [PR #53](https://github.com/diegorhoger/autorouter/pull/53), [#42](https://github.com/diegorhoger/autorouter/issues/42) | `3710f74b226c7f2cca7401042db6db75d076e37c` | 613 full regression passes, 157 earlier focused passes; suites overlap. Draft/unmerged, useful partial candidate; added competitive-policy acceptance is not yet implemented or accepted. |
| [#40](https://github.com/diegorhoger/autorouter/issues/40) discovery candidate | `b8403bb95e78a9beea366923b0bb2a043ca8446e` | Local clean commit, unpublished; 611 passes (571 unit/API, 30 browser fixture, 10 actual isolated-host gates) using synthetic provider transport. Paused before publication for this reconciliation. |
| [#41](https://github.com/diegorhoger/autorouter/issues/41) dependent acceptance wrapper | `cb19613` (local abbreviation only) | Local unmerged-base candidate on PR [#36](https://github.com/diegorhoger/autorouter/issues/36); not tested/published when implementation paused. Additional quota-policy/window amendment still needs work; not complete. |
| [#43](https://github.com/diegorhoger/autorouter/issues/43) task profiles | Base `3710f74b226c7f2cca7401042db6db75d076e37c` | Clean dependent worktree; no implementation edits, tests or publication before pause. |

Historical passing tests apply only to the named revision and scope. Browser fixtures are not live theme acceptance; synthetic provider transport is not live access. Unmerged dependencies must be labeled explicitly and reconciled after authorized merge. Source approval is not permission to merge.

## Newly approved planning changes

- Existing [#41](https://github.com/diegorhoger/autorouter/issues/41), [#42](https://github.com/diegorhoger/autorouter/issues/42), [#45](https://github.com/diegorhoger/autorouter/issues/45) and [#46](https://github.com/diegorhoger/autorouter/issues/46) were amended in place, preserving the previous body and existing issue ownership; [#43](https://github.com/diegorhoger/autorouter/issues/43) explicitly keeps automatic classification outside V1 scope.
- [#54](https://github.com/diegorhoger/autorouter/issues/54) records the optional gateway/credential-authority/reservation security gates as deferred design-only work outside V1. It does not authorize a gateway implementation or become a V1 prerequisite.
- [#55](https://github.com/diegorhoger/autorouter/issues/55) tracks this ADR register and decision backlog. Epic [#37](https://github.com/diegorhoger/autorouter/issues/37) remains the only V1 epic with the same 15 delivery units.
- The owner approved the competitive suggestions before this register; new feature implementation was paused while issues/ADRs were reconciled. Candidate code is not retroactively accepted against expanded criteria.

## Outstanding controls

No self-merge, public release, visibility change, production installation/deployment, paid API usage or unapproved Hermes modification. Future gateway code, local credential custody, atomic spending reservations, automatic task classification and unsafe retry/replay require separate scope/authority. Full V1 user-journey acceptance and artifact/release gates remain incomplete.
