# Connect and Manage Providers — V1 host boundary

Related to #46 and Epic #37; onboarding (#59) and six-provider discovery (#57)
are merged through #69. It extends the existing
Providers tab rather than introducing a second application or credential vault.

## Supported user path

Choose one of the six fixed discovery adapters in the searchable provider
coverage view. A link such as `/autorouter?provider=gemini` opens Providers with
Gemini's official setup guidance selected. Configure through a supported Hermes
interface, then refresh the presence view and inspect discovery and model evidence
in Providers/Models. Recommendations and eligibility remain distinct from
successful authentication or operational entitlement. Model evidence counts refer
to the displayed bounded proof snapshot, not an unlimited catalog scan.

NVIDIA/OpenRouter retain their existing declared-profile presence behavior;
Gemini accepts only its fixed aliases actually declared by the host profile.
Groq/Mistral remain metadata adapters even when the pinned host has no native
provider profile. In that case native setup/presence stays unavailable, rather
than reading a secret independently or presenting a working connection.

## Readiness is not a connected badge

The connection API separates operator configuration, observed environment presence,
authentication validation, discovered models, eligible models and operational
usability. Unknown proof or corrupt state remains unknown rather than zero.
Unscoped provider authentication failures are not blamed on the current credential.
Named connection slots, labels, credential/account counts and allowed account/model
scopes remain unavailable unless a sanctioned host authority supplies them. Extra
untrusted observation fields cannot create those objects or authorize actions.

The current host contract does not offer credential lifecycle, validation/test,
secure intake or named-slot enumeration to this plugin. Add/replace/remove/enable/
disable/test controls remain denied or disabled with precise managed, permission,
configuration or capability reasons. A saved/present credential is never labeled
validated. No raw-key form, secret persistence, reveal/export, billing test,
automatic rotation or execution retry is introduced.

**External blocker:** actual lifecycle management and validated native connection
acceptance require the separately verified secure Hermes authority described in
#46 and the ADRs. This read-only UX cannot establish that host API. Select/apply/use
still belongs to #45; account identity/quota to #41. None is silently implemented
through private attributes or a background provider call.

## Source-backed setup references

Checked 7 November 2026; these are provider guidance, not free-access evidence:

- Groq: https://console.groq.com/docs/quickstart and https://console.groq.com/keys
- Gemini: https://ai.google.dev/gemini-api/docs/api-key and https://aistudio.google.com/apikey
- Mistral: https://docs.mistral.ai/getting-started/quickstarts/studio/activate-and-generate-api-key and https://console.mistral.ai/

Existing NVIDIA/OpenRouter sources remain as documented by the prior credential
contract. Issuing a key or following a provider quickstart does not authorize
paid inference or mean that the particular Hermes build supports that provider.
