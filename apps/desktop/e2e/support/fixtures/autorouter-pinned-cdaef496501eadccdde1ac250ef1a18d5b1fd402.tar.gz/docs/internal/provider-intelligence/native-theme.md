# Native Hermes web theme adapter (#26)

AutoRouter inherits the mounted Hermes dashboard's CSS variables. It does not
choose a theme, write a preference, set `data-theme`, watch OS appearance, load a
font, or maintain a separate light/dark palette. Existing SDK registration and
all five functional tabs are retained. CSS remains scoped to `.ar-*` descendants.
No Hermes source, production configuration, credentials or services are changed.

## Verified web contract

Actual target: Hermes **`b200f5bc60e31588ba2cb60e288029c4a54ba5fa`**, inspected read-only
in the clean source archive and running as an isolated dashboard with its matching
shipped web assets. References:

- [Web stylesheet and token bridge](https://github.com/NousResearch/hermes-agent/blob/b200f5bc60e31588ba2cb60e288029c4a54ba5fa/web/src/index.css).
- [Theme application to document-root variables](https://github.com/NousResearch/hermes-agent/blob/b200f5bc60e31588ba2cb60e288029c4a54ba5fa/web/src/themes/context.tsx).
- [Installed built-in theme definitions](https://github.com/NousResearch/hermes-agent/blob/b200f5bc60e31588ba2cb60e288029c4a54ba5fa/web/src/themes/presets.ts).
- [Actual native theme chooser](https://github.com/NousResearch/hermes-agent/blob/b200f5bc60e31588ba2cb60e288029c4a54ba5fa/web/src/components/ThemeSwitcher.tsx).
- [Web plugin SDK v1.1.0 exports](https://github.com/NousResearch/hermes-agent/blob/b200f5bc60e31588ba2cb60e288029c4a54ba5fa/web/src/plugins/registry.ts).

The same relevant web contract was compared with upstream
`323c318c4eb4a22fd75e9172639d88379bbc3d42`. Desktop `DESIGN.md` was not treated as a
web token/API contract. No private desktop package is imported. The existing
vanilla DOM implementation uses a thin CSS adapter rather than replacing its
framework or importing private React modules.

| Concern | Verified host input | Adapter behavior |
| --- | --- | --- |
| Canvas | `--background-base` | Same opaque host canvas; system Canvas fallback |
| Text | `--midground` | Visible host text; **not** default transparent `--foreground` |
| Secondary text | `--color-muted-foreground`, `--color-text-secondary`, `--midground-base` | Blend 25% native secondary with 75% opaque host text for readable contrast |
| Hairlines | `--color-border` | Verified 15% midground fallback expression |
| Input/hover surfaces | `--color-muted`, `--color-accent`, `--midground-base` | Verified 8%/10% host midground/base fallback expressions |
| Focus | `--color-ring`, `--midground` | Visible native ring; all links/disclosures/controls have focus treatment |
| Body/measurement fonts | Inherited font, `--theme-font-sans`, `--theme-font-mono` | No bundled/private font stack |
| Heading | `--font-rules-expanded`, `--theme-font-display` | Matches confirmed native Config/System heading primitive, with inheriting fallback |
| Radius/density | `--theme-radius`, `--radius`, `--theme-spacing-mul` | Dynamic host radius and spacing; native square control shape retained |
| Charts/status | `--color-success`, `--color-destructive`, `--series-input-token`, `--series-output-token` | Live semantic/series colors; no fixed green/red/gray claims |

The default host's secondary text is 80% alpha. On installed light Nous Blue that
would yield approximately **3.73:1** against the host canvas. The adapter keeps the
host colors and raises opacity through the host-text blend; actual rendered
secondary contrast is **4.72:1** there. No runtime contrast/theme engine or fixed
replacement color is introduced. Status meanings remain textual.

Private dark surfaces, gradients, glow, raised-card shadows, custom logo,
uppercase metric decoration, duplicate in-page product heading and thick toast accent were removed.
The existing header dot now includes its previously dropped enabled/disabled/unknown
text, so status does not rely on color alone. Native spacing,
hairlines, inherited type, square controls and lightweight status labels replace
them. Tables remain horizontally scrollable inside the viewport; reduced-motion
also covers the root-level toast. The existing safe DOM and settings flow are
unchanged.

## Reproducible verification

Offline suite:

```sh
python -m pytest -q tests/test_native_theme_contract.py tests/browser/test_native_theme.py
```

The CSS contract rejects fixed palette literals, gradients/shadows and selectors
outside `.ar-*`. Browser fixtures mutate **mock host** tokens without remounting,
verify exact inheritance and no extra API calls, and exercise five tabs, keyboard
focus, reduced motion and 390/768/1440px layouts. These tests are not live-host proof.

Opt-in **actual isolated Hermes** acceptance uses the existing host SDK/API and
native theme chooser, not mocked HTML/API responses:

```sh
python tests/browser/host_theme_probe.py \
  --base http://127.0.0.1:19129 \
  --fixture-root /tmp/autorouter-dashboard-isolated \
  --output /tmp/autorouter-dashboard-isolated/theme-evidence
```

The probe first confirms that the plugin state directory belongs to the explicit
temporary fixture root. It changes only that isolated host's theme and an allowed
plugin policy, restoring both. No inference/provider calls are made. It covers:

- Eight installed themes: Hermes Teal, Hermes Teal (Large), Nous Blue, Midnight,
  Ember, Mono, Cyberpunk and Rosé. The mounted AutoRouter node and selected provider
  filter survive every switch, without refresh/remount.
- Computed background, foreground, border, focus and secondary text equal the
  verified host-derived expressions. Body/secondary contrast is at least 4.5:1
  across these installed presets; minimums are 5.07:1 and 4.72:1 respectively.
- Actual native **Config and System** pages alongside AutoRouter in dark Teal and
  light Nous Blue, with screenshots. Optional external Google font stylesheets
  are blocked during the isolated run; inherited font stacks and locally shipped
  design-system fonts are verified, not external font download availability.
- All five plugin tabs at 390/768/1440px in every installed theme, keyboard tab
  navigation, empty-state rendering, reduced motion, and a real allowed policy
  save/restore through Hermes' authenticated plugin settings API.

Artifacts are actual-host screenshots and `actual-host-theme-report.json` under
the explicit output directory. The temporary fixture initially has an empty plugin
SQLite database and no credentials/configured providers; zero/unknown displays
are intentional. Non-neutral routing evidence belongs to the separate scoring
parity acceptance, not a claim manufactured from these empty visual fixtures.

## Unsupported host acceptance: OS-system theme

**`BLOCKED_HOST_SYSTEM_THEME`**: this pinned host exposes eight named presets and
no OS-system theme mode or OS-appearance subscription. Its “System Sans,” “System
Serif” and “System Mono” entries are **font choices**, not theme modes. OS light/dark
emulation while a named host theme is active correctly leaves both host and plugin
colors unchanged. That is not a passed OS-system-theme acceptance check. AutoRouter
does not invent a theme engine or patch Hermes to satisfy an unavailable host
capability. Issue #26 is referenced without automatic closure so the orchestrator
can assess this precise remaining host acceptance limitation.
