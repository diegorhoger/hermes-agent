# First-use guidance v1

AutoRouter’s Overview offers **Start guided setup**. It reads current configuration,
provider-presence diagnostics and the canonical Models preview. Opening or
rechecking the guide does not enable the plugin, refresh a provider, write
configuration, select a model or execute inference.

## Deliberate setup sequence

1. Opt in through Hermes Plugins and the existing plugin runtime setting.
   The guide supplies native CLI commands and the official plugin documentation.
   Managed configurations direct the user to their administrator without overrides.
2. Open existing Settings to choose authorized providers. An explicit empty
   provider list stays empty, including in the registered runtime tools.
3. Open Providers to inspect environment presence and approved setup links.
   Presence never proves authentication, account identity or entitlement. An
   observed unbound authentication failure may belong to a different credential.
4. Ask Hermes to run the existing `autorouter_refresh` tool explicitly, then
   recheck. No undocumented dashboard-to-tool dispatch API is introduced.
5. Open Models, choose explicit requirements and inspect the canonical preview.
   Missing, stale, unknown-cost and paid evidence cannot authorize a recommendation.
6. Prepare the existing validated manual handoff. Native context-bound apply and
   restore remain unavailable; no request is executed by this guide.

## Completion and failures

`GET /first-use` is read-only and available before the database is initialized.
It reports schema version 1 and a bounded snapshot: disabled/unreadable config,
no authorized providers, unavailable/empty catalog, no eligible recommendation,
or recommendation evidence ready. The latter proves only a canonical cached
recommendation, never authenticated inference or applied selection.

Cached row counts cannot prove complete or partial refresh success. The result
therefore reports refresh outcome unknown and providers without displayed models,
rather than inventing a successful job receipt. Actual failed refresh handling
remains in the native tool. Five-provider discovery and onboarding are merged from #57/#59. Live quota
authority remains a separate host capability.

All instructions use existing native actions; there is no credential form,
credential vault, background probe, paid call or implicit mutation. Browser
controls are keyboard buttons with a labeled ordered list and polite status
announcements. Official links use HTTPS with noopener/noreferrer.

## Validation and topology

The branch includes merged main through #64, including #57/#59 discovery
and onboarding plus plugin-side #36/#58 quota integration. No host extension
or credential authority is implied. Synthetic snapshots
cover missing/stale/no-match/partial/invalid-auth evidence. Real isolated Hermes
loads the plugin and runs its registered refresh/selection tools against synthetic
public-catalog transport for disabled, no-provider and first-recommendation cases.
Browser harness tests exercise guide discovery, read-only recheck and native-tab
navigation. Synthetic transport is not live-provider acceptance.

The bounded first-use delivery is closed under issue #39. Combined five-provider
synthetic catalog scenarios do not establish live provider entitlement.
Human assistive-technology and native context-bound Apply/Restore acceptance
remain open under #37/#49; closing #39 does not satisfy those gates.

## Provider authorization validation

A genuinely missing provider setting retains only the established NVIDIA and
OpenRouter defaults when the plugin is explicitly enabled. An explicit empty
list remains empty. Non-list values, mixed-type lists and unsupported IDs reject
the entire authorization list, not merely its invalid entries. Registration,
read-only inventory, Settings validation and first-use guidance share the fixed
five-provider validation. Malformed configuration grants no credential-presence
probe, refresh or selection authority; guidance remains configuration unavailable.
