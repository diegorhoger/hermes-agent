# Structured Hermes credential scope

AutoRouter consumes the optional `credential_scope` field on `pre_api_request`,
`post_api_request` and `api_request_error`. The locally tested host is Hermes
`3a5f88ece685f16082369504ee263fbc12a41cc8`; the everyday installed Hermes
`b200f5bc60e31588ba2cb60e288029c4a54ba5fa` does not produce this field. This
document does not claim upstream acceptance or deployment of either change.

The plugin declares `llm.credential_scope`. Hermes owns consent and strips the
field per callback when that capability is not granted. Installing this manifest
does not grant permission or enable AutoRouter: its default remains disabled.

```json
{
  "provider_id": "openrouter",
  "credential_scope_id": "0123456789abcdef0123456789abcdef",
  "identity_status": "known"
}
```

This is a fictional opaque entry ID, not a credential or a billing-account ID.
Only the exact three-field shape, `known` status, matching provider and 32 lower
case hexadecimal ID are accepted. The internal reference is `provider:id`, then
the existing telemetry/health boundaries hash it for persistence. Missing,
unavailable, unknown, invalid or mismatched metadata yields an empty scope.
Objects are never stringified into apparent analytics identities. Explicit legacy
string references remain supported; no reference is inferred from an environment
variable, provider name, profile or credential material.

Each observation uses the scope captured by Hermes for that attempt. A retry
using another entry records health separately and makes the logical request's
overall scope unknown. Each recorded attempt retains its own hashed scope in
schema v4; old attempts migrate to unknown without inventing historical identity.
Read-only diagnostics continue to read unmigrated databases without writes.
An observed entry never overwrites the current account in
router settings: simultaneous requests do not establish a single current account.
No credential selection, execution retry, provider switch or new network request
is introduced.

## Quota boundary

The same decoded reference invalidates existing cached account observations on
401/403/429. Other scopes are untouched. Existing expiry timestamps are retained;
a 429 does not invent exhausted allowance, and stale/unknown evidence cannot
authorize guaranteed no-charge execution. Verified zero-price/capability/health
eligibility remains independent of whether an identity is present.

The approved Hermes scope interface does **not** expose account-bound quota
observations or an authenticated metadata collector. This repair does not pair
an observed scope with a separately resolved environment key. The existing
explicit metadata-refresh path is not activated or bound by observing requests.
A future collector needs a supported host-owned binding to the same executing
entry, provenance, freshness, consent and account-isolation tests. Until then,
operational account collection remains unknown; cached quota tests use clearly
synthetic source-shaped fixtures. Credential-entry identity alone is not proof of
billing-account identity, validity, allowance or a hard billing stop.

### Quota collection refresh gate

Only a structured, known OpenRouter scope is eligible for collection. Before
calling the optional host operation, AutoRouter atomically reserves its existing
SQLite quota refresh lease for 120 seconds per provider/canonical scope. The
transaction commits before host I/O, so concurrent callbacks and reopened stores
share the cooldown. Successful ingestion preserves the reserved deadline; failed,
unavailable and malformed operations cannot trigger immediate retries. Stored
observation timestamps and expiry are never renewed by a cache hit or failure.

The call remains in the authorized attempt callback. The tested private Hermes
extension (`db5b14b32eefb7a7081966227e2c58bb153c2269`,
`agent/scope_quota.py`, `ScopeQuotaService.fetch`) independently requires the
current plugin/request/scope authorization, claims a 120-second host refresh
window, limits active workers to four per profile, and invokes
`run_bounded_sync(collect, 2.0)`. Its fixed-endpoint transport also has a two-second
timeout and a 64-KiB decoded response bound. A timeout returns unavailable; late
results cannot update plugin state. An eligible cold refresh can therefore add
up to the host's two-second collection deadline (plus local scheduling/storage
overhead); ordinary callbacks inside the lease perform no host collection. This
is not a latency guarantee for arbitrary third-party implementations of the
optional method. Standard Hermes v0.23.0 lacks this host contract and safely
skips collection. No background scheduler or detached plugin worker is used.
