# Final private mainline integration candidate

All parent PRs #36, #52, #53, #56, #57, #58, #59 and #60–#68 have landed.
The reconciliation base is main `e9e716c3e3d9582be6c6bbf0ed7bae8764c709f0`.
Their accepted implementations are authoritative; this branch preserves history
without reintroducing older copies. Source merge does not authorize public release.

## Unique remaining integration

The only runtime delta is schema version 5, reconciling health-event provenance
and immutable per-attempt scope. Main already contains the transactional optional
column migrations, pure read-only path lookup, enabled-runtime initialization,
default canonical quota evaluator, fail-closed provider lists, callback cancellation
and dashboard request-generation protections. These are reused, not duplicated.

Schema tests use real SQLite v3/v4 representations: original attempt target/time
and known scope survive, absent legacy scope stays unknown, health event time
never comes from updated_at, failure rolls back, diagnostics never migrate.
The package lifecycle restores a matching schema-v4 snapshot before the older
writer is opened; plugin replacement alone does not downgrade a v5 database.

Actual registered-host tests cover all five discovery adapters with complete and
partial synthetic catalogs, cache/API/guide/recommendation parity and secret
isolation. Public model-price proof is distinct from authentication, entitlement,
active-account authority and no-charge guarantees. Strict no-charge stays denied.
The original Router quota proof now lives in main's quota-policy regression file.

The claims checker clears inherited filtering, collects every parametrized case,
compares JUnit identities and rejects missing, skipped, empty or failed evidence.
Frozen quotations, states and release gates remain intact. Website source is not
verified by local mapping or synthetic fixtures. ADR validation remains separate.

## Historical artifact and GUI provenance

The accepted original artifact is `autorouter-0.2.0-7122f8e43a20.zip`, source
`7122f8e43a20f0e49a5c3e7b8bc752e575ecc1ef`, tree
`1092c64c0d4c49f254724b3ffb5af57b55308757`, SHA256
`0642be5637e1e48a68bc62bb46157b672b60966d844b10e018c2edec0ffb57a3`.
It remains immutable; its integrity acceptance is not new-mainline acceptance.
Historical authenticated GUI evidence at bb9c40c stays bound to its original
artifact. A new candidate requires its own source/tree/checksum, two builds,
artifact-backed lifecycle and accurately attributed GUI receipt.

`tests/browser/host_theme_probe.py` accepts only an owned loopback dashboard and
fixture root. It verifies deployed hashes, uses the sanctioned SDK without token
export, checks authenticated endpoints and anonymous denials, themes, responsive
tabs and explicitly synthetic preview/manual handoff. Always stop the owned
server and verify the port is closed. Never target everyday Hermes.

## Remaining host/release boundaries

Pinned private Hermes supports isolated attribution tests, not standard-Hermes
selected-account consent or an authorized quota producer. Context-bound native
Apply/Restore, actual decision-to-request linkage, live entitlement and spending
enforcement remain unavailable. No gateway, private fallback mutation, replay,
paid inference, production change, autorouter-web change, release/tag or issue closure.
