---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Accepted boundary; automatic replay/fallback remains inactive and unauthorized."
---

# ADR-0008: No replay or enforcement without execution authority

Observer hooks record outcomes and selection-time health/cooldowns; they do not authorize replaying requests, replacing committed output, repeating tool effects or enforcing spending. Automatic retry/failover requires explicit ownership and proof of streaming/side-effect commitment, cancellation and replay safety. A future adapter may declare only operations it actually controls.

## Consequences and limits

An inactive private fallback-chain helper is not a supported apply API. A future gateway can be considered under [#54](https://github.com/diegorhoger/autorouter/issues/54) after separate approval; its existence would not imply blanket safe fallback or cross-provider no-charge enforcement.

## Evidence and ownership

[#15](https://github.com/diegorhoger/autorouter/issues/15); [#45](https://github.com/diegorhoger/autorouter/issues/45); [#47](https://github.com/diegorhoger/autorouter/issues/47); [#50](https://github.com/diegorhoger/autorouter/issues/50); [#54](https://github.com/diegorhoger/autorouter/issues/54). Code anchors: `runtime.py`, `integration.py`, `failover.py`, `health.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
