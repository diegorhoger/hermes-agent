---
status: accepted
recorded: 2026-11-15
authority: owner-approved native-controls direction following UI SDK compatibility discovery
implementation: "Implemented in the unmerged issue-#108 branch (see CHANGELOG 'Issue #108 (implementation)' and the PR for issue #108). Independent acceptance still pending."
---

# ADR-0014: Native Hermes model toggles without a second UI framework

## Context and evidence

The AutoRouter model catalog requires simpler model inclusion/exclusion than complex selectors. The user approved a primary per-model on/off interaction with search, provider filtering, and transparent routing eligibility.

The existing web dashboard is a host-registered IIFE using plain DOM and host-scoped CSS (`dashboard/README.md`, `dashboard/dist/index.js`). The Desktop runtime plugin is plain ESM using `@hermes/plugin-sdk` and `react*` only (`desktop/plugin.js`, `docs/desktop-integration.md`); `tests/test_desktop_plugin.py` enforces this import allowlist. Native Desktop primitives already include `ToggleRow`, `SearchField`, `Input`, and `SegmentedControl`. Direct `@ui-sdk/react` imports are therefore unsupported through the currently documented Desktop plugin loader. A host React 19+ runtime prerequisite for UI SDK has not been independently established. No dependency installation/build proof was performed in discovery.

## Decision

Keep AutoRouter's existing Hermes-native web and Desktop UI architecture and host design tokens. Implement simple accessible per-model on/off controls with search and provider/eligibility filters using native Hermes primitives for Desktop and accessible dependency-free controls for the web IIFE. Do not scaffold Next.js, import UI SDK packages into the restricted plugin runtime, modify Hermes, or introduce a duplicate management backend. Revisit a bundled external component library only after a documented, independently verified host extension/loading contract and explicit authorization.

A toggle records **user inclusion preference**, not an assertion of model eligibility, cost, live health, or execution authorization. Display these dimensions separately. Existing `model_include` and `model_exclude` settings and sanctioned API are the persistence boundary; define and test the default/unrestricted state, explicit exclusions, bulk operations, stale/concurrent changes, partial writes, failed writes and re-read confirmation before implementing mutations. Preserve the existing plugin reload semantics and state that changes may not be active until restart.

Do not duplicate the canonical eligibility engine, bypass mandatory verified-free-only policy, fabricate provider evidence, expose credentials, or claim that user enablement authorizes paid inference or automatic execution-level fallback.

## Scope and acceptance

Issue [#108](https://github.com/diegorhoger/autorouter/issues/108) governs incremental web and Desktop implementation and tests. Keep search, provider filtering, pagination, row-level ineligibility reasons, responsive layouts and keyboard/screen-reader support; test native host theme behavior, missing/unknown metadata, empty and failed states, model-specific persistence, partial saves, and security failure-closed behavior. Preserve accepted [ADR-0003](0003-mandatory-free-only-and-billing-uncertainty.md), [ADR-0009](0009-native-dashboard-and-host-theme-inheritance.md), and [ADR-0011](0011-versioned-policy-and-execution-independent-evidence.md).

This ADR accepts UX architecture only. It does not authorize changes to host code, paid inference, runtime routing authority, PR merges, or releases; code implementation and actual-host acceptance require separate verification.

## Addendum (2026-11-15, dispatch #111 — repair of PR #110 review findings)

The review of PR #110 identified two defects in the implementation above; both are repaired on the same branch:

1. **Last-model OFF can never widen selection.** The preference is now persisted as the single, plugin-scoped `model_preference` key (`{version: 1, mode: "none"|"allowlist"|"unrestricted", include, exclude}`), written with one atomic Hermes save (`save_plugin_setting`), so the include/exclude/mode triple is all-or-nothing across processes. The canonical selector (`routing_settings` → `merge_global_and_profile` → `hybrid_select`) understands the explicit `none` mode and refuses to route — fail closed, zero outbound requests, including for models discovered afterwards. An allowlist emptied by toggles transitions to `none`, never to unrestricted; a profile can narrow but never widen the global mode (an empty include intersection fails closed too). Eligibility remains independent: free-only and provider authorization are untouched, and a toggle never makes a model eligible. `Reset to unrestricted` (`POST /models/preference {"reset": "unrestricted"}`, itself hash-checked; two-step button in web and Desktop) is the only way back — a permission-widening action is never hidden inside OFF. Legacy `model_include`/`model_exclude` files stay readable and are migrated verbatim into `model_preference` on the first toggle write; unrecognized legacy entries refuse the toggle without mutating anything.
2. **Cross-process writes cannot clobber each other.** Preference writes (toggles, reset, and raw settings edits of the include/exclude keys, which fold into the single key) serialize on a plugin-scoped file lock spanning the base-hash check → write → read-back verification. Two processes racing the same base: exactly one wins; the other is refused as stale (HTTP 409) before mutating anything. Web and Desktop re-fetch authoritative state on 409 and replay only when the mode is unchanged; a changed mode is surfaced as a conflict requiring explicit re-confirmation.

This addendum supersedes the "falls back to unrestricted" behaviour described in the original implementation entry. The recorded ADR acceptance boundary (UX architecture only) is unchanged; live-host acceptance remains a separate step.

## Evidence

Repository sources inspected on 2026-11-15: `dashboard/README.md`, `dashboard/dist/index.js`, `desktop/plugin.js`, `docs/desktop-integration.md`, `tests/test_desktop_plugin.py`, `docs/dashboard.md`; decision tracked in issue #108. Discovery is static repository inspection, not an installation or live-host compatibility test.
