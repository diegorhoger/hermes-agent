# Future gateway acceptance gates — design only

Owner: [issue #54](https://github.com/diegorhoger/autorouter/issues/54).
Status: **DEFERRED / DESIGN-ONLY / OUTSIDE V1**. This document grants no execution,
credential-custody, OAuth, spending, retry, deployment or release authority. It is
not an implementation plan or a prerequisite for [V1](https://github.com/diegorhoger/autorouter/issues/37).

The accepted V1 boundary remains a Hermes-native intelligence plugin with explicit
manual handoff where native authority is unavailable. Existing source, tests and
private Hermes experiments do not prove a future gateway safe or operational.

## Separate decisions before any implementation

| Gate | Required future decision and owner | Evidence required before acceptance |
| --- | --- | --- |
| Intelligence reuse | Product and selection-policy owner preserve one versioned eligibility/ranking/evidence engine. | Identical sanitized fixtures across plugin and proposed executor; paid/unknown-cost rejection, schema denial and deterministic no-match. No duplicate engine. |
| Credential authority | Host/security owner defines user, profile, plugin, connection and request ownership, explicit consent, custody and revocation. | Cross-user/profile/plugin/account denial; forged, stale and revoked binding rejection; secret-free outputs/errors/audit. An opaque ID is not permission to use a credential. No default two-vault synchronization. |
| Execution capabilities | Execution owner declares selection, target validation, confirmed apply, execution, streaming, reservation and retry separately. | Unsupported operations deny without side effects; actual context-bound receipts survive into the intended request/attempt. Manual instructions cannot count as confirmed apply. |
| Reservations | Execution and security owners define atomic reserve/settle/cancel and crash recovery only for operations they can enforce. | Concurrent requests cannot over-reserve; cancellation, expiry, duplicate settlement, process crash and multi-client isolation tested. Provider quota snapshots and refresh leases are not reservations or a billing guarantee. |
| Streaming and side effects | Execution owner defines commitment before output/tool effects and cancellation semantics. | No replay after irreversible output or tool commitment; partial streams, interrupted tools, uncertain completion and missing receipts fail safely. No generic safe-retry claim. |
| Retry and failover | Product/security owners separately authorize each replayable operation and target. | Explicit attempt provenance, idempotency and consent; no hidden paid fallback, account switch or replay after uncertain completion. Capability absence means no retry. |
| Endpoint security | Security and protocol owners define authenticated clients, authorization, origin policy and provider allowlists. | Unauthorized endpoint calls denied; arbitrary URLs, private/link-local/metadata targets, DNS rebinding, redirect escapes and credential-forwarding attacks rejected. Bound bodies, concurrency, rate, response size and time. |
| Protocol compatibility | Protocol owner defines supported request/response/stream/error shapes and version negotiation. | Adversarial malformed/unsupported input, disconnect, backpressure, cancellation and bounded error tests; no inferred compatibility from model names. |
| Multi-client operations | Named operator owns deployment, isolation, observability, incident response and upgrades. | User/profile/session isolation, least privilege, redacted retention, startup/shutdown, resource limits and recovery demonstrated in an isolated environment. No implicit production rollout. |
| Rollback and release | Repository/product owner authorizes an exact reviewed source/artifact and rollback pair. | Reproducible package identity, compatible data snapshot, consent/config restoration and revocation tested; no automatic schema downgrade or deletion of user state. Separate public-release and production permissions. |

## Acceptance authority and stop conditions

A future dispatch must name its scope, accountable owners, supported host/protocol
versions, security reviewer, execution authority, test environment and exact
acceptance criteria. Independent source/artifact acceptance and explicit owner
implementation authorization precede deployment. A design record or green mock is
not that authorization. Missing authority, uncertain commitment, cross-context
identity or unverifiable quota remains unavailable; it must not be fabricated in
the plugin.

Begin with synthetic credentials and transport. Real-provider tests require
separate bounded consent and entitlement; local tests cannot claim live provider
availability or no-charge enforcement. No secret belongs in fixtures or receipts.
Gateway, credential service, OAuth, reservation controller and inference retry
code remain absent from this work.

Automatic task classification is independently deferred. Any future proposal must
be optional, privacy-preserving and testable without confusing keyword matching
with semantic competence. V1 keeps explicit General/Coding/Fast response profiles.

## Existing decisions retained

[ADR-0001](../adr/0001-native-intelligence-and-replaceable-execution.md),
[ADR-0002](../adr/0002-host-owned-credentials-and-request-scopes.md),
[ADR-0007](../adr/0007-quota-observations-preflight-and-reservations.md),
[ADR-0008](../adr/0008-no-unsafe-replay-or-unowned-enforcement.md) and
[ADR-0011](../adr/0011-versioned-policy-and-execution-independent-evidence.md)
retain their approved meaning. [external evaluation interoperability](https://github.com/diegorhoger/autorouter/issues/35)
is a separate future evidence boundary and does not confer execution authority.
