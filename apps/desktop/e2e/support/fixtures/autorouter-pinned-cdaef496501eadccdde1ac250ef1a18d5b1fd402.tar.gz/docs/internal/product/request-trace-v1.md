# Request lifecycle evidence v1

Analytics request detail adds a bounded, sanitized `trace` object. Version 1
reports the existing host request identity, request context presence, observed
attempt coverage/target consistency, terminal outcome and metric availability.
It never joins a recommendation to a request by model name, timing, a browser
confirmation or caller-supplied decision ID.

## Observable and unavailable links

The current inspected Hermes hook contract supplies request/session/task/turn
identifiers and final/error observations. The plugin stores hashed buckets and
allowlisted labels. Decision identifiers and sanctioned context-bound apply
receipts are not supplied. Therefore `decision`, `apply` and end-to-end
correlation remain **unavailable**, including after manual handoff. A successful
request proves neither application of a AutoRouter recommendation nor spending safety.

Account scope is an observed hashed bucket, never current credential authority.
Missing or changing scope permanently removes specific request attribution;
per-attempt account proof remains unavailable. Callback context contradictions
cannot mutate an existing request: a stored session must match, including when a
later callback omits session; task/turn contradictions are rejected when present.
Unbound historical requests remain explicitly unknown, without guessed identity.

## Event ordering and counts

An already known request ID returns its row without another insert. Accepted
attempt ordinals are immutable; repeated observations cannot replace their target,
error or timestamp. Terminal requests are counted once. A terminal callback may
arrive before pre; later pre does not reopen it. Late attempts after completion
are ignored rather than treated as new successes. Canceled outcomes are stored
as canceled and do not train health success/failure observations.

The detail query reads at most 101 attempt rows and displays at most 100. A
truncated or gapped ordinal sequence is partial. Contiguous stored ordinals do
not prove all host callbacks arrived. Total host retry count stays unavailable:
legacy ingestion can assign ordinals when the host omits them. Observed additional
attempts are a diagnostic count, never replay authorization. Changed attempt
provider/model is shown as a different observed target, not correlated to an
applied recommendation. No retry is dispatched.

## Metric and timestamp meaning

Each metric has `observed`/`unavailable` and a nullable value. Observed zero stays
zero; missing, negative or nonfinite data stays unavailable. Tokens are not a
billing ledger, and no cost/savings calculation is introduced. Stored event times
are shown with their limitation: old rows do not record whether a timestamp came
from the host or local ingestion. Invalid clock ordering is explicitly unknown.
Attempt `created_at` is ingestion time, not provider execution time.

The trace contains no request/session/account hash values, prompts, completions,
raw provider errors, secrets or PII. Existing request detail remains sanitized.
Reads create neither database/schema changes nor execution authority.

## Validation and acceptance

Regression tests cover identity mismatch, missing session, account changes,
repeated attempts/terminal callbacks, terminal-before-pre, cancellation, targets,
unknown/zero usage, malformed metrics and bounded read-only details. Browser tests
show unavailable correlation and usage separately from observed zero. Actual
isolated Hermes loads registered callbacks for synthetic success and failure;
those outcomes remain uncorrelated to the read-only recommendation/manual handoff.

This candidate includes merged main through #66, including plugin-side #36/#58
integration. It adds no host extension. The complete decision → sanctioned apply → request acceptance required
by #50 remains blocked on a supported host receipt/identifier producer. This is
not actual inference, live provider acceptance, formal review, release or issue
closure. Standard-host authority and live credential/provider acceptance remain separate.

Cancellation is terminal through both post-request and supported error callbacks.
It neither updates provider health/reliability nor invalidates quota allowance.
A retryable flag cannot keep a canceled request pending. Genuine errors retain
existing health and bounded retry-accounting behavior.
