---
status: accepted
recorded: 2026-11-07
authority: owner-approved direction; retrospective context where noted
implementation: "Mandatory verified-free-only canonical policy merged; no paid fallback or enforceable no-charge guarantee."
---

# ADR-0003: Mandatory verified-free-only before ranking

All V1 policies admit only source-attributed, fresh verified-zero-price models that pass the other hard requirements. Ranking preferences cannot authorize paid or unknown-cost models. Published zero pricing, promotional credits and cached quota are not a provider billing hard stop or an independently enforceable no-charge guarantee. Strict no-charge execution therefore denies without separate adequate evidence, rather than silently spending a balance.

## Consequences and limits

The website Free-first fictional paid-fallback behavior conflicts with production semantics and must be aligned under [#42](https://github.com/diegorhoger/autorouter/issues/42). A separately governed paid policy is not authorized. Preference and requirement vocabulary must be explicit.

## Evidence and ownership

[#8](https://github.com/diegorhoger/autorouter/issues/8); [#13](https://github.com/diegorhoger/autorouter/issues/13); [#38](https://github.com/diegorhoger/autorouter/issues/38); [#41](https://github.com/diegorhoger/autorouter/issues/41); [#42](https://github.com/diegorhoger/autorouter/issues/42). Code anchors: `eligibility.py`, `free_access.py`, `quota.py`. The [delivery history](delivery-history.md) separates merged work, private experiments, unmerged candidates and unverified host support. Source: earlier project decisions and the owner-approved competitive review supplied 7 November 2026. Competitor claims are reference material, not a new independent security audit or imported implementation.
