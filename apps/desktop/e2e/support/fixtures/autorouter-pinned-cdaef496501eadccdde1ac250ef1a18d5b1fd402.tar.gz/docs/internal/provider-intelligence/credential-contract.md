# the connection contract credential backend contract (Issue #17)

## Bounded source mapping

Reference: third-party project sources were inspected read-only during this work; no third-party code or dependency is included or copied here.

| Reference files | Responsibility / transition | AutoRouter adaptation |
|---|---|---|
| masked-key list view | Query configured providers, onboard a missing provider, check-all refresh | Read-only inventory, stable provider slot IDs and explicit capability flags; UI deferred to #18 |
| provider list rows | Group/search masked key rows; enable/disable/delete/test and bulk operations | Separate presence, verification and provider-level health; expose no unsupported success states |
| add-key dialog and form | Preselect provider, password input, provider-specific fields, multi-key import | Known-provider validation; no secret submissions or import because the host writer is unavailable |
| edit-key dialog | Empty replacement input, preserve absent values, mask stored key/proxy | Replacement explicitly unavailable; never return stored key fragments |
| `custom-provider-section.tsx` | Validate endpoint/provider/protocol and discover/probe | Unknown/custom integrations rejected; no arbitrary URLs, probes or activation |
| `quota-signals-section.tsx` | Render observed quota provenance | No credential entitlement or quota fabricated; outside #17 |
| `copy-key-dialog.tsx` | Reveal transition requires reauthentication, transient password state; desktop exception | No reveal/export contract; desktop bypass is not adopted |
| `server/src/routes/keys.ts` | Platform enum, bounded labels/model scopes/caps, validated CRUD/import, masked list, duplicate handling, protected export/reveal | Fixed known provider allowlist, secret-free output schema, explicit 400/403/404/501/503 errors |
| `server/src/lib/crypto.ts` | Separate AES-256-GCM key material, authenticated encryption, masked display | No AutoRouter vault, encryption key, decryption or raw-secret persistence |

## Host capability decision

Inspected installed Hermes source at `b200f5bc60e31588ba2cb60e288029c4a54ba5fa`:

- `hermes_cli/plugins.py`: `PluginContext.get_config` / `set_config` are scoped to this plugin's settings, not a provider credential API. Registrars and dashboard-auth provider registration do not authorize changing upstream credentials.
- `hermes_cli/plugins_capability_ctx.py`: capability probing and side questions, no provider credential CRUD or account enumeration facade.
- `hermes_cli/plugins_settings.py`: plugin settings persistence is not authority to rewrite global provider configuration or credentials.
- `providers/__init__.py:get_provider_profile`: the same profile interface used by existing AutoRouter discovery; only the fixed supported provider's declared environment slot is observed.

No sanctioned **plugin-facing provider credential** writer/replacer/deleter, account enumerator, non-billable authentication validator, or strong credential-reveal reauthentication contract was identified. This is a capability limitation, not permission to call host CLI/auth internals, rewrite dotenv/config, or invent a vault. Even an arbitrary object exposing a guessed `write_key` method would grant no authority. Live host credential stores were not opened or changed.

The read-only fallback explicitly permitted by Issue #17 is implemented. Genuine unavailable capabilities are add/replace/remove/enable/disable/test, account enumeration, export and reveal. Future support requires an explicitly sanctioned and permissioned host provider-credential API, plus a new scoped implementation. Since these operations never execute, there is no write/test request producer to rate-limit and no upstream 401/429/5xx to misrepresent. Simulated provider authentication failures are reported only as existing provider/model health observations, not new validation results.

## HTTP contract

These routes extend the existing Hermes-mounted router under `/api/plugins/autorouter`. Hermes owns dashboard authentication and per-request plugin consent, exactly as for Models/Providers. No new listener, frontend, browser storage, or auth bypass is introduced.

- `GET /connections`: read-only capability matrix and inventory of the existing NVIDIA/OpenRouter integrations.
- `GET /connections/{provider_id}`: one fixed provider's safe metadata. IDs are `nvidia` and `openrouter` (existing canonical runtime IDs); unknown/candidate/gateway/custom integrations return sanitized 404. This is not a second provider registry. PR #19's candidate registry is still open and is not imported/cherry-picked into this branch. Broader inventory integration awaits its merge and supported adapters.
- `POST /connections/{provider_id}/actions/{operation}`: explicit unavailable-operation contract for `add`, `replace`, `remove`, `enable`, `disable`, `test`. It never reads or parses a submitted body and never performs the operation. Consumers must not send secrets to this endpoint. Unsupported operations are not advertised as usable controls.

Errors have `{detail: {code, message}}` with fixed, secret-free messages:

| Condition | HTTP / code |
|---|---|
| Malformed provider ID or unknown operation | 400 / `invalid_provider` or `unsupported_operation` |
| Unsupported provider integration | 404 / `unsupported_provider` |
| Managed configuration | 403 / `managed_configuration` |
| Operator has not configured/authorized provider | 403 / `provider_not_authorized` |
| Configuration unreadable | 503 / `configuration_unavailable` |
| Supported provider but no sanctioned operation API | 501 / `host_capability_unavailable` |

No reveal, copy, plaintext export, delete or credential update endpoint exists outside this fixed denial contract. Presence metadata is passive: `enabled=null` / `activation_state=not_observable` does not enable or disable existing routing.

## Meaning of a connection

`hermes-env:nvidia` and `hermes-env:openrouter` identify **observable provider environment slots**, not keys/accounts. IDs never depend on key bytes, lengths or fingerprints, and remain stable if an operator changes a host credential elsewhere.

- `presence=configured`: the expected declared environment slot is nonempty. This is **not authentication verification**, model access, valid region/account scope or free allowance.
- `presence=not_observed`: that environment slot is empty/unset. Credentials may still exist in another host source; AutoRouter does not inspect those stores here.
- `presence=unknown`: host metadata/config/permission unavailable, provider not authorized, or unsupported observation. Previous presence is never silently reused as fresh.
- `masked_credential`: a constant eight-bullet placeholder for observed presence; never a slice of the key, not even its last characters or original length.
- `verified=false`, `verification=unverified`, `last_tested_at=null`: no credential validation is performed.
- `credential_count=null`, `account_count=null`, `account_scope=not_observable`, `region_scope=unknown`, `model_scope=null`: no invented multi-account/duplicate/region/model-scope semantics. Multiple env names do not imply multiple keys. Unobservable keyless auth is not claimed.
- `authorized`: provider appears in readable existing operator settings. Duplicate configured IDs do not duplicate rows. Unknown configured IDs are not reflected or activated.
- `health=provider_auth_failure_observed`: existing default-scope provider/model health has an auth failure flag. It is not bound to the current credential, and never means a newly tested key is invalid. No stored error text, labels, model identifiers or raw credential data are copied into this API.

SQLite is read-only and optional. Missing/corrupt/partial state yields `local_state=unavailable` with unknown observations, while host presence inventory remains usable. No schema changes or credential writes occur. No model-list or inference call is used as a key test. Existing verified free-only routing remains unchanged.

## Verification and limitations

Tests use fake host profiles/environment values, real temporary SQLite files, and the existing FastAPI test harness. They cover supported presence reads, host absence/permission/failure, managed/operator denials, malformed provider/account submissions without body reflection, replacement/multi-key denial, duplicates, keyless/region/model-scope unknowns, stale-presence non-reuse, provider auth observations, absent/corrupt state, read-only database bytes, secret-free responses/logs, unchanged free-only selection, Models/Providers compatibility and simulated outer host auth/consent enforcement. The simulated outer gate is not an independently executed live Hermes authorization integration test.

No production setup, real credential validation, paid inference, host mutation or Issue #18 UI work is performed. Configure credentials using Hermes' own setup/auth tooling; do not submit keys to AutoRouter.

### Actual test results

With `/tmp/autorouter-metadata-venv/bin/python`:

- `-m pytest -q -rs`: **203 passed, 0 failed, 9 skipped**, one third-party Starlette/httpx deprecation warning.
- `-m pytest -q -rs tests/test_connections.py tests/test_dashboard_api.py tests/test_dashboard_state_reader.py`: **96 passed, 0 failed, 0 skipped**, same dependency warning.

The nine unexecuted integration tests are acceptance gates at `tests/integration/test_acceptance_gates.py:127,139,163,173` (unavailable `hermes_cli.plugins`), constructor matrix at `tests/integration/test_constructor_matrix.py:64,73,82,91` and probe at `tests/integration/test_probe_agent.py:26` (unavailable `hermes_cli`/`run_agent` in the isolated test environment). These are not passing live-host integration results. Follow-on consumers include #14 and #18; neither interface is implemented here.
