# AutoRouter documentation

User documentation for AutoRouter, an experimental opt-in Hermes Agent plugin.

- [Installation](installation.md) — obtain, verify, install, enable, roll back
- [Quick start](quickstart.md) — guided first-run workflow
- [Configuration](configuration.md) — every setting, default, effect and reload rules
- [Providers](providers.md) — the six discovery integrations and what credentials they need
- [Model selection](model-selection.md) — eligibility, evidence, refusal
- [Dashboard](dashboard.md) — the five tabs and what each indicator means
- [Desktop integration](desktop-integration.md) — the native Hermes Desktop entry, enablement and limits
- [Safety and limitations](safety-and-limitations.md) — read before relying on it
- [Troubleshooting](troubleshooting.md) — reproducible diagnostics
- [Upgrading](upgrading.md) — backups, build verification, rollback


Issue tracker: https://github.com/diegorhoger/autorouter/issues
