# Providers

AutoRouter keeps six read-only discovery integrations and one controlled local mock provider. No integration performs inference, moves credentials between keys, or grants spending authority. Each integration needs only what its catalog GET sends — nothing is pooled or reused across providers.

| Provider | Credential required | What is discovered | Execution |
|----------|--------------------|---------------------|-----------|
| NVIDIA NIM | None for discovery (identifiers only) | Model identifiers only; no pricing, tools or context claims are asserted | Not verified for execution |
| OpenRouter | Not needed for catalog read; zero price components must be verified for free eligibility | Full metadata rows (id, context length, supported parameters, USD-component prices) | Catalog discovery only; free selection requires fresh verified zero-price evidence |
| Nous Portal | Hermes Nous OAuth sign-in (`read_credential_pool("nous")`) | Full public catalog when signed in | Transport not verified; entitlement stays UNKNOWN without host quota authority |
| Groq | `GROQ_API_KEY` | Model identifiers (fixed-origin, read-only) | Not verified; pricing unpublished → free tier not granted |
| Gemini | `GEMINI_API_KEY` or `GOOGLE_API_KEY` | Model identifiers (fixed-origin, read-only) | Not verified |
| Mistral | `MISTRAL_API_KEY` | Model identifiers (fixed-origin, read-only) | Not verified |

Catalog discovery for Groq, Gemini and Mistral does **not** publish price data — those adapters never grant free eligibility from catalog rows alone.

## Fixed-origin protection

Every integration pins its endpoint: no adapter consults, redirects to or rewrites a different origin based on any configuration, catalog row or environment value. Nous discovery additionally refuses to dispatch a credential unless the auth-store URL is exactly `https://inference-api.nousresearch.com/v1`. Any other scheme, origin, port, userinfo, path, query or fragment fails closed before any HTTP call is made. Redirects are never followed with credentials.

## Credential presence vs authority

The dashboard Providers tab reports **presence only**:

- `Credential present, validity unknown` — a process credential slot or Hermes Nous OAuth state was observed. The value is never displayed, logged, or stored by AutoRouter. Presence is not validity, not entitlement, not quota.
- `Credential not observed` — nothing observed.
- `Not authorized` — the provider is not in your `providers` allowlist.

No credential is persisted, logged, displayed or exported by AutoRouter. Authorizing a provider in the allowlist authorizes **discovery**, never inference or spending. Analytics markers are truncated unsalted SHA-256 hashes of opaque scope labels only — never usable as keys.

## Health and failures

Health evidence comes only from observed requests (yours, through the router or Hermes hooks), with bounded retry-aware circuits per model: failures open a circuit with cooldown, successes close it, and nothing is probed in the background. Three provider outages, model retirement (404/410 with explicit model-not-found semantics) or auth failures are reported per model; recovery after the cooldown becomes half-open automatically. Health never borrows another provider's or account's observations.

## Quota observations

When a sanctioned producer exists (today: none on a standard Hermes host), quota observations are recorded scope-bound per opaque connection reference; they never authorize spending and never aggregate into an allowance without source validation. Without such a producer, all allowance reads as `unknown` and no strict allowance policy can pass, which is fail-closed by construction.
