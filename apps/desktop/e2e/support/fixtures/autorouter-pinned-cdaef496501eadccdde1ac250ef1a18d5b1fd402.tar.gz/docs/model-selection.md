# Model selection and eligibility

Selection is a computation over your profile's own stored evidence. Nothing is selected that the current evidence does not admit.

## Eligibility contract (all required)

1. **Fresh verified zero-price cost evidence.** The `capabilities` record for exactly this provider/model must carry fresh, source-attributed proof that *all* supplied price components (prompt, completion, and any others) are USD 0.00. Legacy fresh field evidence is accepted; missing/expired/malformed evidence is a denial. Promotional credits, trials, and exhausted credit do **not** qualify as free.
2. **Context window ≥ `min_context`.** Or unknown context is a denial under this rule.
3. **Tool capability verified** when `requires_tools: true` (else tools may be `unknown`).
4. **Provider authorized** in `providers`. Authorized-but-unverified providers yield empty models, never guessed ones.
5. **Health not excluded:** retired/404/410, authentication failures, open circuit in cooldown or rate-limited by verified exhaustion-scoped evidence. Unobserved providers are allowed under unobserved-health tolerance only; observed auth/outage failures are not.
6. **Quota:** verified exhaustion in the scoped connection rejects that connection; `unknown` is never borrowed or escalated.
7. **Not in the model’s `model_exclude` list.**

Anything failing is shown with the *exact* rule and excluded. Before/after of catalog refresh: evidence replaces facts in-place under the metadata TTL (24 h); partial refreshes retain prior evidence with original provenance; explicit fresh negative evidence clears older free proof.

## Ranking

Among eligible models, the active `policy` ranks by bounded, attributed evidence:

- **General/Auto (auto)** — reliability first, then latency, context headroom
- **Coding** — tool support and context headroom weighted
- **Fastest** — observed latency
- **Reliability-first** — observed reliability with conservative prior (unobserved → prior, never fabricated confidence)

Equal scores tie-break by provider/model name. Semantic quality is never claimed — ranking uses observed, bounded evidence only.

`Router.preview()` exposes the full candidate breakdown (including rejected rows and the weighted contribution of each factor) without touching credentials, discovery state or history.

## Why a model might be excluded — read this first

- `Context is unknown or below the required minimum` — refresh metadata or lower `min_context`.
- `Fresh verified zero-price evidence is unavailable` — pricing unpublished/stale; zero price cannot be verified.
- `Provider is not configured for selection` — provider not in `providers`.
- `Provider/model is excluded` — your own `model_exclude`.
- Circuit open / retired / auth-failed — health evidence.
- Quota exhausted (scoped, verified) — that connection only; another scoped account is unaffected.

## What selection can and cannot promise

Can: never pick a paid model; never pick without fresh free evidence; best-effort schema-consistent ranking; exact refusal reasons; zero network calls on refusal.

Cannot: guarantee a provider accepts the request; guarantee entitlement to any free tier; prevent requests made outside AutoRouter; reserve allowance; replay or retry anything at runtime.

Direct Hermes requests bypass this gate entirely — AutoRouter filters models offered through its own tools/router (and the opt-in chat router), nothing else.

## Quota uncertainty, stated plainly

- `unknown` is the correct maximum claim for any unobserved allowance.
- A zero-token-price model with unknown account quota is eligible on price evidence alone — exhaustion is only recognized with verified, scoped evidence, never guessed.
- No cross-account borrowing, ever.
