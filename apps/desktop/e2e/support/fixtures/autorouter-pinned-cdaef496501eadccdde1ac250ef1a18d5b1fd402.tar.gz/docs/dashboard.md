# Dashboard

The five-tab management console lives at the AutoRouter tab (`/autorouter`) of the Hermes dashboard. It is served read-only from your profile's live plugin state; nothing is mocked, and no analytics are ever transmitted.

## Overview

Plugin state at a glance: routing enable/disable, live runtime activation ("interposed in this process" vs deferred to next plugin load), selected policy, minimum context and tool requirements, authorized providers, catalog size with breakdown by provider, recent selection activity (empty until the first selection runs), recent provider failures, and the last catalog refresh. Selection **zero** is shown honestly as such — not as "all clear".

## Providers

Six discovery integrations (NVIDIA, OpenRouter, Nous Portal, Groq, Gemini, Mistral) with:

- Presence-only credential labels (never shown, never validated inline)
- Discovered model counts and refresh times per provider
- Health: observed availability, failures by class (auth, retire, cooldown, outage)
- Quota: observed scoped quota or `unknown`

Clicking a provider inspects its models and refresh controls. Nothing on this tab reveals, tests or exports a credential.

## Models and the on/off toggle

A full, paginated catalog (typically hundreds of rows): search, provider filter, eligibility filter (all / eligible only / ineligible only), preference filter (all models / enabled only / disabled only), free-only toggle, and sorting (provider, context asc/desc, cost tier, health, eligibility) with stable tie-breaking. Every row shows cost tier, tools, context, health and eligibility *with the exact ineligibility rule* where excluded. Each row carries an **inclusion switch** — flipping it changes only your *preference*, never eligibility: a model with no verified zero-price evidence, missing capability or a failing health check stays ineligible — the switch only controls whether AutoRouter may consider it. Rows excluded by you show “disabled by you”; rows excluded by the active routing profile show “disabled by routing profile ‘<name>’”. **Enable page** / **Disable page** flip every model on the current page in one write. Disabling the last allowlisted model turns *every* model off (the explicit all-disabled state) — AutoRouter refuses to route until you enable at least one model; new catalog entries never sneak back in. A two-step **Reset to unrestricted** button is the only way back; it is never hidden inside an OFF toggle. **Refresh catalog** re-runs discovery and evidence refresh, then the view re-renders against the new state.

## Models

A full, paginated catalog (typically hundreds of rows): search, provider filter, eligibility filter (all / eligible only / ineligible only), free-only toggle, and sorting (provider, context asc/desc, cost tier, health, eligibility) with stable tie-breaking. Every row shows cost tier, tools, context, health and eligibility *with the exact ineligibility rule* where excluded. A **Preview / Why this model?** section shows the current policy's ranked outcome with a contribution breakdown per factor (reliability, speed, quality, cooldown, tools). **Refresh catalog** re-runs discovery and evidence refresh, then the view re-renders against the new state.

Empty state is explicit: `No models match your filters` with a **Clear filters** affordance — never a false success.

## Analytics

Recorded inference requests (the `requests` ledger) with range/filter/sort/pagination, request detail with attempt history, hourly success/error timeline with table values, latency percentiles and an *Operational scoring* panel — always labeled as small-sample/insufficient below n=10 and "Historical evidence only" for pre-deployment failure history. Missing values stay missing; zeros render as zeros; nothing is fabricated. Use `Range` to bound the view.

## Settings

Read-only plugin state (enabled/disabled), policy selection, free-only restriction display (locked on), cooldown and authorized providers (editable with validation), state-directory display. Saving reports exactly which keys were persisted, including partial saves. Paid authorization is shown as deprecated and inert.

## Visual states

Every tab degrades to explicit unavailable/empty rendering with retry controls when the store is absent, corrupt or unreachable — the core plugin is unaffected by the dashboard being down, and vice versa.
