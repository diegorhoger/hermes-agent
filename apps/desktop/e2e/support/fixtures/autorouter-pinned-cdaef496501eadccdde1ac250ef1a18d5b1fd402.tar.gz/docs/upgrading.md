# Upgrading and rollback

Isolated-profile default; substitute your own profile only at the `HERMES_HOME` line.

## Before any change

Back up the profile's `config.yaml`, `plugins/autorouter/` and `plugin-data/autorouter/autorouter.db` (a SQLite snapshot via `.backup`, or a plain file copy while the gateway is stopped).

```sh
export HERMES_HOME="${HERMES_HOME:-$HOME/.hermes-autorouter}"   # the install you want to upgrade
```

## Build the new package

```sh
export WORK="$(mktemp -d)"
git clone https://github.com/diegorhoger/autorouter.git "$WORK/autorouter"
cd "$WORK/autorouter"
git checkout main                          # or: git checkout <the newer revision>
sha=$(git rev-parse HEAD)
mkdir -p "$WORK/dist"
python3 tools/build_package.py --repo . --revision "$sha" --output "$WORK/dist"
artifact="$WORK/dist/autorouter-0.2.0-${sha:0:12}.zip"
(cd "$WORK/dist" && shasum -a 256 -c "$artifact.sha256")
```

Verify the archive's own hashes (see [installation.md](installation.md) step 3) — the manifest must reproduce `sha` and the ZIP must pass `shasum -a 256 -c "$artifact.sha256"`.

## Stop the runtime, then swap

```sh
stop the gateway / dashboard for that profile
# park the running plugin aside — this is the instant rollback path
mv "$HERMES_HOME/plugins/autorouter" "$WORK/autorouter.parked"
# sanity: verify what is being installed
python3 -m zipfile -e "$artifact" "$HERMES_HOME/plugins/"
```

Enabling, smoke-testing and reverting:

```sh
hermes plugins enable autorouter            # if the plugin stays desired
hermes dashboard                            # smoke-test the tabs (see Quick start)
```

## Roll back

```sh
mv "$WORK/autorouter.parked" "$HERMES_HOME/plugins/autorouter"
hermes plugins enable autorouter           # if it was enabled before
restart gateway/dashboard
```

Never downgrade the SQLite schema. `autorouter.db` migrates forward only; keep schema-compatible builds for rollback, and verify the new build against the seeded catalog before deleting the parked copy.

## After upgrading

1. Restart the gateway (or plugin-reload) — settings never hot-apply.
2. Open **Settings** — confirm policy, cooldown and providers persisted.
3. **Models** — refresh the catalog; confirm counts.
4. Send a smoke test through `/model`; confirm Analytics records it (or a fail-closed refusal).

`plugin-data/autorouter/autorouter.db` is preserved across upgrades and downgrades of the plugin directory.
