# Desktop integration

AutoRouter ships a **Hermes Desktop** half: `desktop/plugin.js` (issue #96). With it,
the management console appears as a native **AutoRouter** sidebar entry (zap icon) and
a full page at `#/autorouter` — Overview, Providers, Models, Analytics and Settings —
driven by the exact same gateway backend the web dashboard uses
(`/api/plugins/autorouter/*` through the plugin REST door). No second server, no
second state reader, no copied data; the web dashboard is untouched.

## How it loads

Hermes Desktop discovers a unified agent+desktop package's desktop half at
`<plugins root>/<name>/desktop/plugin.js` and copies it (with a `.hermes-package.json`
marker) into the app-level `desktop-plugins/` root on its own reconcile pass. The
bundle ships **opt-in** on the desktop side (installed-but-inert posture, matching the
agent half): after installation, flip **Desktop** on for AutoRouter in
Capabilities ▸ Plugins. The sidebar entry, `/autorouter` page and the
`AutoRouter: Open management console` palette command hot-load immediately; no restart
is required.

Runtime requirements: the desktop half must sit inside the AutoRouter package
(`plugins/autorouter/desktop/plugin.js`). A packaged AutoRouter release (built with
`tools/build_package.py`) carries it; an older install without `desktop/plugin.js`
keeps working exactly as before (agent tools + web dashboard only) until upgraded.

## What it shows

Same five tabs, same semantics, as the web dashboard:

- **Overview** — enabled state, virtual-route guard, policy, chat-routing state,
  provider/catalog counts, observed health, recent selection activity and failures,
  last catalog refresh. Honest empty and unavailable states.
- **Providers** — authorized providers with existence-only credential presence
  (never values), discovered/healthy/failing counts, last refresh, attention
  breakdown; the read-only credential inventory.
- **Models** — full paginated catalog (page size 50), server-side search,
  provider filter, eligibility filter and preference filter (all / enabled only /
  disabled only), refresh button; per-row cost tier, tools, context,
  eligibility rule and health; a per-row inclusion switch, **Enable page** /
  **Disable page** bulk actions, and explicit “disabled by you” /
  “blocked by routing profile” notes. The switch changes preference only —
  eligibility (verified free, tools, context, health) is computed independently and
  paid or unknown-cost models stay out of selection.
- **Analytics** — recorded Hermes API-hook telemetry with range selector
  (24h/7d/30d/90d/All), summary counters, per-provider and per-model breakdowns and
  paginated recent requests. Absence of telemetry renders an explicit empty state —
  nothing is fabricated.
- **Settings** — same per-key validated writes through Hermes' sanctioned
  plugin-settings API (`cooldown_seconds`, `min_context`, `policy`, `requires_tools`,
  `enable_chat_router`, `providers`, `model_include`, `model_exclude`), with
  client-side checks mirroring the server validator and partial-save reporting.
  `enabled`, `state_dir`, `paid_authorized` and `free_only` are read-only by design.

## Honest limits

- A desktop half loaded by the runtime door is plain ESM evaluated in the renderer;
  it can only import `@hermes/plugin-sdk` and `react*`. This file respects that
  allowlist and is linted/tested by `tests/test_desktop_plugin.py`.
- The window chrome, theme and density are the app's, not ours; no host files are
  patched or bundled, and uninstalling is a switch, not surgery.
- Live acceptance for this integration was demonstrated against the pinned Hermes
  source (`3b42157` / v0.23.1, build stamp `local`, 2026-11-10) in an isolated
  desktop instance with a scratch home. The production app on that machine needs the
  AutoRouter package upgraded to one carrying `desktop/plugin.js` before the toggle
  exists there — see issue #96 for the rollout path.

## Verifying the artifact

```sh
python -m pytest tests/test_desktop_plugin.py
python3 tools/build_package.py --repo . --revision HEAD --output ./dist  # deterministic ZIP, desktop/plugin.js included
```
