# Configuration

All settings live in the profile's `config.yaml` under `plugins.entries.autorouter.settings`. All are optional; the plugin is disabled until you set `enabled: true`.

```yaml
plugins:
  entries:
    autorouter:
      settings:
        enabled: true
        enable_chat_router: false
        policy: auto
        free_only: true
        providers: [nvidia, openrouter]
        min_context: 8192
        requires_tools: false
        model_include: []
        model_exclude: []
        cooldown_seconds: 60
        state_dir: ""
        scope_bound_quota: false
        paid_authorized: false   # deprecated, no effect
```

## Editing

Edit the file and restart (gateway or dashboard-plugin reload). Hermes applies plugin settings **one key at a time**; it offers no multi-key transaction. If a batch save fails partway, earlier keys stay persisted, later keys are not attempted, and the dashboard/plugin reports exactly which keys were saved. The dashboard UI surfaces that report; partial saves are labeled as such — never silent.

All settings are read at plugin load. Nothing is hot-applied to a running gateway; the Settings tab edits the persisted configuration only.

## Settings reference

| Key | Type | Default | Validation | Effect |
|-----|------|---------|------------|--------|
| `enabled` | bool | `false` | strict bool | Enables tools/observers and the plugin runtime. Fail-closed on any read error. |
| `enable_chat_router` | bool | `false` | strict bool | Routes `autorouter/auto-free` via the chat-router adapter; refuses before network when unroutable. Gateway restart required. |
| `policy` | str | `auto` | one of `auto`, `coding`, `fastest`, `reliable`, legacy `smartest`, `priority` | Ranking preference among eligible models. Never relaxes free-only eligibility. |
| `free_only` | bool | `true` | strict bool | Mandatory verified-free eligibility. `false` authorizes nothing in this release; paid inference stays disabled. |
| `providers` | list | `[nvidia, openrouter]` | lowercase `[a-z0-9][a-z0-9_-]{0,63}` ids, unknown ignored, ≤16 | Discovery allowlist. Empty array = no discovery. |
| `min_context` | int | `8192` | integer 2048–2000000 | Context-window floor for selection. |
| `requires_tools` | bool | `false` | strict bool | Require verified tool-calling support. |
| `model_include` | list | `[]` | `provider/model` keys, validated, deduplicated | Selection restricted to these. Empty = no extra restriction. |
| `model_exclude` | list | `[]` | same | Never select these; shown as exclusions in the dashboard. |
| `cooldown_seconds` | int | `60` | integer 1–86400 | Default retryable-failure cooldown (not a fixed delay). |
| `state_dir` | str | `""` | path string | Overrides the plugin state DB directory (default profile `plugin-data/autorouter/`). Rarely needed. |
| `scope_bound_quota` | bool | `false` | strict bool | Consume host-mediated quota observations when available; never invents any. |
| `paid_authorized` | bool | `false` | — | **Deprecated, no effect.** Zero spending authority. |

Invalid values are rejected at the API (HTTP 400 with the failing field) before anything is written; the Settings tab mirrors that validation inline and blocks invalid saves client-side.

## Defaults that fail closed

- `enabled: false`, `enable_chat_router: false`, `free_only: true`
- Absent/corrupt config → plugin disabled
- Missing provider credentials → empty catalog for that provider, no requests
- Missing cost evidence → model ineligible

## Environment notes

`state_dir` is the only setting that reads from the environment/filesystem path resolution. Neither is a credential: keys are read by Hermes itself or sent only for a single read-only catalog GET; they are never persisted, logged or exported by this plugin.
