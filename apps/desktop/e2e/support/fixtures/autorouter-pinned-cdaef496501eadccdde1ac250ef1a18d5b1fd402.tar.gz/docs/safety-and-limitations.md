# Safety and limitations

Read this before relying on AutoRouter in anything you care about.

## Scope of the plugin's authority

AutoRouter never:

- blocks, intercepts or rewrites a host request that was made outside its own interfaces
- replaces or substitutes a model without explicit selection through its tools or the opt-in chat router
- persists, logs, displays or exports any credential. Credentials are sent only for the single fixed-origin read-only catalog GET of their provider (environment bearer for Groq/Mistral, `x-goog-api-key` for Gemini, `Authorization` to `inference-api.nousresearch.com` for Nous Portal); the response never carries the credential back out. Analytics keep only a 12-character unsalted truncated SHA-256 hash of the opaque scope label, never a key.
- grants, reserves or borrows provider allowance of any kind
- executes inference itself — a selection result is a *recommendation*, not a request, and it is not applied until you act on it or Hermes applies it through the adapter path
- keeps or lets you keep inference post-commit safety at runtime — Hermes does not report committed state to plugins, so this class of guarantee belongs in Hermes, not here

## Known limits

- **Experimental.** The chat integration (`enable_chat_router`) and the managed virtual model are experimental and will change.
- **Not a universal billing boundary.** Zero observed price ≠ zero possible charge. Composition of offers, account terms, rate limits, your plan, and anything outside the observed catalog is out of scope.
- **Quota accuracy.** On a standard Hermes host there is no sanctioned per-attempt active-account quota interface, so account-scoped allowance reads as `unknown`. Strict allowance policies then refuse — correct but conservative.
- **Disabled virtual model.** When chat routing is disabled the adapter is not interposed, and stock Hermes may forward the literal `autorouter/auto-free` identifier to the configured endpoint as-is — AutoRouter cannot stop that request, because the plugin no longer runs in that path. The bundled guard only *detects* unsafe pins (at plugin load and on the deactivation save) and *warns*: a critical log line and a persistent red dashboard banner telling you to run `/model` or re-enable routing. It never silently substitutes another model, and it never rewrites your configuration. Treat the unresolved-pin warning as a hard stop — fix the pin before the next chat, or re-enable `enable_chat_router` and restart.
- **Evidence is point-in-time.** Catalog verification expires (24 h). Refresh does not recall verification for other contexts; direct/fresh negative evidence always wins over older positive proof.
- **Selection is advisory.** Selection is only as strong as the evidence snapshot; degraded reads surface as errors, never as guesses.

## Defensive behavior guarantees

- With routing disabled, nothing AutoRouter does can prevent Hermes from sending anything — fix the pin instead. With routing enabled, nothing AutoRouter selects can be paid. Requests made outside AutoRouter's selection path (including direct Hermes calls, your own prompt builders and other clients) cannot be stopped by this plugin at all.
- No silent model substitution — ever.
- No network calls in any refusal path.
- No raw credential ever crosses analytics, logs or the dashboard.
- Refusal always explains itself.

## Deployment hygiene

- Keep the plugin disabled until a provider is authorized.
- Use an isolated profile for evaluation; never evaluate on the production profile.
- Back up `config.yaml` and the state database before any change.
- After disabling chat routing or removing the plugin, check for a pinned `autorouter/auto-free` in your profile and fix it with `/model` immediately.
