"""Seed the isolated profile's AutoRouter store (profile-scoped persistent catalog)
with verified field evidence: catalog rows + capability rows carrying
``field_evidence``. The selector's ``evaluate_snapshot`` requires the capability
evidence, not just catalog rows, for an eligible free model.

Usage: python3 tools/seed_ar_store.py [store-dir]

Defaults to ``$HERMES_HOME/plugin-data/autorouter`` (or the path given as the
first argument). The seeded rows are test fixtures for the isolated proof only;
they never touch the production store.
"""
import importlib.util
import json
import sys
from pathlib import Path

# The autorouter package IS the repository root (single-package layout), and this
# script lives in tools/ (NOT inside the package). Register the package shell so
# the package's relative imports ("from . import router") resolve against this
# exact __init__.py, regardless of sys.path contents.
_REPO_ROOT = Path(__file__).resolve().parent.parent  # tools/ -> repo root (AutoRouter)
_SPEC = importlib.util.spec_from_file_location(
    "autorouter", _REPO_ROOT / "__init__.py"
)
_AUTOROUTER_PKG = importlib.util.module_from_spec(_SPEC)
_AUTOROUTER_PKG.__path__ = [str(_REPO_ROOT)]
_AUTOROUTER_PKG.__package__ = "autorouter"
_AUTOROUTER_PKG.__spec__.submodule_search_locations = [str(_AUTOROUTER_PKG.__path__[0])]
sys.modules["autorouter"] = _AUTOROUTER_PKG
_SPEC.loader.exec_module(_AUTOROUTER_PKG)
import autorouter.autorouter_core.storage.state as state_mod  # noqa: F401,E402
import autorouter.autorouter_core.routing.router as router_mod  # noqa: F401,E402


class _Shell:
    state = state_mod
    router = router_mod


_STATE = _Shell()


def seed(store_dir: Path) -> None:
    store_dir = Path(store_dir)
    store_dir.mkdir(parents=True, exist_ok=True)
    store = state_mod.StateStore(store_dir)
    rows = [
        # (provider, model, context_length, capabilities, cost_tier)
        ("mock-local", "free-chat", 131072, {"tools": "supported"}, "free"),
        ("mock-local", "paid-x", 131072, {"tools": "supported"}, "paid"),
        ("mock-local", "small", 4096, {"tools": "supported"}, "free"),
        ("mock-local", "unknown-tools", 32768, {"tools": "unknown"}, "free"),
        ("nvidia", "nvidia-free", 65536, {"tools": "supported"}, "free"),
    ]
    now = 1.0
    expiry = 9999999999.0
    for p, m, ctx, caps, tier in rows:
        store.upsert_catalog(p, m, context_length=ctx, capabilities=caps, cost_tier=tier)
        store.upsert_capability(
            p,
            m,
            json.dumps(
                {
                    "provider": p,
                    "model": m,
                    "field_evidence": {
                        "context_window": {"metadata_source": "provider",
                                           "retrieved_at": now, "expires_at": expiry},
                        "tools": {"metadata_source": "provider",
                                  "retrieved_at": now, "expires_at": expiry},
                        "cost_tier": {"metadata_source": "provider",
                                      "retrieved_at": now, "expires_at": expiry},
                    },
                    "context_window": ctx,
                    "tools": caps["tools"],
                    "cost_tier": tier,
                    "source": "provider",
                }
            ),
            metadata_source="provider",
            retrieved_at=now,
            expires_at=expiry,
        )
    print(f"[seed] store at {store_dir} seeded with {len(rows)} catalog rows")


def _default_store_dir() -> Path:
    import os

    hermes_home = os.environ.get("HERMES_HOME")
    if hermes_home:
        return Path(hermes_home) / "plugin-data" / "autorouter"
    return Path.home() / ".hermes" / "plugin-data" / "autorouter"


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else _default_store_dir()
    seed(target)
