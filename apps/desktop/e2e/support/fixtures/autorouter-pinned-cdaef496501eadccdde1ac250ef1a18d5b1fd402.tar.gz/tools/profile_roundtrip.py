"""Routing-profile proof against an isolated Hermes v0.23.1 install (issue #100).

Proves, with real Hermes processes and a controlled localhost provider:

  1. A user-created routing profile (providers=['mock-local'], include
     ['nvidia/free-chat']) stored in the isolated plugin-data SQLite
     store narrows resolution: autorouter/auto-free resolves to the included
     physical model; the virtual marker never reaches the wire.
  2. The active profile is recorded in the store (survives restart).
  3. A profile requiring tools with NO tools-eligible, verified-free model
     refuses BEFORE any provider network request (zero posts, non-zero exit).
  4. Editing the profile changes the routed model (edit → edit → chat).
  5. Deleting the active profile restores default (non-profile) routing.
  6. No byte of the isolated profile config is modified by any run.

Environment overrides mirror tools/real_chat_roundtrip.py. Production
Hermes (~/.hermes) is never read or written. Raw transcripts and
credentials are never stored or printed.
"""

from __future__ import annotations

import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(REPO_ROOT / "tests" / "fixtures"))
import controlled_mock_server as cms  # noqa: E402

VIRTUAL_MODEL = "autorouter/auto-free"
EXPECTED_PROVIDER = "nvidia"
EXPECTED_MODEL = "free-chat"
QUERY_TEMPLATE = "Respond with exactly: HELLO-AR-1 {corr}"


def _log(msg: str) -> None:
    print(f"[profile-roundtrip] {msg}", flush=True)


def _hermes_bin() -> str:
    env = os.environ.get("HERMES_BIN")
    if env:
        return env
    found = shutil.which("hermes")
    if found:
        return found
    fallback = Path.home() / ".local" / "bin" / "hermes"
    if fallback.is_file():
        return str(fallback)
    raise SystemExit("hermes launcher not found; set HERMES_BIN")


def _prepare_isolated_home(home: Path) -> None:
    if not home.exists():
        return
    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = home.with_name(home.name + f".bak-{stamp}")
    backup.mkdir(parents=False)
    home.rename(backup)
    home.mkdir(parents=True)
    for part in ("installs", "cache"):
        src = backup / part
        if src.is_dir():
            src.rename(home / part)
    _log(f"isolated home moved to {backup}")


def _install_isolated_profile(home: Path, port: int) -> None:
    home.mkdir(parents=True, exist_ok=True)
    base_url = f"http://127.0.0.1:{port}/v1"
    config = f"""# Isolated Hermes home for the routing-profile proof. Disposable.
model:
  default: free-chat
  provider: nvidia
  base_url: {base_url}
  api_mode: chat_completions
plugins:
  enabled: [autorouter]
  entries:
    autorouter:
      settings:
        enabled: true
        enable_chat_router: true
        providers: [nvidia]
custom_providers: []
"""
    (home / "config.yaml").write_text(config, encoding="utf-8")
    # Sentinel key for the isolated mock provider — never a real credential;
    # the only egress is 127.0.0.1:<mock-port>.
    (home / ".env").write_text("NVIDIA_API_KEY=sk-roundtrip-sentinel-not-a-real-key\n", encoding="utf-8")
    plugin_dst = home / "plugins" / "autorouter"
    plugin_dst.parent.mkdir(parents=True, exist_ok=True)
    if plugin_dst.exists():
        shutil.rmtree(plugin_dst)
    shutil.copytree(
        REPO_ROOT, plugin_dst,
        ignore=shutil.ignore_patterns(
            "__pycache__", ".git", ".pytest_cache", ".tmp", "*.pyc", "node_modules", ".venv", ".github", ".pytest_cache",
        ),
    )


def _seed_store(home: Path) -> None:
    """Seed a deterministic, verified-free catalog under the nvidia provider."""
    import importlib.util
    import json as _json

    import sys as _sys
    _sys.path.insert(0, str(REPO_ROOT))
    spec = importlib.util.spec_from_file_location("autorouter", REPO_ROOT / "__init__.py")
    pkg = importlib.util.module_from_spec(spec)
    pkg.__path__ = [str(REPO_ROOT)]
    pkg.__package__ = "autorouter"
    if pkg.__spec__ is not None:
        pkg.__spec__.submodule_search_locations = [str(REPO_ROOT)]
    _sys.modules["autorouter"] = pkg
    spec.loader.exec_module(pkg)
    import autorouter.autorouter_core.storage.state as state_mod

    store_dir = home / "plugin-data" / "autorouter"
    store_dir.mkdir(parents=True, exist_ok=True)
    store = state_mod.StateStore(store_dir)
    rows = [
        ("nvidia", "free-chat", 131072, {"tools": "supported"}, "free"),
        ("nvidia", "notools", 32768, {"tools": "unsupported"}, "free"),
        ("nvidia", "paid-x", 131072, {"tools": "supported"}, "paid"),
    ]
    now = 1.0
    expiry = 9999999999.0
    for p, m, ctx, caps, tier in rows:
        store.upsert_catalog(p, m, context_length=ctx, capabilities=caps, cost_tier=tier)
        store.upsert_capability(
            p, m,
            _json.dumps({
                "provider": p, "model": m,
                "field_evidence": {
                    "context_window": {"metadata_source": "provider", "retrieved_at": now, "expires_at": expiry},
                    "tools": {"metadata_source": "provider", "retrieved_at": now, "expires_at": expiry},
                    "cost_tier": {"metadata_source": "provider", "retrieved_at": now, "expires_at": expiry},
                },
                "context_window": ctx,
                "tools": caps["tools"],
                "cost_tier": tier,
                "source": "provider",
            }),
            metadata_source="provider",
            retrieved_at=now,
            expires_at=expiry,
        )
    print(f"[seed] catalog seeded with {len(rows)} rows")


def _load_plugin_modules():
    """Register the repo as the ``autorouter`` package (same as seed_ar_store)."""
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        "autorouter", REPO_ROOT / "__init__.py"
    )
    pkg = importlib.util.module_from_spec(spec)
    pkg.__path__ = [str(REPO_ROOT)]
    pkg.__package__ = "autorouter"
    if pkg.__spec__ is not None:
        pkg.__spec__.submodule_search_locations = [str(REPO_ROOT)]
    sys.modules["autorouter"] = pkg
    spec.loader.exec_module(pkg)
    return pkg


def _run_oneshot(home: Path, hermes_bin: str, query: str) -> subprocess.CompletedProcess:
    env = {
        "PATH": os.environ.get("PATH", ""),
        "HOME": os.environ.get("HOME", str(Path.home())),
        "HERMES_HOME": str(home),
        "HERMES_INFERENCE_PROVIDER": "",
        "PYTHONIOENCODING": "utf-8",
        "TERM": "dumb",
    }
    return subprocess.run(
        [hermes_bin, "chat", "--model", VIRTUAL_MODEL, "--oneshot", "--query", query],
        capture_output=True, text=True, timeout=180, env=env,
    )


def _provider_posts(baseline: int) -> list[dict]:
    return [r for r in cms.recorded_requests()[baseline:] if r.get("path", "").startswith("/v1/")]


def home_db(state_dir: Path) -> Path:
    return state_dir / "autorouter.db"


def _outbound_model(posts: list[dict]) -> str | None:
    return next(
        (r.get("parsed", {}).get("model") for r in posts if r.get("parsed", {}).get("model")),
        None,
    )


def _config_digest(home: Path) -> str:
    import hashlib

    return hashlib.sha256((home / "config.yaml").read_bytes()).hexdigest()


def main() -> int:
    scratch = Path(os.environ.get("AR_TEST_HOME") or (Path.home() / ".hermes-ar-test"))
    if os.environ.get("AR_TEST_FRESH", "1") == "1":
        _prepare_isolated_home(scratch)
    scratch.mkdir(parents=True, exist_ok=True)
    _log(f"isolated home: {scratch}")

    server = cms.ThreadingHTTPServer(("127.0.0.1", 0), cms.Handler)
    port = server.server_address[1]
    threading.Thread(target=server.serve_forever, daemon=True).start()
    _log(f"controlled mock provider on 127.0.0.1:{port}")

    _install_isolated_profile(scratch, port)
    hermes_bin = _hermes_bin()
    _seed_store(scratch)

    _load_plugin_modules()
    from autorouter.autorouter_core.storage.state import RoutingProfileStore

    state_dir = scratch / "plugin-data" / "autorouter"
    store = RoutingProfileStore(state_dir)

    # 1) Create + activate a profile that narrows to free-chat only.
    profile = store.create({
        "name": "Roundtrip only-free-chat",
        "ranking_policy": "reliable",
        "providers": ["nvidia"],
        "model_include": ["nvidia/free-chat"],
        "min_context": 8192,
        "requires_tools": False,
    })
    store.set_active(profile["id"])
    digest_before = _config_digest(scratch)

    # 2) Positive run: virtual selection must resolve through the profile.
    corr = "ARREQ-" + secrets.token_hex(6)
    query = QUERY_TEMPLATE.format(corr=corr)
    baseline = len(cms.recorded_requests())
    result = _run_oneshot(scratch, hermes_bin, query)
    raw_out = (result.stdout or "") + (result.stderr or "")
    posts = _provider_posts(baseline)
    model = _outbound_model(posts)
    ok_positive = (
        result.returncode == 0
        and posts
        and model == "free-chat"
        and f"mocked by controlled provider {corr}" in raw_out
        and _config_digest(scratch) == digest_before
    )
    _log(f"positive run: exit={result.returncode} outbound_model={model} posts={len(posts)}")

    # 3) Refusal profile: tools required, nothing tools-eligible -> zero posts.
    refusing = store.create({
        "name": "Roundtrip tools-required",
        "ranking_policy": "reliable",
        "providers": ["nvidia"],
        "model_include": ["nvidia/notools"],
        "min_context": 8192,
        "requires_tools": True,
    })
    store.set_active(refusing["id"])
    baseline_neg = len(cms.recorded_requests())
    neg_corr = "ARREQ-" + secrets.token_hex(6)
    neg_result = _run_oneshot(scratch, hermes_bin, QUERY_TEMPLATE.format(corr=neg_corr))
    neg_posts = _provider_posts(baseline_neg)
    ok_refusal = neg_result.returncode != 0 and not neg_posts
    _log(f"refusal run: exit={neg_result.returncode} posts={len(neg_posts)}")

    # 4) Edit the profile: narrow to small (4096 ctx < required 32768) -> still refuses;
    #    then widen to free-chat -> routes again.
    store.update(refusing["id"], {"min_context": 32768, "model_include": ["nvidia/free-chat"], "requires_tools": True})
    baseline_mid = len(cms.recorded_requests())
    mid_corr = "ARREQ-" + secrets.token_hex(6)
    mid_result = _run_oneshot(scratch, hermes_bin, QUERY_TEMPLATE.format(corr=mid_corr))
    mid_posts = _provider_posts(baseline_mid)
    mid_model = _outbound_model(mid_posts)
    ok_edit = (
        mid_result.returncode == 0
        and mid_posts
        and mid_model == "free-chat"
    )
    _log(f"edited run: exit={mid_result.returncode} outbound_model={mid_model} posts={len(mid_posts)}")

    # 5) Delete the active profile -> fallback to default routing still works.
    store.delete(refusing["id"])
    baseline_def = len(cms.recorded_requests())
    def_corr = "ARREQ-" + secrets.token_hex(6)
    def_result = _run_oneshot(scratch, hermes_bin, QUERY_TEMPLATE.format(corr=def_corr))
    def_posts = _provider_posts(baseline_def)
    def_model = _outbound_model(def_posts)
    ok_default = def_result.returncode == 0 and def_posts and def_model == "free-chat"
    _log(f"post-delete run: exit={def_result.returncode} outbound_model={def_model} posts={len(def_posts)}")

    # 5b) Fail-closed: a configured default that is corrupt or missing must
    #     refuse BEFORE any provider network call — never silently fall back
    #     to the global policy.
    import sqlite3 as _sqlite3
    with _sqlite3.connect(str(store_path_db := home_db(state_dir))) as db:
        db.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('active_routing_profile', 'rp_gone')")
    baseline_stale = len(cms.recorded_requests())
    stale_corr = "ARREQ-" + secrets.token_hex(6)
    stale_result = _run_oneshot(scratch, hermes_bin, QUERY_TEMPLATE.format(corr=stale_corr))
    stale_posts = _provider_posts(baseline_stale)
    ok_corrupt_fail_closed = stale_result.returncode != 0 and not stale_posts
    _log(f"corrupt-default run: exit={stale_result.returncode} posts={len(stale_posts)} refusal_expected=True")

    # Restore the healthy default (as the desktop UI's activation button does)
    # and prove the track returns: the very next session must route again.
    with _sqlite3.connect(str(home_db(state_dir))) as db:
        db.execute("INSERT OR REPLACE INTO meta(key, value) VALUES('active_routing_profile', ?)", (profile["id"],))
    baseline_rec = len(cms.recorded_requests())
    rec_corr = "ARREQ-" + secrets.token_hex(6)
    rec_result = _run_oneshot(scratch, hermes_bin, QUERY_TEMPLATE.format(corr=rec_corr))
    rec_posts = _provider_posts(baseline_rec)
    rec_model = _outbound_model(rec_posts)
    ok_recovery = rec_result.returncode == 0 and rec_posts and rec_model == "free-chat"
    _log(f"recovery run: exit={rec_result.returncode} outbound_model={rec_model} posts={len(rec_posts)}")

    # 6) Restart persistence: re-activate the first profile and read via a
    #    fresh store instance (as a gateway restart would).
    fresh_store = RoutingProfileStore(state_dir)
    stored = fresh_store.list()
    fresh_store.set_active(profile["id"])
    reopened = RoutingProfileStore(state_dir)
    active_id = reopened.active_id()
    ok_persist = (
        any(p["name"] == "Roundtrip only-free-chat" for p in stored)
        and active_id == profile["id"]
    )
    _log(f"persistence: profiles={len(stored)} active={active_id}")

    server.shutdown()

    evidence = {
        "hermes_version": _hermes_bin(),
        "isolated_home": str(scratch),
        "assertions": {
            "profile_narrows_route": ok_positive,
            "outbound_never_virtual_marker": ok_positive,
            "refusal_zero_posts": ok_refusal,
            "edit_changes_route": ok_edit,
            "delete_restores_default": ok_default,
            "corrupt_default_fails_closed": ok_corrupt_fail_closed,
            "recovery_after_repair": ok_recovery,
            "restart_persistence": ok_persist,
            "config_unchanged": _config_digest(scratch) == digest_before,
        },
        "counts": {
            "provider_posts_positive": len(posts),
            "provider_posts_refusal": len(neg_posts),
            "provider_posts_edit": len(mid_posts),
            "provider_posts_default": len(def_posts),
        },
    }
    evidence_path = scratch / "profile-evidence.json"
    evidence_path.write_text(json.dumps(evidence, indent=2))
    _log(f"evidence: {evidence_path}")
    ok = all(evidence["assertions"].values())
    _log("PROOF PASSED" if ok else "PROOF FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
