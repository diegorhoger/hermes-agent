#!/usr/bin/env python3
"""Constructor-matrix diagnostic runner (one-off tool).

Override the two machine-specific locations with environment variables:

  AUTOROUTER_V02_SCRATCH   scratch checkout of the autorouter v0.2 worktree
                           (default: <repo>/.scratch/autorouter-v02)
  HERMES_AGENT_VENV        interpreter with the Hermes agent and pytest
                           available (default: ~/.hermes/hermes-agent/venv/bin/python)
"""
import json
import os
import signal
import subprocess
import time
from pathlib import Path

_DEFAULT_SCRATCH = Path(__file__).resolve().parent.parent / ".scratch" / "autorouter-v02"
ROOT = Path(os.environ.get("AUTOROUTER_V02_SCRATCH", _DEFAULT_SCRATCH))
PYTHON = os.environ.get(
    "HERMES_AGENT_VENV",
    str(Path.home() / ".hermes" / "hermes-agent" / "venv" / "bin" / "python"),
)
OUTPUT = ROOT / "diagnostics"
OUTPUT.mkdir(parents=True, exist_ok=True)
RESULT_FILE = OUTPUT / "constructor_matrix.json"
CASES = ["A", "B", "C", "D"]
TIMEOUT_SECONDS = 15


def persist(results):
    temporary = RESULT_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(results, indent=2), encoding="utf-8")
    os.replace(temporary, RESULT_FILE)


def run_case(case):
    log_path = OUTPUT / f"constructor_{case}.log"
    if not Path(PYTHON).is_file():
        return {"status": "PYTHON_NOT_FOUND", "exit_code": None,
                "duration_seconds": 0, "log": str(log_path)}
    command = [PYTHON, "-m", "pytest", "-s", "-vv", f"tests/test_constructor_matrix.py::test_case_{case.lower()}"]
    env = os.environ.copy()
    env.pop("PYTHONPATH", None)
    env["PYTHONUNBUFFERED"] = "1"
    started = time.monotonic()
    with log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=TIMEOUT_SECONDS)
            status = "PASS" if code == 0 else "ERROR"
        except subprocess.TimeoutExpired:
            status = "TIMEOUT"
            code = None
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
    return {"status": status, "exit_code": code, "duration_seconds": round(time.monotonic() - started, 2), "log": str(log_path)}


def main():
    results = {case: {"status": "NOT_RUN"} for case in CASES}
    persist(results)
    for case in CASES:
        print(f"Running case {case}", flush=True)
        try:
            results[case] = run_case(case)
        except Exception as exc:
            results[case] = {"status": "ERROR", "exception": repr(exc)}
        persist(results)
        print(case, results[case]["status"], flush=True)
    print(RESULT_FILE.read_text(encoding="utf-8"), flush=True)


if __name__ == "__main__":
    main()
