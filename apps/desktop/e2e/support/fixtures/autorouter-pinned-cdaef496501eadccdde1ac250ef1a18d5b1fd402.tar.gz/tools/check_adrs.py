#!/usr/bin/env python3
"""Check ADR index, status metadata and local Markdown targets; no network access."""
import json
from pathlib import Path
import re
import sys


def check(root):
    directory=root/'docs/internal/adr'
    data=json.loads((directory/'index.json').read_text())
    records=data['records']
    errors=[]
    if data.get('schema_version')!=1 or not records:
        errors.append('missing schema version/records')
    if [r['id'] for r in records]!=[f'ADR-{n:04}' for n in range(1,len(records)+1)]:
        errors.append('ADR IDs must be unique and sequential')
    indexed=[]
    readme=(directory/'README.md').read_text()
    for record in records:
        file=directory/record['path']
        if file.parent.resolve()!=directory.resolve() or not file.is_file():
            errors.append('unsafe or missing indexed ADR')
            continue
        indexed.append(file.name)
        text=file.read_text()
        if (not text.startswith('---\nstatus: '+record['status']+'\n')
                or '\nimplementation: ' not in text or '\nauthority: ' not in text
                or f"# {record['id']}: {record['title']}" not in text
                or f"[{record['id']}]({record['path']})" not in readme):
            errors.append(record['id']+': index/metadata mismatch')
    if sorted(indexed)!=sorted(p.name for p in directory.glob('[0-9][0-9][0-9][0-9]-*.md')):
        errors.append('unindexed or duplicate ADR file')
    for file in [*directory.glob('*.md'),root/'docs/internal/glossary.md']:
        text=file.read_text()
        if re.search(r'\[[^\]\n]*\[[^\]\n]*\]\([^\n)]*\)[^\]\n]*\]\(',text):
            errors.append(file.name+': nested Markdown link')
        for target in re.findall(r'\]\(([^)]+)\)',text):
            if target.startswith(('https://','http://','#')):
                continue
            path=(file.parent/target.split('#',1)[0]).resolve()
            if not path.is_relative_to(root.resolve()) or not path.is_file():
                errors.append(file.name+': missing/unsafe local link')
    return errors


if __name__=='__main__':
    root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
    try:
        errors=check(root)
    except (OSError,ValueError,KeyError,TypeError):
        errors=['unreadable or malformed ADR register']
    print(json.dumps({'status':'FAIL' if errors else 'PASS','errors':errors},indent=2))
    raise SystemExit(bool(errors))
