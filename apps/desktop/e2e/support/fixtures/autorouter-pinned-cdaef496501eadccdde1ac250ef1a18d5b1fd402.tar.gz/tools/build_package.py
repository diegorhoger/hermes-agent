#!/usr/bin/env python3
"""Build a deterministic, credential-free directory-plugin ZIP from a Git commit."""

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import zipfile

REQUIRED = {
    "plugin.yaml",
    "__init__.py",
    "LICENSE",
    "NOTICE",
    "README.md",
    "RELEASE.md",
    "CHANGELOG.md",
    "SECURITY.md",
    "dashboard/manifest.json",
    "dashboard/dist/index.js",
    "dashboard/dist/style.css",
    "desktop/plugin.js",
}
MANIFEST = "PACKAGE-MANIFEST.json"
MAX_BYTES = 16 * 1024 * 1024
SECRET = re.compile(
    rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|(?:gh[pousr]_|sk-|nvapi-|hf_)[A-Za-z0-9_-]{24,}|AIza[A-Za-z0-9_-]{30,}"
)


def selected(name):
    p = PurePosixPath(name)
    if p.is_absolute() or any(
        x in ("..", ".git", "state", "__pycache__") or x.startswith(".env")
        for x in p.parts
    ):
        return False
    return (
        name in REQUIRED
        or p.parts[0] == "autorouter_core"
        and p.suffix == ".py"
        or p.parts[0] == "dashboard"
        and p.suffix in (".py", ".js", ".css", ".json", ".md")
        or p.parts[0] == "data"
        and p.suffix in (".json", ".csv")
        or p.parts[0] == "docs"
        # Package ships only user-facing docs (docs/<name>.md). Internal
        # engineering records under docs/internal/ are repository history,
        # not distribution content, and are never packaged.
        and len(p.parts) == 2
        and p.suffix == ".md"
    )


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encode(files, source_sha, tree_sha):
    """Pure payload builder; ignores environment, working-tree files and mtimes."""
    if not REQUIRED <= files.keys() or not all(selected(n) for n in files):
        raise ValueError("required files missing or forbidden payload path")
    if any(not re.fullmatch(r"[0-9a-f]{40}", s) for s in (source_sha, tree_sha)):
        raise ValueError("exact source and tree SHA required")
    if sum(map(len, files.values())) > MAX_BYTES:
        raise ValueError("payload size limit exceeded")
    if any(SECRET.search(data) for data in files.values()):
        raise ValueError("secret-pattern scan rejected payload; values redacted")
    if b"MIT License" not in files["LICENSE"]:
        raise ValueError("MIT license record missing")
    version = re.search(
        rb"(?m)^version: ([0-9]+\.[0-9]+\.[0-9]+)$", files["plugin.yaml"]
    )
    if not version or not re.search(rb"(?m)^name: autorouter$", files["plugin.yaml"]):
        raise ValueError("plugin identity/version invalid")
    manifest = dict(
        schema_version=1,
        source_sha=source_sha,
        tree_sha=tree_sha,
        plugin_id="autorouter",
        version=version[1].decode(),
        license="MIT",
        notice="NOTICE",
        dependency_scope="no third-party dependencies vendored; host supplies Python and dashboard dependencies",
        secret_scan="bounded known-token/private-key patterns; not proof no unknown secret exists",
        files=[
            dict(path=n, bytes=len(files[n]), sha256=digest(files[n]))
            for n in sorted(files)
        ],
    )
    payload = dict(files)
    payload[MANIFEST] = (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode()
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_STORED) as archive:
        for name in sorted(payload):
            info = zipfile.ZipInfo(
                "autorouter/" + name, date_time=(1980, 1, 1, 0, 0, 0)
            )
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, payload[name])
    return out.getvalue()


def verify(data, *, source_sha=None, tree_sha=None):
    """Validate inventory before any extraction; archives are not signatures."""
    if len(data) > MAX_BYTES * 2:
        raise ValueError("archive size limit exceeded")
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or len(names) > 2000:
            raise ValueError("duplicate or excessive archive entries")
        if sum(i.file_size for i in archive.infolist()) > MAX_BYTES:
            raise ValueError("expanded size limit exceeded")
        for info in archive.infolist():
            p = PurePosixPath(info.filename)
            if (
                p.as_posix() != info.filename
                or p.is_absolute()
                or p.parts[0] != "autorouter"
                or len(p.parts) < 2
                or ".." in p.parts
                or "\\" in info.filename
                or info.external_attr >> 16 != 0o100644
            ):
                raise ValueError("unsafe archive entry")
        manifest = json.loads(archive.read("autorouter/" + MANIFEST))
        if (source_sha is not None and manifest.get("source_sha") != source_sha) or (
            tree_sha is not None and manifest.get("tree_sha") != tree_sha
        ):
            raise ValueError("archive does not match expected source/tree identity")
        files = {
            n.removeprefix("autorouter/"): archive.read(n)
            for n in names
            if n != "autorouter/" + MANIFEST
        }
        # Rebuilding verifies paths, hashes, scan, metadata and exact member set.
        rebuilt = encode(files, manifest["source_sha"], manifest["tree_sha"])
        if rebuilt != data:
            raise ValueError("archive inventory or canonical encoding mismatch")
        return manifest


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args])


def build(repo, revision):
    sha = git(repo, "rev-parse", "--verify", revision + "^{commit}").decode().strip()
    tree = git(repo, "rev-parse", sha + "^{tree}").decode().strip()
    files = {}
    for entry in git(repo, "ls-tree", "-r", "-z", sha).split(b"\0"):
        if not entry:
            continue
        metadata, raw_name = entry.split(b"\t", 1)
        mode, kind, blob = metadata.split()
        name = raw_name.decode("utf-8")
        if selected(name):
            if mode not in (b"100644", b"100755") or kind != b"blob":
                raise ValueError("symlink/submodule in package payload")
            files[name] = git(repo, "cat-file", "blob", blob.decode())
    return encode(files, sha, tree)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--repo", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--revision", default="HEAD")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = build(args.repo, args.revision)
    manifest = verify(data)
    args.output.mkdir(parents=True, exist_ok=True)
    filename = (
        "autorouter-" + manifest["version"] + "-" + manifest["source_sha"][:12] + ".zip"
    )
    target = args.output / filename
    if target.exists() and target.read_bytes() != data:
        raise ValueError("refusing to replace a different artifact")
    target.write_bytes(data)
    target.with_suffix(".zip.sha256").write_text(digest(data) + "  " + filename + "\n")
    print(
        json.dumps(
            dict(
                artifact=str(target),
                sha256=digest(data),
                source_sha=manifest["source_sha"],
                tree_sha=manifest["tree_sha"],
                files=len(manifest["files"]),
            )
        )
    )


if __name__ == "__main__":
    main()
