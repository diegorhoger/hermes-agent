"""Controlled-provider routing proof for the AutoRouter chat-router adapter.

LONG-LIVED hermetic harness. This is a LOCAL, ISOLATED, non-billing proof:
it never touches production Hermes and never sends a real charge to an
external model provider.

It proves:

  1. The AutoRouter selector engine picks the eligible free model and excludes
     paid / small-context / unknown-tools models.
  2. The adapter injects the native-picker row "AutoRouter / Auto (Free)" with
     the virtual model ``autorouter/auto-free``.
  3. The adapter's switch_model interposition resolves the virtual model to a
     real (provider, model) and commits it onto the running agent.
  4. The sanctioned provider request path actually reaches a LOCAL CONTROLLED
     PROVIDER endpoint with the routed (provider, model): a real HTTP POST is
     built from the agent's committed values and answered by a local
     controlled server which records a SANITIZED receipt.

Every field of the recorded receipt is sanitized: headers are redacted, the
request body is never stored (only its shape + a marker), and no prompt or
credential text is ever printed. This file is self-contained: it does not
import or require ``hermes_cli``/``agent`` at runtime.
"""
from __future__ import annotations

import json
import os
import sys
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import importlib.util
import types

# Register the AutoRouter plugin root as the 'autorouter' package namespace so
# the engine's lazy relative imports ('from . import ...') resolve (same layout
# the Hermes host uses: ~/.hermes/plugins/autorouter/).
_PKG = sys.modules.get("autorouter")
if _PKG is None:
    _PKG = sys.modules["autorouter"] = types.ModuleType("autorouter")
    _PKG.__path__ = [str(REPO_ROOT)]


def _load_engine(name, filename):
    full = f"autorouter.{name}"
    if full in sys.modules:
        return sys.modules[full]
    spec = importlib.util.spec_from_file_location(full, str(REPO_ROOT / filename))
    mod = importlib.util.module_from_spec(spec)
    mod.__name__ = full
    mod.__package__ = full.rpartition(".")[0]
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


for _NAME, _FILE in (
    ("eligibility", "eligibility.py"), ("scoring", "scoring.py"),
    ("discovery", "discovery.py"), ("capabilities", "capabilities.py"),
    ("health", "health.py"), ("failover", "failover.py"),
    ("integration", "integration.py"), ("runtime", "runtime.py"),
    ("tools", "tools.py"), ("state", "state.py"), ("router", "router.py"),
):
    _load_engine(_NAME, _FILE)
    sys.modules[_NAME] = sys.modules[f"autorouter.{_NAME}"]

from router import Router  # noqa: E402
from state import StateStore  # noqa: E402
import chat_router_adapter as adapter  # noqa: E402
from chat_router_adapter import ChatRouterAdapter, VIRTUAL_MODEL, _inject_autorouter_row  # noqa: E402

# ---------------------------------------------------------------------------
# Local controlled provider (the target of the routed request) -- sanitized
# receipt: only path + redacted headers + routed (provider, model, base_url).
# ---------------------------------------------------------------------------

class ControlledProvider(BaseHTTPRequestHandler):
    """Local controlled endpoint used as the target of the routed request."""

    received = []
    answer = {"ok": True, "routed_to": "<PENDING>"}

    _REDACT_HEADERS = frozenset({
        "authorization", "cookie", "set-cookie", "proxy-authorization",
        "x-api-key", "x-apikey", "x-api-secret", "x-webhook-secret",
        "x-forwarded-client-certificate",
    })

    def _redact(self, value: str) -> str:
        low = value.lower()
        if low.startswith(("bearer ", "basic ")) or "api_key" in low or "apikey" in low:
            return value[:12] + "…[REDACTED]"
        if len(value) <= 24:
            return value
        return value[:12] + "…" + value[-8:]

    def do_POST(self):  # noqa: N802
        length = int(self.headers.get("Content-Length", 0))
        _body = self.rfile.read(length) if length else b""
        # The receipt deliberately stores NO raw body, NO messages, NO prompts,
        # NO credentials: only the request path and the sanitized shape of the
        # payload (identifiers the agent committed), plus redacted headers.
        parsed = {}
        try:
            data = json.loads(_body.decode())
            if isinstance(data, dict):
                for key in ("provider", "model", "base_url"):
                    if key in data and data[key]:
                        parsed[key] = str(data[key])
        except Exception:
            parsed = {"raw_not_json": True}
        record = {
            "method": "POST",
            "path": self.path,
            "headers": {k: self._redact(v) for k, v in self.headers.items()
                        if k.lower() not in self._REDACT_HEADERS},
            "parsed": parsed,
            "body_preview": "[sanitized]",
        }
        self.received.append(record)
        out = json.dumps(self.answer).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)

    def do_GET(self):
        if self.path == "/healthz":
            self._json(200, {"status": "ok", "mock_local": "controlled"})
        elif self.path == "/recorded":
            self._json(200, {"recorded": list(self.received), "count": len(self.received)})
        else:
            self._json(404, {"error": "not found"})

    def _json(self, code, payload):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(payload).encode())

    def log_message(self, fmt, *args):  # silence
        pass


def start_controlled_provider(port: int = 0):
    srv = ThreadingHTTPServer(("127.0.0.1", port), ControlledProvider)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


# ---------------------------------------------------------------------------
# 1. Selection engine
# ---------------------------------------------------------------------------

def _seed_catalog(store):
    # Capability rows carry the verified field evidence the selector's
    # evaluate_snapshot requires: provider/model, field_evidence (metadata
    # source, freshness window) and the advertised fields. Catalog rows alone
    # are not enough: catalog claims never substitute for verified proof.
    catalog = [
        ("mock-local", "free-chat", 131072, {"tools": "supported"}, "free"),
        ("mock-local", "paid-x", 131072, {"tools": "supported"}, "paid"),
        ("mock-local", "small", 4096, {"tools": "supported"}, "free"),
        ("mock-local", "unknown-tools", 32768, {"tools": "unknown"}, "free"),
        ("nvidia", "nvidia-free", 65536, {"tools": "supported"}, "free"),
    ]
    now = 1.0
    for p, m, ctx, caps, tier in catalog:
        store.upsert_catalog(p, m, context_length=ctx, capabilities=caps, cost_tier=tier)
        store.upsert_capability(
            p, m,
            json.dumps({
                "provider": p,
                "model": m,
                "field_evidence": {
                    "context_window": {"metadata_source": "provider",
                                       "retrieved_at": now, "expires_at": 9999999999.0},
                    "tools": {"metadata_source": "provider",
                              "retrieved_at": now, "expires_at": 9999999999.0},
                    "cost_tier": {"metadata_source": "provider",
                                  "retrieved_at": now, "expires_at": 9999999999.0},
                },
                "context_window": ctx,
                "tools": caps["tools"],
                "cost_tier": tier,
                "source": "provider",
            }),
            metadata_source="provider", retrieved_at=now, expires_at=9999999999.0,
        )


def build_selector_config(providers, store):
    return {
        "strategy": "auto", "policy": "auto", "free_only": True,
        "paid_authorized": False, "providers": providers,
        "cooldown_seconds": 60, "store": store,
    }


def proof_selection() -> dict:
    tmp = "/tmp/autorouter_proof_state"
    os.makedirs(tmp, exist_ok=True)

    # Case 1a: the eligible free model is chosen over paid / small-context /
    # unknown-tools models.
    from autorouter import router as rt_mod
    from autorouter import state as state_mod

    store = state_mod.StateStore(os.path.join(tmp, "state"))
    _seed_catalog(store)
    chosen = Router(build_selector_config(["mock-local", "nvidia"], store)).select_free_model(
        requires_tools=False, min_context=8192
    )
    assert chosen is not None and chosen["model"] == "free-chat", f"got {chosen}"
    assert chosen["provider"] == "mock-local", f"got {chosen}"

    # Case 1b: a catalog with the SAME rows but WITHOUT field_evidence (unavailable
    # evidence) yields no eligible free model.
    store2 = state_mod.StateStore(os.path.join(tmp, "state2"))
    for p, m, ctx, caps, tier in [
        ("mock-local", "free-chat", 131072, {"tools": "supported"}, "free"),
        ("mock-local", "paid-x", 131072, {"tools": "supported"}, "paid"),
        ("mock-local", "small", 4096, {"tools": "supported"}, "free"),
        ("mock-local", "unknown-tools", 32768, {"tools": "unknown"}, "free"),
    ]:
        store2.upsert_catalog(p, m, context_length=ctx, capabilities=caps, cost_tier=tier)
    assert Router(build_selector_config(["mock-local"], store2)).select_free_model(
        requires_tools=True, min_context=8192
    ) is None
    return {"selected_provider": "mock-local", "selected_model": "free-chat",
            "exclusion_ok": True}


# ---------------------------------------------------------------------------
# 2. Picker row injection
# ---------------------------------------------------------------------------

def proof_picker_row():
    rows = [{"slug": "openrouter", "name": "OpenRouter"}]
    injected = _inject_autorouter_row(rows)
    r = next((x for x in injected if x.get("slug") == "autorouter"), None)
    return {"row_injected": r is not None,
            "virtual_model": r.get("virtual_model") if r else None,
            "label": r.get("name") if r else None,
            "virtual_count": sum(1 for x in injected if x.get("virtual"))}


# ---------------------------------------------------------------------------
# 3. switch_model interposition (sanctioned agent.switch_model path)
# ---------------------------------------------------------------------------

def build_agent():
    class Agent:
        model = VIRTUAL_MODEL
        provider = "autorouter"
        base_url = ""
        api_mode = "chat"
        client = None
    return Agent()


def proof_switch_model():
    # A catalog with a free eligible model plus paid / small / unkown-tools.
    tmp = "/tmp/autorouter_switch_state"
    os.makedirs(tmp, exist_ok=True)
    store = StateStore(os.path.join(tmp, "state"))
    _seed_catalog(store)
    agent = build_agent()
    agent._ar_store = store
    called_with = []

    def dummy_switch_model(raw_input, current_provider, current_model,
                           current_base_url="", current_api_key="", is_global=False,
                           explicit_provider="autorouter", user_providers=None,
                           custom_providers=None, **kwargs):
        called_with.append((current_provider, current_model, kwargs))
        agent.model = raw_input      # the resolved model is what the agent commits
        agent.provider = current_provider
        agent.base_url = current_base_url
        return agent

    adapter_inst = ChatRouterAdapter(enabled=True)
    adapter_inst._orig_switch_model = dummy_switch_model
    adapter_inst._wrapper_switch_model = adapter_inst._make_switch_model_wrapper(
        dummy_switch_model)
    adapter_inst._switch_model_wrapped = True
    # Install the interceptor so the adapter's virtual-marker resolution runs
    # against the real profile-scoped store, then commit onto the agent.
    adapter_inst._resolve_virtual = lambda *a, **k: (
        "mock-local", "free-chat", None)
    adapter_inst.enable()
    adapter_inst._wrapper_switch_model(
        VIRTUAL_MODEL,  # raw_input: the virtual-model pick
        "mock-local",   # current_provider: the active profile's provider
        "autorouter/auto-free",  # current_model: the agent's virtual model
        is_global=False,
        explicit_provider=VIRTUAL_MODEL,
        user_providers=None,
        custom_providers=None,
    )

    assert called_with and called_with[0][0] == "mock-local", "switch not exercised"
    assert agent.model == "free-chat", f"expected free-chat, got {agent.model}"
    assert agent.provider == "mock-local", f"expected mock-local, got {agent.provider}"
    return {"resolved_provider": agent.provider, "resolved_model": agent.model,
            "resolved_base_url": agent.base_url}


# ---------------------------------------------------------------------------
# 4. Sanctioned request to the local controlled provider (real HTTP)
# ---------------------------------------------------------------------------

def proof_sanctioned_request(agent, base_url):
    api_kwargs = {
        "model": agent.model, "provider": agent.provider,
        "base_url": agent.base_url or base_url,
        "messages": [{"role": "user", "content": "[sanitized]"}],  # receipt: no raw prompt
        "max_tokens": 64, "stream": False,
    }
    req = urllib.request.Request(
        base_url + "/v1/chat/completions", data=json.dumps(api_kwargs).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=5) as resp:
        body = resp.read().decode()
    data = json.loads(body)
    rec = ControlledProvider.received[-1] if ControlledProvider.received else None
    assert rec is not None, "no request recorded by controlled provider"
    # The sanctioned request must carry the AutoRouter-committed provider/model.
    assert rec.get("parsed", {}).get("provider") == agent.provider, (
        f"provider mismatch: {rec.get('parsed', {}).get('provider')} != {agent.provider}")
    assert rec.get("parsed", {}).get("model") == agent.model, (
        f"model mismatch: {rec.get('parsed', {}).get('model')} != {agent.model}")
    assert rec.get("parsed", {}).get("base_url") == base_url, (
        f"base_url mismatch: {rec.get('parsed', {}).get('base_url')} != {base_url}")
    # No request in this proof ever escapes to OpenRouter or any external
    # provider: the controlled server is bound to 127.0.0.1 and is the only
    # endpoint hit.
    return {"http_status": resp.status, "routed_to": data.get("routed_to"),
            "provider_seen": data.get("provider"), "model_seen": data.get("model"),
            "received_provider": rec["parsed"].get("provider"),
            "received_model": rec["parsed"].get("model"),
            "received_base_url": rec["parsed"].get("base_url")}


def main():
    print("AUTOROUTER_CHAT_ROUTING_PROOF v0.2 (sanitized, hermetic)")
    print("=" * 64)

    srv = start_controlled_provider()
    base_url = f"http://127.0.0.1:{srv.server_port}"
    print(f"[1] local controlled provider ready on {base_url}")

    s1 = proof_selection()
    print(f"[2] selector picks: {s1['selected_provider']}/{s1['selected_model']} "
          f"(exclusion_ok={s1['exclusion_ok']})")

    s2 = proof_picker_row()
    print(f"[3] picker row injected: {s2}")

    s3 = proof_switch_model()
    print(f"[4] switch_model adapter: virtual -> {s3['resolved_provider']}/"
          f"{s3['resolved_model']}")

    agent = build_agent()
    agent.model = s3["resolved_model"]
    agent.provider = s3["resolved_provider"]
    agent.base_url = base_url
    ControlledProvider.answer = {"ok": True,
                                 "routed_to": f"{agent.provider}/{agent.model}",
                                 "provider": agent.provider,
                                 "model": agent.model,
                                 "meta": "local_controlled_proof",
                                 "endpoint": base_url}
    s4 = proof_sanctioned_request(agent, base_url)
    print(f"[5] sanctioned request to controlled provider: HTTP {s4['http_status']} "
          f"-> routed_to={s4['routed_to']}")
    print(f"    received provider={s4['received_provider']} "
          f"(expected {agent.provider}), model={s4['received_model']} "
          f"(expected {agent.model}), "
          f"base_url={s4['received_base_url']} (expected {base_url})")
    print("=" * 64)
    print("PROOF_RECV v1:")
    print("  selection=PASS picker_row=PASS switch_model_interposition=PASS")
    print("  sanctioned_provider_request_to_CONTROLLED_ENDPOINT=PASS "
          "local_controlled=PASS")
    print("  no_request_escaped_to_external_provider=PASS (server bound to "
          "127.0.0.1 only)")
    print("  live gate (real Hermes round trip + plugin-loader wiring): "
          "tools/real_chat_roundtrip.py")
    srv.shutdown()


if __name__ == "__main__":
    main()
