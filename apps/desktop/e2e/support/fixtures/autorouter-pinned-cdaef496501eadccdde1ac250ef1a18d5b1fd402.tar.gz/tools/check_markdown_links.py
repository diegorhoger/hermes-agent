"""Validate relative markdown links in user-facing docs; every target must exist."""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DOCS = [p for p in ROOT.rglob("*.md") if ".git" not in p.parts and "internal" not in p.parts
        and "node_modules" not in p.parts]

LINK = re.compile(r"\]\(([^)#\s]+)(#[^)]*)?\)")
bad = []
for path in DOCS:
    text = path.read_text(encoding="utf-8")
    for match in LINK.finditer(text):
        target = match.group(1)
        if target.startswith(("http://", "https://", "mailto:")):
            continue
        resolved = (path.parent / target).resolve()
        if not resolved.exists():
            bad.append(f"{path.relative_to(ROOT)} -> {target}")
print("docs checked:", len(DOCS))
if bad:
    print("BROKEN LINKS:")
    print("\n".join(bad))
    sys.exit(1)
print("all relative links resolve")
