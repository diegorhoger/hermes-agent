#!/usr/bin/env python3
"""Validate frozen launch claims; coverage is never confused with release readiness."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / 'docs/internal/product/claims-v1.json'


def inside(root, raw):
    if not isinstance(raw, str) or not raw or Path(raw).is_absolute():
        return None
    path = (root / raw).resolve()
    return path if path.is_relative_to(root.resolve()) and path.is_file() else None


def validate(data, root=ROOT, website=None):
    """Return bounded authored diagnostics and unique executable proof node IDs."""
    errors, proofs = [], []
    claims = data.get('claims', [])
    if (data.get('schema_version') != 1 or data.get('claim_count') != 24
            or not isinstance(claims, list) or len(claims) != 24):
        return ['contract must contain schema version 1 and exactly 24 claims'], []
    if not re.fullmatch(r'[0-9a-f]{40}', str(data.get('website_revision', ''))):
        errors.append('website revision must be an exact commit')
    if [c.get('id') if isinstance(c, dict) else None for c in claims] != [f'AC-C{i:02}' for i in range(1,25)]:
        errors.append('claim IDs must be unique, ordered AC-C01 through AC-C24')
    for index, claim in enumerate(claims, 1):
        label = f'claim {index}'
        if not isinstance(claim, dict):
            errors.append(label + ': record required')
            continue
        for key in ('title','interface','environment','evidence_level','limitation','release_gate'):
            if not isinstance(claim.get(key), str) or not claim[key].strip():
                errors.append(label + ': missing ' + key)
        if claim.get('state') not in ('supported','partial','blocked'):
            errors.append(label + ': invalid state')
        if not re.fullmatch(r'https://github.com/diegorhoger/autorouter/issues/\d+', str(claim.get('owner_issue',''))):
            errors.append(label + ': invalid owner issue link')
        paths = claim.get('implementation')
        if not isinstance(paths, list) or not paths or any(inside(root,p) is None for p in paths):
            errors.append(label + ': missing/unsafe implementation path')
        source = claim.get('website')
        if not isinstance(source, dict):
            errors.append(label + ': missing website quotation')
        else:
            quote = source.get('quote')
            if not isinstance(quote,str) or not quote.strip() or not re.fullmatch(r'[0-9a-f]{64}',str(source.get('source_sha256',''))):
                errors.append(label + ': invalid quotation/source digest')
            if website is not None:
                path = inside(website, source.get('path'))
                if path is None:
                    errors.append(label + ': missing/unsafe website source')
                elif (not isinstance(quote,str) or quote not in path.read_text()
                        or hashlib.sha256(path.read_bytes()).hexdigest()!=source.get('source_sha256')):
                    errors.append(label + ': website quotation/source drift')
        refs = claim.get('proofs')
        if not isinstance(refs,list) or not refs:
            errors.append(label + ': no executable proof')
            continue
        for ref in refs:
            if not isinstance(ref,str) or re.fullmatch(r'tests/[A-Za-z0-9_/]+\.py::test_[A-Za-z0-9_]+', ref) is None:
                errors.append(label + ': invalid proof reference')
                continue
            filename, function = ref.split('::')
            path = inside(root, filename)
            if path is None or not any(isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name==function for node in ast.parse(path.read_text()).body):
                errors.append(label + ': proof test function missing')
            elif ref not in proofs:
                proofs.append(ref)
    return errors, proofs


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--website-checkout',type=Path)
    parser.add_argument('--run-proofs',action='store_true')
    parser.add_argument('--release',action='store_true')
    args=parser.parse_args(argv)
    try:
        data=json.loads(CONTRACT.read_text())
        errors,proofs=validate(data, website=args.website_checkout)
    except (OSError,ValueError,TypeError,SyntaxError):
        print('FAIL: malformed or unreadable claim contract/source')
        return 1
    if args.website_checkout is not None:
        try:
            head=subprocess.check_output(['git','-C',str(args.website_checkout),'rev-parse','HEAD'],text=True,stderr=subprocess.DEVNULL).strip()
            if head!=data['website_revision']:errors.append('website checkout is not the frozen revision')
        except (OSError,subprocess.CalledProcessError):errors.append('website revision cannot be verified')
    if errors:
        print(json.dumps({'mapping':'FAIL','errors':errors},indent=2))
        return 1
    proof_status='NOT_EXECUTED'
    proof_counts=None
    if args.run_proofs:
        # pytest exits zero when required isolated-host proofs skip; that is not acceptance.
        with tempfile.TemporaryDirectory(prefix='claim-proofs-') as temporary:
            report=Path(temporary)/'proofs.xml'
            environment=dict(os.environ)
            environment.pop('PYTEST_ADDOPTS',None)
            command=[sys.executable,'-B','-m','pytest','-o','addopts=','--import-mode=importlib','-q',*proofs]
            collected=subprocess.run([*command,'--collect-only'],cwd=ROOT,env=environment,capture_output=True,text=True)
            expected={line.strip() for line in collected.stdout.splitlines() if line.startswith('tests/') and '::' in line}
            covered={node.split('[',1)[0] for node in expected}
            collection_complete=collected.returncode==0 and bool(expected) and set(proofs)<=covered
            run=subprocess.run([*command,'--junitxml='+str(report)],cwd=ROOT,env=environment)
            try:
                cases=list(ET.parse(report).getroot().iter('testcase'))
                proof_counts=dict(total=len(cases),failed=sum(c.find('failure') is not None for c in cases),
                    errors=sum(c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases))
                reported={c.get('classname','').replace('.','/')+'.py::'+c.get('name','') for c in cases}
                proof_counts['missing']=len(expected-reported)
                proof_counts['passed']=proof_counts['total']-sum(proof_counts[k] for k in ('failed','errors','skipped'))
                proof_status=('PASS' if run.returncode==0 and collection_complete and not proof_counts['missing'] and cases and not any(proof_counts[k] for k in ('failed','errors','skipped'))
                    else 'INCOMPLETE' if run.returncode==0 and proof_counts['skipped'] else 'FAIL')
            except (OSError,ET.ParseError):
                proof_status='FAIL'
    blockers=[c['id'] for c in data['claims'] if c['state']!='supported']
    release_ready=(not blockers and data.get('independent_release_acceptance') is True
                   and args.website_checkout is not None and proof_status=='PASS')
    print(json.dumps({'mapping':'PASS','claims':len(data['claims']),'unique_proof_functions':len(proofs),
        'proof_execution':proof_status,'proof_tests':proof_counts,'website_source':'VERIFIED' if args.website_checkout else 'NOT_VERIFIED',
        'release':'READY' if release_ready else 'BLOCKED','incomplete_claims':blockers,
        'independent_release_acceptance':data.get('independent_release_acceptance') is True},indent=2))
    if args.run_proofs and proof_status!='PASS':return 1
    return 2 if args.release and not release_ready else 0


if __name__=='__main__':
    raise SystemExit(main())
