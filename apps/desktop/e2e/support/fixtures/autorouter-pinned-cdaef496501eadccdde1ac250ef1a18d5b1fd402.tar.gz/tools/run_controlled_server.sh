#!/bin/bash
# Start the controlled localhost mock provider (port 19997).
# Usage: tools/run_controlled_server.sh start|stop|status
# Env: CONTROLLED_SERVER_LOG (default: <profile>/logs/controlled_mock_server.log)
#      HERMES_HOME is not required; the server binds 127.0.0.1:19997.
set -euo pipefail
ACTION=${1:-status}
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
LOGDIR=${CONTROLLED_SERVER_LOGDIR:-"$ROOT/.local"}
PIDFILE="$LOGDIR/controlled_mock_server.pid"
LOG="$LOGDIR/controlled_mock_server.log"
mkdir -p "$LOGDIR"
case "$ACTION" in
  start)
    if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
      echo "mock server already running (pid $(cat "$PIDFILE"))"
      exit 0
    fi
    nohup python3 "$ROOT/tests/controlled_mock_server.py" >"$LOG" 2>&1 &
    echo $! > "$PIDFILE"
    sleep 1
    echo "started (pid $(cat "$PIDFILE")); log: $LOG"
    ;;
  stop)
    if [ -f "$PIDFILE" ]; then
      kill "$(cat "$PIDFILE")" 2>/dev/null && echo "stopped" || echo "already stopped"
      rm -f "$PIDFILE"
    else
      echo "not running (no pidfile)"
    fi
    ;;
  status)
    if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
      echo "running (pid $(cat "$PIDFILE"))"
    else
      echo "not running"
    fi
    ;;
  *) echo "unknown action"; exit 1;;
esac
