"""Interactive-picker acceptance for the AutoRouter chat-router adapter.

Verifies, against a real (isolated) Hermes v0.23.1 code base, the exact
functions the interactive ``/model`` picker uses at runtime — not a stub and
not a re-implementation:

  1. The plugin loader (``hermes_cli.plugins.discover_plugins()``) loads the
     isolated profile's autorouter plugin, whose register() wiring enables
     the chat-router adapter (``enable_chat_router: true`` in the isolated
     profile config).
  2. The interactive picker's provider-listing call —
     ``hermes_cli.model_switch_providers.list_picker_providers(...)``, the
     symbol ``gateway/slash_commands_model.py`` imports at call time —
     returns an AutoRouter row carrying the virtual model
     ``autorouter/auto-free`` ("Auto (Free)").
  3. Choosing it through the core model-switch pipeline —
     ``hermes_cli.model_switch.switch_model(...)``, the same call the gateway
     makes after a picker selection — resolves to ``mock-local/free-chat``.
  4. Ordinary (non-virtual) selections pass through the patched pipeline
     unchanged.
  5. The profile store recorded the routing decision (policy + chosen
     provider/model + eligible candidate count), which is what the dashboard
     Overview renders as "Current selection".
  6. The adapter's fail-closed behavior is preserved: with the catalog moved
     aside, resolution returns (None, None, error) before any provider call.

Usage:
    python3 tools/verify_interactive.py

The tool creates (and moves aside) the isolated profile the same way the
round-trip harness does. Nothing here modifies production Hermes
(``~/.hermes``) or reads credentials of any kind. Raw prompts/transcripts and
secrets are never stored in the evidence file.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import importlib.util
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

os.environ.setdefault("HERMES_DISABLE_LAZY_INSTALLS", "1")


def _log(msg: str) -> None:
    print(f"[verify] {msg}", flush=True)


def _import_from_path(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def _setup_isolated_home() -> Path:
    rtr = _import_from_path(REPO_ROOT / "tools" / "real_chat_roundtrip.py", "real_chat_roundtrip_tool")

    home = Path(os.environ.get("AR_TEST_HOME") or (Path.home() / ".hermes-ar-test"))
    rtr._prepare_isolated_home(home)
    home.mkdir(parents=True, exist_ok=True)
    base_url = "http://127.0.0.1:9/v1"  # placeholder: never contacted in this proof
    config = f"""# Isolated Hermes home for the AutoRouter interactive acceptance.
model:
  default: free-chat
  provider: mock-local
  base_url: {base_url}
  api_mode: chat_completions
providers:
  mock-local:
    base_url: {base_url}
plugins:
  enabled: [autorouter]
  entries:
    autorouter:
      settings:
        enabled: false
        enable_chat_router: true
        providers: [mock-local]
        policy: auto
        min_context: 8192
        requires_tools: false
custom_providers: []
"""
    (home / "config.yaml").write_text(config, encoding="utf-8")
    plugin_dst = home / "plugins" / "autorouter"
    plugin_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(REPO_ROOT, plugin_dst,
                    ignore=shutil.ignore_patterns("__pycache__", ".git", ".pytest_cache", "*.pyc",
                                                  "node_modules", ".venv", ".github"))
    seed_mod = _import_from_path(REPO_ROOT / "tools" / "seed_ar_store.py", "seed_ar_store_tool")
    seed_mod.seed(home / "plugin-data" / "autorouter")
    return home


def main() -> int:
    home = _setup_isolated_home()
    evidence_path = Path(os.environ.get("AR_PICKER_EVIDENCE", str(home / "interactive_evidence.json")))
    os.environ["HERMES_HOME"] = str(home)
    hermes_agent = os.environ.get("HERMES_AGENT", str(Path.home() / ".hermes" / "hermes-agent"))
    if hermes_agent not in sys.path:
        sys.path.insert(0, hermes_agent)

    import hermes_cli.model_switch as _ms  # noqa: E402
    import hermes_cli.model_switch_providers as _msp  # noqa: E402

    # 1) Plugin loader loads the isolated profile's plugin; register() wires the adapter.
    from hermes_cli.plugins import discover_plugins  # noqa: E402

    discover_plugins()
    loaded = None
    try:
        from hermes_plugins import autorouter as _apkg

        loaded = bool(getattr(_apkg, "__name__", ""))
    except Exception:
        pass
    adapter_patched = getattr(_ms.switch_model, "_ar_patched", False)
    _log(f"plugin loaded: {bool(loaded)}; switch_model patched by adapter: {adapter_patched}")

    out = {"hermes_agent": hermes_agent, "isolated_home": str(home), "checks": {}}
    failures: list[str] = []

    def check(name: str, ok: bool, detail):
        out["checks"][name] = {"ok": bool(ok), "detail": detail}
        _log(f"{name}: {'PASS' if ok else 'FAIL'} — {detail}")
        if not ok:
            failures.append(name)

    # 2) The interactive picker's listing call returns the AutoRouter row.
    rows = _msp.list_picker_providers(
        current_provider="mock-local", current_base_url="http://127.0.0.1:9/v1",
        user_providers={"mock-local": {"base_url": "http://127.0.0.1:9/v1"}},
        custom_providers=[], max_models=50, current_model="free-chat",
        include_moa=False, excluded_providers=None, non_blocking_catalogs=True,
        probe_custom_providers=False, probe_current_custom_provider=False,
    )
    row = next((r for r in rows if r.get("slug") == "autorouter"), None)
    check("interactive_picker_row_present", row is not None,
          {"slug": row.get("slug"), "virtual_model": row.get("virtual_model")} if row else None)
    if row is not None:
        out["picker_row"] = {
            "slug": row.get("slug"),
            "models": row.get("models"),
            "virtual_model": row.get("virtual_model"),
            "virtual": row.get("virtual"),
        }

    # 3) Choosing the virtual model through the real switch pipeline resolves it.
    result = _ms.switch_model(
        raw_input="autorouter/auto-free", current_provider="mock-local",
        current_model="free-chat", is_global=False, explicit_provider="",
        user_providers={"mock-local": {"base_url": "http://127.0.0.1:9/v1"}},
        custom_providers=[])
    check("switch_pipeline_resolves_virtual", getattr(result, "success", False) is True
          and getattr(result, "new_model", None) == "free-chat"
          and getattr(result, "target_provider", None) == "mock-local",
          {"success": getattr(result, "success", None),
           "new_model": getattr(result, "new_model", None),
           "target_provider": getattr(result, "target_provider", None),
           "error_message": getattr(result, "error_message", None)})
    out["switch_result"] = {
        "success": bool(getattr(result, "success", False)),
        "new_model": getattr(result, "new_model", None),
        "target_provider": getattr(result, "target_provider", None),
    }

    # 4) Ordinary switching passes through unchanged.
    ordinary = _ms.switch_model(
        raw_input="free-chat", current_provider="mock-local",
        current_model="free-chat", is_global=False, explicit_provider="",
        user_providers={"mock-local": {"base_url": "http://127.0.0.1:9/v1"}},
        custom_providers=[])
    check("ordinary_switch_passthrough", getattr(ordinary, "success", False) is True
          and getattr(ordinary, "new_model", None) == "free-chat"
          and getattr(ordinary, "target_provider", None) == "mock-local",
          {"success": getattr(ordinary, "success", None),
           "new_model": getattr(ordinary, "new_model", None),
           "target_provider": getattr(ordinary, "target_provider", None),
           "error_message": getattr(ordinary, "error_message", None)})

    # 5) The profile store recorded the decision the dashboard displays.
    out["decision_row"] = None
    try:
        pkg = next((m for name, m in sys.modules.items()
                    if name.startswith("hermes_plugins.autorouter") and hasattr(m, "state")), None)
        if pkg is None:
            pkg = next((m for name, m in sys.modules.items()
                        if name.startswith("hermes_plugins.autorouter")), None)
        store = pkg.state.StateStore(home / "plugin-data" / "autorouter")
        with store._connect() as db:
            rows = db.execute(
                "SELECT provider, model, policy, reason, candidates FROM decisions"
                " ORDER BY ts DESC LIMIT 1").fetchall()
        if rows:
            r = rows[0]
            out["decision_row"] = {"provider": r[0], "model": r[1], "policy": r[2],
                                   "reason": r[3], "candidates": r[4]}
        check("decision_recorded_for_overview", bool(rows), out["decision_row"])
    except Exception as exc:
        check("decision_recorded_for_overview", False, f"{type(exc).__name__}")

    # 6) Fail-closed: catalog aside -> resolution refused before network.
    store_dir = home / "plugin-data" / "autorouter"
    backup = home / "plugin-data" / "autorouter.aside"
    if backup.exists():
        shutil.rmtree(backup)
    shutil.move(str(store_dir), str(backup))
    try:
        result2 = _ms.switch_model(
            raw_input="autorouter/auto-free", current_provider="mock-local",
            current_model="free-chat", is_global=False, explicit_provider="",
            user_providers={"mock-local": {"base_url": "http://127.0.0.1:9/v1"}},
            custom_providers=[])
        fail_closed_ok = getattr(result2, "success", True) is False and getattr(result2, "new_model", "") == ""
        out["fail_closed"] = {"success": bool(getattr(result2, "success", None)),
                              "error_message": getattr(result2, "error_message", None)}
        check("fail_closed_before_network", fail_closed_ok, out["fail_closed"])
    finally:
        shutil.move(str(backup), str(store_dir))

    evidence_path.write_text(json.dumps(out, indent=2, default=str), encoding="utf-8")
    _log(f"evidence: {evidence_path}")

    if failures:
        _log(f"FAILED: {failures}")
        return 1
    _log("INTERACTIVE PROOF PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
