# Contributing to AutoRouter

## Setup

```sh
git clone https://github.com/diegorhoger/autorouter.git
cd autorouter
python3 --version    # 3.11+ with the Hermes-provided deps (fastapi, pydantic, PyYAML; no vendored deps)
python3 -m pytest -q
```

## Testing requirements

A change is acceptable when:

- The full unit suite passes (`python3 -m pytest -q`).
- Browser-harness changes keep `python3 -m pytest tests/browser` green.
- Host-integration-observable changes pass `python3 -m pytest tests/integration` with `AUTOROUTER_TEST_PACKAGE`, `AUTOROUTER_PREVIOUS_PACKAGE` and `AUTOROUTER_HERMES_SOURCE` set (see [installation.md](docs/installation.md)).
- Regression tests exist for the bug being fixed, at the layer it was found (unit, browser, or integration).

## Coding standards

- Match existing style, type-annotation density and module layout.
- Prefer refusal-first behavior: unknown or missing evidence must end in a denial, not a default.
- Never fabricate: no invented prices, balances, latency, quality scores or provider entitlements.
- Never weaken a test silently or convert an unverified assumption into a claim — document uncertainty, not certainty.
- No inference or paid calls in tests or tooling.

## Pull requests

- Describe what broke, the minimal fix, and the verification run.
- Keep PRs bounded — one coherent concern each.
- Never commit generated artifacts (ZIP packages, databases, caches).
- Documentation ships with code; unreachable-but-merged docs must survive.

## Compatibility rules

- Manifest `manifest_version: 2`, plugin id `autorouter` — breaking changes require coordinated migration.
- SQLite schema migrations are additive or forward-only; historical rows are never rewritten.

## Releases

Builds are made with `tools/build_package.py`; releases (if any) are authorized by the product owner and are never triggered from CI automatically.
