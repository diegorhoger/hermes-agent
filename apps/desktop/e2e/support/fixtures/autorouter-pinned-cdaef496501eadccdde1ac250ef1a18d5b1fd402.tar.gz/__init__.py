"""AutoRouter — Hermes-native model discovery and selection plugin.

This package is imported by the Hermes plugin loader as a directory plugin. It
registers hooks and tools with the Hermes plugin context. It never depends on
any external gateway.

Public API re-exported for tests and tooling.
"""

from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

PLUGIN_NAME = "autorouter"
PLUGIN_VERSION = "0.2.0"


def _plugin_root() -> Path:
    return Path(__file__).resolve().parent


# Lazy imports of submodules to avoid import cycles during plugin discovery.
def _load_submodules():
    import importlib
    core_pkg = f"{__package__}.autorouter_core" if __package__ else "autorouter_core"
    return tuple(importlib.import_module(f'.{path}', core_pkg) for path in [
        'storage.state', 'discovery.discovery', 'health.health', 'eligibility.eligibility',
        'routing.scoring', 'routing.router', 'routing.failover', 'routing.integration', 'integration.tools',
    ])


def _strict_bool(value) -> bool:
    """Strict opt-in check. Anything other than the literal ``True`` is off."""
    return value is True


def _record_activation(state_dir, *, _state_dir_mod, selection_mode: str, chat_router: bool,
                       native_routing: bool, registered: bool | None, supported: bool | None,
                       reason: str | None) -> None:
    """Write a durable activation marker the dashboard reads (issue #116).

    Never raises, never mutates anything beyond the marker itself: a banner
    written here can only describe the registration that actually happened.
    """
    import json
    import time

    marker = {
        "schema_version": 1,
        "recorded_at": time.time(),
        "selection_mode": selection_mode,      # disabled | native | unavailable
        "chat_router": chat_router,
        "enable_native_routing": native_routing,
        "native_routing_registered": registered,
        "host_supported": supported,
        "reason": reason,
    }
    try:
        resolved = _state_dir_mod.resolve_state_dir(str(state_dir or "").strip(), _plugin_root())
        path = resolved / "native-routing-state.json"
        resolved.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(marker, sort_keys=True), encoding="utf-8")
    except Exception:  # pragma: no cover - banner only
        logger.warning("autorouter: could not persist the activation marker")


def register(ctx) -> None:
    """Plugin entry point called by the Hermes plugin loader."""
    try:
        state, discovery, health, eligibility, scoring, router, failover, integration, tools_mod = _load_submodules()
        from .autorouter_core.storage import state_dir as _state_dir_mod
    except Exception as exc:  # pragma: no cover - defensive
        logger.exception("autorouter: failed to import submodules: %s", exc)
        return

    try:
        state_dir_raw = str(ctx.get_config("state_dir", "") or "").strip()
        enabled = _strict_bool(ctx.get_config("enabled", False))
        chat_router_requested = _strict_bool(ctx.get_config("enable_chat_router", False))
        native_requested = _strict_bool(ctx.get_config("enable_native_routing", False))
    except Exception:
        # Config store unavailable: without a readable state_dir we cannot publish
        # an activation marker that names any location; refuse and register nothing.
        logger.exception("autorouter: plugin config read failed; plugin disabled failing closed")
        return

    # ---- Primary enable gate (strict boolean only) ------------------------
    # An enabled=False / missing / malformed value means this host registers
    # NOTHING — no middleware, no hooks, no tools, and an explicit activation
    # marker so downstream surfaces (the dashboard) can never read stale
    # "native active" state. Anything other than literal True is off.
    if not enabled:
        _record_activation(state_dir_raw, _state_dir_mod=_state_dir_mod,
                           selection_mode="disabled",
                           chat_router=False,
                           native_routing=False,
                           registered=False, supported=None, reason=None)
        return

    # ---- Native pre-inference routing consumer (opt-in, host-gated) -------
    # Exactly one MODE A path per host:
    #
    #   Native-capable host  → the sanctioned pre_inference_route consumer is
    #                          the ONLY resolver. The legacy monkey-patching
    #                          adapter is never loaded on such hosts.
    #   Nativeless host      → the ADR-0015 native picker route is
    #                          unavailable; fail closed — nothing resolves,
    #                          nothing advertised as actionable, no
    #                          monkey-patching installed.
    #
    # The legacy interposition class remains in the source tree for the
    # documented v0.1 patch-candidate workflow (tools/routing_proof.py) and
    # the deactivation guard; it is deliberately NOT activated from register().
    activation = None
    if chat_router_requested or native_requested:
        try:
            from .autorouter_core.integration import native_routing as _native_mod
            activation = _native_mod.register_if_supported(ctx)
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("autorouter: native pre-inference routing probe failed: %s", exc)

    if chat_router_requested:
        # MODE A: explicit AutoRouter picker selection. Fail closed if the
        # consumer registration did not land — never fall back to patching.
        if isinstance(activation, dict) and activation.get("registered") is True:
            activation_state = "native"
            activation_reason = None
            logger.info("autorouter: chat router engaged via the sanctioned pre_inference_route consumer")
        else:
            activation_state = "unavailable"
            activation_reason = (activation or {}).get("reason") or (
                "this Hermes exposes no sanctioned pre_inference_route extension")
            logger.error(
                "autorouter: enable_chat_router is on but the native routing consumer "
                "could not be activated (%s); chat routing stays OFF — refusing to load the legacy monkey-patch adapter",
                activation_reason,
            )
    elif native_requested:
        # MODE B alone (ordinary-session automatic routing).
        if isinstance(activation, dict) and activation.get("registered") is True:
            activation_state, activation_reason = "native", None
        else:
            activation_state = "unavailable"
            activation_reason = (activation or {}).get("reason") or (
                "this Hermes exposes no sanctioned pre_inference_route extension")
            logger.error("autorouter: enable_native_routing is on but the consumer could not be activated (%s)",
                         activation_reason)
    else:
        activation_state, activation_reason = "disabled", None

    _record_activation(state_dir_raw, _state_dir_mod=_state_dir_mod,
                       selection_mode=activation_state,
                       chat_router=chat_router_requested,
                       native_routing=native_requested,
                       registered=(activation or {}).get("registered") if isinstance(activation, dict) else None,
                       supported=(activation or {}).get("supported") if isinstance(activation, dict) else None,
                       reason=activation_reason)

    # ---- Virtual-model deactivation guard --------------------------------
    # Without the adapter the virtual marker is unresolvable; an unresolved
    # pin would be sent upstream verbatim by the host. Report loudly (logs +
    # durable dashboard banner); the guard never rewrites the profile
    # configuration. Never blocks the host.
    try:
        from .autorouter_core.integration import virtual_pin_guard as _guard_mod
        from .autorouter_core.storage import state_dir as _state_dir_mod
        _state_dir = _state_dir_mod.resolve_state_dir(
            str(ctx.get_config("state_dir", "") or "").strip(), _plugin_root())
        _guard_mod.guard(_state_dir)
    except Exception:
        logger.warning("autorouter: virtual-model deactivation guard failed", exc_info=True)

    policy = str(ctx.get_config("policy", "auto") or "auto")
    free_only = bool(ctx.get_config("free_only", True))
    providers = ctx.get_config("providers", ["nvidia", "openrouter"])
    from .autorouter_core.providers.connections import valid_provider_list
    if not valid_provider_list(providers):
        providers = []  # Invalid or explicitly empty authorization must not enable default providers.
    cooldown = int(ctx.get_config("cooldown_seconds", 60) or 60)
    state_dir_raw = str(ctx.get_config("state_dir", "") or "").strip()
    # Runtime resolution is authoritative; the dashboard reads the same
    # database via the shared resolver in state_dir.py.
    state_dir = _state_dir_mod.initialize_state_dir(state_dir_raw, _plugin_root())

    # Persist a runtime handle on the context manager via module-level singleton
    from .autorouter_core.integration import runtime as _runtime
    _runtime.configure(
        ctx=ctx,
        policy=policy,
        free_only=free_only,
        providers=list(providers),
        cooldown_seconds=cooldown,
        state_dir=state_dir,
    )

    # Register observer hooks only. Automatic runtime fallback is DISABLED
    # in v0.1.0: Hermes does not supply streamed_committed or
    # tool_side_effects_committed to any plugin hook payload, so AutoRouter
    # cannot enforce postcommit safety at runtime.
    for hook in ("pre_api_request", "post_api_request", "api_request_error"):
        try:
            cb = getattr(_runtime, f"on_{hook}", None) or (lambda **kw: None)
            ctx.register_hook(hook, cb)
        except Exception as exc:
            logger.debug("autorouter: hook %s registration failed: %s", hook, exc)

    # Register tools
    try:
        tools_mod.register_tools(ctx)
    except Exception as exc:
        logger.warning("autorouter: tool registration failed: %s", exc)

    logger.info("autorouter: registered (policy=%s, providers=%s)", policy, providers)


