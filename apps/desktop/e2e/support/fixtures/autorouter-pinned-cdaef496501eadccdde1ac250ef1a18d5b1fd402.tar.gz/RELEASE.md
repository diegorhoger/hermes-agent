# Building and verifying a package

AutoRouter is not currently published as an installable release. This page documents how to build and verify a distributable candidate from an exact source revision — the same evidence every installed build in this repository's history was produced from.

> A built candidate is **not** a published release. No tags, public installers, or production deployments are produced by this procedure. Do not redistribute without your own review of the diff and this document.

## Build

Use Python 3.11+ and Git. The builder reads committed Git blobs (never the working tree), requires no network access, pip installs, credentials or build dependencies. From the repository root, after `git checkout <revision-you-want>`:

```sh
export WORK="$(mktemp -d)" ; mkdir -p "$WORK/dist"
python3 tools/build_package.py --repo . --revision "$(git rev-parse HEAD)" --output "$WORK/dist"
```

Outputs: `autorouter-0.2.0-<sha12>.zip` and a matching `.zip.sha256`. The member order, timestamps, permissions and encoding are fixed; the same revision builds byte-identical output.

## Verify the artifact

```sh
python3 - "$WORK"/dist/autorouter-*.zip <<'EOF'
import importlib.util, sys, pathlib
spec = importlib.util.spec_from_file_location("b", "tools/build_package.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
manifest = m.verify(pathlib.Path(sys.argv[1]).read_bytes())
print("source_sha:", manifest["source_sha"], "| tree_sha:", manifest["tree_sha"], "| files:", len(manifest["files"]))
EOF
```

This checks structural integrity, expected identity (when pinned), every member hash, archive member order/timestamps/permissions, license presence, plugin identity, secret-pattern scan and exact inventory. A SHA-256 and manifest are **not** a signature or independent approval — verify the revision yourself before installing anything derived from it.

## Install (isolated profile only)

Extract the ZIP into the target profile's `plugins/` directory (see [installation](docs/installation.md)) and run `hermes plugins enable autorouter`, then restart. The plugin manifest never installs or enables itself; Hermes' plugin manager owns the consent gate.

## Isolated acceptance workflow

Before trusting a build in any active profile, exercise it in disposable homes (fake `HERMES_HOME`, synthetic catalog):

1. Fresh disposable profile: install → enable → verify the dashboard tab mounts and the Settings page loads.
2. `autorouter_refresh`, then inspect Models/Providers tabs.
3. `autorouter_select` returns an eligible model or refuses clearly.
4. Empty-catalog and unverified-free cases must refuse before any network access.
5. Rollback: restore the prior plugin directory; confirm behavior returns. State data survives removal.
6. Swaps between schema-compatible builds must preserve profile data; no downgrade attempt is supported.

The package's lifecycle is also covered by `tests/integration/test_package_lifecycle.py`, which needs the exported `AUTOROUTER_TEST_PACKAGE` and `AUTOROUTER_PREVIOUS_PACKAGE` and a pinned Hermes source archive (see [installation.md](docs/installation.md)).

## What ships in the package

Runtime Python modules, dashboard manifest and prebuilt assets, provider registry data, license files, user documentation (root README/CHANGELOG/RELEASE/SECURITY plus `docs/*.md`). What does **not** ship: tests, build machinery, Git metadata, `.env*`, runtime databases/logs/caches, internal engineering records under `docs/internal/`, credentials of any kind.

## Limitations

- No public release is established by any build artifact. Publication requires separate owner authorization.
- No upstream quota/billing guarantee exists on a standard Hermes host; account-scoped allowance reads `unknown`.
- Verified-free selection requires fresh verified zero-price evidence per model; publish status of prices is never a billing guarantee.
