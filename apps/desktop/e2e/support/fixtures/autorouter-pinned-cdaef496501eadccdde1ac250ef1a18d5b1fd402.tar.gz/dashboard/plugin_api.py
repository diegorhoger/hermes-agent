"""AutoRouter dashboard plugin backend.

Mounted by the Hermes web server at ``/api/plugins/autorouter/`` when (and
only when) the ``autorouter`` plugin is enabled. These routes sit behind
Hermes' dashboard auth gate and its per-request plugin consent check; this
module adds no authentication of its own and must never be the only thing
protecting data — keep it read-only and secret-free by construction.

All handlers are synchronous ``def`` (FastAPI runs them in a worker thread)
so SQLite reads never block the gateway's event loop.
"""

from __future__ import annotations

import importlib.util
import logging
import sys
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Body
from pydantic import BaseModel


def _load_state_reader():
    """Load the sibling ``state_reader.py`` by file location.

    Hermes imports this file as a standalone module (not as part of the
    ``autorouter`` package), so plain ``import state_reader`` is not
    guaranteed to resolve. Loading by path is explicit and robust.
    """
    name = "_autorouter_dashboard_state_reader"
    if name in sys.modules:
        return sys.modules[name]
    file_path = Path(__file__).resolve().parent / "state_reader.py"
    spec = importlib.util.spec_from_file_location(name, file_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("state_reader.py could not be loaded")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    try:
        spec.loader.exec_module(mod)
    except Exception:
        sys.modules.pop(name, None)
        raise
    return mod


_sr = _load_state_reader()
assemble_analytics = _sr.assemble_analytics
assemble_models = _sr.assemble_models
assemble_model_preference = _sr.assemble_model_preference
assemble_overview = _sr.assemble_overview
assemble_providers = _sr.assemble_providers
assemble_settings = _sr.assemble_settings
validate_settings_updates = _sr.validate_settings_updates
write_settings = _sr.write_settings
apply_model_preference = _sr.apply_model_preference
refresh_catalog = _sr.refresh_catalog
SettingsWriteError = getattr(_sr, "SettingsWriteError", None)

logger = logging.getLogger("autorouter.dashboard")

router = APIRouter()


class SettingsUpdate(BaseModel):
    updates: dict[str, Any]


class ModelToggle(BaseModel):
    provider: str
    model: str
    enabled: bool


class ModelPreferenceUpdate(BaseModel):
    toggles: list[ModelToggle] = []
    base: str
    reset: Optional[str] = None


@router.get("/overview")
def overview() -> dict[str, Any]:
    try:
        return assemble_overview()
    except Exception:
        logger.exception("autorouter dashboard: overview assembly failed")
        return {"available": False, "reason": "Overview could not be assembled from plugin state"}


@router.get("/providers")
def providers() -> dict[str, Any]:
    try:
        return assemble_providers()
    except Exception:
        logger.exception("autorouter dashboard: providers assembly failed")
        return {"available": False, "reason": "Provider summary could not be assembled from plugin state"}


@router.get("/models")
def models(page: int = 1, page_size: int = 50, query: str = "", provider: str = "",
           eligibility: str = "all", free_only: bool = False, sort: str = "provider",
           preference: str = "all") -> dict[str, Any]:
    try:
        return assemble_models(page=page, page_size=page_size, query=query, provider=provider,
                               eligibility=eligibility, free_only=free_only, sort=sort,
                               preference=preference)
    except Exception:
        logger.exception("autorouter dashboard: models assembly failed")
        return {"available": False, "reason": "Model catalog could not be assembled from plugin state"}


@router.get("/first-use")
def first_use() -> dict[str, Any]:
    try:
        return _sr.assemble_first_use()
    except Exception:
        raise HTTPException(status_code=503,detail="First-use evidence unavailable") from None


@router.get("/execution-capabilities")
def execution_capabilities() -> dict[str, Any]:
    return _sr._load_submodule("execution_adapter").capabilities()


@router.post("/models/refresh")
def models_refresh() -> dict[str, Any]:
    try:
        return refresh_catalog()
    except Exception:
        logger.exception("autorouter dashboard: catalog refresh failed")
        raise HTTPException(status_code=503, detail={"code": "refresh_unavailable",
                                                     "message": "Catalog refresh is unavailable in this process"}) from None


@router.get("/models/preference")
def models_preference() -> dict[str, Any]:
    """Fresh read-back of the user's model inclusion/exclusion preference.

    Never mutates anything. Includes a content hash the toggle endpoint uses
    for optimistic concurrency — a writer whose base no longer matches is
    refused rather than silently clobbering the other writer's lists.
    """
    try:
        return assemble_model_preference()
    except Exception:
        logger.exception("autorouter dashboard: model preference read failed")
        return {"available": False,
                "reason": "Model preferences could not be read from plugin configuration"}


@router.post("/models/preference")
def models_preference_toggle(body: ModelPreferenceUpdate) -> dict[str, Any]:
    """Flip one or more models on/off or reset the preference (user preference
    only — eligibility is never affected). Optimistic concurrency via ``base``
    (the hash from the last read); a stale base returns 409 with the current
    state — clients must re-evaluate against fresh state rather than blindly
    replay. Validated before any write; conflicting operations for the same
    model in one batch resolve last-wins. ``reset='unrestricted'`` is the only
    way back from the all-disabled state and clears both lists."""
    toggles = [toggle.model_dump() for toggle in body.toggles]
    if body.reset is not None:
        if body.reset != "unrestricted":
            raise HTTPException(status_code=400, detail={"errors": [f"unsupported reset {body.reset!r}"]})
        if toggles:
            raise HTTPException(status_code=400, detail={"errors": ["reset cannot be combined with toggles"]})
    elif not toggles:
        raise HTTPException(status_code=400, detail={"errors": ["toggles must not be empty"]})
    if len(toggles) > 200:
        raise HTTPException(status_code=400, detail={"errors": ["toggles must not exceed 200 operations"]})
    try:
        result = apply_model_preference(toggles, body.base, reset=body.reset)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail={"errors": [str(exc)]}) from None
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from None
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from None
    except Exception as exc:
        if SettingsWriteError is not None and isinstance(exc, SettingsWriteError):
            origin = getattr(exc, "original", None)
            status_code = 403 if isinstance(origin, PermissionError) else 503 if isinstance(origin, RuntimeError) else 500
            if exc.saved:
                detail = {
                    "message": (
                        "Some settings were saved; the model preference was not. "
                        f"Saved: {', '.join(exc.saved)}. "
                        f"Failed: {exc.failed} ({exc.reason}). "
                        f"Not attempted: {', '.join(exc.remaining) or 'none'}. "
                        "The preference blob is all-or-nothing; the saved keys stay saved."
                    ),
                    "partial": True,
                    "saved": exc.saved,
                    "failed": {exc.failed: exc.reason},
                    "remaining": exc.remaining,
                }
            else:
                detail = {
                    "message": (
                        "The model preference could not be saved and nothing was written. "
                        f"Failed: {exc.failed} ({exc.reason}). "
                        "The previous preference is unchanged."
                    ),
                    "partial": False,
                    "saved": [],
                    "failed": {exc.failed: exc.reason},
                    "remaining": exc.remaining,
                }
            raise HTTPException(status_code=status_code, detail=detail) from exc
        logger.exception("autorouter dashboard: model preference write failed")
        raise HTTPException(status_code=500, detail="Model preferences could not be saved") from None
    if result.get("stale"):
        raise HTTPException(status_code=409, detail=result)
    if result.get("overwritten"):
        # Our write landed, but a non-participating writer crossed it before
        # the read-back; the persisted state is not what we intended. Report
        # a conflict the client can re-evaluate against fresh state instead
        # of claiming success.
        conflict = dict(result)
        conflict["stale"] = True
        raise HTTPException(status_code=409, detail=conflict)
    # Success: return the freshly assembled view (counts + hash), not just the diff.
    try:
        fresh = assemble_model_preference()
    except Exception:
        fresh = dict(result)
    fresh["applied"] = {k: result[k] for k in ("changed", "toggles_applied", "allowlist_emptied", "mode", "reset") if k in result}
    return fresh


@router.post("/handoff/manual")
def manual_handoff(body: Any = Body(...)) -> dict[str, Any]:
    allowed={"selection", "confirmed", "selection_policy", "requires_tools", "min_context"}
    if not isinstance(body,dict) or not {"selection","confirmed"} <= body.keys() or not body.keys() <= allowed:
        raise HTTPException(status_code=400,detail="Invalid handoff request")
    module=_sr._load_submodule("execution_adapter")
    values=(_sr.read_plugin_config().get("values") or {})
    if values.get("enabled") is not True:
        return module._receipt("unavailable_evidence", "plugin_disabled", __import__("time").time())
    router_mod=_sr._load_submodule("router")
    # Router.preview opens only the existing read-only snapshot; no init or writer.
    reader=_sr._load_submodule("snapshot").ReadOnlyStateStore(_sr._db_path(values))
    adapter=module.ManualHermesAdapter(router_mod.Router(dict(values,store=reader)))
    options={key:body[key] for key in ("selection_policy","requires_tools","min_context") if key in body}
    return adapter.handoff(body["selection"],confirmed=body["confirmed"],**options)


@router.get("/task-profiles")
def task_profiles() -> dict[str, Any]:
    profiles = _sr._load_submodule("task_profiles")
    config = _sr.read_plugin_config()
    providers = (config.get("values") or {}).get("providers") or []
    return {"schema_version": 1, "profiles": profiles.catalog(),
        "requests": {p["id"]: profiles.request(p["id"], providers) for p in profiles.catalog()},
        "execution_authority": False}




# ---------------------------------------------------------------------------
# Routing profiles (issue #100) — CRUD + read-only preview + explicit activation.
# Profiles are stored in the plugin-scoped SQLite store only; activation is a
# per-plugin flag consumed by the chat-router adapter on the next session and
# never touches Hermes configuration, credentials or the global default model.
# ---------------------------------------------------------------------------


def _profiles_mod():
    return _sr._load_submodule("profiles")


def _profile_store():
    values = (_sr.read_plugin_config().get("values") or {})
    state_dir = Path(_sr._db_path(values)).parent
    return _sr._load_submodule("state").RoutingProfileStore(state_dir)


def _profile_values(exc: Exception) -> tuple[int, dict[str, Any]]:
    code = getattr(exc, "code", "profile_error")
    message = getattr(exc, "message", str(exc))
    fields = getattr(exc, "fields", None)
    if code == "profile_not_found":
        status = 404
    elif code == "profile_name_conflict":
        status = 409
    else:
        status = 400
    detail: dict[str, Any] = {"code": code, "message": message}
    if fields:
        detail["fields"] = fields
    return status, detail


@router.get("/routing-profiles")
def list_routing_profiles() -> dict[str, Any]:
    try:
        store = _profile_store()
        profiles_mod = _profiles_mod()
        rows = [profiles_mod.public_profile(p) for p in store.list()]
        return {"schema_version": 1, "profiles": rows, "active": store.active_id(),
                "ranking_policies": list(profiles_mod.RANKING_POLICIES),
                "execution_authority": False}
    except Exception:
        logger.exception("autorouter dashboard: routing profiles could not be listed")
        return {"available": False, "reason": "Routing profiles could not be read from plugin state"}


@router.post("/routing-profiles", status_code=201)
def create_routing_profile(body: Any = Body(...)) -> dict[str, Any]:
    try:
        store = _profile_store()
        return {"profile": _profiles_mod().public_profile(store.create(body))}
    except _profiles_mod().ProfileError as exc:
        status, detail = _profile_values(exc)
        raise HTTPException(status_code=status, detail=detail) from None
    except Exception:
        logger.exception("autorouter dashboard: routing profile could not be created")
        raise HTTPException(status_code=503, detail={"code": "profile_unavailable", "message": "Routing profiles are unavailable"}) from None


@router.get("/routing-profiles/{profile_id}")
def get_routing_profile(profile_id: str) -> dict[str, Any]:
    try:
        store = _profile_store()
        profiles_mod = _profiles_mod()
        row = store.get(profile_id)
        if row is None:
            raise HTTPException(status_code=404, detail={"code": "profile_not_found", "message": "Routing profile not found"})
        return {"profile": profiles_mod.public_profile(row), "active": store.active_id() == profile_id}
    except HTTPException:
        raise
    except Exception:
        logger.exception("autorouter dashboard: routing profile could not be read")
        raise HTTPException(status_code=503, detail={"code": "profile_unavailable", "message": "Routing profiles are unavailable"}) from None


@router.put("/routing-profiles/{profile_id}")
def update_routing_profile(profile_id: str, body: Any = Body(...)) -> dict[str, Any]:
    try:
        store = _profile_store()
        profiles_mod = _profiles_mod()
        return {"profile": profiles_mod.public_profile(store.update(profile_id, body))}
    except _profiles_mod().ProfileError as exc:
        status, detail = _profile_values(exc)
        raise HTTPException(status_code=status, detail=detail) from None
    except Exception:
        logger.exception("autorouter dashboard: routing profile could not be updated")
        raise HTTPException(status_code=503, detail={"code": "profile_unavailable", "message": "Routing profiles are unavailable"}) from None


@router.delete("/routing-profiles/{profile_id}")
def delete_routing_profile(profile_id: str) -> dict[str, Any]:
    try:
        store = _profile_store()
        outcome = store.delete(profile_id)
        if not outcome["deleted"]:
            raise HTTPException(status_code=404, detail={"code": "profile_not_found", "message": "Routing profile not found"})
        return {"deleted": True, "deactivated": outcome["deactivated"]}
    except HTTPException:
        raise
    except Exception:
        logger.exception("autorouter dashboard: routing profile could not be deleted")
        raise HTTPException(status_code=503, detail={"code": "profile_unavailable", "message": "Routing profiles are unavailable"}) from None


@router.post("/routing-profiles/{profile_id}/duplicate", status_code=201)
def duplicate_routing_profile(profile_id: str, body: Any = Body(default=None)) -> dict[str, Any]:
    try:
        store = _profile_store()
        profiles_mod = _profiles_mod()
        name = None
        if isinstance(body, dict):
            raw = body.get("name")
            if raw is not None and not isinstance(raw, str):
                raise _profiles_mod().ProfileError("profile_invalid", "name must be a string", {"name": "must be a string"})
            name = raw
        return {"profile": profiles_mod.public_profile(store.duplicate(profile_id, name=name))}
    except _profiles_mod().ProfileError as exc:
        status, detail = _profile_values(exc)
        raise HTTPException(status_code=status, detail=detail) from None
    except Exception:
        logger.exception("autorouter dashboard: routing profile could not be duplicated")
        raise HTTPException(status_code=503, detail={"code": "profile_unavailable", "message": "Routing profiles are unavailable"}) from None


@router.post("/routing-profiles/{profile_id}/preview")
def preview_routing_profile(profile_id: str) -> dict[str, Any]:
    try:
        store = _profile_store()
        profiles_mod = _profiles_mod()
        row = store.get(profile_id)
        if row is None:
            raise HTTPException(status_code=404, detail={"code": "profile_not_found", "message": "Routing profile not found"})
        values = (_sr.read_plugin_config().get("values") or {})
        authorized = [p for p in (values.get("providers") or []) if isinstance(p, str)]
        db_path = _sr._db_path(values)
        if not db_path.is_file():
            raise HTTPException(status_code=503, detail={"code": "evidence_unavailable", "message": "The AutoRouter catalog is not available"})
        preview_mod = _sr._load_submodule("profile_preview")
        cooldown = values.get("cooldown_seconds", 60)
        result = preview_mod.preview_profile(db_path, row, authorized_providers=authorized,
                                             cooldown_seconds=cooldown if isinstance(cooldown, int) and not isinstance(cooldown, bool) else 60)
        result["profile_id"] = profile_id
        result["profile"] = profiles_mod.public_profile(row)
        return result
    except HTTPException:
        raise
    except Exception:
        logger.exception("autorouter dashboard: routing profile preview failed")
        raise HTTPException(status_code=503, detail={"code": "profile_unavailable", "message": "Routing profiles are unavailable"}) from None


@router.post("/routing-profiles/{profile_id}/activate")
def activate_routing_profile(profile_id: str) -> dict[str, Any]:
    try:
        store = _profile_store()
        store.set_active(profile_id)
        return {"active": profile_id}
    except _profiles_mod().ProfileError as exc:
        status, detail = _profile_values(exc)
        raise HTTPException(status_code=status, detail=detail) from None
    except Exception:
        logger.exception("autorouter dashboard: routing profile could not be activated")
        raise HTTPException(status_code=503, detail={"code": "profile_unavailable", "message": "Routing profiles are unavailable"}) from None


@router.post("/routing-profiles/deactivate")
def deactivate_routing_profile() -> dict[str, Any]:
    try:
        store = _profile_store()
        store.set_active(None)
        return {"active": None}
    except Exception:
        logger.exception("autorouter dashboard: routing profile could not be deactivated")
        raise HTTPException(status_code=503, detail={"code": "profile_unavailable", "message": "Routing profiles are unavailable"}) from None


@router.post("/selection/preview")
def selection_preview(body: Any = Body(...)) -> dict[str, Any]:
    # Recommendations only: no settings, decisions, credential or execution writes.
    try:
        if not isinstance(body, dict) or set(body) != {"selection_policy"}:
            raise ValueError("invalid request")
        policy = _sr._load_submodule("selection_policy").validate(body["selection_policy"])
    except (TypeError, ValueError) as error:
        raise HTTPException(status_code=400, detail={"code": getattr(error, "code", "selection_policy_invalid"), "message": "Invalid selection policy"}) from None
    result = assemble_models(selection_policy=policy)
    if result.get("available") is not True or "preview" not in result:
        raise HTTPException(status_code=503, detail={"code":"evidence_unavailable", "evidence_report":result.get("evidence_report")})
    return result["preview"]


@router.get("/analytics")
def analytics(
    range: str | None = None,
    view: str = "summary",
    request_id: int | None = None,
    provider: str | None = None,
    status: str | None = None,
    limit: int = 20,
    offset: int = 0,
    sort: str = "newest",
) -> dict[str, Any]:
    try:
        return assemble_analytics(
            range=range,
            view=view,
            request_id=request_id,
            provider=provider,
            status=status,
            limit=limit,
            offset=offset,
            sort=sort,
        )
    except Exception:
        logger.exception("autorouter dashboard: analytics assembly failed")
        return {"available": False, "reason": "Analytics could not be assembled from plugin state"}


@router.get("/settings")
def settings() -> dict[str, Any]:
    try:
        return assemble_settings()
    except Exception:
        logger.exception("autorouter dashboard: settings assembly failed")
        return {"available": False, "reason": "Settings could not be read from plugin configuration"}


def _run_virtual_pin_guard() -> dict[str, Any]:
    """Explicit-deactivation entry point for the virtual-model safety guard.

    Best effort by contract: any failure degrades to a conservative report;
    the settings response still succeeds (the pin problem is surfaced, not
    hidden by an exception). The guard is warning-only: it never rewrites
    the profile configuration; the outcome tells the user to run /model.
    """
    try:
        values = (_sr.read_plugin_config().get("values") or {})
        store_dir = Path(_sr._db_path(values)).parent
    except Exception:
        store_dir = None
    try:
        guard = _sr._load_submodule("virtual_pin_guard")
        # The caller is the deactivation save: the next host load will see
        # routing disabled even though this process' adapter is still
        # interposed (settings are deliberately not hot-applied). Verdicts
        # must reflect the next load, not this process.
        return guard.guard(store_dir, assume_disabled=True)
    except Exception:
        logger.warning("autorouter: virtual-model deactivation guard failed", exc_info=True)
        return {"state": "guard_error", "pins": [],
                "detail": "The deactivation guard could not run; run /model and verify the pinned model."}


@router.put("/settings")
def update_settings(body: SettingsUpdate) -> dict[str, Any]:
    clean, errors = validate_settings_updates(body.updates)
    if errors:
        raise HTTPException(status_code=400, detail={"errors": errors})
    try:
        write_settings(clean)
    except PermissionError as exc:
        # Managed install or administrator-managed key — safe to surface.
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        if SettingsWriteError is not None and isinstance(exc, SettingsWriteError):
            origin = getattr(exc, "original", None)
            if isinstance(origin, PermissionError):
                status_code = 403
            elif isinstance(origin, RuntimeError):
                status_code = 503
            else:
                status_code = 500
            # Report the partial outcome accurately: earlier keys stay
            # persisted; later keys were not attempted.
            raise HTTPException(status_code=status_code, detail={
                "message": (
                    "Some settings were saved; the rest were not. "
                    f"Saved: {', '.join(exc.saved) or 'none'}. "
                    f"Failed: {exc.failed} ({exc.reason}). "
                    f"Not attempted: {', '.join(exc.remaining) or 'none'}. "
                    "Earlier keys were already persisted and stay persisted."
                ),
                "partial": True,
                "saved": exc.saved,
                "failed": {exc.failed: exc.reason},
                "remaining": exc.remaining,
            }) from exc
        logger.exception("autorouter dashboard: settings write failed")
        raise HTTPException(status_code=500, detail="Settings could not be saved") from None
    # Deactivation path: the user just turned chat routing off (or the whole
    # toggle changed). Run the virtual-model safety guard so an unresolvable
    # pin is surfaced loudly (the guard never rewrites configuration);
    # include its outcome in the response so the UI can say exactly what
    # happened.
    if clean.get("enable_chat_router") is False:
        guard_outcome = _run_virtual_pin_guard()
        res = assemble_settings()
        if isinstance(guard_outcome, dict):
            res["virtual_pin_guard"] = {
                "state": guard_outcome.get("state"),
                "pins": guard_outcome.get("pins"),
                "restored": guard_outcome.get("restored"),
                "restore_error": guard_outcome.get("restore_error"),
                "detail": guard_outcome.get("detail"),
                "action": guard_outcome.get("action"),
            }
        return res
    return assemble_settings()


@router.get("/connections")
def connections_inventory():
    try:
        return _sr.assemble_connections()
    except Exception:
        raise HTTPException(status_code=503, detail={"code": "inventory_unavailable", "message": "Connection inventory unavailable"}) from None


@router.get("/connections/{provider_id}")
def connection_detail(provider_id: str):
    contract = _sr._load_submodule("connections")
    try:
        contract.validate_provider(provider_id)
    except contract.ConnectionError as exc:
        raise HTTPException(status_code=exc.status, detail={"code": exc.code, "message": exc.message}) from None
    result = connections_inventory()
    return next(row for row in result["connections"] if row["provider_id"] == provider_id)


@router.post("/connections/{provider_id}/actions/{operation}")
def connection_action(provider_id: str, operation: str):
    # Intentionally no request-body schema: never parse/echo submitted secret values.
    contract = _sr._load_submodule("connections")
    try:
        contract.unavailable_operation(provider_id, operation, _sr.read_plugin_config())
    except contract.ConnectionError as exc:
        raise HTTPException(status_code=exc.status, detail={"code": exc.code, "message": exc.message}) from None
    except Exception:
        raise HTTPException(status_code=503, detail={"code": "host_capability_unavailable", "message": "Credential operation unavailable"}) from None
