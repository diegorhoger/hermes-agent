"""Read-only state assembly for the AutoRouter dashboard plugin.

This module turns AutoRouter's on-disk state (the SQLite store plus the
Hermes plugin configuration) into plain JSON-able dicts for the five-tab
management UI. It performs **no writes**, opens the database strictly
read-only, and never touches the network.

It is imported by ``plugin_api.py`` (mounted by the Hermes web server) and
by the test-suite. Every public function takes an optional ``now`` so tests
can freeze time.

Design rules:

* Reuse AutoRouter's own modules (``eligibility``, ``router``) instead of
  re-implementing rules. Importing them by file location keeps this module
  working when imported by Hermes' plugin loader, which loads it as a
  standalone file rather than as part of the ``autorouter`` package.
* Treat everything stored in the database as untrusted: strings are
  stripped of control characters, matched against common secret patterns
  and truncated before leaving this module.
* Any failure degrades to a section-level ``available: false`` payload
  instead of an exception bubbling up into the HTTP layer.
"""

from __future__ import annotations

import copy
import contextlib
import json
import logging
import os
import re
import sqlite3
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("autorouter.dashboard.state_reader")

_PLUGIN_ROOT = Path(__file__).resolve().parent.parent
_CORE_ROOT = _PLUGIN_ROOT / "autorouter_core"
_PKG_NAME = "_autorouter_dashboard_core_pkg"

MAX_MODELS = 500
MAX_RECENT = 15


# ---------------------------------------------------------------------------
# importing the AutoRouter package by file location (no sys.path mutation)
# ---------------------------------------------------------------------------

def _load_package():
    """Load the autorouter_Core package shell by file location without sys.path."""
    import sys
    import importlib.util

    if _PKG_NAME in sys.modules:
        return sys.modules[_PKG_NAME]
    init_file = _CORE_ROOT / "__init__.py"
    spec = importlib.util.spec_from_file_location(
        _PKG_NAME, init_file, submodule_search_locations=[str(_CORE_ROOT)]
    )
    mod = importlib.util.module_from_spec(spec)
    sys.modules[_PKG_NAME] = mod
    try:
        spec.loader.exec_module(mod)
    except Exception:
        sys.modules.pop(_PKG_NAME, None)
        raise
    return mod


_MODULE_PATHS = {
    'router': 'routing.router',
    'model_selector': 'routing.model_selector',
    'scoring': 'routing.scoring',
    'failover': 'routing.failover',
    'execution_adapter': 'routing.execution_adapter',
    'task_profiles': 'routing.task_profiles',
    'profiles': 'routing.profiles',
    'profile_preview': 'routing.preview',
    'integration': 'routing.integration',
    'eligibility': 'eligibility.eligibility',
    'discovery': 'discovery.discovery',
    'adapters': 'discovery.adapters',
    'metadata': 'discovery.metadata',
    'nous_catalog': 'discovery.nous_catalog',
    'provider_registry': 'discovery.provider_registry',
    'first_use': 'discovery.first_use',
    'connections': 'providers.connections',
    'provider_intelligence': 'providers.provider_intelligence',
    'evidence': 'evidence.evidence',
    'free_access': 'evidence.free_access',
    'quota': 'evidence.quota',
    'scope_quota': 'evidence.scope_quota',
    'credential_scope': 'evidence.credential_scope',
    'health': 'health.health',
    'health_guidance': 'health.health_guidance',
    'telemetry': 'telemetry.telemetry',
    'request_trace': 'telemetry.request_trace',
    'decision_report': 'telemetry.decision_report',
    'state': 'storage.state',
    'state_dir': 'storage.state_dir',
    'snapshot': 'storage.snapshot',
    'backup': 'storage.backup',
    'tools': 'integration.tools',
    'runtime': 'integration.runtime',
    'chat_router_adapter': 'integration.chat_router_adapter',
    'virtual_pin_guard': 'integration.virtual_pin_guard',
    'policies': 'configuration.policies',
    'capabilities': 'configuration.capabilities',
    'selection_policy': 'configuration.selection_policy',
}


def _load_submodule(name: str):
    import sys
    import importlib.util

    rel = _MODULE_PATHS[name]
    full = f"{_PKG_NAME}.{rel}"
    mod = sys.modules.get(full)
    if mod is not None:
        return mod
    _load_package()
    import importlib
    mod = importlib.import_module(f".{rel}", _PKG_NAME)
    sys.modules[full] = mod
    return mod


# ---------------------------------------------------------------------------
# secret scrubbing / truncation (stored strings are untrusted)
# ---------------------------------------------------------------------------

_SECRET_PATTERNS = [
    re.compile(r"(?i)\bsk-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"(?i)\bgh[pousr]_[A-Za-z0-9]{20,}"),
    re.compile(r"(?i)\bxox[baprs]-[A-Za-z0-9\-]{10,}"),
    re.compile(r"(?i)\bBearer\s+[A-Za-z0-9_\-\.\=]{8,}"),
    re.compile(r"(?i)(api[_-]?key|token|secret|password|authorization)(\s*[:=]\s*)(bearer\s+)?[^\s,;\"']{4,}"),
    re.compile(r"(?i)([?&](?:access_token|api_key|token|key|secret)=)[^&\s]{4,}"),
]

_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def scrub(value: Any, limit: int = 240) -> Optional[str]:
    """Return a control-character-free, secret-pattern-redacted, truncated string."""
    if value is None:
        return None
    text = str(value)
    text = text.replace("\r", " ").replace("\n", " ")
    text = _CONTROL_CHARS.sub("", text)
    for pat in _SECRET_PATTERNS:
        text = pat.sub("[redacted]", text)
    text = re.sub(r"\s{2,}", " ", text).strip()
    if len(text) > limit:
        text = text[: limit - 1].rstrip() + "…"
    return text


def _num(value: Any) -> Optional[float]:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _int(value: Any) -> Optional[int]:
    num = _num(value)
    return int(num) if num is not None else None


# ---------------------------------------------------------------------------
# configuration (read-only)
# ---------------------------------------------------------------------------

_DEFAULTS = {
    "enabled": False,
    "policy": "auto",
    "free_only": True,
    "providers": ["nvidia", "openrouter"],
    "cooldown_seconds": 60,
    "state_dir": "",
    "paid_authorized": False,
    "enable_chat_router": False,
    "min_context": 8192,
    "requires_tools": False,
    "model_include": [],
    "model_exclude": [],
    # Canonical single-key preference (mode + include + exclude in one
    # indivisible value so Hermes' per-key writer persists it atomically).
    # Absent on legacy installs; the legacy two keys remain readable there.
    "model_preference": None,
}

POLICY_OPTIONS = list(_load_submodule("policies").POLICY_OPTIONS)
EDITABLE_KEYS = (
    "policy", "free_only", "cooldown_seconds", "providers",
    "enable_chat_router", "min_context", "requires_tools",
    "model_include", "model_exclude",
)


def _activation_marker(db_path: Path) -> Optional[dict[str, Any]]:
    """Durable activation outcome the plugin's register() wrote, if any.

    ``native``: the sanctioned consumer registered and this plugin class is the
    only resolver bound — the ADR-0015 picker mode is genuinely actionable.
    ``unavailable``: flag(s) on, but the host cannot route — uneven raw-config
    trust, missing seam, registration failure. Never fabricated.
    ``disabled``: no flag set.
    """
    try:
        path = Path(db_path).parent / "native-routing-state.json"
        if not path.is_file():
            return None
        raw = json.loads(path.read_text("utf-8"))
    except Exception:
        return None
    return raw if isinstance(raw, dict) and isinstance(raw.get("selection_mode"), str) else None


_MODE_TO_RUNTIME = {"disabled": "inactive", "native": "active"}


def _chat_routing_state(values: dict[str, Any], marker: Optional[dict[str, Any]] = None) -> str:
    plugin_enabled = values.get("enabled") is True
    if not plugin_enabled:  # stale marker can never outrank a disabled plugin
        return "inactive"
    if marker is not None:
        return _MODE_TO_RUNTIME.get(marker.get("selection_mode"), "unavailable")
    return "inactive" if not bool(values.get("enable_chat_router")) else "unavailable"


def _runtime_activation(values: dict[str, Any], marker: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Truthful runtime activation for the chat-router selection route.

    The marker written at plugin registration is authoritative when present:
    it describes the registration that actually happened. Without one nothing
    is inferred from raw config — the state reports ``unavailable``, which is
    correct for a host where the seam or the consumer never activated.
    """
    plugin_enabled = values.get("enabled") is True
    enabled = bool(values.get("enable_chat_router"))
    if not plugin_enabled:
        return {"configured": enabled, "runtime": "inactive",
                "detail": "The AutoRouter plugin is disabled (enabled != true)."}
    if marker is not None:
        mode = _MODE_TO_RUNTIME.get(marker.get("selection_mode"), "unavailable")
        detail = str(marker.get("reason") or "")
        if mode == "unavailable" and not detail:
            detail = "The native pre-inference route consumer is not active on this host."
        return {"configured": enabled, "runtime": mode, "detail": detail}
    return {"configured": enabled,
            "runtime": "inactive" if not enabled else "unavailable",
            "detail": ("" if not enabled else
                       "Activation is unproven in this process; enable the plugin or a supported host to activate it.")}


def _virtual_pin_guard(db_path: Path) -> Optional[dict[str, Any]]:
    """Durable outcome of the virtual-model deactivation guard, if any."""
    try:
        vpg = _load_submodule("virtual_pin_guard")
        return vpg.read_marker(db_path.parent)
    except Exception:
        return None


def read_plugin_config() -> dict[str, Any]:
    """Read ``plugins.entries.autorouter.settings`` without mutating anything.

    Falls back to defaults when Hermes internals are not importable (e.g. in
    unit tests outside Hermes). Never raises.
    """
    out = {
        "values": dict(_DEFAULTS),
        "available": False,
        "reason": "Hermes configuration is not readable in this process",
        "managed": False,
    }
    try:
        from hermes_cli.config import load_config_readonly

        cfg = load_config_readonly() or {}
        entry = cfg.get("plugins", {}).get("entries", {}).get("autorouter", {})
        settings = entry.get("settings", {}) if isinstance(entry, dict) else {}
        if not isinstance(settings, dict):
            settings = {}
        merged = dict(_DEFAULTS)
        for key in _DEFAULTS:
            if key in settings:
                merged[key] = settings[key]
        valid = _load_submodule("connections").valid_provider_list(merged["providers"])
        out["provider_configuration_valid"] = valid
        if not valid:
            merged["providers"] = []
        out["values"] = merged
        out["available"] = True
        out["reason"] = None
        try:
            from hermes_cli import managed_scope

            out["managed"] = bool(
                managed_scope.is_key_managed("plugins.entries.autorouter.settings")
                or managed_scope.is_key_managed("plugins")
            )
        except Exception:
            out["managed"] = False
        return out
    except Exception:
        # Hermes internals unavailable (tests, standalone harness) — defaults hold.
        out["values"] = dict(_DEFAULTS)
        return out


# ---------------------------------------------------------------------------
# read-only database access
# ---------------------------------------------------------------------------

def _state_dir(cfg_values: dict[str, Any]) -> Path:
    """Resolve the state directory exactly as the running plugin does.

    The runtime registration behavior (``register()`` in ``__init__.py``) is
    authoritative: the configured ``state_dir`` wins, otherwise the
    profile-scoped ``plugin-data/autorouter/`` directory is used. ``AUTOROUTER_STATE_DIR`` is
    intentionally not consulted — honoring it here would let the dashboard
    read a different database than the running plugin.
    """
    raw = str(cfg_values.get("state_dir") or "").strip()
    try:
        resolver = _load_submodule("state_dir")
    except Exception as exc:
        raise RuntimeError(
            "autorouter: shared state_dir resolver (state_dir.py) could not be loaded"
        ) from exc
    return resolver.resolve_state_dir(raw, _PLUGIN_ROOT)


def _db_path(cfg_values: dict[str, Any]) -> Path:
    return _state_dir(cfg_values) / "autorouter.db"


def _ro_connect(db_path: Path) -> Optional[sqlite3.Connection]:
    if not db_path.is_file():
        return None
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=2.0)
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error:
        return None


def _query(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
    try:
        rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.Error:
        return []


def _scalar(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> Any:
    try:
        row = conn.execute(sql, params).fetchone()
        if row is None:
            return None
        return row[0]
    except sqlite3.Error:
        return None


_CORE_TABLES = ("catalog", "health", "decisions", "events")


def _core_tables_missing(conn: sqlite3.Connection) -> Optional[list[str]]:
    """None when the catalog cannot be read at all (unreadable/corrupt)."""
    try:
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"
        ).fetchall()
        present = {r[0] for r in rows}
    except sqlite3.Error:
        return None
    return [t for t in _CORE_TABLES if t not in present]


# ---------------------------------------------------------------------------
# shared row assembly
# ---------------------------------------------------------------------------

def _availability(health: Optional[dict[str, Any]], now: float) -> tuple[bool, Optional[str]]:
    """Mirror of StateStore.is_available() over a ro health row snapshot.

    Kept deliberately tiny; ``tests/test_dashboard_state_reader.py`` asserts
    this agrees with ``StateStore.is_available()`` on seeded rows.
    """
    if not health:
        return True, None
    if health.get("reason") == "health_invalid":
        return False, "health data unavailable (invalid stored values)"
    if int(health.get("retired") or 0):
        return False, "retired (provider returned 404/410)"
    if int(health.get("auth_failed") or 0):
        return False, "authentication failed (provider returned 401/403)"
    if float(health.get("cooldown_until") or 0) > now:
        until = float(health.get("cooldown_until") or 0)
        return False, f"cooling down until {int(until)}"
    return True, None


def _health_map(conn: sqlite3.Connection, now=None, credential_scopes=None) -> dict[tuple[str, str], dict[str, Any]]:
    rows = _query(
        conn,
        """SELECT provider, model, key_scope, successes, failures, consecutive_failures,
                  last_status, last_error, last_latency_ms, last_success_at, last_failure_at,
                  cooldown_until, retired, auth_failed
           FROM health WHERE key_scope = ''""",
    )
    result = {(r["provider"], r["model"]): r for r in rows}
    health_mod = _load_submodule("health")
    shim = _ReadOnlyStoreShim(conn)
    keys = set(result) | {(r["provider"], r["model"]) for r in _catalog_map(conn)}
    for provider, model in keys:
        observed = health_mod.decision(shim, provider, model, (credential_scopes or {}).get(provider, ""), now=now)
        result[(provider, model)] = dict(observed["health"], available=observed["available"],
            circuit_state=observed["circuit"], reason=observed["reason"], scope_state=observed["scope"])
    return result


def _catalog_map(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    return _query(
        conn,
        """SELECT provider, model, context_length, capabilities, cost_tier, updated_at
           FROM catalog ORDER BY provider, model""",
    )


def _availability_counts(catalog: list[dict[str, Any]], health: dict[tuple[str, str], dict[str, Any]],
                         now: float) -> dict[str, int]:
    counts = {"healthy": 0, "health_unknown": 0, "cooldown": 0, "retired": 0, "auth_failed": 0, "health_invalid": 0}
    for row in catalog:
        h = health.get((row.get("provider"), row.get("model")))
        ok, _reason = _availability(h, now)
        if ok:
            stamp = (h or {}).get("last_success_at")
            observed = type(stamp) in (int,float) and 0 < stamp <= now and now-stamp < 7*86400 and stamp >= ((h or {}).get("last_failure_at") or 0) and (h or {}).get("circuit_state") != "half_open"
            counts["healthy" if observed else "health_unknown"] += 1
        elif h and h.get("reason") == "health_invalid":
            counts["health_invalid"] += 1
        elif h and int(h.get("retired") or 0):
            counts["retired"] += 1
        elif h and int(h.get("auth_failed") or 0):
            counts["auth_failed"] += 1
        else:
            counts["cooldown"] += 1
    return counts


# ---------------------------------------------------------------------------
# Overview tab
# ---------------------------------------------------------------------------

# Canonical include/exclude keys for catalog entries: "provider/model".
_MODEL_KEY = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}/[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}$")
MAX_MODEL_KEYS = 512


def _last_decision(conn: sqlite3.Connection, catalog_by_key: dict, health: dict, now: float):
    rows = _query(
        conn,
        "SELECT ts, policy, provider, model, reason, candidates FROM decisions"
        " ORDER BY ts DESC LIMIT 1",
    )
    if not rows:
        return None
    row = rows[0]
    provider = row.get("provider")
    model = row.get("model")
    facts = None
    catalog_row = catalog_by_key.get((provider, model))
    if catalog_row is not None:
        caps = catalog_row.get("capabilities")
        if isinstance(caps, str):
            try:
                caps = json.loads(caps)
            except Exception:
                caps = {}
        catalog_row = dict(catalog_row, capabilities=caps)
        health_row = health.get((provider, model)) or {}
        facts = {
            "context_length": _int(catalog_row.get("context_length")),
            "cost_tier": scrub(str(catalog_row.get("cost_tier") or "unknown"), 24),
            "tools": _tool_label(caps if isinstance(caps, dict) else {}),
            "circuit_state": scrub(str(health_row.get("circuit_state") or "closed"), 16),
            "health_reason": scrub(str(health_row.get("reason") or "health_unknown"), 32),
            "last_success_at": _num(health_row.get("last_success_at")),
        }
    return {
        "ts": _num(row.get("ts")),
        "policy": scrub(row.get("policy"), 40),
        "provider": scrub(provider, 80),
        "model": scrub(model, 160),
        "reason": scrub(row.get("reason"), 80),
        "candidates": _int(row.get("candidates")),
        "facts": facts,
    }


def _active_routing_profile(db_path):
    """Read-only active profile descriptor for the overview payload."""
    try:
        conn = _ro_connect(db_path)
        if conn is None:
            return None
        try:
            row = conn.execute("SELECT value FROM meta WHERE key = 'active_routing_profile'").fetchone()
        finally:
            conn.close()
    except Exception:
        return None
    profile_id = row["value"] if row else None
    if not profile_id:
        return None
    try:
        conn = _ro_connect(db_path)
        if conn is None:
            return {'id': profile_id}
        try:
            prow = conn.execute("SELECT name, ranking_policy, providers, min_context, requires_tools, updated_at FROM routing_profiles WHERE id = ?", (profile_id,)).fetchone()
        finally:
            conn.close()
    except Exception:
        return {'id': profile_id}
    if prow is None:
        return {'id': profile_id, 'missing': True}
    try:
        import json as _json
        providers = _json.loads(prow['providers']) if isinstance(prow['providers'], str) else []
    except Exception:
        providers = []
    return {'id': profile_id, 'name': scrub(prow['name'], 80), 'ranking_policy': scrub(prow['ranking_policy'], 40),
            'providers': [scrub(p, 64) for p in providers][:16], 'min_context': _int(prow['min_context']),
            'requires_tools': bool(prow['requires_tools']), 'updated_at': _num(prow['updated_at']),
            'scope': 'global_default',
            'scope_note': ('Default routing profile for sessions created after activation; sessions already '
                           'running keep their resolved model; /resume re-resolves with the current default. '
                           'Never changes the global Hermes default model.')}


def assemble_overview(now: Optional[float] = None) -> dict[str, Any]:
    now = time.time() if now is None else now
    cfg = read_plugin_config()
    values = cfg["values"]
    db_path = _db_path(values)
    unavailable: list[str] = []

    payload: dict[str, Any] = {
        "available": True,
        "generated_at": now,
        "plugin": {
            "enabled": bool(values.get("enabled")) if cfg["available"] else None,
            "policy": scrub(values.get("policy"), 40),
            "free_only": True,
            "cooldown_seconds": _int(values.get("cooldown_seconds")),
            "providers": [scrub(p, 64) for p in (values.get("providers") or [])],
            "paid_authorized_deprecated": bool(values.get("paid_authorized")),
            "paid_inference": "disabled",
            "config_managed": bool(cfg["managed"]),
            "config_readable": bool(cfg["available"]),
        },
        "virtual_pin_guard": _virtual_pin_guard(db_path),
        "active_routing_profile": _active_routing_profile(db_path),
        "routing": {
            "chat_routing_enabled": bool(values.get("enable_chat_router")),
            "chat_routing_state": _chat_routing_state(values, _activation_marker(db_path)),
            "runtime_activation": _runtime_activation(values, _activation_marker(db_path)),
            "policy": scrub(values.get("policy"), 40),
            "min_context": _int(values.get("min_context")),
            "requires_tools": bool(values.get("requires_tools")),
            "providers": [scrub(p, 64) for p in (values.get("providers") or [])],
            "cooldown_seconds": _int(values.get("cooldown_seconds")),
            "model_include": [scrub(v, 240) for v in effective_model_preference(values)["include"]],
            "model_exclude": [scrub(v, 240) for v in effective_model_preference(values)["exclude"]],
            "last_decision": None,
        },
        "counts": None,
        "last_catalog_refresh": None,
        "recent_decisions": [],
        "recent_failures": [],
        "unavailable": unavailable,
    }

    conn = _ro_connect(db_path)
    if conn is None:
        payload["available"] = False
        payload["reason"] = (
            "AutoRouter state database not initialized yet"
            if not db_path.is_file()
            else "AutoRouter state database could not be opened (unreadable or corrupt)"
        )
        unavailable.extend(["counts", "last_catalog_refresh", "recent_decisions", "recent_failures"])
        return payload

    missing = _core_tables_missing(conn)
    if missing is None or missing:
        conn.close()
        payload["available"] = False
        payload["reason"] = (
            "AutoRouter state database could not be read (unreadable or corrupt)"
            if missing is None
            else "AutoRouter state database is missing required tables (" + ", ".join(missing) + ")"
        )
        unavailable.extend(["counts", "last_catalog_refresh", "recent_decisions", "recent_failures"])
        return payload

    try:
        catalog = _catalog_map(conn)
        health = _health_map(conn, now=now, credential_scopes=values.get("credential_scopes"))
        avail = _availability_counts(catalog, health, now)

        total_successes = _scalar(conn, "SELECT COALESCE(SUM(successes), 0) FROM health") or 0
        total_failures = _scalar(conn, "SELECT COALESCE(SUM(failures), 0) FROM health") or 0
        decisions = _scalar(conn, "SELECT COUNT(*) FROM decisions")
        events = _scalar(conn, "SELECT COUNT(*) FROM events")

        last_refresh = _scalar(conn, "SELECT MAX(updated_at) FROM catalog")
        if last_refresh is None:
            last_refresh = _scalar(conn, "SELECT MAX(ts) FROM lkg_catalog")

        payload["counts"] = {
            "discovered_models": len(catalog),
            "providers": len({r.get("provider") for r in catalog}),
            "healthy": avail["healthy"],
            "health_unknown": avail["health_unknown"],
            "cooldown": avail["cooldown"],
            "retired": avail["retired"],
            "auth_failed": avail["auth_failed"],
            "health_invalid": avail["health_invalid"],
            "successes": int(total_successes),
            "failures": int(total_failures),
            "decisions": _int(decisions),
            "events": _int(events),
        }
        payload["last_catalog_refresh"] = _num(last_refresh)
        catalog_by_key = {(r.get("provider"), r.get("model")): r for r in catalog}
        payload["routing"]["last_decision"] = _last_decision(conn, catalog_by_key, health, now)

        payload["recent_decisions"] = [
            {
                "ts": _num(r.get("ts")),
                "policy": scrub(r.get("policy"), 40),
                "provider": scrub(r.get("provider"), 80),
                "model": scrub(r.get("model"), 160),
                "reason": scrub(r.get("reason"), 80),
                "candidates": _int(r.get("candidates")),
            }
            for r in _query(
                conn,
                "SELECT ts, policy, provider, model, reason, candidates"
                " FROM decisions ORDER BY ts DESC LIMIT ?",
                (MAX_RECENT,),
            )
        ]

        payload["recent_failures"] = [
            {
                "ts": _num(r.get("last_failure_at")),
                "provider": scrub(r.get("provider"), 80),
                "model": scrub(r.get("model"), 160),
                "failures": _int(r.get("failures")),
                "status_code": _int(r.get("last_status")),
                "error": scrub(_load_submodule("state").safe_health_error(r.get("last_error")), 240),
            }
            for r in _query(
                conn,
                "SELECT provider, model, failures, last_status, last_error, last_failure_at"
                " FROM health WHERE failures > 0 AND key_scope = ''"
                " ORDER BY COALESCE(last_failure_at, 0) DESC LIMIT ?",
                (MAX_RECENT,),
            )
        ]
    except sqlite3.Error:
        payload["available"] = False
        payload["reason"] = "AutoRouter state database could not be read (unreadable or corrupt)"
        unavailable.extend(["counts", "last_catalog_refresh", "recent_decisions", "recent_failures"])
    finally:
        conn.close()
    return payload


# ---------------------------------------------------------------------------
# Providers tab
# ---------------------------------------------------------------------------

def _auth_presence(provider: str) -> str:
    """Existence-only check of the provider profile's declared env vars.

    Returns "configured", "missing" or "unknown". Variable *values* are never
    read, logged or returned.
    """
    try:
        import providers  # provided by Hermes at runtime; absent in unit tests

        profile = providers.get_provider_profile(provider)
    except Exception:
        return "unknown"
    if profile is None:
        return "unknown"
    env_vars = list(getattr(profile, "env_vars", ()) or ())
    if not env_vars:
        return "unknown"
    for var in env_vars:
        try:
            if os.environ.get(var):
                return "configured"
        except Exception:
            continue
    return "missing"


def assemble_providers(now: Optional[float] = None) -> dict[str, Any]:
    now = time.time() if now is None else now
    cfg = read_plugin_config()
    values = cfg["values"]
    configured = [scrub(p, 64) for p in (values.get("providers") or [])]
    db_path = _db_path(values)

    payload: dict[str, Any] = {
        "available": True,
        "generated_at": now,
        "providers": [],
        "unavailable": [],
    }

    conn = _ro_connect(db_path)
    catalog: list[dict[str, Any]] = []
    health: dict[tuple[str, str], dict[str, Any]] = {}
    if conn is not None:
        missing = _core_tables_missing(conn)
        if missing is None or missing:
            conn.close()
            payload["available"] = False
            payload["reason"] = (
                "AutoRouter state database could not be read (unreadable or corrupt)"
                if missing is None
                else "AutoRouter state database is missing required tables (" + ", ".join(missing) + ")"
            )
            payload["unavailable"].append("database")
            conn = None
    if conn is not None:
        try:
            catalog = _catalog_map(conn)
            health = _health_map(conn, now=now, credential_scopes=values.get("credential_scopes"))
        except sqlite3.Error:
            payload["unavailable"].append("database")
        finally:
            conn.close()
    else:
        if not db_path.is_file():
            payload["unavailable"].append("database")
            payload["reason"] = "AutoRouter state database not initialized yet"
        else:
            payload["available"] = False
            payload["reason"] = "AutoRouter state database could not be opened (unreadable or corrupt)"

    by_provider: dict[str, list[dict[str, Any]]] = {}
    for row in catalog:
        by_provider.setdefault(row.get("provider") or "unknown", []).append(row)

    seen = list(dict.fromkeys([*configured, *sorted(by_provider.keys())]))
    for name in seen:
        rows = by_provider.get(name, [])
        avail = _availability_counts(rows, health, now)
        successes = failures = 0
        last_success = last_failure = last_refresh = None
        last_error = None
        for row in rows:
            h = health.get((row.get("provider"), row.get("model"))) or {}
            successes += int(h.get("successes") or 0)
            failures += int(h.get("failures") or 0)
            ls = _num(h.get("last_success_at"))
            lf = _num(h.get("last_failure_at"))
            last_success = max([v for v in (last_success, ls) if v is not None], default=None)
            if lf is not None and (last_failure is None or lf >= last_failure):
                last_failure = lf
                last_error = scrub(h.get("last_error"), 240)
            ru = _num(row.get("updated_at"))
            if ru is not None:
                last_refresh = max([v for v in (last_refresh, ru) if v is not None], default=None)
        payload["providers"].append(
            {
                "name": name,
                "configured": name in configured,
                "discovered_models": len(rows),
                "healthy": avail["healthy"],
            "health_unknown": avail["health_unknown"],
                "cooldown": avail["cooldown"],
                "retired": avail["retired"],
                "auth_failed": avail["auth_failed"],
                "health_invalid": avail["health_invalid"],
                "successes": successes,
                "failures": failures,
                "last_catalog_refresh": last_refresh,
                "last_success_at": last_success,
                "last_failure_at": last_failure,
                "last_error": last_error,
                "auth": _auth_presence(name),
            }
        )
    try:
        details = _load_submodule("provider_intelligence")
        models = assemble_models(now=now)
        payload["intelligence"] = details.registry_details(configured, models.get("models", []))
        payload["intelligence"]["models_truncated"] = models.get("truncated", False)
        for provider in payload["providers"]:
            provider_models = [m for m in models.get("models", []) if m["provider"] == provider["name"]]
            provider["free_access_states"] = sorted({(m.get("free_access") or {}).get("state", "unknown") for m in provider_models}) or ["unknown"]
            provider["quota_evidence"] = [q for m in provider_models for q in (m.get("free_access") or {}).get("quota_evidence", [])][:10]
    except Exception:
        payload["unavailable"].append("provider_intelligence")
    try:
        payload["connection_inventory"] = assemble_connections(now=now)
    except Exception:
        payload["connection_inventory"] = {"available": False, "reason": "Credential presence is unavailable"}
    return payload


# ---------------------------------------------------------------------------
# Models tab
# ---------------------------------------------------------------------------

def _tool_label(capabilities: Any) -> str:
    caps = capabilities if isinstance(capabilities, dict) else {}
    tools = caps.get("tools")
    if tools is True or tools == "supported":
        return "supported"
    if tools is False or tools == "unsupported":
        return "unsupported"
    return "unknown"


def _vision_label(vision: Any) -> str:
    if vision is True or vision == "supported":
        return "supported"
    if vision is False or vision == "unsupported":
        return "unsupported"
    return "unknown"


class _ReadOnlyStoreShim:
    """Router evidence/health/scoring facade over an already-open ro connection.

    Reuses the same bounded scoring SQL as normal and snapshot stores.
    Performs no writes, initialization, index migration or file creation.
    """

    def __init__(self, conn: sqlite3.Connection):
        self._conn = conn

    def get_capability(self, provider: str, model: str):
        try:
            row = self._conn.execute(
                "SELECT capability_json, expires_at FROM capabilities"
                " WHERE provider = ? AND model = ?",
                (provider, model),
            ).fetchone()
        except sqlite3.Error:
            return None
        if row is None:
            return None
        return {"capability_json": row[0], "expires_at": row[1]}


    def get_scoring_observations(self, provider, model, key_scope=""):
        return _load_submodule("state").read_scoring_observations(self._conn, provider, model, key_scope)

    def get_health(self, provider, model, key_scope=""):
        return _load_submodule("state").read_health_observation(self._conn, provider, model, key_scope)

    def get_health_circuits(self, provider, model, scope=""):
        return _query(self._conn, "SELECT * FROM health_circuits WHERE provider=? AND "
            "(layer='provider' OR (layer='model' AND model=?) OR (layer='credential' AND scope=?) "
            "OR (layer='connection' AND model=? AND scope=?))", (provider, model, scope, model, scope))

    def get_in_flight(self, provider, model):
        # Legacy stores may not expose concurrency observations.
        rows = _query(self._conn, "SELECT reserved FROM in_flight WHERE provider=? AND model=?",
                      (provider, model))
        return rows[0].get("reserved") if rows else None


def _scrub_preview(value):
    if isinstance(value, dict):
        return {k: _scrub_preview(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_scrub_preview(v) for v in value]
    return scrub(value) if isinstance(value, str) else value


_SELECTION_UNSET = object()


def _assemble_models_base(now: Optional[float], selection_policy) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    cfg = read_plugin_config()
    values = cfg["values"]
    free_only = bool(values.get("free_only", True))
    db_path = _db_path(values)

    payload: dict[str, Any] = {
        "available": True,
        "generated_at": now,
        "models": [],
        "truncated": False,
        "free_only": free_only,
        "unavailable": [],
    }

    report_mod = _load_submodule("decision_report")
    payload["evidence_report"] = report_mod.unavailable("evidence_unavailable", now)
    conn = _ro_connect(db_path)
    if conn is None:
        payload["evidence_report"] = report_mod.unavailable("database_unreadable" if db_path.is_file() else "database_missing", now)
        if not db_path.is_file():
            payload["reason"] = "AutoRouter state database not initialized yet"
        else:
            payload["available"] = False
            payload["reason"] = "AutoRouter state database could not be opened (unreadable or corrupt)"
        payload["unavailable"].append("models")
        return payload, []
    missing = _core_tables_missing(conn)
    if missing is None or missing:
        conn.close()
        payload["available"] = False
        payload["reason"] = (
            "AutoRouter state database could not be read (unreadable or corrupt)"
            if missing is None
            else "AutoRouter state database is missing required tables (" + ", ".join(missing) + ")"
        )
        payload["unavailable"].append("models")
        return payload, []

    try:
        try:
            eligibility_mod = _load_submodule("eligibility")
            router_mod = _load_submodule("router")
        except Exception:
            payload["available"] = False
            payload["reason"] = "AutoRouter modules could not be loaded"
            payload["unavailable"].append("eligibility")
            return payload, []

        catalog = _catalog_map(conn)
        health = _health_map(conn, now=now, credential_scopes=values.get("credential_scopes"))
        catalog_refreshed_at = {(row.get("provider"), row.get("model")): _num(row.get("updated_at")) for row in catalog}
        provider_options = sorted({str(r.get("provider") or "unknown") for r in catalog})
        payload["provider_options"] = provider_options

        # Build raw candidates from the read-only snapshot, then apply the same
        # capability-record merge the router uses for selection.
        raw_candidates = []
        for r in catalog:
            caps = r.get("capabilities")
            if isinstance(caps, str):
                try:
                    caps = json.loads(caps)
                except Exception:
                    caps = None
            raw_candidates.append(
                {
                    "provider": r.get("provider"),
                    "model": r.get("model"),
                    "context_length": r.get("context_length"),
                    "capabilities": caps,
                    "cost_tier": r.get("cost_tier"),
                }
            )
        state = dict(values)
        state["store"] = _ReadOnlyStoreShim(conn)
        try:
            router = router_mod.Router(state)
            candidates = router._resolved_candidates(raw_candidates, now=now)
            preview = router._evaluate(candidates, now=now, limit=min(max(1, len(candidates)), 50000), **({"selection_policy": selection_policy} if selection_policy is not _SELECTION_UNSET else {}))
            # Evaluate the whole snapshot, but publish only the leading slice:
            # the evidence contract on `preview.considered` caps at 500 rows.
            consider_full = preview.get("considered") or []
            ranked_full = preview.get("ranked") or []
            preview["considered"] = consider_full[:MAX_MODELS]
            preview["ranked"] = ranked_full[:MAX_MODELS]
            preview["truncated"] = len(consider_full) > MAX_MODELS
            payload["preview"] = _scrub_preview(preview)
            payload["evidence_report"] = payload["preview"]["evidence_report"]
            preview_rows = {(c["provider"], c["model"]): c for c in consider_full}
            model_details = {}
            model_visions = {}
            for c in sorted(candidates, key=lambda row: (row["provider"], row["model"])):
                try:
                    raw = state["store"].get_capability(c["provider"], c["model"])
                    cap = json.loads(raw["capability_json"]) if raw else {}
                    model_details[(c["provider"], c["model"])] = _load_submodule("provider_intelligence").model_details(cap, now, scrub)
                    caps_ev = cap.get("capabilities") if isinstance(cap.get("capabilities"), dict) else {}
                    vision = cap.get("vision", caps_ev.get("vision"))
                    model_visions[(c["provider"], c["model"])] = _vision_label(vision)
                except Exception:
                    model_details[(c["provider"], c["model"])] = {}
                    model_visions[(c["provider"], c["model"])] = "unknown"
            health_decisions = { (c["provider"], c["model"]):
                _load_submodule("health").decision(state["store"], c["provider"], c["model"], (state.get("credential_scopes") or {}).get(c["provider"], ""), now=now)
                for c in candidates }
        except Exception:
            candidates = []
    finally:
        conn.close()

    rows = []
    for c in sorted(candidates, key=lambda row: (row["provider"], row["model"])):
        row_provider = scrub(c.get("provider"), 80) or "unknown"
        model = scrub(c.get("model"), 160) or "unknown"
        h = health.get((c.get("provider"), c.get("model")))
        health_decision = health_decisions.get((c.get("provider"), c.get("model")), {})
        available = health_decision.get("available", True)
        avail_reason = health_decision.get("reason") if not available else None
        h = health_decision.get("health", h)
        caps = c.get("capabilities") if isinstance(c.get("capabilities"), dict) else {}
        ctx_len = _int(c.get("context_length"))
        cost_tier = (str(c.get("cost_tier") or "unknown").lower())[:24]

        reasons: list[str] = []
        if not available and avail_reason:
            reasons.append(avail_reason)
        ctx_ok = eligibility_mod.has_sufficient_context(c.get("context_length"), 8192)
        if not ctx_ok:
            reasons.append(
                "context length unknown or below 8192"
                if c.get("context_length") is None
                else "context length below 8192"
            )
        cost_ok = eligibility_mod.cost_allowed(cost_tier, free_only, False)
        if not cost_ok:
            reasons.append(f"cost tier '{cost_tier}' is not eligible (only verified free tier is admitted)")

        base_ok = (
            eligibility_mod.is_eligible(
                c, requires_tools=False, min_context=8192,
                free_only=free_only, paid_authorized=False, store=None,
            )
            and available
        )
        tool_capable = eligibility_mod.is_tool_capable(c.get("provider"), c.get("model"), caps)
        evaluated = preview_rows.get((c["provider"], c["model"]), {})
        base_ok = evaluated.get("eligible", False)
        reasons = evaluated.get("reasons", reasons)
        details = model_details.get((c["provider"], c["model"]), {})

        rows.append(
            {
                "provider": row_provider,
                "model": model,
                **details,
                "free_access": _scrub_preview(evaluated.get("free_access")),
                "reason_codes": evaluated.get("reason_codes", []),
                "context_length": ctx_len,
                "metadata_source": scrub(c.get("metadata_source")),
                "retrieved_at": _num(c.get("retrieved_at")),
                "metadata_freshness": scrub(c.get("metadata_freshness")),
                "field_freshness": c.get("field_freshness", {}),
                "field_evidence": {key: {k: scrub(v) if k == "metadata_source" else _num(v) for k, v in info.items()} for key, info in c.get("field_evidence", {}).items()},
                "cost_tier": cost_tier,
                "tools": _tool_label(caps),
                "eligible": bool(base_ok),
                "reasons": reasons,
                "health": {
                    "available": available,
                    "guidance": evaluated.get("health_guidance"),
                    "verified_quota_exhausted": "verified_account_quota_exhausted" in evaluated.get("reason_codes", []),
                    "circuit_state": health_decision.get("circuit", "closed"),
                    "reason": health_decision.get("reason", "health_unknown"),
                    "scope_state": health_decision.get("scope", "scope_unknown"),
                    "successes": _int((h or {}).get("successes")),
                    "failures": _int((h or {}).get("failures")),
                    "consecutive_failures": _int((h or {}).get("consecutive_failures")),
                    "cooldown_until": _num((h or {}).get("cooldown_until")),
                    "retired": bool(int((h or {}).get("retired") or 0)),
                    "auth_failed": bool(int((h or {}).get("auth_failed") or 0)),
                    "last_success_at": _num((h or {}).get("last_success_at")),
                    "last_failure_at": _num((h or {}).get("last_failure_at")),
                    "last_error": scrub((h or {}).get("last_error"), 240),
                    "last_latency_ms": _int((h or {}).get("last_latency_ms")),
                },
                "catalog_refreshed_at": catalog_refreshed_at.get((c.get("provider"), c.get("model"))),
                "vision": model_visions.get((c["provider"], c["model"]), "unknown"),
                "tool_capable": bool(tool_capable),
            }
        )

    rows.sort(key=lambda r: (str(r.get("provider") or ""), str(r.get("model") or "")))
    try:
        payload["preference"] = _annotate_preferences(rows, values)
    except Exception:
        logger.warning("autorouter dashboard: model preference annotation failed", exc_info=True)
        payload["preference"] = {"available": False}
    return payload, rows




_MODELS_CACHE_TTL_SECONDS = 30.0
_MODELS_CACHE_MAX_ENTRIES = 8
_models_cache: dict[tuple, dict] = {}


def _sig_of(path):
    try:
        stat = path.stat()
        return (path.name, stat.st_mtime_ns, stat.st_size)
    except OSError:
        return (path.name, None, None)


def _store_files(db_path):
    """Main DB plus its WAL/SHM companions; WAL writers change the companion's
    mtime/size, not necessarily the main file's."""
    db_path = Path(db_path)
    return [db_path, db_path.with_suffix(db_path.suffix + "-wal"), db_path.with_suffix(db_path.suffix + "-shm")]

def _models_fingerprint(values: dict[str, Any], db_path: Path, now: float):
    """Stable key for the fully-assembled row set (now bucketed to the TTL)."""
    bucket = int(now // _MODELS_CACHE_TTL_SECONDS)
    try:
        providers = tuple(sorted(str(p) for p in (values.get("providers") or [])))
    except Exception:
        providers = ()
    try:
        sig = tuple(_sig_of(p) for p in _store_files(db_path))
    except OSError:
        sig = None
    try:
        # mode=ro (not immutable): WAL stores carry the live state in the
        # -wal file until the last writer checkpoints. immutable=1 cannot
        # open them and would both fail this query and produce stale keys.
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            cat = conn.execute("SELECT COUNT(*), COALESCE(MAX(updated_at),0) FROM catalog").fetchone()
            caps = conn.execute("SELECT COUNT(*), COALESCE(MAX(retrieved_at),0) FROM capabilities").fetchone()
        finally:
            conn.close()
        facts = (tuple(cat or ()), tuple(caps or ()))
    except Exception:
        facts = None
    try:
        scopes = tuple(sorted((values.get("credential_scopes") or {}).items()))
    except Exception:
        scopes = ()
    try:
        ctx_hash = __import__("hashlib").sha256(
            __import__("json").dumps(values.get("connection_contexts"), sort_keys=True, default=str).encode()
        ).hexdigest()
    except Exception:
        ctx_hash = None
    try:
        eff_pref = effective_model_preference(values)
        pref_fp = (eff_pref["mode"], tuple(eff_pref["include"]), tuple(eff_pref["exclude"]))
    except Exception:
        pref_fp = ("unreadable",)
    return (str(db_path), bucket, sig, providers, str(values.get("policy")),
            bool(values.get("free_only", True)), scopes, ctx_hash, facts,
            pref_fp)


def _assemble_models_cached(now: float, selection_policy):
    """Layer-1 assembly with a short-lived cache; callers get deep copies."""
    if selection_policy is not _SELECTION_UNSET:
        return _assemble_models_base(now, selection_policy)
    values = read_plugin_config()["values"]
    db_path = _db_path(values)
    key = _models_fingerprint(values, db_path, now)
    cached = _models_cache.get(key)
    if cached is not None:
        ts, payload, rows = cached
        if time.time() - ts < _MODELS_CACHE_TTL_SECONDS:
            return payload, rows
        _models_cache.pop(key, None)
    payload, rows = _assemble_models_base(now, selection_policy)
    if len(_models_cache) >= _MODELS_CACHE_MAX_ENTRIES:
        oldest = sorted(_models_cache.items(), key=lambda item: item[1][0])[: len(_models_cache) - _MODELS_CACHE_MAX_ENTRIES + 1]
        for old_key, _ in oldest:
            _models_cache.pop(old_key, None)
    _models_cache[key] = (time.time(), payload, rows)
    return payload, rows


def assemble_models(now: Optional[float] = None, selection_policy=_SELECTION_UNSET, *, page: Any = 1,
                    page_size: Any = 50, query: Any = "", provider: Any = "", eligibility: Any = "all",
                    free_only: Any = False, sort: Any = "provider", preference: Any = "all") -> dict[str, Any]:
    now = time.time() if now is None else now
    base, rows = _assemble_models_cached(now, selection_policy)
    payload = dict(base)
    catalog_size = len(rows)
    rows = _models_filter(rows, query=query, provider=provider, eligibility=eligibility,
                          free_only=bool(free_only), cost_tier=None, preference=str(preference or "all"))
    rows = _models_sort(rows, sort)
    return _models_paginate(payload, rows, page=page, page_size=page_size, catalog_size=catalog_size)


def _models_filter(rows, *, query="", provider="", eligibility="all", free_only=True, cost_tier=None,
                   preference="all"):
    """Filter the *full* enriched catalog (never just the published page)."""
    q = query.strip().lower() if isinstance(query, str) else ""
    prov = provider.strip().lower() if isinstance(provider, str) else ""
    if isinstance(cost_tier, str) and cost_tier.strip():
        wanted_cost = cost_tier.strip().lower()
        rows = [r for r in rows if (str(r.get("cost_tier") or "").lower() == wanted_cost)]
    if prov:
        rows = [r for r in rows if str(r.get("provider") or "").lower() == prov]
    if free_only:
        rows = [r for r in rows if (str(r.get("cost_tier") or "").lower() == "free")]
    if eligibility == "eligible":
        rows = [r for r in rows if r.get("eligible") is True]
    elif eligibility == "ineligible":
        rows = [r for r in rows if r.get("eligible") is not True]
    pref = (preference or "all").strip().lower()
    if pref == "on":
        rows = [r for r in rows if r.get("user_preference") == "on"]
    elif pref == "off":
        rows = [r for r in rows if r.get("user_preference") == "off"]
    if q:
        rows = [r for r in rows if q in (str(r.get("provider") or "") + " " + str(r.get("model") or "")).lower()]
    return rows


def _models_sort(rows, sort):
    """Deterministic order; (provider, model) tie-break everywhere."""
    def ctx(r):
        value = r.get("context_length")
        return value if isinstance(value, int) and not isinstance(value, bool) else None

    cost_rank = {"free": 0, "unknown": 1, "paid": 2, "premium": 3}

    def key_for(r):
        base = (str(r.get("provider") or ""), str(r.get("model") or ""))
        if sort == "context_desc":
            v = ctx(r)
            return (v is None, -(v or 0), *base)
        if sort == "context_asc":
            v = ctx(r)
            return (v is None, v if v is not None else 2**62, *base)
        if sort == "cost":
            return (cost_rank.get(str(r.get("cost_tier") or "unknown").lower(), 4), *base)
        if sort == "health":
            return (0 if (r.get("health") or {}).get("available", True) is not False else 1, *base)
        if sort == "eligibility":
            return (0 if r.get("eligible") is True else 1, *base)
        return base

    return sorted(rows, key=key_for)


_SORTS = {"provider", "context_desc", "context_asc", "cost", "health", "eligibility"}


def _models_paginate(payload, rows, *, page, page_size, catalog_size):
    try:
        size = int(page_size)
    except (TypeError, ValueError):
        size = 50
    size = min(max(size, 1), 200)
    try:
        p = int(page)
    except (TypeError, ValueError):
        p = 1
    total = len(rows)
    total_pages = max(1, (total + size - 1) // size) if total else 1
    p = min(max(p, 1), total_pages)
    start_idx = (p - 1) * size
    window = rows[start_idx:start_idx + size]
    payload["models"] = window
    payload["page"] = p
    payload["page_size"] = size
    payload["total"] = total
    payload["total_catalog"] = catalog_size
    payload["total_pages"] = total_pages
    payload["truncated"] = False
    payload["filtered"] = True
    return payload


# ---------------------------------------------------------------------------
# Model preference (user inclusion/exclusion) — shared by /models and the
# toggle endpoints. The user's on/off choice is a preference, never an
# eligibility gate; verified-free-only and authorization are untouched here.
# ---------------------------------------------------------------------------

_MODEL_KEY_RE = re.compile(r"^([a-z0-9][a-z0-9_-]{0,63})/([A-Za-z0-9][A-Za-z0-9._:/-]{0,199})$")
_ROUTING_PROFILE_META_KEY = "active_routing_profile"
_MAX_TOGGLE_OPS = 200


def _model_pair(value):
    if not isinstance(value, str):
        return None
    match = _MODEL_KEY_RE.match(value.strip())
    if not match:
        return None
    return (match.group(1).strip().lower(), match.group(2).strip())


def _pairs(value):
    pairs = set()
    for item in value or []:
        pair = _model_pair(item)
        if pair:
            pairs.add(pair)
    return pairs


def _parse_model_preference(blob: Any) -> tuple[Optional[dict[str, Any]], Optional[str]]:
    """Strictly validate the single-key ``model_preference`` value.

    Returns ``(parsed, None)`` on success or ``(None, reason)`` on any
    violation. ``parsed`` carries normalized ``include_pairs``/``exclude_pairs``
    plus the ``mode``. Anything unrecognized fails closed — the caller must
    never treat an invalid blob as unrestricted.
    """
    if not isinstance(blob, dict):
        return None, "model_preference must be an object"
    version = blob.get("version", 1)
    if version != 1:
        return None, f"model_preference version {version!r} is not supported"
    mode = blob.get("mode")
    if mode not in ("none", "allowlist", "unrestricted"):
        return None, "model_preference mode must be one of 'none', 'allowlist', 'unrestricted'"

    def _pairs_or_error(raw, key):
        if raw is None:
            return set(), None
        if not isinstance(raw, list):
            return None, f"model_preference {key} must be a list"
        if len(raw) > MAX_MODEL_KEYS:
            return None, f"model_preference {key} may not exceed {MAX_MODEL_KEYS} entries"
        pairs: set[tuple[str, str]] = set()
        for item in raw:
            pair = _model_pair(item)
            if pair is None:
                return None, f"model_preference {key} entries must be 'provider/model'"
            pairs.add(pair)
        return pairs, None

    inc, err = _pairs_or_error(blob.get("include"), "include")
    if err:
        return None, err
    exc, err = _pairs_or_error(blob.get("exclude"), "exclude")
    if err:
        return None, err
    if mode == "allowlist" and not inc:
        return None, "model_preference allowlist mode requires a non-empty include list"
    if mode == "none":
        inc = set()
    return {"mode": mode, "include_pairs": inc, "exclude_pairs": exc}, None


def effective_model_preference(values: dict[str, Any]) -> dict[str, Any]:
    """Resolve the effective preference from plugin ``values``.

    The single-key ``model_preference`` is authoritative when present. When it
    is absent (legacy installs), the two legacy keys are read with the legacy
    semantics (a non-empty include list implies allowlist mode). An invalid
    ``model_preference`` fails closed to mode ``none`` — never to unrestricted.
    """
    blob = values.get("model_preference")
    if blob is not None:
        parsed, err = _parse_model_preference(blob)
        if err:
            logger.warning("autorouter dashboard: %s; treating every model as disabled", err)
            exc = set()
            try:
                raw_exc = blob.get("exclude") if isinstance(blob, dict) else []
                if isinstance(raw_exc, list):
                    exc = {p for p in (_model_pair(i) for i in raw_exc) if p}
            except Exception:
                exc = set()
            return {
                "mode": "none",
                "include_pairs": set(),
                "exclude_pairs": exc,
                "include": [],
                "exclude": sorted(f"{p}/{m}" for p, m in exc),
                "source": "model_preference",
                "error": err,
            }
        return {
            "mode": parsed["mode"],
            "include_pairs": parsed["include_pairs"],
            "exclude_pairs": parsed["exclude_pairs"],
            "include": sorted(f"{p}/{m}" for p, m in parsed["include_pairs"]),
            "exclude": sorted(f"{p}/{m}" for p, m in parsed["exclude_pairs"]),
            "source": "model_preference",
            "error": None,
        }
    inc = _pairs(values.get("model_include"))
    exc = _pairs(values.get("model_exclude"))
    return {
        "mode": "allowlist" if inc else "unrestricted",
        "include_pairs": inc,
        "exclude_pairs": exc,
        "include": sorted(f"{p}/{m}" for p, m in inc),
        "exclude": sorted(f"{p}/{m}" for p, m in exc),
        "source": "legacy",
        "error": None,
    }


def _unrecognized_legacy_entries(values: dict[str, Any]) -> list[str]:
    out = []
    for key in ("model_include", "model_exclude"):
        for item in values.get(key) or []:
            if _model_pair(item) is None:
                out.append(str(item))
    return out


def model_preference_hash(values: dict[str, Any]) -> str:
    """Stable fingerprint of the effective preference for optimistic concurrency."""
    import hashlib

    eff = effective_model_preference(values)
    payload = json.dumps({"mode": eff["mode"],
                          "model_include": eff["include"],
                          "model_exclude": eff["exclude"]},
                         sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode()).hexdigest()


def _active_profile_context():
    """Return (profile or None, profile_name or None). Never raises."""
    try:
        cfg = read_plugin_config()
        db_path = Path(_db_path(cfg.get("values") or {}))
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute("SELECT value FROM meta WHERE key = ?", (
                _ROUTING_PROFILE_META_KEY,)).fetchone()
            if not row or not isinstance(row["value"], str) or not row["value"]:
                return None, None
            profile_row = conn.execute("SELECT * FROM routing_profiles WHERE id = ?",
                                       (row["value"],)).fetchone()
        finally:
            conn.close()
        if profile_row is None:
            return None, "no row for the configured active routing profile"
        state_mod = _load_submodule("state")
        profile = state_mod._row_to_profile(profile_row)
        if not isinstance(profile, dict):
            return None, None
        return profile, scrub(profile.get("name"), 80) or None
    except Exception:
        return None, None


def _merge_include_for_display(values, profile):
    """Display-side replica of profiles.merge_global_and_profile's include/exclude math.

    Used ONLY to annotate rows (eligibility decisions stay in the routing
    engine). Global lists keep their meaning for the toggle UI; profile
    lists only narrow for display. A global none mode yields an empty include
    for display purposes.
    """
    eff = effective_model_preference(values)
    if eff["mode"] == "none":
        g_inc = set()
    else:
        g_inc = eff["include_pairs"]
    g_exc = eff["exclude_pairs"]
    if not isinstance(profile, dict):
        return g_inc, g_exc, None
    p_inc = _pairs(profile.get("model_include"))
    p_exc = _pairs(profile.get("model_exclude"))
    if g_inc and p_inc:
        m_inc = g_inc & p_inc
    else:
        m_inc = p_inc or g_inc
    m_exc = g_exc | p_exc
    return m_inc, m_exc, scrub(profile.get("name"), 80) or None


def _annotate_preferences(rows, values):
    """Annotate catalog rows with the user's preference state (never eligibility)."""
    eff = effective_model_preference(values)
    mode = eff["mode"]
    g_inc = eff["include_pairs"]
    g_exc = eff["exclude_pairs"]
    allowlist = mode == "allowlist"
    profile, profile_name = _active_profile_context()
    p_exc = _pairs(profile.get("model_exclude")) if profile else set()
    p_inc = _pairs(profile.get("model_include")) if profile else set()
    enabled = disabled = blocked = 0
    for row in rows:
        provider = str(row.get("provider") or "").lower()
        model = str(row.get("model") or "")
        pair = (provider, model)
        in_user_exc = pair in g_exc
        in_user_inc = pair in g_inc
        if mode == "none":
            user_on = False
        elif allowlist:
            user_on = pair in g_inc and not in_user_exc
        else:
            user_on = not in_user_exc
        profile_blocked = False
        if profile:
            if pair in p_exc and not in_user_exc:
                profile_blocked = True
            elif p_inc and pair not in p_inc and pair not in g_exc:
                profile_blocked = True
            elif allowlist and pair in g_inc and p_inc and pair not in p_inc:
                profile_blocked = True
        if user_on:
            enabled += 1
            note = None
        else:
            disabled += 1
            if mode == "none" and not in_user_exc:
                note = "no models enabled (all models are toggled off)"
            elif in_user_exc:
                note = "disabled by you"
            elif allowlist and not in_user_inc:
                note = "not in the model allowlist"
            elif profile_blocked:
                note = f"disabled by routing profile '{profile_name}'"
            else:
                note = "disabled"
        if profile_blocked:
            blocked += 1
            if note is None:
                note = f"disabled by routing profile '{profile_name}'"
        row["user_preference"] = "on" if user_on else "off"
        row["preference_note"] = note
        row["allowlist_mode"] = allowlist
        row["blocked_by_profile"] = profile_name if (profile_blocked and profile_name) else None
    return {
        "mode": mode,
        "allowlist_mode": allowlist,
        "enabled_count": enabled,
        "disabled_count": disabled,
        "blocked_by_profile": blocked,
        "profile": profile_name,
        "include_size": len(g_inc),
        "exclude_size": len(g_exc),
        "preference_hash": model_preference_hash(values),
    }


def apply_toggles(values: dict[str, Any], toggles: list[dict[str, Any]]):
    """Compute the new effective preference from toggle operations.

    Semantics (deterministic, documented in ADR-0014):
    * unrestricted mode: enabled=true removes the pair from exclude;
      enabled=false appends it to exclude.
    * allowlist mode: enabled=true removes the pair from exclude and adds it to
      include; enabled=false removes it from include. An include list emptied
      by toggles transitions to the explicit ``none`` mode — never to
      unrestricted.
    * none mode (all models disabled): enabled=true switches to allowlist mode
      with exactly that model; enabled=false is a no-op. Routing refuses to
      select while in none mode — an OFF toggle never broadens selection.

    Returns ``(preference, meta)`` where preference is the single blob to
    persist (mode + include + exclude). Raises ValueError with a message safe
    to surface. Never widens provider authorization.
    """
    eff = effective_model_preference(values)
    if eff["error"]:
        raise ValueError(
            "the stored model_preference is invalid and was not changed; "
            "fix it in the raw settings editor or reset to unrestricted"
        )
    if eff["source"] == "legacy":
        unrecognized = _unrecognized_legacy_entries(values)
        if unrecognized:
            shown = ", ".join(repr(item) for item in unrecognized[:5])
            raise ValueError(
                f"the persisted model_include/model_exclude contain {len(unrecognized)} "
                f"unrecognized entr{'y' if len(unrecognized) == 1 else 'ies'} ({shown}); "
                "these were preserved untouched. Remove or fix them in the raw settings "
                "editor before toggling."
            )

    mode = eff["mode"]
    inc: set[tuple[str, str]] = set(eff["include_pairs"])
    exc: set[tuple[str, str]] = set(eff["exclude_pairs"])

    meta = {"toggles_applied": 0, "mode": mode, "allowlist_emptied": False}

    by_pair: dict[tuple[str, str], bool] = {}
    order: list[tuple[str, str]] = []
    for toggle in toggles:
        pair = _model_pair(f"{toggle.get('provider')}/{toggle.get('model')}")
        if pair is None:
            raise ValueError(f"invalid provider/model '{toggle.get('provider')}/{toggle.get('model')}'")
        if pair not in by_pair:
            order.append(pair)
        by_pair[pair] = bool(toggle.get("enabled"))

    for pair in order:
        enabled = by_pair[pair]
        meta["toggles_applied"] += 1
        if enabled:
            exc.discard(pair)
            if mode == "allowlist":
                inc.add(pair)
            elif mode == "none":
                inc = {pair}
                mode = "allowlist"
            # unrestricted: nothing added to include
        else:
            if mode == "allowlist":
                inc.discard(pair)
                if not inc:
                    # Last allowlist model disabled: explicit none — never unrestricted.
                    mode = "none"
                    meta["allowlist_emptied"] = True
            elif mode == "unrestricted":
                exc.add(pair)
            # none mode: already nothing enabled; OFF is a no-op
    if len(inc) > MAX_MODEL_KEYS or len(exc) > MAX_MODEL_KEYS:
        raise ValueError(f"model lists may not exceed {MAX_MODEL_KEYS} entries (include={len(inc)}, exclude={len(exc)})")
    meta["mode"] = mode
    preference = {
        "version": 1,
        "mode": mode,
        "include": sorted(f"{p}/{m}" for p, m in inc),
        "exclude": sorted(f"{p}/{m}" for p, m in exc),
    }
    return preference, meta


_PREFERENCE_LOCK = threading.Lock()


@contextlib.contextmanager
def _preference_file_lock():
    """Cross-process lock for the model-preference read-modify-write.

    Guards every writer that persists the preference through this module —
    ``threading.Lock`` alone cannot serialize the web process and the Desktop
    plugin process. The lock file lives in the plugin-scoped state directory;
    if that cannot be resolved, a per-plugin-root lock in the system temp dir
    is used so writers still serialize (never silently unlocked).
    """
    lock_path = None
    try:
        cfg = read_plugin_config()
        state_dir = _state_dir(cfg.get("values") or {})
        state_dir.mkdir(parents=True, exist_ok=True)
        lock_path = state_dir / ".model-preference.lock"
    except Exception:
        import hashlib

        digest = hashlib.sha256(str(_PLUGIN_ROOT).encode()).hexdigest()[:16]
        lock_path = Path(tempfile.gettempdir()) / f"autorouter-preference-{digest}.lock"
    with open(lock_path, "a+b") as handle:
        if os.name == "nt":
            import msvcrt

            if handle.seek(0, os.SEEK_END) == 0:
                handle.write(b"\0")
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _save_model_preference_blob(blob: dict[str, Any]) -> None:
    """Persist the preference as ONE key via the sanctioned writer.

    A single ``save_plugin_setting`` call is atomic under Hermes' own
    cross-process lock, so the include/exclude/mode triple can never land as a
    torn or partial multi-key write. Raises SettingsWriteError (saved=[]) if
    the key was refused/failed — nothing was written in that case.
    """
    try:
        from hermes_cli.plugins_state import save_plugin_setting
    except Exception as exc:
        raise RuntimeError("Hermes plugin settings API is not available in this process") from exc

    try:
        save_plugin_setting("autorouter", ("model_preference",), blob)
    except Exception as exc:
        raise SettingsWriteError(
            saved=[], failed="model_preference", reason=exc, remaining=[], original=exc
        ) from exc


def apply_model_preference(toggles: list[dict[str, Any]], base: str,
                           reset: Optional[str] = None) -> dict[str, Any]:
    """Cross-process compare-and-swap read-modify-write of the preference.

    Serializes concurrent writers with a file lock that spans the base-hash
    check, the write and the read-back verification, so two processes can
    never both observe the same base and land conflicting updates: the second
    to arrive sees the first's persisted state and is refused as stale (HTTP
    409) before mutating anything. The preference is a single key, so the
    write is all-or-nothing — there is no partial include/exclude state.

    ``reset='unrestricted'`` is the explicit, separately confirmed way back to
    unrestricted; toggles can never produce it.
    """
    if reset is not None and reset != "unrestricted":
        raise ValueError(f"unsupported reset {reset!r} (expected 'unrestricted')")
    with _PREFERENCE_LOCK, _preference_file_lock():
        cfg = read_plugin_config()
        values = cfg.get("values") or {}
        current_hash = model_preference_hash(values)
        if not isinstance(base, str) or base != current_hash:
            stale = _fresh_preference_view(values)
            stale.update({"ok": False, "stale": True})
            return stale
        if reset == "unrestricted":
            preference = {"version": 1, "mode": "unrestricted", "include": [], "exclude": []}
            meta = {"toggles_applied": 0, "mode": "unrestricted",
                    "allowlist_emptied": False, "reset": True}
        else:
            preference, meta = apply_toggles(values, toggles)
        intended = model_preference_hash({"model_preference": preference})
        if intended == current_hash:
            fresh = _fresh_preference_view(values)
            fresh.update({"ok": True, "changed": False, **meta})
            return fresh
        _save_model_preference_blob(preference)
        fresh_values = read_plugin_config().get("values") or {}
        fresh = _fresh_preference_view(fresh_values)
        fresh.update({"ok": True, "changed": True, **meta})
        if fresh["preference_hash"] != intended:
            # A concurrent non-participating writer (e.g. a raw config edit)
            # landed between our write and this read-back. The persisted
            # state is authoritative; report it, never claim our write won.
            fresh["overwritten"] = True
        return fresh


def _fresh_preference_view(values: dict[str, Any]) -> dict[str, Any]:
    eff = effective_model_preference(values)
    mode = eff["mode"]
    profile, profile_name = _active_profile_context()
    return {
        "model_include": eff["include"],
        "model_exclude": eff["exclude"],
        "mode": mode,
        "allowlist_mode": mode == "allowlist",
        "include_size": len(eff["include_pairs"]),
        "exclude_size": len(eff["exclude_pairs"]),
        "preference_hash": model_preference_hash(values),
        "profile": profile_name,
        **({"preference_error": eff["error"]} if eff.get("error") else {}),
        "restart_note": (
            "Changes take effect on the next routing decision (the selector reads "
            "the persisted preference each time); the catalog view and the decision "
            "ledger refresh within the plugin's short cache window. No gateway "
            "restart is required for inclusion/exclusion changes."
        ),
    }


def assemble_model_preference(now: Optional[float] = None) -> dict[str, Any]:
    """Fresh read-back of the preference lists plus catalog-level counts."""
    try:
        now = time.time() if now is None else now
        base, rows = _assemble_models_cached(now, _SELECTION_UNSET)
        values = read_plugin_config().get("values") or {}
        summary = _fresh_preference_view(values)
        enabled = sum(1 for row in rows if row.get("user_preference") == "on")
        summary.update({
            "available": bool(base.get("available", True)),
            "enabled_count": enabled,
            "disabled_count": len(rows) - enabled,
            "blocked_by_profile": sum(1 for row in rows if row.get("blocked_by_profile")),
            "catalog_size": base.get("total_catalog", len(rows)),
        })
        return summary
    except Exception:
        logger.exception("autorouter dashboard: model preference assembly failed")
        return {"available": False, "reason": "Model preferences could not be read from plugin configuration"}




# Analytics ranges. Mirrors telemetry.ANALYTICS_RANGES; duplicated here
# because this module is loaded standalone by the Hermes plugin loader and must
# not depend on package imports for a constant.
ANALYTICS_RANGES = ("24h", "7d", "30d", "90d", "all")
_RANGE_SECONDS = {
    "24h": 24 * 3600,
    "7d": 7 * 86400,
    "30d": 30 * 86400,
    "90d": 90 * 86400,
    "all": None,
}
MAX_RECENT_REQUESTS = 20
MAX_BREAKDOWN_ROWS = 12
MAX_TIMELINE_BARS = 48
MAX_LATENCY_SAMPLES = 5000

_TELEMETRY_TABLES_REQUIRED = (
    "requests", "request_attempts", "request_hourly",
    "cache_events", "search_events", "credential_scopes", "lifetime_counters",
)


def normalize_range(value: Any) -> str:
    """Return a supported range; unknown values fall back to ``7d``."""
    if isinstance(value, str) and value in ANALYTICS_RANGES:
        return value
    return "7d"


def _telemetry_tables_missing(conn: sqlite3.Connection) -> Optional[list[str]]:
    """None when the catalog cannot be read at all (unreadable/corrupt)."""
    try:
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"
        ).fetchall()
        present = {r[0] for r in rows}
    except sqlite3.Error:
        return None
    return [t for t in _TELEMETRY_TABLES_REQUIRED if t not in present]


def _percentile(sorted_values: list[float], fraction: float) -> Optional[float]:
    """Nearest-rank percentile (same rule as telemetry.percentile)."""
    if not sorted_values:
        return None
    import math
    offset = max(0, min(len(sorted_values) - 1, math.ceil(len(sorted_values) * fraction) - 1))
    return sorted_values[offset]


def _p_stats(samples: list[float]) -> dict[str, Any]:
    """avg / p50 / p95 / sample count. Missing values stay ``null`` — never 0."""
    clean = sorted(v for v in samples if v is not None)
    if not clean:
        return {"avg_ms": None, "p50_ms": None, "p95_ms": None, "samples": 0}
    return {
        "avg_ms": round(sum(clean) / len(clean), 1),
        "p50_ms": _percentile(clean, 0.5),
        "p95_ms": _percentile(clean, 0.95),
        "samples": len(clean),
    }


def _success_rate(success: int, error: int) -> Optional[float]:
    decided = success + error
    if decided <= 0:
        return None
    return round(success / decided * 100, 1)


def _group_breakdown(rows: list[dict[str, Any]], key_fields: tuple[str, ...]) -> list[dict[str, Any]]:
    """Aggregate request rows into per-key buckets (provider, model, agent)."""
    buckets: dict[tuple, dict[str, Any]] = {}
    for r in rows:
        key = tuple(r.get(f) for f in key_fields)
        b = buckets.setdefault(key, {
            "requests": 0, "success": 0, "error": 0, "canceled": 0,
            "input_tokens": 0, "output_tokens": 0,
            "_latency": [], "_ttft": [], "_lat_with_tokens": 0.0, "_tokens_for_tps": 0,
        })
        b["requests"] += 1
        status = r.get("status")
        if status == "success":
            b["success"] += 1
        elif status == "error":
            b["error"] += 1
        elif status == "canceled":
            b["canceled"] += 1
        b["input_tokens"] += int(r.get("input_tokens") or 0)
        b["output_tokens"] += int(r.get("output_tokens") or 0)
        latency = r.get("latency_ms")
        if latency is not None:
            b["_latency"].append(float(latency))
        if r.get("ttft_ms") is not None:
            b["_ttft"].append(float(r["ttft_ms"]))
        if latency is not None and r.get("output_tokens"):
            b["_lat_with_tokens"] += float(latency)
            b["_tokens_for_tps"] += int(r["output_tokens"])

    out = []
    for key, b in buckets.items():
        tps = None
        if b["_lat_with_tokens"] > 0:
            tps = round(b["_tokens_for_tps"] / (b["_lat_with_tokens"] / 1000.0), 1)
        entry: dict[str, Any] = {}
        for i, f in enumerate(key_fields):
            entry[f] = key[i] if key[i] is not None else None
        entry.update({
            "requests": b["requests"],
            "success": b["success"],
            "error": b["error"],
            "canceled": b["canceled"],
            "success_rate": _success_rate(b["success"], b["error"]),
            "input_tokens": b["input_tokens"] if b["input_tokens"] else None,
            "output_tokens": b["output_tokens"] if b["output_tokens"] else None,
            "latency": _p_stats(b["_latency"]),
            "ttft": _p_stats(b["_ttft"]),
            "tokens_per_second": tps,
        })
        out.append(entry)
    out.sort(key=lambda e: (-e["requests"], tuple(str(e.get(f) or "") for f in key_fields)))
    return out[:MAX_BREAKDOWN_ROWS]


def _hour_floor(epoch: float) -> str:
    import datetime

    dt = datetime.datetime.fromtimestamp(epoch, tz=datetime.timezone.utc)
    return dt.strftime("%Y-%m-%d %H:00:00")


def _host_unsupported() -> list[dict[str, str]]:
    """Missing-callback matrix from telemetry.py (static fallback if unloadable)."""
    try:
        telemetry = _load_submodule("telemetry")
        return list(telemetry.host_observation_matrix()["unsupported"])
    except Exception:
        return [
            {"measurement": "client IP / User-Agent",
             "missing_callback": "Hermes supplies no client_ip / client_user_agent field on any api hook"},
            {"measurement": "raw credential identity",
             "missing_callback": "Raw keys and billing-account identity are not exposed; optional opaque entry scopes require compatible Hermes and consent"},
            {"measurement": "prompt-cache hits",
             "missing_callback": "No cache_event hook; bounded ingestion contract only"},
            {"measurement": "search backend observations",
             "missing_callback": "No search_event hook; bounded ingestion contract only"},
            {"measurement": "dollar cost / savings",
             "missing_callback": "No pricing feed; dashboard reports counts only"},
        ]


def _assemble_request_detail(db_path: Path, request_id: int, now: float) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "available": True, "generated_at": now, "view": "request",
        "request": None, "attempts": [],
    }
    conn = _ro_connect(db_path)
    if conn is None:
        payload["available"] = False
        payload["reason"] = "AutoRouter state database could not be opened (unreadable or corrupt)"
        return payload
    try:
        row = conn.execute("SELECT * FROM requests WHERE id = ?", (int(request_id),)).fetchone()
        if row is None:
            payload["available"] = False
            payload["reason"] = f"Request #{int(request_id)} not found in the telemetry store"
            return payload
        req = dict(row)
        payload["request"] = {
            "id": _int(req.get("id")),
            "api_request_id": scrub(req.get("api_request_id"), 128),
            "task_id": scrub(req.get("task_id"), 128),
            "turn_id": scrub(req.get("turn_id"), 128),
            "agent": scrub(req.get("session_hash"), 16),
            "platform": scrub(req.get("platform"), 40),
            "provider": scrub(req.get("provider"), 80),
            "model": scrub(req.get("model"), 160),
            "response_model": scrub(req.get("response_model"), 160),
            "status": scrub(req.get("status"), 20) or "pending",
            "key_scope": scrub(req.get("key_scope"), 16),
            "approx_input_tokens": _int(req.get("approx_input_tokens")),
            "input_tokens": _int(req.get("input_tokens")),
            "output_tokens": _int(req.get("output_tokens")),
            "latency_ms": _num(req.get("latency_ms")),
            "ttft_ms": _num(req.get("ttft_ms")),
            "error_category": scrub(_load_submodule("state").safe_telemetry_error(req.get("error_category")), 40),
            "error_summary": scrub(_load_submodule("state").safe_telemetry_error(req.get("error_summary")), 240),
            "started_at": _num(req.get("started_at")),
            "ended_at": _num(req.get("ended_at")),
        }
        attempt_columns = {row["name"] for row in _query(conn, "SELECT name FROM pragma_table_info('request_attempts')")}
        scope_column = "key_scope" if "key_scope" in attempt_columns else "'' AS key_scope"
        raw_attempts = _query(conn,
            "SELECT ordinal, provider, model, status_code, retryable, reason,"
            " error_category, duration_ms, created_at, " + scope_column + " FROM request_attempts"
            " WHERE request_id = ? ORDER BY ordinal ASC, id ASC LIMIT 101", (int(request_id),))
        payload["attempts"] = [
            {
                "ordinal": _int(a.get("ordinal")),
                "provider": scrub(a.get("provider"), 80),
                "model": scrub(a.get("model"), 160),
                "status_code": _int(a.get("status_code")),
                "retryable": None if a.get("retryable") is None else bool(a["retryable"]),
                "reason": scrub(_load_submodule("state").safe_telemetry_error(a.get("reason")), 160),
                "error_category": scrub(_load_submodule("state").safe_telemetry_error(a.get("error_category")), 40),
                "duration_ms": _num(a.get("duration_ms")),
                "key_scope": a.get("key_scope") if isinstance(a.get("key_scope"), str) and re.fullmatch(r"k_[0-9a-f]{12}", a["key_scope"]) else "",
                "created_at": _num(a.get("created_at")),
            }
            for a in raw_attempts[:100]
        ]
        truncated = len(raw_attempts) > 100
        payload["attempts"] = payload["attempts"][:100]
        payload["trace"] = _load_submodule("request_trace").build(req, raw_attempts[:100], truncated=truncated)
    except sqlite3.Error:
        payload["available"] = False
        payload["reason"] = "AutoRouter state database could not be read (unreadable or corrupt)"
    finally:
        conn.close()
    return payload


def _sql_breakdown(conn, where_sql, params, keys=()):
    """Complete-range SQL counts/sums with exact observed latency statistics."""
    class Stats:
        def __init__(self): self.values = []
        def step(self, value):
            import math
            if value is not None and math.isfinite(value) and value >= 0:
                self.values.append(float(value))
        def finalize(self): return json.dumps(_p_stats(self.values))
    conn.create_aggregate("observed_stats", 1, Stats)
    columns = ", ".join(keys)
    query = ("SELECT " + (columns + ", " if keys else "") +
        "COUNT(*) AS requests, SUM(status='success') AS success, SUM(status='error') AS error, "
        "SUM(status='canceled') AS canceled, SUM(status='pending') AS pending, "
        "SUM(input_tokens) AS input_tokens, SUM(output_tokens) AS output_tokens, "
        "observed_stats(latency_ms) AS latency, observed_stats(ttft_ms) AS ttft, "
        "SUM(CASE WHEN latency_ms > 0 THEN output_tokens END) AS tps_tokens, "
        "SUM(CASE WHEN latency_ms > 0 AND output_tokens IS NOT NULL THEN latency_ms END) AS tps_duration "
        "FROM requests " + where_sql + (" GROUP BY " + columns if keys else ""))
    rows = _query(conn, query, tuple(params))
    for row in rows:
        for key in keys:
            row[key] = scrub(row[key], 160)
        for key in ("latency", "ttft"):
            row[key] = json.loads(row[key]) if row[key] else _p_stats([])
        row["success_rate"] = _success_rate(row["success"] or 0, row["error"] or 0)
        row["tokens_per_second"] = round(row["tps_tokens"] / (row["tps_duration"] / 1000), 1) if row["tps_duration"] else None
    return sorted(rows, key=lambda r: -r["requests"])


def _adaptive_analytics(db_path, models, now):
    """Unknown-scope ranking evidence only; no credential enumeration or writes."""
    from_store = _load_submodule("snapshot").ReadOnlyStateStore(db_path)
    scoring = _load_submodule("scoring")
    min_samples = 10
    out = []
    for model in models[:25]:
        observed = from_store.get_scoring_observations(model["provider"], model["model"])
        stats = scoring.summarize_observations(observed["rows"], now=now, available=observed["available"])
        samples = stats.get("samples") or 0
        if samples < min_samples:
            # Too few outcomes for a meaningful reliability/confidence figure;
            # keep the raw counts, never fabricate a rate.
            stats = dict(stats)
            stats["sample_state"] = "insufficient_samples"
            stats["min_samples"] = min_samples
            stats["reliability"] = None
            stats["confidence"] = None
        out.append({"provider": model["provider"], "model": model["model"],
                    "credential_scope": "unknown", "statistics": stats})
    return {"source": "bounded attributed final requests; unknown credential scope", "models": out,
            "model_limit": 25, "sample_limit": scoring.SAMPLE_LIMIT, "semantic_quality": "unknown",
            "range_filter_applies": False, "status_filter_applies": False}


def _selection_distribution(conn, since, now, provider):
    where, params = ["ts <= ?"], [now]
    if since is not None:
        where.append("ts >= ?")
        params.append(since)
    if provider:
        where.append("provider = ?")
        params.append(provider)
    clause = " WHERE " + " AND ".join(where)
    try:
        total = conn.execute("SELECT COUNT(*) FROM decisions" + clause, tuple(params)).fetchone()[0]
        rows = conn.execute("SELECT provider,model,COUNT(*) AS selections FROM decisions" + clause +
            " GROUP BY provider,model ORDER BY selections DESC,provider,model LIMIT 101", tuple(params)).fetchall()
        return {"available": True, "total": total, "source": "recorded_selection_decisions",
                "status_filter_applies": False, "row_limit": 100, "truncated": len(rows) > 100,
                "rows": [{"provider": scrub(row["provider"], 80), "model": scrub(row["model"], 160),
                          "selections": row["selections"]} for row in rows[:100]]}
    except sqlite3.Error:
        return {"available": False, "total": None, "rows": [], "source": "recorded_selection_decisions"}


def assemble_analytics(
    now: Optional[float] = None,
    *,
    range: Optional[str] = None,  # noqa: A002 — matches the HTTP query param
    view: str = "summary",
    request_id: Optional[int] = None,
    provider: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = MAX_RECENT_REQUESTS,
    offset: int = 0,
    sort: str = "newest",
) -> dict[str, Any]:
    """Inference-request analytics from the schema-v2 telemetry tables.

    Every number here comes from recorded Hermes api hooks. Routing
    *decisions* (the ``decisions`` table) are deliberately NOT counted as
    inference requests — they are surfaced in the Overview tab only.
    Missing observations stay ``null`` / ``observed: false``; nothing is
    fabricated and missing values are never turned into zeroes.
    """
    now = time.time() if now is None else now
    cfg = read_plugin_config()
    values = cfg["values"]
    db_path = _db_path(values)

    range_value = normalize_range(range)
    since = None if _RANGE_SECONDS[range_value] is None else now - _RANGE_SECONDS[range_value]

    view = "request" if view == "request" else "summary"
    if view == "request":
        if request_id is None:
            return {"available": False, "view": "request",
                    "reason": "view=request requires a request_id query parameter",
                    "generated_at": now}
        return _assemble_request_detail(db_path, int(request_id), now)

    payload: dict[str, Any] = {
        "available": True,
        "generated_at": now,
        "view": "summary",
        "range": {"value": range_value, "since": since, "until": now},
        "summary": None,
        "adaptive_scoring": {"models": [], "semantic_quality": "unknown"},
        "selection_distribution": {"available": False, "rows": [], "total": None},
        "by_provider": [],
        "by_model": [],
        "by_agent": [],
        "by_error": [],
        "timeline": [],
        "recent_requests": [],
        "recent_total": 0,
        "filters": {
            "provider": scrub(provider, 80) or None,
            "status": scrub(status, 20) or None,
            "limit": max(1, min(int(limit or MAX_RECENT_REQUESTS), 100)),
            "offset": max(0, int(offset or 0)),
        },
        "lifetime": None,
        "cache": {"observed": False,
                  "reason": "No Hermes callback reports prompt-cache events; the bounded ingestion "
                            "contract exists but no producer ships yet"},
        "search": {"observed": False,
                   "reason": "No Hermes callback reports search-backend events; the bounded ingestion "
                             "contract exists but no producer ships yet"},
        "unsupported": _host_unsupported(),
    }

    conn = _ro_connect(db_path)
    if conn is None:
        payload["available"] = False
        payload["reason"] = (
            "AutoRouter state database not initialized yet"
            if not db_path.is_file()
            else "AutoRouter state database could not be opened (unreadable or corrupt)"
        )
        return payload
    missing = _telemetry_tables_missing(conn)
    if missing is None:
        conn.close()
        payload["available"] = False
        payload["reason"] = "AutoRouter state database could not be read (unreadable or corrupt)"
        return payload
    if missing:
        conn.close()
        payload["available"] = False
        payload["telemetry_schema"] = "v1"
        payload["reason"] = (
            "Telemetry tables not created yet (schema v1). They are created automatically"
            " when the next request is recorded after the plugin upgrade."
        )
        return payload

    try:
        # ---- request rows for the selected range (bounded) ----
        where = ["started_at <= ?"]
        if since is not None: where.append("started_at >= ?")
        params: list[Any] = [now] + ([since] if since is not None else [])
        f_provider = payload["filters"]["provider"]
        if f_provider:
            where.append("provider = ?")
            params.append(f_provider)
        f_status = payload["filters"]["status"]
        if f_status in ("success", "error", "canceled", "pending"):
            where.append("status = ?")
            params.append(f_status)
        where_sql = ("WHERE " + " AND ".join(where)) if where else ""

        rows = [
            dict(r)
            for r in _query(
                conn,
                "SELECT id, provider, model, response_model, status, session_hash,"
                " input_tokens, output_tokens, latency_ms, ttft_ms, error_category,"
                " started_at, ended_at FROM requests "
                + where_sql +
                " ORDER BY " + {"oldest": "started_at ASC, id ASC", "latency": "latency_ms DESC, id DESC"}.get(sort, "started_at DESC, id DESC") + " LIMIT ? OFFSET ?",
                tuple(params) + (payload["filters"]["limit"], payload["filters"]["offset"]),
            )
        ]
        payload["recent_total"] = int(
            _scalar(conn, "SELECT COUNT(*) FROM requests " + where_sql, tuple(params)) or 0
        )

        # All panels share the selected range/provider/status filters.
        summary = _sql_breakdown(conn, where_sql, params)[0]
        summary["total_requests"] = summary.pop("requests")
        payload["summary"] = summary
        payload["by_provider"] = _sql_breakdown(conn, where_sql, params, ("provider",))
        payload["by_model"] = _sql_breakdown(conn, where_sql, params, ("provider", "model"))
        payload["adaptive_scoring"] = _adaptive_analytics(db_path, payload["by_model"], now)
        payload["selection_distribution"] = _selection_distribution(conn, since, now, f_provider)
        agents = _sql_breakdown(conn, where_sql, params, ("session_hash",))
        payload["by_agent"] = [dict(r, agent=r["session_hash"]) for r in agents if r["session_hash"]]
        payload["by_error"] = _query(conn, "SELECT error_category AS category, COUNT(*) AS count, "
            "MAX(COALESCE(ended_at,started_at)) AS last_seen FROM requests " +
            (where_sql + " AND " if where_sql else "WHERE ") +
            "error_category IS NOT NULL GROUP BY error_category ORDER BY count DESC", tuple(params))

        error_groups = {}
        for row in payload["by_error"]:
            category = _load_submodule("state").safe_telemetry_error(row["category"]) or "Other"
            group = error_groups.setdefault(category, {"category": category, "count": 0, "last_seen": None})
            group["count"] += row["count"]
            if group["last_seen"] is None or (row["last_seen"] is not None and row["last_seen"] > group["last_seen"]):
                group["last_seen"] = row["last_seen"]
        payload["by_error"] = sorted(error_groups.values(), key=lambda row: (-row["count"], row["category"]))

        timeline = _query(conn, "SELECT strftime('%Y-%m-%d %H:00:00', started_at, 'unixepoch') AS hour, "
            "COUNT(*) AS total, SUM(status='success') AS success, SUM(status='error') AS error, "
            "SUM(status='canceled') AS canceled, SUM(input_tokens) AS input_tokens, "
            "SUM(output_tokens) AS output_tokens, observed_stats(latency_ms) AS latency FROM requests " + where_sql +
            " GROUP BY hour ORDER BY hour", tuple(params))
        for bucket in timeline:
            bucket["latency"] = json.loads(bucket["latency"]) if bucket["latency"] else _p_stats([])
        payload["timeline"] = timeline
        payload["timeline_total_hours"] = len(timeline)

        # ---- recent requests (filtered, paginated) ----
        f = payload["filters"]
        recent = rows
        payload["recent_requests"] = [
            {
                "id": _int(r.get("id")),
                "started_at": _num(r.get("started_at")),
                "ended_at": _num(r.get("ended_at")),
                "provider": scrub(r.get("provider"), 80),
                "model": scrub(r.get("model"), 160),
                "response_model": scrub(r.get("response_model"), 160),
                "status": scrub(r.get("status"), 20),
                "latency_ms": _num(r.get("latency_ms")),
                "ttft_ms": _num(r.get("ttft_ms")),
                "input_tokens": _int(r.get("input_tokens")),
                "output_tokens": _int(r.get("output_tokens")),
                "error_category": scrub(_load_submodule("state").safe_telemetry_error(r.get("error_category")), 40),
                "agent": scrub(r.get("session_hash"), 16),
            }
            for r in recent
        ]

        # ---- lifetime counters (all time) ----
        lifetime = {}
        for key in ("total_requests", "total_input_tokens", "total_output_tokens"):
            lifetime[key] = _int(_scalar(
                conn, "SELECT value FROM lifetime_counters WHERE key = ?", (key,)))
        payload["lifetime"] = lifetime

        # ---- cache / search: only legitimately observed events count ----
        cache_since = _scalar(
            conn, "SELECT COUNT(*) FROM cache_events" + (" WHERE ts >= ?" if since is not None else ""),
            (since,) if since is not None else ())
        if cache_since:
            hits = _scalar(conn, "SELECT COUNT(*) FROM cache_events WHERE hit = 1"
                                 + (" AND ts >= ?" if since is not None else ""),
                           (since,) if since is not None else ())
            cache_lat = _scalar(conn, "SELECT AVG(latency_ms) FROM cache_events"
                                      " WHERE latency_ms IS NOT NULL"
                                      + (" AND ts >= ?" if since is not None else ""),
                                (since,) if since is not None else ())
            payload["cache"] = {
                "observed": True,
                "events": _int(cache_since),
                "hits": _int(hits),
                "misses": _int(cache_since) - _int(hits),
                "hit_rate": round(_int(hits) / _int(cache_since) * 100, 1) if cache_since else None,
                "avg_latency_ms": _num(cache_lat),
            }
        search_since = _scalar(
            conn, "SELECT COUNT(*) FROM search_events" + (" WHERE ts >= ?" if since is not None else ""),
            (since,) if since is not None else ())
        if search_since:
            search_lat = _scalar(conn, "SELECT AVG(latency_ms) FROM search_events"
                                       " WHERE latency_ms IS NOT NULL"
                                       + (" AND ts >= ?" if since is not None else ""),
                                 (since,) if since is not None else ())
            search_results = _scalar(conn, "SELECT AVG(results_count) FROM search_events"
                                           " WHERE results_count IS NOT NULL"
                                           + (" AND ts >= ?" if since is not None else ""),
                                     (since,) if since is not None else ())
            payload["search"] = {
                "observed": True,
                "events": _int(search_since),
                "avg_latency_ms": _num(search_lat),
                "avg_results": round(float(search_results), 1) if search_results is not None else None,
            }
    except sqlite3.Error:
        payload["available"] = False
        payload["reason"] = "AutoRouter state database could not be read (unreadable or corrupt)"
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return payload
# ---------------------------------------------------------------------------

def assemble_settings() -> dict[str, Any]:
    cfg = read_plugin_config()
    values = cfg["values"]
    try:
        policy_value = _load_submodule("policies").resolve(values.get("policy", "auto"))["id"]
    except ValueError:
        policy_value = scrub(values.get("policy"), 40)
    editable = bool(cfg["available"]) and not bool(cfg["managed"])
    reason = None
    if not cfg["available"]:
        reason = "Hermes plugin settings API is not available in this process; values are shown read-only."
    elif cfg["managed"]:
        reason = "This installation is administrator-managed; plugin settings cannot be changed here."

    return {
        "available": True,
        "generated_at": time.time(),
        "editable": editable,
        "edit_block_reason": reason,
        "values": {
            "enabled": bool(values.get("enabled")),
            "policy": policy_value,
            "free_only": True,
            "providers": [scrub(p, 64) for p in (values.get("providers") or [])],
            "cooldown_seconds": _int(values.get("cooldown_seconds")),
            "state_dir": scrub(str(values.get("state_dir") or ""), 200) or "",
            "paid_authorized": bool(values.get("paid_authorized")),
            "paid_inference": "disabled",
            "enable_chat_router": bool(values.get("enable_chat_router")),
            "min_context": _int(values.get("min_context")) or 8192,
            "requires_tools": bool(values.get("requires_tools")),
            "model_include": [scrub(v, 240) for v in effective_model_preference(values)["include"]],
            "model_exclude": [scrub(v, 240) for v in effective_model_preference(values)["exclude"]],
            "model_preference_mode": effective_model_preference(values)["mode"],
        },
        "policy_contract": _load_submodule("policies").contract(),
        "schema": {
            "policy": {"type": "enum", "options": list(POLICY_OPTIONS)},
            "free_only": {"type": "boolean", "const": True},
            "cooldown_seconds": {"type": "integer", "min": 1, "max": 86400},
            "providers": {
                "type": "string_list",
                "item_pattern": "^[a-z0-9][a-z0-9_-]{0,63}$",
                "max_items": 16,
            },
            "enable_chat_router": {"type": "boolean"},
            "min_context": {"type": "integer", "min": 2048, "max": 2000000},
            "requires_tools": {"type": "boolean"},
            "model_include": {
                "type": "string_list",
                "item_pattern": "^[a-z0-9][a-z0-9_-]{0,63}/[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}$",
                "max_items": MAX_MODEL_KEYS,
            },
            "model_exclude": {
                "type": "string_list",
                "item_pattern": "^[a-z0-9][a-z0-9_-]{0,63}/[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}$",
                "max_items": MAX_MODEL_KEYS,
            },
        },
        "notes": [
            "AutoRouter requires fresh verified-free-only eligibility for every policy. Paid fallback is unavailable; free-first is a legacy name for General, not spending authorization.",
            "Settings are written one key at a time via Hermes' sanctioned plugin-settings API and take effect the next time the plugin loads (gateway restart or plugin reload); they are not hot-applied. The AutoRouter selection path reads these values at each routing decision, so policy/min_context/requires_tools/model_preference changes apply to the *next* selection, not retroactively to committed sessions.",
            "The model inclusion/exclusion preference is stored as the single 'model_preference' key (mode + include + exclude in one indivisible value) and written with one atomic save, so include and exclude can never land torn across processes. Raw edits to model_include/model_exclude here are folded into that single key; an empty include list means unrestricted. 'None enabled' (all models off) is reachable only through per-model toggles and can only be left by enabling a model or by an explicit Reset to unrestricted.",
            "There is no multi-key transaction: if a write fails, keys saved earlier in the batch stay saved and later keys are not attempted. The response reports exactly which keys were saved.",
            "enabled is intentionally read-only here: use `hermes plugins enable|disable autorouter` and restart the gateway.",
        ],
    }


_PROVIDER_TOKEN = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")


def validate_settings_updates(updates: Any) -> tuple[dict[str, Any], list[str]]:
    """Validate a settings update payload. Returns (clean, errors)."""
    errors: list[str] = []
    clean: dict[str, Any] = {}
    if not isinstance(updates, dict) or not updates:
        return {}, ["updates must be a non-empty object"]

    for key, value in updates.items():
        if key in ("enabled", "state_dir", "paid_authorized"):
            errors.append(f"'{key}' cannot be changed from the management UI")
            continue
        if key not in EDITABLE_KEYS:
            errors.append(f"unknown setting '{key}'")
            continue

        if key == "policy":
            if not isinstance(value, str) or value not in POLICY_OPTIONS + list(_load_submodule("policies").ALIASES):
                errors.append(f"policy must be one of: {', '.join(POLICY_OPTIONS)}")
            else:
                clean[key] = value
        elif key == "free_only":
            if value is not True:
                errors.append("free_only must be true (free-only eligibility is mandatory)")
            else:
                clean[key] = value
        elif key == "cooldown_seconds":
            if isinstance(value, bool) or not isinstance(value, int):
                errors.append("cooldown_seconds must be an integer")
            elif not (1 <= value <= 86400):
                errors.append("cooldown_seconds must be between 1 and 86400")
            else:
                clean[key] = value
        elif key == "providers":
            if not isinstance(value, list) or len(value) > 16:
                errors.append("providers must be a list of at most 16 entries")
                continue
            seen: list[str] = []
            ok = True
            for item in value:
                if not isinstance(item, str):
                    ok = False
                    continue
                token = item.strip().lower()
                if not _PROVIDER_TOKEN.fullmatch(token) or token not in _load_submodule("connections").PROVIDERS:
                    ok = False
                    continue
                if token not in seen:
                    seen.append(token)
            if not ok:
                errors.append("providers entries must match ^[a-z0-9][a-z0-9_-]{0,63}$")
            else:
                clean[key] = seen

        elif key == "enable_chat_router":
            if value is not True and value is not False:
                errors.append("enable_chat_router must be a boolean")
            else:
                clean[key] = value

        elif key == "min_context":
            if isinstance(value, bool) or not isinstance(value, int):
                errors.append("min_context must be an integer")
            elif not (2048 <= value <= 2000000):
                errors.append("min_context must be between 2048 and 2000000")
            else:
                clean[key] = value

        elif key == "requires_tools":
            if value is not True and value is not False:
                errors.append("requires_tools must be a boolean")
            else:
                clean[key] = value

        elif key in ("model_include", "model_exclude"):
            if not isinstance(value, list) or len(value) > MAX_MODEL_KEYS:
                errors.append(f"{key} must be a list of at most {MAX_MODEL_KEYS} entries")
                continue
            seen: list[str] = []
            ok = True
            for item in value:
                if not isinstance(item, str):
                    ok = False
                    continue
                token = item.strip()
                if not _MODEL_KEY.fullmatch(token):
                    ok = False
                    continue
                if token not in seen:
                    seen.append(token)
            if not ok:
                errors.append(f"{key} entries must be 'provider/model' (e.g. nvidia/nvidia-free)")
            else:
                clean[key] = seen
    return clean, errors


class SettingsWriteError(Exception):
    """A per-key settings write failed partway through a multi-key update.

    Hermes provides no multi-key transaction: each key is persisted
    individually by ``save_plugin_setting`` (atomic per key, locked,
    managed/administrator-managed refusals). Keys in ``saved`` were already
    persisted when this error is raised and stay persisted; ``failed`` is
    the key that was refused/failed; ``remaining`` keys were not attempted.

    Never imply (or document) that the multi-key update was atomic.
    """

    def __init__(self, saved: list[str], failed: str, reason: Any, remaining: list[str], original: Exception):
        self.saved = list(saved)
        self.failed = str(failed)
        self.reason = scrub(reason, 240) or "unknown error"
        self.remaining = list(remaining)
        self.original = original
        super().__init__(
            f"settings write stopped at {self.failed!r}: {self.reason} "
            f"(saved: {', '.join(self.saved) or 'none'}; not attempted: "
            f"{', '.join(self.remaining) or 'none'})"
        )


def refresh_catalog() -> dict[str, Any]:
    """User-initiated catalog refresh over the configured authorized providers.

    Runs the plugin's sanctioned discovery path: only providers listed in
    ``plugins.entries.autorouter.settings.providers`` are contacted, and the
    host's credential mechanism resolves their keys (a provider without an
    authorized key reports zero models — never an error, never a guess).
    Persisted evidence goes to the profile-scoped AutoRouter store, exactly
    like the ``autorouter_refresh`` tool. Never fabricates models when
    discovery returns nothing.
    """
    now = time.time()
    cfg = read_plugin_config()
    values = cfg["values"]
    providers = [p for p in (values.get("providers") or []) if isinstance(p, str)]
    if not cfg["available"]:
        return {
            "available": False,
            "reason": (
                "Hermes configuration is not readable in this process; "
                "the refresh was not performed."
            ),
            "generated_at": now,
            "refreshed": {},
        }
    if not providers:
        return {
            "available": False,
            "reason": "No authorized providers configured "
                      "(plugins.entries.autorouter.settings.providers).",
            "generated_at": now,
            "refreshed": {},
        }
    discovery = _load_submodule("discovery")
    state_mod = _load_submodule("state")
    try:
        store = state_mod.StateStore(_state_dir(values))
    except Exception as exc:
        logger.warning("autorouter dashboard: catalog store unavailable: %s", exc)
        return {
            "available": False,
            "reason": "AutoRouter catalog store could not be opened.",
            "generated_at": now,
            "refreshed": {},
        }
    try:
        out = discovery.discover_all(list(providers), store=store)
    except Exception as exc:
        logger.warning("autorouter dashboard: catalog refresh failed: %s", exc)
        return {
            "available": False,
            "reason": "Catalog refresh failed for every authorized provider "
                      "(discovery reported an error; nothing was persisted).",
            "generated_at": now,
            "refreshed": {},
        }
    refreshed = {provider: len(models or []) for provider, models in out.items()}
    return {
        "available": True,
        "generated_at": now,
        "providers": providers,
        "refreshed": refreshed,
        "total_models": sum(refreshed.values()),
    }


def write_settings(updates: dict[str, Any]) -> dict[str, Any]:
    """Persist validated settings via Hermes' sanctioned per-key writer.

    Preference keys (``model_include``/``model_exclude``) are folded into the
    single ``model_preference`` key and persisted as ONE atomic write under
    the cross-process preference lock, so the inclusion/exclusion pair can
    never land torn. Explicit raw edits to those keys set the lists exactly
    as typed (an empty include yields unrestricted mode — the documented
    meaning of the raw field); toggles remain the only path to ``none``.

    Remaining keys are applied one at a time in the order given by
    ``updates`` after the preference write. Hermes has no multi-key
    transaction; each write is atomic only on its own. On the first failure
    the remaining keys are **not** attempted, and a :class:`SettingsWriteError`
    is raised reporting exactly which keys were saved, which failed and which
    were never attempted — never a claim of atomicity that did not happen.
    """
    try:
        from hermes_cli.plugins_state import save_plugin_setting
    except Exception as exc:
        raise RuntimeError("Hermes plugin settings API is not available in this process") from exc

    preference_keys = [k for k in updates if k in ("model_include", "model_exclude")]
    hash_locked = bool(preference_keys)
    saved: list[str] = []

    with _preference_file_lock() if hash_locked else contextlib.nullcontext():
        if preference_keys:
            values = read_plugin_config().get("values") or {}
            eff = effective_model_preference(values)
            inc = list(eff["include"])
            exc = list(eff["exclude"])
            if "model_include" in updates:
                inc = list(dict.fromkeys(updates["model_include"]))
            if "model_exclude" in updates:
                exc = list(dict.fromkeys(updates["model_exclude"]))
            unrecognized = [item for item in inc + exc
                            if not isinstance(item, str) or _model_pair(item) is None]
            if unrecognized:
                raise ValueError("model_include/model_exclude entries must be 'provider/model'")
            mode = "allowlist" if _pairs(inc) else "unrestricted"
            blob = {"version": 1, "mode": mode,
                    "include": sorted({f"{p}/{m}" for p, m in _pairs(inc)}),
                    "exclude": sorted({f"{p}/{m}" for p, m in _pairs(exc)})}
            try:
                save_plugin_setting("autorouter", ("model_preference",), blob)
            except Exception as exc:
                raise SettingsWriteError(saved=[], failed="model_preference", reason=exc,
                                         remaining=[k for k in updates if k not in preference_keys],
                                         original=exc) from exc
            saved.append("model_preference")

        items = [(k, v) for k, v in updates.items() if k not in ("model_include", "model_exclude")]
        for index, (key, value) in enumerate(items):
            segments = tuple(str(key).split("."))
            try:
                save_plugin_setting("autorouter", segments, value)
            except Exception as exc:
                remaining = [str(k) for k, _ in items[index + 1:]]
                raise SettingsWriteError(saved=saved, failed=str(key), reason=exc,
                                         remaining=remaining, original=exc) from exc
            saved.append(str(key))
    return assemble_settings()


def assemble_connections(now=None):
    """Read-only credential inventory, independent of healthy SQLite/catalog state."""
    connections = _load_submodule("connections")
    config = read_plugin_config()
    observations = {}
    state_status = "unavailable"
    conn = None
    try:
        conn = _ro_connect(_db_path(config["values"]))
        if conn is not None:
            # Strict queries: schema corruption must not masquerade as zero observations.
            rows = conn.execute("SELECT provider, COUNT(*) AS n FROM catalog GROUP BY provider").fetchall()
            health = conn.execute("SELECT provider, MAX(auth_failed) AS failed FROM health WHERE key_scope='' GROUP BY provider").fetchall()
            observations = {r["provider"]: {"model_count": int(r["n"])} for r in rows if r["provider"] in connections.PROVIDERS}
            for row in health:
                if row["provider"] in connections.PROVIDERS:
                    observations.setdefault(row["provider"], {})["auth_failed"] = bool(row["failed"])
            state_status = "available"
    except Exception:
        observations, state_status = {}, "unavailable"
    finally:
        if conn is not None:
            conn.close()
    # Reuse current model proof/eligibility, not catalog row counts as usability.
    if state_status == "available":
        model_data = assemble_models(now=now)
        if model_data.get("available") is True:
            for provider in connections.PROVIDERS:
                rows = [row for row in model_data.get("models", []) if row.get("provider") == provider]
                observations.setdefault(provider, {}).update(
                    discovered_model_count=sum(row.get("discovery_status") == "discovered" for row in rows),
                    eligible_model_count=sum(row.get("eligible") is True for row in rows))
    result = connections.inventory(config, observations, state_status)
    result["generated_at"] = time.time() if now is None else now
    return result


def assemble_first_use(now=None):
    """Read existing snapshots only; no automatic activation/refresh or DB writes."""
    now=time.time() if now is None else now
    config=read_plugin_config()
    inventory=assemble_connections(now=now)
    models=assemble_models(now=now)
    return _load_submodule("first_use").build(config,inventory,models,now=now,
        capabilities=_load_submodule("execution_adapter").capabilities())
