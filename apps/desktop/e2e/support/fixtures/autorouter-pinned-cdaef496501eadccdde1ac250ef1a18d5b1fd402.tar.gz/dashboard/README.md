# AutoRouter — dashboard extension

This directory is a **Hermes dashboard plugin**. When the `autorouter` plugin
is enabled, Hermes mounts an **AutoRouter** tab (`/autorouter`) in the web
dashboard with five sections: Overview, Providers, Models, Analytics, Settings.

## Layout

```
dashboard/
├── manifest.json      # tab registration (name, path, position, assets)
├── plugin_api.py      # FastAPI router mounted at /api/plugins/autorouter/
├── state_reader.py    # read-only assembly of plugin state into JSON dicts
└── dist/
    ├── index.js       # IIFE bundle; registers via window.__HERMES_PLUGINS__
    └── style.css      # scoped under .ar-*, high contrast, focus-visible
```

There is no build step and no runtime dependency beyond what Hermes already
ships. The bundle uses only `window.__HERMES_PLUGIN_SDK__` (React + host
utilities) and plain DOM APIs.

## Data flow

`dist/index.js` → `GET/PUT /api/plugins/autorouter/<section>` →
`plugin_api.py` → `state_reader.py` → read-only (`mode=ro`) SQLite snapshot of
the plugin's state database (default profile `plugin-data/autorouter/autorouter.db`) plus `plugins.entries.autorouter.settings`
from Hermes config (via `hermes_cli.config.load_config_readonly`).

Eligibility is computed by AutoRouter's own `eligibility.py` and the capability
merge from `router.py` (`Router._resolved_candidates`). No second filtering
engine exists here.

## Guarantees

- Read-only by construction: every SQL statement issued through this package is
  a `SELECT` against a read-only connection; the database is never created,
  migrated or written by the UI.
- Stored strings are untrusted: control characters are stripped, common
  secret patterns are redacted server-side, and the bundle renders exclusively
  via `textContent` / `createElementNS` (no `innerHTML`).
- Settings writes only to `plugins.entries.autorouter.settings` via
  `hermes_cli.plugins_state.save_plugin_setting` (per-key atomic, locked,
  refuses administrator-managed keys and managed installs). Hermes offers
  no multi-key transaction: settings are applied one key at a time, and if
  a write fails partway, earlier keys stay persisted, later keys are not
  attempted, and the response reports exactly which keys were saved (the
  UI renders that breakdown). `enabled`, `state_dir` and `paid_authorized`
  are never writable from the UI; paid inference stays disabled.
- Viewing the dashboard cannot break the core plugin: all backend failures
  degrade to explicit `available: false` payloads or HTTP 4xx/5xx JSON errors.

## Testing

- `tests/test_dashboard_state_reader.py` — data assembly, corrupt/missing DB,
  redaction, settings validation.
- `tests/test_dashboard_api.py` — HTTP layer (needs `fastapi`, `httpx`):
  `uv run --with fastapi --with httpx --with pytest python -m pytest tests/test_dashboard_api.py`
- `tests/test_dashboard_manifest.py` — manifest/bundle hygiene.
- `tests/browser/harness.html` — real-browser UI harness with a mocked plugin
  API (`?mode=normal|empty|error`), used for interaction evidence.

## Install

See the "Five-tab dashboard" section of the top-level README. In short:
`hermes plugins enable autorouter`, restart the dashboard, open the
**AutoRouter** tab. The dashboard never bypasses Hermes' auth gate.
