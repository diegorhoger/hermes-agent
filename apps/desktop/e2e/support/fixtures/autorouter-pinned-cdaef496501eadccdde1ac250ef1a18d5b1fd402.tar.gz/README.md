# AutoRouter

AutoRouter is an experimental, opt-in Hermes Agent plugin that helps you use your authorized model providers more effectively.

It discovers models from the providers you authorize, keeps a verified catalog in your profile's own state database, and selects the best eligible free model for a request from current evidence — instead of hard-coding a model name into your workflow.

What you can do with it:

- **Discover and compare models** from NVIDIA and OpenRouter (and connect Nous Portal, Groq, Gemini and Mistral for read-only catalog probes where credentials are present).
- **See exactly why a model is eligible or not** — price evidence, tool support, context length, health and availability are all shown per model.
- **Select a model by policy** — Auto, Coding, Fastest, Reliability-first (plus legacy smartest/priority) — or pick manually with the `/model` picker.
- **Route chats through a virtual model** (`autorouter/auto-free`) that resolves at selection time to an eligible free model, or refuses before any network request is made.
- **Inspect what happened** — five-tab dashboard (Overview, Providers, Models, Analytics, Settings) backed by live plugin state.
- **Keep paid inference unreachable** — paid, premium, unknown and missing-cost models are never eligible.

> **Experimental.** The chat integration (`enable_chat_router`) and the managed virtual model are experimental. Production behavior, quota guarantees and upstream provider terms are outside this plugin's control. Read [Safety and limitations](docs/safety-and-limitations.md) before relying on it.

## Requirements

- **Hermes Agent v0.23.x** (tested against the v0.23.1 runtime; integration-tested against a pinned Hermes checkout). Other Hermes versions may work but are not verified.
- **Python 3** bundled with Hermes Agent.
- **macOS or Linux** with a Hermes profile (the isolated test profile used for every verification in this repository's history).
- **Provider credentials**: discovery uses a few bounded, fixed-origin catalog requests. OpenRouter and NVIDIA need no credential for discovery (NVIDIA's identifier catalog is read via Hermes' own provider profile). Groq, Gemini and Mistral send the matching environment variable (`GROQ_API_KEY`, `GEMINI_API_KEY`/`GOOGLE_API_KEY`, `MISTRAL_API_KEY`) as the authorization header on a single read-only GET. Nous Portal reads a bearer through Hermes' sanctioned `read_credential_pool('nous')` and sends it only to `https://inference-api.nousresearch.com/v1/models`. No credential is persisted, logged, exported or copied by this plugin.
- A **Hermes dashboard** instance if you want the five-tab management UI.

## Installation

AutoRouter is a Hermes Agent **directory plugin** — not a PyPI package, no release is tagged. Install a package built from an exact revision of the source. The documented workflow uses an isolated profile (`$HOME/.hermes-autorouter`) and never touches your everyday Hermes profile.

```sh
# 1) clone and pin an exact revision
export WORK="$(mktemp -d)"
git clone https://github.com/diegorhoger/autorouter.git "$WORK/autorouter"
cd "$WORK/autorouter"
git checkout origin/main                       # or: git checkout <sha>
sha=$(git rev-parse HEAD)

# 2) build a verified package (deterministic)
mkdir -p "$WORK/dist"
python3 tools/build_package.py --repo . --revision "$sha" --output "$WORK/dist"
artifact="$WORK/dist/autorouter-0.2.0-${sha:0:12}.zip"
(cd "$WORK/dist" && shasum -a 256 -c "$artifact.sha256")   # => autorouter-… : OK

# 3) install into the isolated profile (never overwrites silently)
export HERMES_HOME="${HERMES_HOME:-$HOME/.hermes-autorouter}"
install_dir="$HERMES_HOME/plugins"
mkdir -p "$install_dir"
[ -e "$install_dir/autorouter" ] && mv "$install_dir/autorouter" "$install_dir/autorouter.bak.$(date +%Y%m%d%H%M%S)"
python3 -m zipfile -e "$artifact" "$install_dir/"

# 4) enable and authorize a provider (edit config.yaml as shown below)
hermes plugins enable autorouter

# 5) restart and open the dashboard
hermes dashboard                             # mounts /autorouter
```

Every file in the package is hash-pinned and `PACKAGE-MANIFEST.json` binds the archive to `source_sha`. Full lifecycle (verify, upgrade, uninstall, rollback) is documented in [docs/installation.md](docs/installation.md) and [docs/upgrading.md](docs/upgrading.md).

## Configuration

Every setting lives under `plugins.entries.autorouter.settings` in your profile's `config.yaml`. All settings are optional; disabled by default means zero effect until you opt in.

| Key | Default | Effect | Restart? |
|-----|---------|--------|----------|
| `enabled` | `false` | Enables the `autorouter_status` / `autorouter_refresh` / `autorouter_select` tools and observers. | Yes |
| `enable_chat_router` | `false` | Routes the virtual model `autorouter/auto-free` through Hermes' selection path. Refuses before network when nothing eligible. | Yes |
| `policy` | `auto` | Ranking preference: `auto`, `coding`, `fastest`, `reliable` (legacy `smartest`, `priority` accepted). | Yes |
| `free_only` | `true` | Keeps only verified-free models eligible. `false` does **not** authorize paid models in this release. | Yes |
| `providers` | `[nvidia, openrouter]` | Discovery allowlist; unknown ids are ignored. 4–16 recommended. | Yes |
| `min_context` | `8192` | Minimum context window in tokens (2048–2000000). | Yes |
| `requires_tools` | `false` | Require verified tool-calling support for selection. | Yes |
| `model_include` | `[]` | Restrict to `provider/model` keys. | Yes |
| `model_exclude` | `[]` | Never select these `provider/model` keys. | Yes |
| `cooldown_seconds` | `60` | Default retryable-failure cooldown (1–86400). | Yes |
| `state_dir` | `""` | Override the plugin state database directory (rarely needed). | Yes |
| `scope_bound_quota` | `false` | Consume host-mediated quota observations when the host provides them. | Yes |
| `paid_authorized` | `false` | **Deprecated, no effect.** Paid inference is disabled. | — |

Full reference: [docs/configuration.md](docs/configuration.md). Editing takes effect on the next plugin load — settings are deliberately not hot-applied; the dashboard's routing toggle needs a gateway or dashboard-plugin restart to change routing behavior.

## Model selection and eligibility

A model is eligible only when **all** of these hold:

1. **Cost tier = free**, with fresh, source-attributed evidence that both prompt and completion prices are zero across every supplied price component. Unknown, missing, expired, paid, premium or promotional pricing is never eligible.
2. **Context window ≥ `min_context`.**
3. **Tool support verified**, when `requires_tools` is on.
4. **Provider authorized** in `providers` (catalog presence never authorizes selection).
5. **Health** not retired, not auth-failed, not in an open circuit; unknown health is tolerated only for unobserved providers.
6. **Quota** exhaustion verified by current evidence rejects the connection; unknown allowance is not treated as available.

Otherwise the model is shown with the exact failing rule and excluded. Nothing is invented: missing evidence means ineligible, never assumed.

Key rules of thumb:

- **Published zero price is not a billing guarantee.** Zero pricing means observed price metadata, nothing more — upstream terms, rate limits, and account quotas are entirely separate.
- **Quota unknown ≠ quota zero ≠ quota available.** AutoRouter never displays or claims balances it cannot observe, and never borrows one account's observed quota for another.
- **Refusal beats a bad pick.** If nothing qualifies, selection fails closed and no request is made.

See [docs/model-selection.md](docs/model-selection.md) for the full eligibility contract.

## Dashboard overview

| Tab | What you will find |
|-----|--------------------|
| **Overview** | Plugin enabled/routing state, runtime activation, selection policy, usage counts, recent selection activity (empty until the first selection), failures, catalog freshness, routing lifecycle |
| **Providers** | Six discovery integrations with presence-only credential labels, per-provider model counts, health status and quota state — all honestly `unknown` until observed |
| **Models** | Searchable, paginated full catalog with per-model cost tier, context, tool support, health, eligibility and the exact ineligibility reason; provider / eligibility / free-only filters; context sorting; live preview with score breakdown |
| **Analytics** | Recorded requests and outcomes, absolute timestamps, small-sample "insufficient" signals, latency percentiles, timeline — no fabricated billing or savings |
| **Settings** | Persisted configuration with validation; edits take effect on the next plugin load |

Full tour: [docs/dashboard.md](docs/dashboard.md).

## Limitations

- **Experimental.** Selection quality, provider adapters and the dashboard are validated against Hermes v0.23.x and may change without notice.
- **Not a billing boundary.** AutoRouter cannot observe provider accounts end-to-end and no guarantee against charges exists — especially not for requests made outside AutoRouter.
- **Quota observations are scoped and partial** and only exist where a host or adapter supplies them; they never authorize spending and are never treated as available balance by themselves.
- **Chat routing needs the opt-in adapter.** With routing disabled, the adapter is absent, or the adapter fails to load, stock Hermes has no way to resolve `autorouter/auto-free` — by default it may forward the literal identifier to the configured endpoint. The plugin detects such pins precisely (config, env, dashboard settings) and warns loudly (logs plus a persistent dashboard banner directing you to `/model`); it cannot block the outbound request, because the plugin does not run there. Nothing is silently substituted for you — fix the pin or re-enable routing.
- **Direct Hermes requests are uncontrolled.** AutoRouter only gates models selected through its own selection/preview interfaces and the opt-in chat router.

Full detail: [docs/safety-and-limitations.md](docs/safety-and-limitations.md).

## Troubleshooting

| Symptom | First things to check |
|---------|----------------------|
| AutoRouter tab missing | `hermes plugins enable autorouter` ran; dashboard restarted; profile has `plugins.enabled: [autorouter]` |
| Empty catalog | Provider reachable and authorized; look at catalog refresh status; check discovery logs |
| No eligible models | Raise/lower `min_context`, relax `requires_tools`, widen provider allowlist — or read the exact ineligibility reason per model |
| Refusal on `/model` | Nothing eligible under current evidence — correct and safe |
| `autorouter/auto-free` unresolved | Enable `enable_chat_router` and restart; never paste it once routing is disabled |
| Settings "took effect partially" | Keys persist one at a time by design; the response reports exactly what was saved |
| Rate/auth failures | Check Providers tab credential presence labels; re-check in Hermes, not here |

Full guide: [docs/troubleshooting.md](docs/troubleshooting.md).

## Repository layout

```
autorouter/           # this plugin directory
├── __init__.py       # Hermes loader entry (register(ctx)); user-facing plugin API
├── plugin.yaml       # plugin manifest: id, tools, hooks, settings schema
├── autorouter_core/  # implementation package (feature subpackages)
│   ├── routing/      # router, scoring, selection policy, failover
│   ├── discovery/    # catalogs, discovery orchestration, metadata normalize
│   ├── providers/    # provider-specific adapters and presence
│   ├── eligibility/  # verified-free gate
│   ├── evidence/     # quota, credential scope, evidence helpers
│   ├── health/       # health observations, scope + circuit tracking
│   ├── telemetry/    # events, analytics, traces
│   ├── storage/      # SQLite schema, health/scoring state access
│   ├── integration/  # tools/hooks/chat-router loader + guardrails
│   └── configuration/ # policy definitions and capabilities
├── dashboard/        # user-facing management console (FastAPI + dist bundle)
├── data/             # pinned candidate registry (offline; never routes)
├── docs/             # user + developer docs
├── tests/            # root unit tests, integration/, browser/, fixtures/
└── tools/            # build/verification helpers
```

### Runtime subpackage responsibilities

- **routing/** — model selection, scoring, task profiles, selection policy, failover
- **discovery/** — provider catalog ingestion, metadata normalization, Nous + NVIDIA/OpenRouter defaults
- **providers/** — connection inventory, presence labels, capability probes
- **eligibility/** — free-only hard gates, tool/context/cost requirements, exclusion reasons
- **evidence/** — quota snapshots, credential scope handling, free-service evaluation
- **health/** — provider/model health, auth/circuit flags
- **telemetry/** — request analytics, scoring observations, traces
- **storage/** — SQLite schema, migrations, state access, backups
- **integration/** — tool registration, hooks, chat-router adapter, guardrails
- **configuration/** — policy definitions, capability helpers, selection policy

### How the Hermes loader uses the tree

At plugin load, Hermes imports the plugin via **`__init__.py`** at the plugin root. The entrypoint lazily loads subpackages from **`autorouter_core/`** as needed. The Dashboard backend is a standalone FastAPI router under **`dashboard/`** which loads `autorouter_core/` at runtime by file path with a safe package loader.

See **[docs/installation.md](docs/installation.md)** for exact build/install steps and **[docs/upgrading.md](docs/upgrading.md)** for the full acceptance checklist.

## Development and verification

```sh
python3 -m pytest -q               # unit tests
python3 -m pytest tests/browser    # browser harness
python3 -m pytest tests/integration  # Hermes host integration (needs archive + artifacts; see docs/installation.md)
```

Building a package: [docs/upgrading.md](docs/upgrading.md) and `tools/build_package.py --help`. Contribution rules: [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT — see [LICENSE](LICENSE) and [NOTICE](NOTICE).

## Links

- [Installation](docs/installation.md) · [Quick start](docs/quickstart.md) · [Configuration](docs/configuration.md) · [Providers](docs/providers.md) · [Model selection](docs/model-selection.md) · [Dashboard](docs/dashboard.md) · [Safety and limitations](docs/safety-and-limitations.md) · [Troubleshooting](docs/troubleshooting.md) · [Upgrading](docs/upgrading.md) · [Changelog](CHANGELOG.md)
- Report issues: https://github.com/diegorhoger/autorouter/issues
